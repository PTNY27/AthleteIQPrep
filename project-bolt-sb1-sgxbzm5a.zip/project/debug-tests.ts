import { generateAthleteProfile } from './src/lib/intelligenceEngine';
import { datasetA } from './src/lib/validationEngine';
import { computeEffectSize, computeMDC } from './src/lib/statisticalEngine';

// Debug S6-031
const athlete = { id: 'a1', name: 'Test Athlete', sport: 'football' as const, position: 'Central Midfielder' as const, age: 24, team: 'T', avatarColor: '#000', initials: 'TA' };
const sessions = datasetA.map(s => ({ ...s, relativeDistance: 100, highIntensityEfforts: 30, playerLoad: 100, maxHeartRate: 190, hrZonePercent: { z1: 20, z2: 30, z3: 30, z4: 15, z5: 5 } })) as any[];
const matches = [{ id: 'm1', athleteId: 'a1', date: '2026-08-10', opponent: 'Test', duration: 90, minutesPlayed: 90, totalDistance: 11, relativeDistance: 122, highSpeedRunning: 1200, sprintDistance: 500, accelerations: 50, decelerations: 45, highIntensityEfforts: 65, avgHeartRate: 168, maxHeartRate: 192, sessionRPE: 9 }];
const tests = [{ id: 't1', category: 'Speed' as const, name: '30m Sprint', unit: 's', baseline: 4.35, previous: 4.28, latest: 4.25, benchmark: 4.10, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 4.35 }, { date: '2026-03-20', value: 4.32 }, { date: '2026-06-10', value: 4.28 }, { date: '2026-08-20', value: 4.25 }] }];
const profile = generateAthleteProfile({ athlete, sessions, matches, tests, interventions: [] });
console.log('=== S6-031 DEBUG ===');
console.log('strengths:', profile.strengths.length);
console.log('developmentAreas:', profile.developmentAreas.length);
console.log('criticalWeaknesses:', profile.criticalWeaknesses.length);
console.log('gaps:', profile.gaps.length);
console.log('priorities:', profile.priorities.length);
console.log('recommendations:', profile.recommendations.length);
console.log('timeline:', profile.timeline.length);
console.log('dataSufficiency:', JSON.stringify(profile.dataSufficiency));
console.log('overallLevel:', profile.overallLevel);
console.log('overallConfidence:', profile.overallConfidence);
console.log('developmentIndex:', JSON.stringify(profile.developmentIndex?.result));
console.log('priorities detail:', JSON.stringify(profile.priorities.map(p => ({ metric: p.metric, priority: p.priority })), null, 2));

// Debug T041
console.log('\n=== T041 DEBUG ===');
const es = computeEffectSize([10,12,11,10,12], [14,15,13,14,15], true);
console.log('EffectSize:', JSON.stringify(es));

// Debug T043
console.log('\n=== T043 DEBUG ===');
const mdc = computeMDC([4.3,4.4,4.2,4.3,4.4], 4.4, 4.2);
console.log('MDC:', JSON.stringify(mdc));

// Debug S6-017
console.log('\n=== S6-017 DEBUG ===');
console.log('recommendedAction:', profile.recommendations[0]?.recommendedAction);
console.log('targetValue:', profile.recommendations[0]?.targetValue);
