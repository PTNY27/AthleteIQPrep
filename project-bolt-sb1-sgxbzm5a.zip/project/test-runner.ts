import { runAllTests, computeValidationSummary } from './src/lib/validationEngine';

const results = runAllTests();
const summary = computeValidationSummary(results);
console.log('Total:', summary.total, 'Passed:', summary.passed, 'Failed:', summary.failed, 'Warnings:', summary.warnings, 'Insufficient:', summary.insufficient);
console.log('Pass rate:', summary.passRate + '%');
console.log('Release status:', summary.releaseStatus);
const failures = results.filter(r => r.result === 'fail');
if (failures.length > 0) {
  console.log('\nFAILURES:');
  failures.forEach(f => console.log(f.id, f.name, '-', f.error));
} else {
  console.log('\nAll tests passed!');
}
