import { generateAthleteProfile } from './intelligenceEngine';
import { getAllAthletes, getAthleteById, getAllTrainingSessions, getAllMatchRecords, getAllCapacityTests, computeReadiness, computeDataQuality } from './extendedData';
import { computeLoads, getLoadStatus } from './demoData';
import type {
  Athlete, ScoutingProject, TargetProfile, ProfileCriterion, ScoutObservation,
  ScoutingReport, ShortlistEntry, WatchlistEntry, RecruitmentPipelineEntry,
  ScoutingDecision, SavedScoutingView, ProfileMatchResult, AthleteScoutingSummary,
  ScoutingProjectStatus, ScoutObservationCategory, ScoutRecommendation,
  ShortlistStatus, WatchlistStatus, RecruitmentStage, ScoutingDecisionType,
  ScoutingDecisionAction, ScoutingReportStatus,
  EvidenceRecord, EvidenceSource, EvidenceConfidence, DataQualityFlag,
  ScoutTask, ScoutTaskStatus, ScoutTaskPriority, ScoutingAuditEntry,
} from './types';

const SCOUT_ID = 'scout-1';

let projectCounter = 0;
let profileCounter = 0;
let observationCounter = 0;
let reportCounter = 0;
let shortlistCounter = 0;
let watchlistCounter = 0;
let pipelineCounter = 0;
let decisionCounter = 0;
let viewCounter = 0;
let evidenceCounter = 0;
let taskCounter = 0;
let auditCounter = 0;

function genId(prefix: string, counter: number): string {
  return `${prefix}-${Date.now()}-${counter}`;
}

const projects: Map<string, ScoutingProject> = new Map();
const profiles: Map<string, TargetProfile> = new Map();
const observations: Map<string, ScoutObservation> = new Map();
const reports: Map<string, ScoutingReport> = new Map();
const shortlists: Map<string, ShortlistEntry> = new Map();
const watchlist: Map<string, WatchlistEntry> = new Map();
const pipeline: Map<string, RecruitmentPipelineEntry> = new Map();
const scoutingDecisions: Map<string, ScoutingDecision> = new Map();
const savedViews: Map<string, SavedScoutingView> = new Map();
const evidence: Map<string, EvidenceRecord> = new Map();
const tasks: Map<string, ScoutTask> = new Map();
const auditLog: ScoutingAuditEntry[] = [];

// ===== SCOUTING PROJECTS =====

export function getScoutingProjects(): ScoutingProject[] {
  return Array.from(projects.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function getScoutingProject(projectId: string): ScoutingProject | undefined {
  return projects.get(projectId);
}

export function createScoutingProject(params: {
  name: string;
  sport: string;
  position?: string;
  ageMin?: number;
  ageMax?: number;
  competitionLevel?: string;
  location?: string;
  description?: string;
}): ScoutingProject {
  const project: ScoutingProject = {
    id: genId('sp', projectCounter++),
    name: params.name,
    sport: params.sport,
    position: params.position,
    ageMin: params.ageMin,
    ageMax: params.ageMax,
    competitionLevel: params.competitionLevel,
    location: params.location,
    description: params.description,
    status: 'DRAFT',
    createdBy: SCOUT_ID,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  projects.set(project.id, project);
  return project;
}

export function updateScoutingProject(projectId: string, updates: Partial<ScoutingProject>): ScoutingProject | undefined {
  const project = projects.get(projectId);
  if (!project) return undefined;
  const updated = { ...project, ...updates, updatedAt: new Date().toISOString() };
  projects.set(projectId, updated);
  return updated;
}

export function activateProject(projectId: string): ScoutingProject | undefined {
  return updateScoutingProject(projectId, { status: 'ACTIVE' });
}

export function pauseProject(projectId: string): ScoutingProject | undefined {
  return updateScoutingProject(projectId, { status: 'PAUSED' });
}

export function completeProject(projectId: string): ScoutingProject | undefined {
  return updateScoutingProject(projectId, { status: 'COMPLETED' });
}

// ===== TARGET PROFILES =====

export function getTargetProfiles(projectId: string): TargetProfile[] {
  return Array.from(profiles.values()).filter((p) => p.projectId === projectId);
}

export function getActiveTargetProfile(projectId: string): TargetProfile | undefined {
  return Array.from(profiles.values()).find((p) => p.projectId === projectId && p.isActive);
}

export function createTargetProfile(params: {
  projectId: string;
  name: string;
  criteria: ProfileCriterion[];
  weights?: Record<string, number>;
}): TargetProfile {
  const existing = getTargetProfiles(params.projectId);
  const versionNum = existing.length + 1;
  for (const p of existing) {
    profiles.set(p.id, { ...p, isActive: false });
  }
  const profile: TargetProfile = {
    id: genId('tp', profileCounter++),
    projectId: params.projectId,
    version: `v${versionNum}.0`,
    name: params.name,
    criteria: params.criteria,
    weights: params.weights ?? {},
    isActive: true,
    createdBy: SCOUT_ID,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  profiles.set(profile.id, profile);
  return profile;
}

export function updateTargetProfile(profileId: string, updates: Partial<TargetProfile>): TargetProfile | undefined {
  const profile = profiles.get(profileId);
  if (!profile) return undefined;
  const updated = { ...profile, ...updates, updatedAt: new Date().toISOString() };
  profiles.set(profileId, updated);
  return updated;
}

// ===== CANDIDATE DISCOVERY =====

export interface CandidateFilter {
  sport?: string;
  position?: string;
  ageMin?: number;
  ageMax?: number;
  projectId?: string;
  shortlistedOnly?: boolean;
  watchlistOnly?: boolean;
  minAssessmentCoverage?: number;
}

export function discoverCandidates(filter?: CandidateFilter): AthleteScoutingSummary[] {
  let athletes = getAllAthletes();

  if (filter?.sport) athletes = athletes.filter((a) => a.sport === filter.sport);
  if (filter?.position) athletes = athletes.filter((a) => a.position === filter.position);
  if (filter?.ageMin) athletes = athletes.filter((a) => a.age >= filter.ageMin!);
  if (filter?.ageMax) athletes = athletes.filter((a) => a.age <= filter.ageMax!);

  if (filter?.shortlistedOnly) {
    const shortlistedIds = new Set(Array.from(shortlists.values()).filter((s) => s.status === 'SHORTLISTED').map((s) => s.athleteId));
    athletes = athletes.filter((a) => shortlistedIds.has(a.id));
  }
  if (filter?.watchlistOnly) {
    const watchingIds = new Set(Array.from(watchlist.values()).filter((w) => w.status === 'WATCHING').map((w) => w.athleteId));
    athletes = athletes.filter((a) => watchingIds.has(a.id));
  }

  return athletes.map((a) => getAthleteScoutingSummary(a.id, filter?.projectId));
}

export function getAthleteScoutingSummary(athleteId: string, projectId?: string): AthleteScoutingSummary {
  const athlete = getAthleteById(athleteId) ?? getAllAthletes()[0];
  const sessions = getAllTrainingSessions(athleteId);
  const matches = getAllMatchRecords(athleteId);
  const tests = getAllCapacityTests(athleteId);
  const profile = generateAthleteProfile({ athlete, sessions, matches, tests, interventions: [] });

  const athleteObservations = Array.from(observations.values()).filter((o) => o.athleteId === athleteId);
  const athleteShortlist = Array.from(shortlists.values()).find((s) => s.athleteId === athleteId && s.status === 'SHORTLISTED' && (!projectId || s.projectId === projectId));
  const athleteWatch = Array.from(watchlist.values()).find((w) => w.athleteId === athleteId && w.status === 'WATCHING' && (!projectId || w.projectId === projectId));
  const athletePipeline = Array.from(pipeline.values()).filter((p) => p.athleteId === athleteId && (!projectId || p.projectId === projectId)).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];

  const assessmentCount = tests.length;
  const coverage: 'high' | 'medium' | 'low' | 'none' = assessmentCount >= 5 ? 'high' : assessmentCount >= 3 ? 'medium' : assessmentCount >= 1 ? 'low' : 'none';

  const improvingCount = profile.trends.filter((t) => t.trend === 'IMPROVING').length;
  const trend = improvingCount > profile.trends.length / 2 ? 'Improving' : improvingCount > 0 ? 'Mixed' : profile.trends.length > 0 ? 'Stable' : 'No data';

  const avgRating = athleteObservations.length > 0
    ? athleteObservations.reduce((sum, o) => sum + (o.rating ?? 0), 0) / athleteObservations.length
    : undefined;

  let matchResults: ProfileMatchResult[] | undefined;
  let matchScore: number | undefined;
  if (projectId) {
    const targetProfile = getActiveTargetProfile(projectId);
    if (targetProfile) {
      matchResults = matchAthleteToProfile(athleteId, targetProfile);
      matchScore = matchResults.length > 0
        ? Math.round(matchResults.reduce((sum, m) => sum + (m.weightedScore ?? 0), 0))
        : undefined;
    }
  }

  return {
    athlete,
    currentLevel: profile.overallLevel,
    developmentTrend: trend,
    assessmentCoverage: coverage,
    observationCount: athleteObservations.length,
    scoutRating: avgRating ? Math.round(avgRating * 10) / 10 : undefined,
    profileMatchScore: matchScore,
    matchResults,
    shortlistStatus: athleteShortlist?.status,
    watchlistStatus: athleteWatch?.status,
    pipelineStage: athletePipeline?.stage,
  };
}

// ===== PROFILE MATCHING =====

export function matchAthleteToProfile(athleteId: string, targetProfile: TargetProfile): ProfileMatchResult[] {
  const athlete = getAthleteById(athleteId);
  if (!athlete) return [];
  const tests = getAllCapacityTests(athleteId);
  const sessions = getAllTrainingSessions(athleteId);
  const matches = getAllMatchRecords(athleteId);
  const profile = generateAthleteProfile({ athlete, sessions, matches, tests, interventions: [] });

  const results: ProfileMatchResult[] = [];

  for (const criterion of targetProfile.criteria) {
    const test = tests.find((t) => t.name.toLowerCase().includes(criterion.metric.toLowerCase()) || criterion.metric.toLowerCase().includes(t.name.toLowerCase()));
    const interpretation = profile.strengths.find((s) => s.metric.toLowerCase().includes(criterion.metric.toLowerCase()))
      ?? profile.developmentAreas.find((d) => d.metric.toLowerCase().includes(criterion.metric.toLowerCase()))
      ?? profile.criticalWeaknesses.find((c) => c.metric.toLowerCase().includes(criterion.metric.toLowerCase()));

    const athleteValue = test?.latest;
    const targetValue = criterion.value ?? criterion.minValue;
    const unit = criterion.unit ?? test?.unit ?? '';
    const weight = targetProfile.weights[criterion.metric] ?? 0;

    let match: ProfileMatchResult['match'] = 'no_data';
    let evidence = '';
    let weightedScore = 0;

    if (athleteValue !== undefined && targetValue !== undefined) {
      if (criterion.requirement === 'minimum') {
        match = athleteValue >= targetValue ? 'match' : 'gap';
        evidence = `${athleteValue} ${unit} vs minimum ${targetValue} ${unit}`;
      } else if (criterion.requirement === 'target') {
        if (test?.higherIsBetter) {
          match = athleteValue >= targetValue ? 'exceeds' : 'gap';
        } else {
          match = athleteValue <= targetValue ? 'exceeds' : 'gap';
        }
        evidence = `${athleteValue} ${unit} vs target ${targetValue} ${unit}`;
      } else if (criterion.requirement === 'range' && criterion.minValue !== undefined && criterion.maxValue !== undefined) {
        match = athleteValue >= criterion.minValue && athleteValue <= criterion.maxValue ? 'match' : 'gap';
        evidence = `${athleteValue} ${unit} vs range ${criterion.minValue}-${criterion.maxValue} ${unit}`;
      }

      if (match === 'match' || match === 'exceeds') {
        weightedScore = weight;
      } else if (match === 'gap') {
        weightedScore = 0;
      }
    } else if (interpretation) {
      evidence = `${interpretation.level} (${Math.round(interpretation.percentOfBenchmark ?? 0)}% of benchmark)`;
      match = interpretation.level === 'ELITE' || interpretation.level === 'ADVANCED' ? 'exceeds' : interpretation.level === 'DEVELOPING' ? 'match' : 'gap';
      weightedScore = match === 'exceeds' ? weight : match === 'match' ? weight * 0.6 : 0;
    } else {
      evidence = 'No data available — requires further assessment';
    }

    results.push({
      metric: criterion.metric,
      athleteValue,
      targetValue,
      unit,
      match,
      evidence,
      weight,
      weightedScore,
    });
  }

  return results;
}

// ===== SCOUT OBSERVATIONS =====

export function getObservationsForAthlete(athleteId: string): ScoutObservation[] {
  return Array.from(observations.values())
    .filter((o) => o.athleteId === athleteId)
    .sort((a, b) => b.observationDate.localeCompare(a.observationDate));
}

export function getObservationsForProject(projectId: string): ScoutObservation[] {
  return Array.from(observations.values()).filter((o) => o.projectId === projectId);
}

export function createObservation(params: {
  athleteId: string;
  projectId?: string;
  category: ScoutObservationCategory;
  observation: string;
  rating?: number;
  context?: string;
  oppositionLevel?: string;
  conditions?: string;
  observationDate: string;
}): ScoutObservation {
  const obs: ScoutObservation = {
    id: genId('obs', observationCounter++),
    athleteId: params.athleteId,
    projectId: params.projectId,
    scoutId: SCOUT_ID,
    category: params.category,
    observation: params.observation,
    rating: params.rating,
    context: params.context,
    oppositionLevel: params.oppositionLevel,
    conditions: params.conditions,
    observationDate: params.observationDate,
    createdAt: new Date().toISOString(),
  };
  observations.set(obs.id, obs);
  return obs;
}

export function deleteObservation(observationId: string): boolean {
  return observations.delete(observationId);
}

// ===== SCOUTING REPORTS =====

export function getReportsForAthlete(athleteId: string): ScoutingReport[] {
  return Array.from(reports.values())
    .filter((r) => r.athleteId === athleteId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function getReportsForProject(projectId: string): ScoutingReport[] {
  return Array.from(reports.values()).filter((r) => r.projectId === projectId);
}

export function createReport(params: {
  athleteId: string;
  projectId?: string;
  context?: string;
  currentPerformance?: string;
  keyStrengths?: string;
  developmentAreas?: string;
  tacticalObservations?: string;
  physicalObservations?: string;
  developmentTrajectory?: string;
  profileMatch?: string;
  areasRequiringEvidence?: string;
  recommendation: ScoutRecommendation;
  nextAction?: string;
  aiGeneratedDraft?: string;
  aiGenerated?: boolean;
}): ScoutingReport {
  const report: ScoutingReport = {
    id: genId('rpt', reportCounter++),
    athleteId: params.athleteId,
    projectId: params.projectId,
    scoutId: SCOUT_ID,
    context: params.context,
    currentPerformance: params.currentPerformance,
    keyStrengths: params.keyStrengths,
    developmentAreas: params.developmentAreas,
    tacticalObservations: params.tacticalObservations,
    physicalObservations: params.physicalObservations,
    developmentTrajectory: params.developmentTrajectory,
    profileMatch: params.profileMatch,
    areasRequiringEvidence: params.areasRequiringEvidence,
    recommendation: params.recommendation,
    nextAction: params.nextAction,
    aiGeneratedDraft: params.aiGeneratedDraft,
    aiGenerated: params.aiGenerated ?? false,
    status: 'DRAFT',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  reports.set(report.id, report);
  return report;
}

export function updateReport(reportId: string, updates: Partial<ScoutingReport>): ScoutingReport | undefined {
  const report = reports.get(reportId);
  if (!report) return undefined;
  const updated = { ...report, ...updates, updatedAt: new Date().toISOString() };
  reports.set(reportId, updated);
  return updated;
}

export function approveReport(reportId: string, approver: string): ScoutingReport | undefined {
  return updateReport(reportId, { status: 'APPROVED', approvedBy: approver, approvedAt: new Date().toISOString() });
}

// ===== AI REPORT DRAFT =====

export function draftScoutingReport(athleteId: string, projectId?: string): { draft: string; aiGenerated: boolean } {
  const athlete = getAthleteById(athleteId);
  if (!athlete) return { draft: 'Unable to generate — athlete not found.', aiGenerated: false };

  const sessions = getAllTrainingSessions(athleteId);
  const matches = getAllMatchRecords(athleteId);
  const tests = getAllCapacityTests(athleteId);
  const profile = generateAthleteProfile({ athlete, sessions, matches, tests, interventions: [] });
  const athleteObservations = getObservationsForAthlete(athleteId);
  const matchResults = projectId ? matchAthleteToProfile(athleteId, getActiveTargetProfile(projectId)!) : [];

  const sections: string[] = [];
  sections.push(`SCOUTING REPORT — ${athlete.name}`);
  sections.push(`Sport: ${athlete.sport} | Position: ${athlete.position} | Age: ${athlete.age}`);
  sections.push(`Date: ${new Date().toLocaleDateString()}`);
  sections.push('');

  sections.push('CURRENT PERFORMANCE:');
  sections.push(`Overall Level: ${profile.overallLevel}`);
  sections.push(`Confidence: ${profile.overallConfidence}`);
  sections.push('');

  sections.push('KEY STRENGTHS:');
  for (const s of profile.strengths.slice(0, 5)) {
    sections.push(`- ${s.metric}: ${s.level} (${Math.round(s.percentOfBenchmark ?? 0)}% of benchmark)`);
  }
  sections.push('');

  sections.push('DEVELOPMENT AREAS:');
  for (const d of profile.developmentAreas.slice(0, 5)) {
    sections.push(`- ${d.metric}: ${d.level} (${Math.round(d.percentOfBenchmark ?? 0)}% of benchmark)`);
  }
  sections.push('');

  sections.push('DEVELOPMENT TRAJECTORY:');
  for (const t of profile.trends.slice(0, 5)) {
    sections.push(`- ${t.metric}: ${t.trend} — ${t.evidence}`);
  }
  sections.push('');

  if (matchResults.length > 0) {
    sections.push('PROFILE MATCH:');
    for (const m of matchResults) {
      sections.push(`- ${m.metric}: ${m.match.toUpperCase()} — ${m.evidence}`);
    }
    sections.push('');
  }

  sections.push('SCOUT OBSERVATIONS:');
  for (const o of athleteObservations.slice(0, 10)) {
    sections.push(`- [${o.category}] ${o.observation}${o.rating ? ` (Rating: ${o.rating}/10)` : ''}`);
  }
  sections.push('');

  sections.push('AREAS REQUIRING FURTHER EVIDENCE:');
  const noDataMetrics = matchResults.filter((m) => m.match === 'no_data');
  if (noDataMetrics.length > 0) {
    for (const m of noDataMetrics) {
      sections.push(`- ${m.metric}: No validated data available`);
    }
  } else {
    sections.push('- None identified — assessment coverage is complete');
  }
  sections.push('');

  sections.push('SUGGESTED RECOMMENDATION:');
  if (matchResults.length > 0) {
    const matchCount = matchResults.filter((m) => m.match === 'match' || m.match === 'exceeds').length;
    const totalCount = matchResults.length;
    if (matchCount / totalCount >= 0.7) {
      sections.push('RECOMMEND — Strong profile match with validated evidence');
    } else if (matchCount / totalCount >= 0.5) {
      sections.push('SHORTLIST — Moderate profile match, further observation recommended');
    } else if (matchCount / totalCount >= 0.3) {
      sections.push('MONITOR — Some matching criteria but significant gaps remain');
    } else {
      sections.push('FURTHER_ASSESSMENT — Insufficient match, additional assessment needed');
    }
  } else {
    sections.push('FURTHER_ASSESSMENT — Requires additional assessment before recommendation');
  }

  return { draft: sections.join('\n'), aiGenerated: true };
}

// ===== SHORTLISTS =====

export function getShortlistsForProject(projectId: string): ShortlistEntry[] {
  return Array.from(shortlists.values()).filter((s) => s.projectId === projectId && s.status === 'SHORTLISTED');
}

export function getShortlistForAthlete(athleteId: string, projectId: string): ShortlistEntry | undefined {
  return Array.from(shortlists.values()).find((s) => s.athleteId === athleteId && s.projectId === projectId && s.status === 'SHORTLISTED');
}

export function addToShortlist(params: {
  athleteId: string;
  projectId: string;
  evidenceSummary?: string;
  nextAction?: string;
  reviewDate?: string;
}): ShortlistEntry {
  const existing = getShortlistForAthlete(params.athleteId, params.projectId);
  if (existing) return existing;
  const entry: ShortlistEntry = {
    id: genId('sl', shortlistCounter++),
    athleteId: params.athleteId,
    projectId: params.projectId,
    scoutId: SCOUT_ID,
    evidenceSummary: params.evidenceSummary,
    nextAction: params.nextAction,
    reviewDate: params.reviewDate,
    status: 'SHORTLISTED',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  shortlists.set(entry.id, entry);
  recordScoutingDecision({
    athleteId: params.athleteId,
    projectId: params.projectId,
    decisionType: 'shortlist',
    decision: 'accepted',
    finalDecision: 'Shortlisted',
  });
  advancePipeline(params.athleteId, params.projectId, 'SHORTLISTED', 'Scout shortlisted athlete');
  return entry;
}

export function removeFromShortlist(athleteId: string, projectId: string): boolean {
  const entry = getShortlistForAthlete(athleteId, projectId);
  if (!entry) return false;
  shortlists.set(entry.id, { ...entry, status: 'REMOVED', updatedAt: new Date().toISOString() });
  return true;
}

// ===== WATCHLIST =====

export function getWatchlist(): WatchlistEntry[] {
  return Array.from(watchlist.values()).filter((w) => w.status === 'WATCHING');
}

export function getWatchlistForAthlete(athleteId: string): WatchlistEntry | undefined {
  return Array.from(watchlist.values()).find((w) => w.athleteId === athleteId && w.status === 'WATCHING');
}

export function addToWatchlist(params: { athleteId: string; projectId?: string; reason?: string }): WatchlistEntry {
  const existing = getWatchlistForAthlete(params.athleteId);
  if (existing) return existing;
  const entry: WatchlistEntry = {
    id: genId('wl', watchlistCounter++),
    athleteId: params.athleteId,
    projectId: params.projectId,
    scoutId: SCOUT_ID,
    reason: params.reason,
    status: 'WATCHING',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  watchlist.set(entry.id, entry);
  recordScoutingDecision({
    athleteId: params.athleteId,
    projectId: params.projectId,
    decisionType: 'watchlist',
    decision: 'accepted',
    finalDecision: 'Added to watchlist',
  });
  advancePipeline(params.athleteId, params.projectId ?? '', 'OBSERVING', 'Scout added to watchlist');
  return entry;
}

export function removeFromWatchlist(athleteId: string): boolean {
  const entry = getWatchlistForAthlete(athleteId);
  if (!entry) return false;
  watchlist.set(entry.id, { ...entry, status: 'REMOVED', updatedAt: new Date().toISOString() });
  return true;
}

// ===== RECRUITMENT PIPELINE =====

const STAGE_ORDER: RecruitmentStage[] = [
  'IDENTIFIED', 'OBSERVING', 'SHORTLISTED', 'FURTHER_ASSESSMENT',
  'SCOUT_REVIEW', 'COACH_REVIEW', 'TRIAL', 'RECRUITMENT_DECISION', 'ONBOARDING',
];

export function getPipelineForAthlete(athleteId: string, projectId: string): RecruitmentPipelineEntry | undefined {
  return Array.from(pipeline.values())
    .filter((p) => p.athleteId === athleteId && p.projectId === projectId)
    .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];
}

export function getPipelineForProject(projectId: string): RecruitmentPipelineEntry[] {
  return Array.from(pipeline.values()).filter((p) => p.projectId === projectId);
}

export function advancePipeline(athleteId: string, projectId: string, newStage: RecruitmentStage, rationale?: string): RecruitmentPipelineEntry | undefined {
  const current = getPipelineForAthlete(athleteId, projectId);
  const entry: RecruitmentPipelineEntry = {
    id: genId('pl', pipelineCounter++),
    athleteId,
    projectId,
    stage: newStage,
    previousStage: current?.stage,
    decisionMaker: SCOUT_ID,
    rationale,
    aiInvolved: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  pipeline.set(entry.id, entry);
  return entry;
}

export function getStageIndex(stage: RecruitmentStage): number {
  return STAGE_ORDER.indexOf(stage);
}

export function getNextStage(stage: RecruitmentStage): RecruitmentStage | undefined {
  const idx = getStageIndex(stage);
  return idx >= 0 && idx < STAGE_ORDER.length - 1 ? STAGE_ORDER[idx + 1] : undefined;
}

export { STAGE_ORDER };

// ===== SCOUTING DECISIONS =====

export function recordScoutingDecision(params: {
  athleteId: string;
  projectId?: string;
  decisionType: ScoutingDecisionType;
  decision: ScoutingDecisionAction;
  originalSuggestion?: string;
  finalDecision?: string;
  rationale?: string;
  aiInvolved?: boolean;
}): ScoutingDecision {
  const dec: ScoutingDecision = {
    id: genId('sd', decisionCounter++),
    athleteId: params.athleteId,
    projectId: params.projectId,
    decisionType: params.decisionType,
    decision: params.decision,
    originalSuggestion: params.originalSuggestion,
    finalDecision: params.finalDecision,
    rationale: params.rationale,
    decisionMaker: SCOUT_ID,
    aiInvolved: params.aiInvolved ?? false,
    createdAt: new Date().toISOString(),
  };
  scoutingDecisions.set(dec.id, dec);
  return dec;
}

export function getScoutingDecisionsForAthlete(athleteId: string): ScoutingDecision[] {
  return Array.from(scoutingDecisions.values())
    .filter((d) => d.athleteId === athleteId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

// ===== SAVED VIEWS =====

export function getSavedViews(): SavedScoutingView[] {
  return Array.from(savedViews.values());
}

export function saveView(name: string, filters: Record<string, unknown>): SavedScoutingView {
  const view: SavedScoutingView = {
    id: genId('sv', viewCounter++),
    name,
    scoutId: SCOUT_ID,
    filters,
    createdAt: new Date().toISOString(),
  };
  savedViews.set(view.id, view);
  return view;
}

export function deleteSavedView(viewId: string): boolean {
  return savedViews.delete(viewId);
}

// ===== AI SCOUTING ASSISTANT =====

export function generateScoutingSummary(athleteId: string, projectId?: string): { summary: string; aiGenerated: boolean } {
  const athlete = getAthleteById(athleteId);
  if (!athlete) return { summary: 'Unable to generate — athlete not found.', aiGenerated: false };

  const sessions = getAllTrainingSessions(athleteId);
  const matches = getAllMatchRecords(athleteId);
  const tests = getAllCapacityTests(athleteId);
  const profile = generateAthleteProfile({ athlete, sessions, matches, tests, interventions: [] });
  const athleteObservations = getObservationsForAthlete(athleteId);
  const matchResults = projectId ? matchAthleteToProfile(athleteId, getActiveTargetProfile(projectId)!) : [];

  const lines: string[] = [];
  lines.push(`AI SCOUTING ANALYSIS — ${athlete.name}`);
  lines.push('');
  lines.push('CURRENT ABILITY (Validated):');
  lines.push(`Overall Level: ${profile.overallLevel}`);
  lines.push(`Confidence: ${profile.overallConfidence}`);
  lines.push('');
  lines.push('DEVELOPMENT TRAJECTORY:');
  for (const t of profile.trends.slice(0, 5)) {
    lines.push(`- ${t.metric}: ${t.trend}`);
  }
  lines.push('');
  lines.push('SCOUT OBSERVATIONS SUMMARY:');
  lines.push(`Total observations: ${athleteObservations.length}`);
  const byCategory = { technical: 0, tactical: 0, physical: 0, behavioural: 0 };
  for (const o of athleteObservations) byCategory[o.category]++;
  lines.push(`- Technical: ${byCategory.technical}, Tactical: ${byCategory.tactical}, Physical: ${byCategory.physical}, Behavioural: ${byCategory.behavioural}`);
  lines.push('');
  if (matchResults.length > 0) {
    lines.push('PROFILE MATCH ANALYSIS:');
    const matched = matchResults.filter((m) => m.match === 'match' || m.match === 'exceeds').length;
    const gaps = matchResults.filter((m) => m.match === 'gap').length;
    const noData = matchResults.filter((m) => m.match === 'no_data').length;
    lines.push(`- Matched: ${matched}, Gaps: ${gaps}, Missing data: ${noData}`);
    lines.push('');
    lines.push('AREAS REQUIRING FURTHER EVIDENCE:');
    for (const m of matchResults.filter((m) => m.match === 'no_data')) {
      lines.push(`- ${m.metric}: No validated data available`);
    }
    lines.push('');
  }
  lines.push('SUGGESTED QUESTIONS FOR FURTHER OBSERVATION:');
  if (profile.developmentAreas.length > 0) {
    lines.push(`- How is ${profile.developmentAreas[0].metric} progressing under competitive pressure?`);
  }
  if (athleteObservations.length < 3) {
    lines.push('- Additional observations needed across different competitive contexts');
  }
  if (matchResults.some((m) => m.match === 'no_data')) {
    lines.push('- Assessment required for missing profile criteria');
  }

  return { summary: lines.join('\n'), aiGenerated: true };
}

// ===== EVIDENCE RECORDS =====

export function getEvidenceForAthlete(athleteId: string): EvidenceRecord[] {
  return Array.from(evidence.values())
    .filter((e) => e.athleteId === athleteId)
    .sort((a, b) => b.date.localeCompare(a.date));
}

export function getEvidenceForProject(projectId: string): EvidenceRecord[] {
  return Array.from(evidence.values()).filter((e) => e.projectId === projectId);
}

export function createEvidence(params: {
  athleteId: string;
  projectId?: string;
  source: EvidenceSource;
  date: string;
  author: string;
  context?: string;
  description: string;
  confidence: EvidenceConfidence;
  qualityFlag?: DataQualityFlag;
  linkedObservationId?: string;
}): EvidenceRecord {
  const record: EvidenceRecord = {
    id: genId('ev', evidenceCounter++),
    athleteId: params.athleteId,
    projectId: params.projectId,
    source: params.source,
    date: params.date,
    author: params.author,
    context: params.context,
    description: params.description,
    confidence: params.confidence,
    qualityFlag: params.qualityFlag ?? 'verified',
    linkedObservationId: params.linkedObservationId,
    createdAt: new Date().toISOString(),
  };
  evidence.set(record.id, record);
  recordAudit({
    action: 'evidence_created',
    entityType: 'evidence',
    entityId: record.id,
    athleteId: params.athleteId,
    projectId: params.projectId,
    newState: record.description,
  });
  return record;
}

export function deleteEvidence(evidenceId: string): boolean {
  const record = evidence.get(evidenceId);
  if (!record) return false;
  recordAudit({
    action: 'evidence_deleted',
    entityType: 'evidence',
    entityId: evidenceId,
    athleteId: record.athleteId,
    projectId: record.projectId,
  });
  return evidence.delete(evidenceId);
}

export function getEvidenceConfidenceSummary(athleteId: string): { high: number; moderate: number; low: number; insufficient: number; total: number } {
  const records = getEvidenceForAthlete(athleteId);
  return {
    high: records.filter((e) => e.confidence === 'high').length,
    moderate: records.filter((e) => e.confidence === 'moderate').length,
    low: records.filter((e) => e.confidence === 'low').length,
    insufficient: records.filter((e) => e.confidence === 'insufficient').length,
    total: records.length,
  };
}

export function getDataQualityFlags(athleteId: string): DataQualityFlag[] {
  const records = getEvidenceForAthlete(athleteId);
  const flags = new Set<DataQualityFlag>();
  for (const r of records) flags.add(r.qualityFlag);
  return Array.from(flags);
}

// ===== SCOUT TASKS =====

export function getTasksForProject(projectId: string): ScoutTask[] {
  return Array.from(tasks.values())
    .filter((t) => t.projectId === projectId)
    .sort((a, b) => (b.dueDate ?? '').localeCompare(a.dueDate ?? ''));
}

export function getTasksForAthlete(athleteId: string): ScoutTask[] {
  return Array.from(tasks.values())
    .filter((t) => t.athleteId === athleteId)
    .sort((a, b) => (b.dueDate ?? '').localeCompare(a.dueDate ?? ''));
}

export function getTasksByStatus(status: ScoutTaskStatus): ScoutTask[] {
  return Array.from(tasks.values()).filter((t) => t.status === status);
}

export function createTask(params: {
  title: string;
  description?: string;
  assignee?: string;
  athleteId?: string;
  projectId?: string;
  dueDate?: string;
  priority?: ScoutTaskPriority;
}): ScoutTask {
  const task: ScoutTask = {
    id: genId('task', taskCounter++),
    title: params.title,
    description: params.description,
    assignee: params.assignee ?? SCOUT_ID,
    athleteId: params.athleteId,
    projectId: params.projectId,
    dueDate: params.dueDate,
    status: 'pending',
    priority: params.priority ?? 'medium',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  tasks.set(task.id, task);
  recordAudit({
    action: 'task_created',
    entityType: 'scout_task',
    entityId: task.id,
    athleteId: params.athleteId,
    projectId: params.projectId,
    newState: task.title,
  });
  return task;
}

export function updateTaskStatus(taskId: string, status: ScoutTaskStatus): ScoutTask | undefined {
  const task = tasks.get(taskId);
  if (!task) return undefined;
  const updated = { ...task, status, updatedAt: new Date().toISOString() };
  tasks.set(taskId, updated);
  return updated;
}

export function deleteTask(taskId: string): boolean {
  return tasks.delete(taskId);
}

// ===== AUDIT TRAIL =====

export function recordAudit(params: {
  user?: string;
  action: string;
  entityType: string;
  entityId?: string;
  athleteId?: string;
  projectId?: string;
  previousState?: string;
  newState?: string;
}): void {
  auditLog.push({
    id: genId('audit', auditCounter++),
    user: params.user ?? SCOUT_ID,
    action: params.action,
    entityType: params.entityType,
    entityId: params.entityId,
    athleteId: params.athleteId,
    projectId: params.projectId,
    previousState: params.previousState,
    newState: params.newState,
    timestamp: new Date().toISOString(),
  });
}

export function getAuditTrail(): ScoutingAuditEntry[] {
  return [...auditLog].sort((a, b) => b.timestamp.localeCompare(a.timestamp));
}

export function getAuditForAthlete(athleteId: string): ScoutingAuditEntry[] {
  return auditLog.filter((a) => a.athleteId === athleteId).sort((a, b) => b.timestamp.localeCompare(a.timestamp));
}

export function getAuditForProject(projectId: string): ScoutingAuditEntry[] {
  return auditLog.filter((a) => a.projectId === projectId).sort((a, b) => b.timestamp.localeCompare(a.timestamp));
}

// ===== DISAGREEMENT HANDLING =====

export interface ObservationDisagreement {
  athleteId: string;
  attribute: string;
  ratings: { scoutId: string; rating: number; observation: string; date: string }[];
  spread: number;
  avgRating: number;
}

export function detectDisagreements(athleteId: string): ObservationDisagreement[] {
  const athleteObs = getObservationsForAthlete(athleteId);
  const byMetric = new Map<string, typeof athleteObs>();
  for (const o of athleteObs) {
    const key = `${o.category}:${o.observation.split(' ').slice(0, 3).join(' ')}`;
    const list = byMetric.get(key) ?? [];
    list.push(o);
    byMetric.set(key, list);
  }
  const disagreements: ObservationDisagreement[] = [];
  for (const [key, obs] of byMetric) {
    const rated = obs.filter((o) => o.rating !== undefined);
    if (rated.length < 2) continue;
    const ratings = rated.map((o) => o.rating!);
    const max = Math.max(...ratings);
    const min = Math.min(...ratings);
    const spread = max - min;
    if (spread >= 3) {
      disagreements.push({
        athleteId,
        attribute: key,
        ratings: rated.map((o) => ({ scoutId: o.scoutId, rating: o.rating!, observation: o.observation, date: o.observationDate })),
        spread,
        avgRating: Math.round((ratings.reduce((a, b) => a + b, 0) / ratings.length) * 10) / 10,
      });
    }
  }
  return disagreements;
}

// ===== RECRUITMENT DASHBOARD =====

export interface RecruitmentDashboard {
  activeProjects: number;
  completedProjects: number;
  totalCandidates: number;
  shortlisted: number;
  watching: number;
  pendingTasks: number;
  awaitingDecision: number;
  incompleteProfiles: number;
  recentDecisions: ScoutingDecision[];
  projectSummaries: { project: ScoutingProject; candidates: number; shortlisted: number; reports: number }[];
}

export function getRecruitmentDashboard(): RecruitmentDashboard {
  const allProjects = getScoutingProjects();
  const active = allProjects.filter((p) => p.status === 'ACTIVE');
  const completed = allProjects.filter((p) => p.status === 'COMPLETED');
  const allShortlists = Array.from(shortlists.values()).filter((s) => s.status === 'SHORTLISTED');
  const allWatchlist = Array.from(watchlist.values()).filter((w) => w.status === 'WATCHING');
  const pendingTasks = Array.from(tasks.values()).filter((t) => t.status === 'pending' || t.status === 'in_progress');
  const allDecisions = Array.from(scoutingDecisions.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const allAthletes = getAllAthletes();
  const incomplete = allAthletes.filter((a) => getAllCapacityTests(a.id).length < 2).length;

  const projectSummaries = allProjects.map((p) => {
    const projectCandidates = discoverCandidates({ projectId: p.id });
    const projectShortlists = getShortlistsForProject(p.id);
    const projectReports = getReportsForProject(p.id);
    return { project: p, candidates: projectCandidates.length, shortlisted: projectShortlists.length, reports: projectReports.length };
  });

  return {
    activeProjects: active.length,
    completedProjects: completed.length,
    totalCandidates: allAthletes.length,
    shortlisted: allShortlists.length,
    watching: allWatchlist.length,
    pendingTasks: pendingTasks.length,
    awaitingDecision: allDecisions.filter((d) => d.decision === 'deferred').length,
    incompleteProfiles: incomplete,
    recentDecisions: allDecisions.slice(0, 10),
    projectSummaries,
  };
}

// ===== YOUTH SAFEGUARDS =====

export function isYouthAthlete(athleteId: string): boolean {
  const athlete = getAthleteById(athleteId);
  return athlete ? athlete.age < 18 : false;
}

export function getYouthSafeguardWarnings(athleteId: string): string[] {
  const warnings: string[] = [];
  if (isYouthAthlete(athleteId)) {
    warnings.push('Youth athlete: avoid deterministic future predictions');
    warnings.push('Use age-appropriate benchmarks and development stages');
    warnings.push('Do not display public rankings or market value');
    warnings.push('Maintain enhanced privacy and access controls');
  }
  return warnings;
}

// ===== FAIRNESS & BIAS CHECKS =====

export function getFairnessWarnings(athleteIds: string[]): string[] {
  const warnings: string[] = [];
  const observationCounts = athleteIds.map((id) => getObservationsForAthlete(id).length);
  const max = Math.max(...observationCounts);
  const min = Math.min(...observationCounts);
  if (max - min > 5) {
    warnings.push('Unequal observation volume detected — some athletes have significantly more observations than others');
  }
  const testCounts = athleteIds.map((id) => getAllCapacityTests(id).length);
  const maxTests = Math.max(...testCounts);
  const minTests = Math.min(...testCounts);
  if (maxTests - minTests > 3) {
    warnings.push('Unequal assessment coverage — comparison may not be equivalent');
  }
  return warnings;
}

// ===== SEED DEMO DATA =====

export function seedDemoScoutingData(): void {
  const project = createScoutingProject({
    name: 'U16 Academy Recruitment',
    sport: 'football',
    position: 'Central Midfielder',
    ageMin: 14,
    ageMax: 16,
    competitionLevel: 'Academy',
    location: 'Regional',
    description: 'Identifying midfield prospects for the U16 academy programme',
  });
  activateProject(project.id);

  createTargetProfile({
    projectId: project.id,
    name: 'U16 Midfielder Profile',
    criteria: [
      { metric: 'Acceleration', requirement: 'minimum', value: 3.5, unit: 's', description: '30m acceleration' },
      { metric: 'Aerobic Capacity', requirement: 'minimum', value: 50, unit: 'ml/kg/min', description: 'VO2max' },
      { metric: 'Change of Direction', requirement: 'minimum', value: 10, unit: 's', description: 'Agility test' },
    ],
    weights: { 'Acceleration': 30, 'Aerobic Capacity': 25, 'Change of Direction': 20, 'Technical Ability': 25 },
  });

  const athletes = getAllAthletes();
  for (const athlete of athletes.slice(0, 3)) {
    createObservation({
      athleteId: athlete.id,
      projectId: project.id,
      category: 'technical',
      observation: `${athlete.name} shows good first touch and passing range in training sessions.`,
      rating: 8,
      context: 'Training session',
      oppositionLevel: 'Academy',
      observationDate: '2026-08-15',
    });
    createObservation({
      athleteId: athlete.id,
      projectId: project.id,
      category: 'tactical',
      observation: `${athlete.name} demonstrates good positional awareness and decision-making in match scenarios.`,
      rating: 7,
      context: 'Match observation',
      oppositionLevel: 'Academy',
      observationDate: '2026-08-20',
    });
  }

  addToWatchlist({ athleteId: athletes[0].id, projectId: project.id, reason: 'Strong technical profile, monitoring for development' });
  addToShortlist({ athleteId: athletes[1].id, projectId: project.id, evidenceSummary: 'Strong profile match with validated assessment data', nextAction: 'Arrange trial session', reviewDate: '2026-09-15' });

  createEvidence({
    athleteId: athletes[0].id,
    projectId: project.id,
    source: 'scout_observation',
    date: '2026-08-15',
    author: SCOUT_ID,
    context: 'Training session',
    description: 'Good first touch and passing range observed across 3 training sessions',
    confidence: 'moderate',
  });
  createEvidence({
    athleteId: athletes[1].id,
    projectId: project.id,
    source: 'performance_testing',
    date: '2026-08-10',
    author: SCOUT_ID,
    context: 'Capacity testing',
    description: 'Acceleration and agility tests completed with validated results',
    confidence: 'high',
  });

  createTask({
    title: 'Watch next match for athlete ' + athletes[0].name,
    description: 'Observe performance in upcoming academy fixture',
    athleteId: athletes[0].id,
    projectId: project.id,
    dueDate: '2026-09-10',
    priority: 'high',
  });
  createTask({
    title: 'Request physical testing for ' + athletes[2].name,
    description: 'Arrange strength and repeat sprint assessment',
    athleteId: athletes[2].id,
    projectId: project.id,
    dueDate: '2026-09-20',
    priority: 'medium',
  });
}

seedDemoScoutingData();
