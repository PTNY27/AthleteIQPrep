import type { SportConfig, SportKey } from './types';

export const SPORT_CONFIGS: Record<SportKey, SportConfig> = {
  football: {
    key: 'football',
    label: 'Football',
    positions: ['Goalkeeper', 'Centre Back', 'Full Back', 'Wing Back', 'Defensive Midfielder', 'Central Midfielder', 'Attacking Midfielder', 'Winger', 'Forward', 'Striker'],
    technicalAttributes: ['First Touch', 'Passing', 'Receiving', 'Dribbling', 'Ball Carrying', 'Finishing', 'Crossing', 'Heading', 'Tackling'],
    tacticalAttributes: ['Positioning', 'Scanning', 'Decision Making', 'Space Occupation', 'Transition', 'Defensive Awareness', 'Attacking Movement', 'Pressing', 'Game Understanding'],
    physicalAttributes: ['Acceleration', 'Sprinting', 'Repeated Sprint Ability', 'Endurance', 'Strength', 'Power', 'Agility', 'Change of Direction'],
    performanceMetrics: ['Pass Completion %', 'Duels Won', 'Interceptions', 'Shots on Target', 'Distance Covered', 'Sprint Distance', 'Top Speed'],
    contextFactors: ['Competition Level', 'Opposition Quality', 'Match State', 'Position', 'Minutes Played', 'Tactical System'],
  },
  rugby: {
    key: 'rugby',
    label: 'Rugby',
    positions: ['Prop', 'Hooker', 'Lock', 'Flanker', 'Number 8', 'Scrum-half', 'Fly-half', 'Centre', 'Wing', 'Fullback'],
    technicalAttributes: ['Passing', 'Catching', 'Kicking', 'Tackling', 'Carrying', 'Rucking', 'Ball Security'],
    tacticalAttributes: ['Positioning', 'Defensive Organisation', 'Attacking Decision Making', 'Support Play', 'Phase Understanding', 'Transition', 'Spatial Awareness'],
    physicalAttributes: ['Acceleration', 'Sprint Speed', 'Strength', 'Power', 'Collision Capacity', 'Repeated Effort Capacity', 'Aerobic Capacity', 'Anaerobic Capacity'],
    performanceMetrics: ['Metres Carried', 'Tackles Made', 'Tackles Missed', 'Turnovers Won', 'Line Breaks', 'Kick Success %', 'Lineout Wins'],
    contextFactors: ['Competition Level', 'Opposition Quality', 'Match State', 'Position', 'Phase', 'Game Plan'],
  },
  hockey: {
    key: 'hockey',
    label: 'Hockey',
    positions: ['Goalkeeper', 'Defender', 'Midfielder', 'Forward'],
    technicalAttributes: ['Receiving', 'Passing', 'Ball Control', 'Elimination Skills', 'Shooting', 'Tackling', 'Aerial Skills'],
    tacticalAttributes: ['Positioning', 'Scanning', 'Pressing', 'Defensive Structure', 'Attacking Movement', 'Transition', 'Space Creation'],
    physicalAttributes: ['Acceleration', 'Speed', 'Agility', 'Repeated Sprint Ability', 'Endurance', 'Power'],
    performanceMetrics: ['Pass Completion %', 'Circle Entries', 'Shots on Target', 'Tackles Won', 'Distance Covered', 'Sprint Count'],
    contextFactors: ['Competition Level', 'Opposition Quality', 'Match State', 'Position', 'Formation'],
  },
  swimming: {
    key: 'swimming',
    label: 'Swimming',
    isEventBased: true,
    strokes: ['Freestyle', 'Backstroke', 'Breaststroke', 'Butterfly', 'Individual Medley'],
    events: ['50m', '100m', '200m', '400m', '800m', '1500m'],
    positions: [],
    technicalAttributes: ['Stroke Efficiency', 'Start Performance', 'Turn Performance', 'Finish Performance', 'Technical Consistency', 'Stroke Rate', 'Stroke Length'],
    tacticalAttributes: ['Pacing', 'Race Strategy', 'Lane Awareness', 'Race Execution'],
    physicalAttributes: ['Power', 'Endurance', 'Aerobic Capacity', 'Anaerobic Capacity', 'Flexibility', 'Core Strength'],
    performanceMetrics: ['Race Time', 'Split Times', 'Stroke Rate', 'Stroke Length', 'Start Time', 'Turn Time', 'Finish Time'],
    contextFactors: ['Stroke', 'Event', 'Distance', 'Competition Level', 'Pool Type', 'Lane'],
  },
  cricket: {
    key: 'cricket',
    label: 'Cricket',
    positions: ['Batter', 'Bowler', 'Wicketkeeper', 'All-rounder'],
    formats: ['Test', 'ODI', 'T20'],
    technicalAttributes: ['Batting Technique', 'Bowling Technique', 'Catching', 'Throwing', 'Ground Fielding', 'Wicketkeeping'],
    tacticalAttributes: ['Shot Selection', 'Line and Length', 'Field Placement', 'Match Awareness', 'Decision Making', 'Variation'],
    physicalAttributes: ['Acceleration', 'Speed', 'Agility', 'Power', 'Endurance', 'Reaction Time'],
    performanceMetrics: ['Runs', 'Strike Rate', 'Boundary Frequency', 'Economy Rate', 'Wicket-Taking Rate', 'Catches', 'Run Outs'],
    contextFactors: ['Format', 'Innings', 'Match Situation', 'Opposition', 'Pitch Conditions', 'Role', 'Overs Faced/Bowled'],
  },
  tennis: {
    key: 'tennis',
    label: 'Tennis',
    positions: [],
    technicalAttributes: ['Serve', 'Return', 'Forehand', 'Backhand', 'Volley', 'Overhead', 'Movement', 'Shot Selection'],
    tacticalAttributes: ['Point Construction', 'Rally Management', 'Court Positioning', 'Transition', 'Pattern Recognition', 'Opponent Adaptation'],
    physicalAttributes: ['Acceleration', 'Agility', 'Repeated Effort', 'Endurance', 'Power', 'Movement Efficiency'],
    performanceMetrics: ['First Serve %', 'Second Serve %', 'Break-Point Performance', 'Return Effectiveness', 'Unforced Errors', 'Winners', 'Rally Length'],
    contextFactors: ['Surface', 'Tournament Level', 'Opponent Level', 'Match Stage', 'Indoor/Outdoor'],
  },
  basketball: {
    key: 'basketball',
    label: 'Basketball',
    positions: ['Point Guard', 'Shooting Guard', 'Small Forward', 'Power Forward', 'Centre'],
    technicalAttributes: ['Shooting', 'Passing', 'Dribbling', 'Finishing', 'Rebounding', 'Defensive Technique'],
    tacticalAttributes: ['Spacing', 'Pick and Roll Decisions', 'Transition', 'Help Defence', 'Rotations', 'Decision Making', 'Off-Ball Movement'],
    physicalAttributes: ['Speed', 'Acceleration', 'Vertical Power', 'Strength', 'Agility', 'Endurance'],
    performanceMetrics: ['Points', 'Assists', 'Rebounds', 'Steals', 'Blocks', 'Turnovers', 'Shooting %', 'Free Throw %'],
    contextFactors: ['Competition Level', 'Opposition Quality', 'Match State', 'Position', 'Minutes Played', 'Pace'],
  },
  volleyball: {
    key: 'volleyball',
    label: 'Volleyball',
    positions: ['Setter', 'Outside Hitter', 'Opposite', 'Middle Blocker', 'Libero'],
    technicalAttributes: ['Serving', 'Passing', 'Setting', 'Attacking', 'Blocking', 'Digging'],
    tacticalAttributes: ['Positioning', 'Transition', 'Defensive Reading', 'Attack Selection', 'Block Decisions', 'Serve-Receive Organisation'],
    physicalAttributes: ['Jump Performance', 'Power', 'Agility', 'Speed', 'Repeated Effort Capacity'],
    performanceMetrics: ['Attack Efficiency', 'Serve Effectiveness', 'Reception Quality', 'Block Effectiveness', 'Defensive Actions', 'Setting Quality'],
    contextFactors: ['Competition Level', 'Opposition Quality', 'Set Score', 'Rotation', 'Position'],
  },
};

export const SPORT_LIST = Object.values(SPORT_CONFIGS);

export function getSportConfig(sport: string): SportConfig | undefined {
  return SPORT_CONFIGS[SportKeyCheck(sport)];
}

function SportKeyCheck(sport: string): SportKey {
  const normalized = sport.toLowerCase().replace(/\s+/g, '');
  const valid: SportKey[] = ['football', 'rugby', 'hockey', 'swimming', 'cricket', 'tennis', 'basketball', 'volleyball'];
  return valid.includes(normalized as SportKey) ? normalized as SportKey : 'football';
}

export function getSportPositions(sport: string): string[] {
  return getSportConfig(sport)?.positions ?? [];
}

export function getSportEvents(sport: string): string[] {
  return getSportConfig(sport)?.events ?? [];
}

export function getSportStrokes(sport: string): string[] {
  return getSportConfig(sport)?.strokes ?? [];
}

export function getSportFormats(sport: string): string[] {
  return getSportConfig(sport)?.formats ?? [];
}

export function getSportAttributes(sport: string, category: 'technicalAttributes' | 'tacticalAttributes' | 'physicalAttributes' | 'performanceMetrics'): string[] {
  return getSportConfig(sport)?.[category] ?? [];
}

export function getSportContextFactors(sport: string): string[] {
  return getSportConfig(sport)?.contextFactors ?? [];
}

export function isEventBasedSport(sport: string): boolean {
  return getSportConfig(sport)?.isEventBased ?? false;
}

export function getAllSportKeys(): SportKey[] {
  return Object.keys(SPORT_CONFIGS) as SportKey[];
}
