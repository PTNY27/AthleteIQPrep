// AthleteIQ Algorithm Validation Report — Stage 5A
// Generates per-algorithm validation records from test results

import type { TestResult, ValidationSummary } from './validationEngine';
import { ALGORITHM_METADATA, type AlgorithmId, type AlgorithmMeta, type AlgorithmStatus } from './algorithmEngine';

export interface AlgorithmValidationRecord {
  algorithmId: AlgorithmId;
  name: string;
  version: string;
  status: AlgorithmStatus;
  purpose: string;
  requiredInputs: string[];
  outputUnit: string;
  knownLimitations: string[];
  testCount: number;
  passedTests: number;
  failedTests: number;
  edgeCasesTested: string[];
  validationStatus: 'DRAFT' | 'IMPLEMENTED' | 'TESTED' | 'VALIDATED' | 'FROZEN';
  knownLimitationsNotes: string;
}

export interface Stage5AValidationReport {
  reportDate: string;
  algorithms: AlgorithmValidationRecord[];
  totalAlgorithms: number;
  frozenCount: number;
  testedCount: number;
  totalTests: number;
  totalPassed: number;
  totalFailed: number;
  overallPassRate: number;
  releaseStatus: 'green' | 'amber' | 'red';
  stage5AComplete: boolean;
  freezeAuthorized: boolean;
}

// Map test IDs to algorithm IDs they cover
const testAlgorithmMap: Record<string, AlgorithmId> = {
  T012: 'TRAINING_LOAD', T013: 'TRAINING_LOAD', T014: 'TRAINING_LOAD',
  T015: 'GAP_STATUS', T016: 'GAP_STATUS',
  T017: 'ANOMALY_DETECTION', T035: 'ANOMALY_DETECTION',
  T020: 'TREND_DETECTION', T021: 'TREND_DETECTION',
  T022: 'INTERVENTION_EVALUATION', T023: 'INTERVENTION_EVALUATION',
  T024: 'INTERVENTION_EVALUATION', T025: 'INTERVENTION_EVALUATION',
  T026: 'INTERVENTION_EVALUATION', T027: 'INTERVENTION_EVALUATION',
  T031: 'MDC', T032: 'MDC',
  T033: 'CORRELATION',
  T037: 'DESCRIPTIVE_STATS',
  T039: 'MATCH_AVERAGES',
  T041: 'EFFECT_SIZE', T042: 'EFFECT_SIZE',
  T043: 'MDC', T044: 'MDC',
  T045: 'CONFIDENCE_INTERVAL', T046: 'CONFIDENCE_INTERVAL',
  T047: 'CORRELATION', T048: 'CORRELATION', T049: 'CORRELATION',
  T050: 'TREND_DETECTION', T051: 'TREND_DETECTION',
  T052: 'DESCRIPTIVE_STATS', T053: 'DESCRIPTIVE_STATS',
  T054: 'DEVELOPMENT_INDEX', T055: 'DEVELOPMENT_INDEX',
  T056: 'LOAD_OPTIMIZATION', T057: 'LOAD_OPTIMIZATION', T058: 'LOAD_OPTIMIZATION',
  T059: 'EVIDENCE_LEVEL', T060: 'EVIDENCE_LEVEL',
  T061: 'EFFECT_SIZE',
  T062: 'TRAINING_LOAD', T063: 'TRAINING_LOAD',
  T064: 'GAP_STATUS',
  T065: 'TRAINING_LOAD',
  T028: 'DEMAND_MATRIX', T029: 'DEMAND_MATRIX', T030: 'DEMAND_MATRIX',
  T034: 'INTERVENTION_EVALUATION',
  T036: 'ANOMALY_DETECTION',
  T038: 'DATA_SUFFICIENCY',
  T040: 'DATA_SUFFICIENCY',
};

export function generateValidationReport(
  testResults: TestResult[],
  summary: ValidationSummary
): Stage5AValidationReport {
  const algorithms: AlgorithmValidationRecord[] = ALGORITHM_METADATA.map((meta) => {
    const algoTests = testResults.filter((t) => testAlgorithmMap[t.id] === meta.id);
    const passed = algoTests.filter((t) => t.result === 'pass').length;
    const failed = algoTests.filter((t) => t.result === 'fail').length;

    const edgeCases = algoTests
      .filter((t) => t.notes.includes('Edge case') || t.notes.includes('Boundary') || t.notes.includes('Determinism'))
      .map((t) => `${t.id}: ${t.name}`);

    let validationStatus: AlgorithmValidationRecord['validationStatus'] = 'DRAFT';
    if (meta.status === 'frozen') validationStatus = 'FROZEN';
    else if (meta.status === 'tested') validationStatus = 'TESTED';
    else if (meta.status === 'validated') validationStatus = 'VALIDATED';
    else if (meta.status === 'implemented') validationStatus = 'IMPLEMENTED';

    return {
      algorithmId: meta.id,
      name: meta.name,
      version: meta.version,
      status: meta.status,
      purpose: meta.purpose,
      requiredInputs: meta.requiredInputs,
      outputUnit: meta.outputUnit,
      knownLimitations: meta.knownLimitations,
      testCount: algoTests.length,
      passedTests: passed,
      failedTests: failed,
      edgeCasesTested: edgeCases,
      validationStatus,
      knownLimitationsNotes: meta.knownLimitations.join('; '),
    };
  });

  const frozenCount = algorithms.filter((a) => a.validationStatus === 'FROZEN').length;
  const testedCount = algorithms.filter((a) => a.validationStatus === 'TESTED').length;

  return {
    reportDate: new Date().toISOString(),
    algorithms,
    totalAlgorithms: algorithms.length,
    frozenCount,
    testedCount,
    totalTests: summary.total,
    totalPassed: summary.passed,
    totalFailed: summary.failed,
    overallPassRate: summary.passRate,
    releaseStatus: summary.releaseStatus,
    stage5AComplete: summary.failed === 0 && summary.releaseStatus === 'green',
    freezeAuthorized: summary.failed === 0 && summary.criticalFailures === 0 && summary.highFailures === 0,
  };
}
