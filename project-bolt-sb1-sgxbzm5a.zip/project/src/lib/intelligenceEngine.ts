// AthleteIQ Stage 6 — Intelligence Engine
// Consumes validated Stage 5A outputs and produces:
// Performance Interpretation → Gap Analysis → Priority Ranking → Confidence → Recommendations → Development Tracking
// Does NOT recreate Stage 5A calculations. Consumes their outputs.

import {
  calcACWR, calcGapStatus, calcDescriptiveStats, calcTrend, calcDemandMatrix,
  calcLoadOptimization, calcDataSufficiency, calcDevelopmentIndex, getBenchmark,
  type CalculationResult,
} from './algorithmEngine';
import {
  detectAnomalies, assessEvidenceLevel,
  type DataSufficiency, type TrendResult, type DemandMatrixEntry,
} from './statisticalEngine';
import {
  computeLoads, getLoadStatus, computeTrainingAverages, computeMatchAverages,
  getPositionalDemand,
} from './demoData';
import type {
  Athlete, TrainingSession, MatchRecord, CapacityTest, Intervention,
  LoadStatus, GapStatus,
} from './types';

// ===== STAGE 6 TYPES =====

export type PerformanceLevel =
  | 'ELITE' | 'ADVANCED' | 'DEVELOPING' | 'NEEDS_ATTENTION' | 'INSUFFICIENT_DATA';

export type TrendStatus = 'IMPROVING' | 'STABLE' | 'DECLINING' | 'FLUCTUATING' | 'INSUFFICIENT_DATA';

export type PriorityLevel = 'P1_CRITICAL' | 'P2_HIGH' | 'P3_MODERATE' | 'P4_MONITOR' | 'INSUFFICIENT_DATA';

export type ConfidenceLevel = 'HIGH' | 'MEDIUM' | 'LOW' | 'INSUFFICIENT_DATA';

export type TargetStatus = 'NOT_STARTED' | 'IN_PROGRESS' | 'ON_TRACK' | 'AT_RISK' | 'ACHIEVED';

export type ReassessmentOutcome = 'IMPROVED' | 'NO_SIGNIFICANT_CHANGE' | 'DECLINED' | 'TARGET_ACHIEVED' | 'INSUFFICIENT_DATA';

export type InsightCategory = 'STRENGTH' | 'DEVELOPMENT_AREA' | 'CRITICAL_WEAKNESS' | 'TREND' | 'ANOMALY' | 'DATA_QUALITY';

export type EvidenceType = 'MEASURED' | 'CALCULATED' | 'INTERPRETED' | 'RECOMMENDED';

// ===== CORE INTERFACES =====

export interface PerformanceInterpretation {
  metric: string;
  currentValue: number;
  benchmarkValue?: number;
  unit: string;
  higherIsBetter: boolean;
  level: PerformanceLevel;
  percentOfBenchmark?: number;
  gapPercent?: number;
  evidence: string;
  algorithmVersion: string;
}

export interface GapAnalysisEntry {
  metric: string;
  currentValue: number;
  targetValue: number;
  unit: string;
  gapPercent: number;
  gapStatus: GapStatus | 'INSUFFICIENT_DATA';
  higherIsBetter: boolean;
  evidence: string;
}

export interface PriorityEntry {
  metric: string;
  priority: PriorityLevel;
  gapPercent: number;
  trend: TrendStatus;
  importance: 'high' | 'medium' | 'low';
  confidence: ConfidenceLevel;
  reason: string;
  evidence: string;
}

export interface Recommendation {
  id: string;
  metric: string;
  observation: string;
  whyItMatters: string;
  priority: PriorityLevel;
  recommendedAction: string;
  targetValue?: number;
  targetUnit?: string;
  reassessmentDate?: string;
  confidence: ConfidenceLevel;
  evidence: string;
  evidenceType: EvidenceType;
}

export interface DevelopmentTarget {
  id: string;
  metric: string;
  currentValue: number;
  targetValue: number;
  unit: string;
  targetDate: string;
  priority: PriorityLevel;
  status: TargetStatus;
  higherIsBetter: boolean;
}

export interface TimelineEvent {
  id: string;
  date: string;
  type: 'assessment' | 'personal_best' | 'improvement' | 'decline' | 'goal_achieved' | 'priority_changed' | 'reassessment' | 'intervention';
  title: string;
  description: string;
  metric?: string;
}

export interface AthletePerformanceProfile {
  athleteId: string;
  generatedAt: string;
  stage5aVersion: string;
  overallLevel: PerformanceLevel;
  overallConfidence: ConfidenceLevel;
  strengths: PerformanceInterpretation[];
  developmentAreas: PerformanceInterpretation[];
  criticalWeaknesses: PerformanceInterpretation[];
  trends: { metric: string; trend: TrendStatus; evidence: string }[];
  gaps: GapAnalysisEntry[];
  priorities: PriorityEntry[];
  recommendations: Recommendation[];
  targets: DevelopmentTarget[];
  timeline: TimelineEvent[];
  dataSufficiency: DataSufficiency;
  developmentIndex: CalculationResult<{ score: number; confidence: string; components: { label: string; score: number; description: string }[]; reason: string }> | null;
  explainability: {
    measuredCount: number;
    calculatedCount: number;
    interpretedCount: number;
    recommendedCount: number;
  };
}

// ===== 1. PERFORMANCE INTERPRETATION ENGINE =====

export function interpretPerformance(
  metric: string,
  currentValue: number,
  benchmarkValue: number | undefined,
  unit: string,
  higherIsBetter: boolean,
): PerformanceInterpretation {
  if (benchmarkValue === undefined || benchmarkValue === 0) {
    return {
      metric, currentValue, benchmarkValue: undefined, unit, higherIsBetter,
      level: 'INSUFFICIENT_DATA',
      evidence: `No benchmark available for ${metric}. Cannot classify performance level.`,
      algorithmVersion: 'v1.0 (interpretation)',
    };
  }

  const percentOfBenchmark = higherIsBetter
    ? (currentValue / benchmarkValue) * 100
    : (benchmarkValue / currentValue) * 100;

  const gapPercent = higherIsBetter
    ? ((currentValue - benchmarkValue) / benchmarkValue) * 100
    : ((benchmarkValue - currentValue) / currentValue) * 100;

  let level: PerformanceLevel;
  if (percentOfBenchmark >= 100) level = 'ELITE';
  else if (percentOfBenchmark >= 90) level = 'ADVANCED';
  else if (percentOfBenchmark >= 75) level = 'DEVELOPING';
  else level = 'NEEDS_ATTENTION';

  const evidence = `${metric}: ${currentValue} ${unit} vs benchmark ${benchmarkValue} ${unit} (${percentOfBenchmark.toFixed(1)}% of benchmark)`;

  return {
    metric, currentValue, benchmarkValue, unit, higherIsBetter,
    level, percentOfBenchmark: +percentOfBenchmark.toFixed(1), gapPercent: +gapPercent.toFixed(1),
    evidence, algorithmVersion: 'v1.0 (interpretation)',
  };
}

// ===== 2. GAP ANALYSIS ENGINE =====

export function analyzeGaps(params: {
  tests: CapacityTest[];
  athlete: Athlete;
}): GapAnalysisEntry[] {
  const { tests, athlete } = params;
  const gaps: GapAnalysisEntry[] = [];

  for (const test of tests) {
    const targetValue = test.benchmark;
    const gapPercent = test.higherIsBetter
      ? ((test.latest - targetValue) / targetValue) * 100
      : ((targetValue - test.latest) / test.latest) * 100;

    let gapStatus: GapStatus | 'INSUFFICIENT_DATA';
    if (targetValue === 0) {
      gapStatus = 'INSUFFICIENT_DATA';
    } else {
      const gapResult = calcGapStatus(test.latest, targetValue);
      gapStatus = gapResult.result?.status ?? 'INSUFFICIENT_DATA';
    }

    gaps.push({
      metric: test.name,
      currentValue: test.latest,
      targetValue,
      unit: test.unit,
      gapPercent: +gapPercent.toFixed(1),
      gapStatus,
      higherIsBetter: test.higherIsBetter,
      evidence: `${test.name}: ${test.latest} ${test.unit} vs target ${targetValue} ${test.unit} (gap: ${gapPercent.toFixed(1)}%)`,
    });
  }

  return gaps.sort((a, b) => a.gapPercent - b.gapPercent);
}

// ===== 3. TREND ANALYSIS =====

export function analyzeTrend(test: CapacityTest): { metric: string; trend: TrendStatus; evidence: string } {
  if (test.history.length < 3) {
    return {
      metric: test.name,
      trend: 'INSUFFICIENT_DATA',
      evidence: `Only ${test.history.length} data points for ${test.name}. Minimum 3 required for trend analysis.`,
    };
  }

  const trendResult = calcTrend(test.history, test.higherIsBetter);
  const result = trendResult.result;

  if (!result) {
    return { metric: test.name, trend: 'INSUFFICIENT_DATA', evidence: 'Trend calculation failed.' };
  }

  let trend: TrendStatus;
  switch (result.direction) {
    case 'improving': trend = 'IMPROVING'; break;
    case 'declining': trend = 'DECLINING'; break;
    case 'stable': trend = 'STABLE'; break;
    case 'plateau': trend = 'STABLE'; break;
    case 'variable': trend = 'FLUCTUATING'; break;
    default: trend = 'INSUFFICIENT_DATA';
  }

  return {
    metric: test.name,
    trend,
    evidence: `${result.interpretation} (R²=${result.r2.toFixed(2)}, confidence: ${result.confidence})`,
  };
}

// ===== 4. CONFIDENCE FRAMEWORK =====

export function assessConfidence(params: {
  dataSufficiency: DataSufficiency;
  historyLength: number;
  benchmarkAvailable: boolean;
  dataRecencyDays: number;
}): ConfidenceLevel {
  const { dataSufficiency, historyLength, benchmarkAvailable, dataRecencyDays } = params;

  if (dataSufficiency.level === 'insufficient' || historyLength === 0) {
    return 'INSUFFICIENT_DATA';
  }

  let score = 0;
  if (dataSufficiency.level === 'sufficient') score += 40;
  else if (dataSufficiency.level === 'limited') score += 20;

  if (historyLength >= 4) score += 25;
  else if (historyLength >= 2) score += 15;
  else score += 5;

  if (benchmarkAvailable) score += 20;

  if (dataRecencyDays <= 30) score += 15;
  else if (dataRecencyDays <= 90) score += 10;
  else if (dataRecencyDays <= 180) score += 5;

  if (score >= 75) return 'HIGH';
  if (score >= 50) return 'MEDIUM';
  return 'LOW';
}

// ===== 5. PRIORITY ENGINE =====

export function rankPriorities(params: {
  gaps: GapAnalysisEntry[];
  trends: { metric: string; trend: TrendStatus; evidence: string }[];
  tests: CapacityTest[];
  dataSufficiency: DataSufficiency;
  positionWeights?: Record<string, 'high' | 'medium' | 'low'>;
}): PriorityEntry[] {
  const { gaps, trends, tests, dataSufficiency, positionWeights } = params;
  const priorities: PriorityEntry[] = [];

  for (const gap of gaps) {
    if (gap.gapStatus === 'INSUFFICIENT_DATA') {
      priorities.push({
        metric: gap.metric,
        priority: 'INSUFFICIENT_DATA',
        gapPercent: gap.gapPercent,
        trend: 'INSUFFICIENT_DATA',
        importance: positionWeights?.[gap.metric] ?? 'medium',
        confidence: 'INSUFFICIENT_DATA',
        reason: 'Insufficient data to assign priority.',
        evidence: gap.evidence,
      });
      continue;
    }

    const trend = trends.find((t) => t.metric === gap.metric)?.trend ?? 'INSUFFICIENT_DATA';
    const test = tests.find((t) => t.name === gap.metric);
    const historyLen = test?.history.length ?? 0;
    const confidence = assessConfidence({
      dataSufficiency, historyLength: historyLen,
      benchmarkAvailable: gap.targetValue > 0, dataRecencyDays: 30,
    });

    if (dataSufficiency.level === 'insufficient') {
      priorities.push({
        metric: gap.metric, priority: 'INSUFFICIENT_DATA', gapPercent: gap.gapPercent,
        trend, importance: positionWeights?.[gap.metric] ?? 'medium',
        confidence: 'INSUFFICIENT_DATA',
        reason: 'Insufficient data for reliable priority assignment.',
        evidence: gap.evidence,
      });
      continue;
    }

    // Priority scoring: gap severity + trend direction + importance + confidence
    let score = 0;
    const absGap = Math.abs(gap.gapPercent);

    // Gap severity (negative gap = below target = higher priority)
    if (gap.gapPercent < -25) score += 40;
    else if (gap.gapPercent < -10) score += 25;
    else if (gap.gapPercent < 0) score += 15;
    else if (gap.gapPercent >= 0) score += 5;

    // Trend direction
    if (trend === 'DECLINING') score += 25;
    else if (trend === 'FLUCTUATING') score += 15;
    else if (trend === 'STABLE') score += 10;
    else if (trend === 'IMPROVING') score += 5;

    // Importance weighting
    const importance = positionWeights?.[gap.metric] ?? 'medium';
    if (importance === 'high') score += 20;
    else if (importance === 'medium') score += 10;
    else score += 5;

    // Confidence adjustment
    if (confidence === 'HIGH') score += 10;
    else if (confidence === 'MEDIUM') score += 5;

    let priority: PriorityLevel;
    if (score >= 70) priority = 'P1_CRITICAL';
    else if (score >= 50) priority = 'P2_HIGH';
    else if (score >= 30) priority = 'P3_MODERATE';
    else priority = 'P4_MONITOR';

    const reason = `${gap.metric} gap of ${gap.gapPercent.toFixed(1)}% with ${trend.toLowerCase()} trend (${importance} importance, ${confidence.toLowerCase()} confidence)`;

    priorities.push({
      metric: gap.metric, priority, gapPercent: gap.gapPercent,
      trend, importance, confidence, reason, evidence: gap.evidence,
    });
  }

  return priorities.sort((a, b) => {
    const order: Record<PriorityLevel, number> = { P1_CRITICAL: 0, P2_HIGH: 1, P3_MODERATE: 2, P4_MONITOR: 3, INSUFFICIENT_DATA: 4 };
    return order[a.priority] - order[b.priority];
  });
}

// ===== 6. RECOMMENDATION ENGINE =====

export function generateRecommendations(params: {
  priorities: PriorityEntry[];
  gaps: GapAnalysisEntry[];
  tests: CapacityTest[];
  athlete: Athlete;
}): Recommendation[] {
  const { priorities, gaps, tests, athlete } = params;
  const recs: Recommendation[] = [];

  for (const priority of priorities) {
    if (priority.priority === 'INSUFFICIENT_DATA' || priority.priority === 'P4_MONITOR') continue;

    const gap = gaps.find((g) => g.metric === priority.metric);
    const test = tests.find((t) => t.name === priority.metric);
    if (!gap || !test) continue;

    const targetValue = gap.targetValue;
    const reassessmentDate = new Date();
    reassessmentDate.setDate(reassessmentDate.getDate() + 42); // 6 weeks

    const observation = `${priority.metric} is ${Math.abs(gap.gapPercent).toFixed(1)}% ${gap.gapPercent < 0 ? 'below' : 'above'} target`;
    const whyItMatters = priority.priority === 'P1_CRITICAL'
      ? `${priority.metric} is a critical development priority for a ${athlete.position}. Addressing this gap should be the primary training focus.`
      : priority.priority === 'P2_HIGH'
      ? `${priority.metric} is an important development area for a ${athlete.position}. Targeted training can help close this gap.`
      : `${priority.metric} shows a moderate gap. Progressive development recommended.`;

    const recommendedAction = gap.gapPercent < 0
      ? `Prioritize ${priority.metric.toLowerCase()} development. Target ${targetValue} ${gap.unit}. Current: ${gap.currentValue} ${gap.unit}.`
      : `Maintain ${priority.metric.toLowerCase()} performance. Currently exceeding target.`;

    recs.push({
      id: `rec-${priority.metric.replace(/\s+/g, '-').toLowerCase()}`,
      metric: priority.metric,
      observation,
      whyItMatters,
      priority: priority.priority,
      recommendedAction,
      targetValue,
      targetUnit: gap.unit,
      reassessmentDate: reassessmentDate.toISOString().split('T')[0],
      confidence: priority.confidence,
      evidence: priority.evidence,
      evidenceType: 'RECOMMENDED',
    });
  }

  return recs;
}

// ===== 7. TARGET MANAGEMENT =====

export function createTarget(params: {
  metric: string;
  currentValue: number;
  targetValue: number;
  unit: string;
  targetDate: string;
  priority: PriorityLevel;
  higherIsBetter: boolean;
}): DevelopmentTarget {
  return {
    id: `target-${params.metric.replace(/\s+/g, '-').toLowerCase()}`,
    metric: params.metric,
    currentValue: params.currentValue,
    targetValue: params.targetValue,
    unit: params.unit,
    targetDate: params.targetDate,
    priority: params.priority,
    status: 'NOT_STARTED',
    higherIsBetter: params.higherIsBetter,
  };
}

export function updateTargetStatus(target: DevelopmentTarget, currentValue: number): DevelopmentTarget {
  const { targetValue, higherIsBetter } = target;
  const gapPercent = higherIsBetter
    ? ((currentValue - targetValue) / targetValue) * 100
    : ((targetValue - currentValue) / currentValue) * 100;

  let status: TargetStatus;
  if (gapPercent >= 0) status = 'ACHIEVED';
  else if (gapPercent >= -5) status = 'ON_TRACK';
  else if (gapPercent >= -15) status = 'IN_PROGRESS';
  else if (target.status === 'NOT_STARTED') status = 'NOT_STARTED';
  else status = 'AT_RISK';

  return { ...target, currentValue, status };
}

// ===== 8. REASSESSMENT LOGIC =====

export function evaluateReassessment(params: {
  preValue: number;
  postValue: number;
  targetValue: number;
  higherIsBetter: boolean;
  mdcResult?: { meaningful: boolean } | null;
}): { outcome: ReassessmentOutcome; evidence: string } {
  const { preValue, postValue, targetValue, higherIsBetter, mdcResult } = params;
  const change = higherIsBetter ? postValue - preValue : preValue - postValue;
  const targetAchieved = higherIsBetter ? postValue >= targetValue : postValue <= targetValue;
  const percentChange = preValue === 0 ? 0 : (change / preValue) * 100;

  if (targetAchieved) {
    return { outcome: 'TARGET_ACHIEVED', evidence: `Target achieved: ${postValue} ${higherIsBetter ? '≥' : '≤'} ${targetValue}` };
  }

  if (mdcResult && !mdcResult.meaningful) {
    return { outcome: 'NO_SIGNIFICANT_CHANGE', evidence: `Change of ${percentChange.toFixed(1)}% may be within measurement variation (MDC not exceeded).` };
  }

  if (Math.abs(percentChange) < 2) {
    return { outcome: 'NO_SIGNIFICANT_CHANGE', evidence: `Change of ${percentChange.toFixed(1)}% is below threshold for meaningful change.` };
  }

  if (change > 0) {
    return { outcome: 'IMPROVED', evidence: `Improved by ${percentChange.toFixed(1)}% (${preValue} → ${postValue}).` };
  }

  return { outcome: 'DECLINED', evidence: `Declined by ${Math.abs(percentChange).toFixed(1)}% (${preValue} → ${postValue}).` };
}

// ===== 9. TIMELINE GENERATION =====

export function generateTimeline(params: {
  tests: CapacityTest[];
  interventions: Intervention[];
}): TimelineEvent[] {
  const events: TimelineEvent[] = [];
  const { tests, interventions } = params;

  for (const test of tests) {
    // Assessment completed events
    for (const h of test.history) {
      const isLatest = h.date === test.date;
      const isBest = test.higherIsBetter
        ? h.value === Math.max(...test.history.map((x) => x.value))
        : h.value === Math.min(...test.history.map((x) => x.value));

      events.push({
        id: `tl-${test.id}-${h.date}`,
        date: h.date,
        type: isBest ? 'personal_best' : 'assessment',
        title: `${test.name} assessment`,
        description: `${h.value} ${test.unit}${isLatest ? ' (latest)' : ''}`,
        metric: test.name,
      });
    }

    // Improvement/decline between consecutive assessments
    for (let i = 1; i < test.history.length; i++) {
      const prev = test.history[i - 1];
      const curr = test.history[i];
      const improved = test.higherIsBetter ? curr.value > prev.value : curr.value < prev.value;
      const pctChange = prev.value === 0 ? 0 : Math.abs(((curr.value - prev.value) / prev.value) * 100);

      if (pctChange > 2) {
        events.push({
          id: `tl-${test.id}-${curr.date}-change`,
          date: curr.date,
          type: improved ? 'improvement' : 'decline',
          title: `${test.name} ${improved ? 'improved' : 'declined'}`,
          description: `${prev.value} → ${curr.value} ${test.unit} (${pctChange.toFixed(1)}% ${improved ? 'improvement' : 'decline'})`,
          metric: test.name,
        });
      }
    }
  }

  // Intervention events
  for (const iv of interventions) {
    events.push({
      id: `tl-iv-${iv.id}`,
      date: iv.startDate,
      type: 'intervention',
      title: `Intervention: ${iv.objective}`,
      description: `Target: ${iv.target} ${iv.unit} (from ${iv.startingPoint} ${iv.unit})`,
      metric: iv.metric,
    });

    if (iv.status === 'completed' && iv.results) {
      events.push({
        id: `tl-iv-${iv.id}-end`,
        date: iv.endDate,
        type: iv.results.targetAchieved ? 'goal_achieved' : 'reassessment',
        title: iv.results.targetAchieved ? `Goal achieved: ${iv.objective}` : `Reassessment: ${iv.objective}`,
        description: `${iv.results.beforeValue} → ${iv.results.afterValue} ${iv.unit}`,
        metric: iv.metric,
      });
    }
  }

  return events.sort((a, b) => b.date.localeCompare(a.date));
}

// ===== 10. FULL ATHLETE PERFORMANCE PROFILE =====

export function generateAthleteProfile(params: {
  athlete: Athlete;
  sessions: TrainingSession[];
  matches: MatchRecord[];
  tests: CapacityTest[];
  interventions: Intervention[];
}): AthletePerformanceProfile {
  const { athlete, sessions, matches, tests, interventions } = params;
  const generatedAt = new Date().toISOString();
  const stage5aVersion = 'v1.0';

  // Consume Stage 5A: Data Sufficiency
  const dataSufficiencyResult = calcDataSufficiency({
    sessions, matches, capacityTests: tests, interventions,
  });
  const dataSufficiency = dataSufficiencyResult.result ?? {
    level: 'insufficient' as const, sessions: 0, matches: 0, capacityTests: 0,
    interventions: 0, timeSpanDays: 0, dataCompleteness: 0,
    missingVariables: ['All'], reason: 'No data',
  };

  // Consume Stage 5A: Anomaly Detection
  const anomalies = detectAnomalies({ sessions, matches, capacityTests: tests });

  // Interpret each capacity test
  const interpretations: PerformanceInterpretation[] = tests.map((test) =>
    interpretPerformance(test.name, test.latest, test.benchmark, test.unit, test.higherIsBetter),
  );

  // Classify strengths / development areas / critical weaknesses
  const strengths = interpretations.filter((i) => i.level === 'ELITE' || i.level === 'ADVANCED');
  const developmentAreas = interpretations.filter((i) => i.level === 'DEVELOPING');
  const criticalWeaknesses = interpretations.filter((i) => i.level === 'NEEDS_ATTENTION');

  // Gap analysis
  const gaps = analyzeGaps({ tests, athlete });

  // Trend analysis
  const trends = tests.map((test) => analyzeTrend(test));

  // Position weights from positional demands
  const positionDemands = getPositionalDemand(athlete.position);
  const positionWeights: Record<string, 'high' | 'medium' | 'low'> = {};
  for (const demand of positionDemands) {
    const matchingTest = tests.find((t) =>
      t.name.toLowerCase().includes(demand.label.toLowerCase()) ||
      demand.label.toLowerCase().includes(t.name.toLowerCase()),
    );
    if (matchingTest) {
      positionWeights[matchingTest.name] = demand.category === 'intensity' || demand.category === 'physiological' ? 'high' : 'medium';
    }
  }

  // Priority ranking
  const priorities = rankPriorities({ gaps, trends, tests, dataSufficiency, positionWeights });

  // Recommendations
  const recommendations = generateRecommendations({ priorities, gaps, tests, athlete });

  // Targets (from recommendations)
  const targets: DevelopmentTarget[] = recommendations
    .filter((r) => r.targetValue !== undefined && r.priority !== 'INSUFFICIENT_DATA')
    .map((r) => createTarget({
      metric: r.metric,
      currentValue: gaps.find((g) => g.metric === r.metric)?.currentValue ?? 0,
      targetValue: r.targetValue!,
      unit: r.targetUnit ?? '',
      targetDate: r.reassessmentDate ?? '',
      priority: r.priority,
      higherIsBetter: tests.find((t) => t.name === r.metric)?.higherIsBetter ?? true,
    }));

  // Timeline
  const timeline = generateTimeline({ tests, interventions });

  // Overall level
  const levelOrder: Record<PerformanceLevel, number> = {
    ELITE: 5, ADVANCED: 4, DEVELOPING: 3, NEEDS_ATTENTION: 2, INSUFFICIENT_DATA: 0,
  };
  const validLevels = interpretations.filter((i) => i.level !== 'INSUFFICIENT_DATA');
  const overallLevel: PerformanceLevel = validLevels.length === 0
    ? 'INSUFFICIENT_DATA'
    : validLevels.reduce((min, i) => levelOrder[i.level] < levelOrder[min] ? i.level : min, validLevels[0].level);

  // Overall confidence
  const avgHistoryLen = tests.length > 0
    ? Math.round(tests.reduce((sum, t) => sum + t.history.length, 0) / tests.length)
    : 0;
  const overallConfidence = assessConfidence({
    dataSufficiency, historyLength: avgHistoryLen,
    benchmarkAvailable: tests.every((t) => t.benchmark > 0),
    dataRecencyDays: 30,
  });

  // Development Index (consume Stage 5A)
  let developmentIndex: AthletePerformanceProfile['developmentIndex'] = null;
  if (dataSufficiency.level !== 'insufficient') {
    const capacityProgression = validLevels.length > 0
      ? Math.round(validLevels.reduce((sum, i) => sum + (i.percentOfBenchmark ?? 0), 0) / validLevels.length)
      : 0;

    const trainAvg = computeTrainingAverages(sessions);
    const matchAvg = computeMatchAverages(matches);
    let demandCoverage = 0;
    if (trainAvg && matchAvg) {
      const dm = calcDemandMatrix({
        trainAvg: trainAvg as Record<string, number | undefined>,
        matchAvg: matchAvg as Record<string, number | undefined>,
        positionDemands: positionDemands.map((d) => ({ label: d.label, value: d.value, unit: d.unit, category: d.category })),
        positionWeights,
      });
      if (dm.result) {
        const validEntries = dm.result.filter((e) => e.coverage > 0);
        demandCoverage = validEntries.length > 0
          ? Math.round(validEntries.reduce((sum, e) => sum + e.coverage, 0) / validEntries.length)
          : 0;
      }
    }

    const loads = computeLoads(sessions);
    const loadStatus = getLoadStatus(loads.acute, loads.chronic);
    const loadAlignment = loadStatus === 'OPTIMAL' ? 85 : loadStatus === 'LOW' ? 50 : loadStatus === 'HIGH' ? 60 : 40;

    const improvingCount = trends.filter((t) => t.trend === 'IMPROVING').length;
    const performanceTrend = trends.length > 0
      ? Math.round((improvingCount / trends.length) * 100)
      : 50;

    const dataConfidence = overallConfidence === 'HIGH' ? 85 : overallConfidence === 'MEDIUM' ? 60 : 30;

    developmentIndex = calcDevelopmentIndex({
      capacityProgression,
      demandCoverage,
      loadAlignment,
      performanceTrend,
      dataConfidence,
      dataSufficiency: dataSufficiency.level,
    });
  }

  // Explainability counts
  const explainability = {
    measuredCount: tests.length,
    calculatedCount: 1 + (developmentIndex ? 1 : 0) + gaps.length,
    interpretedCount: interpretations.length + trends.length,
    recommendedCount: recommendations.length,
  };

  return {
    athleteId: athlete.id,
    generatedAt,
    stage5aVersion,
    overallLevel,
    overallConfidence,
    strengths,
    developmentAreas,
    criticalWeaknesses,
    trends,
    gaps,
    priorities,
    recommendations,
    targets,
    timeline,
    dataSufficiency,
    developmentIndex,
    explainability,
  };
}

// ===== 11. LONGITUDINAL COMPARISON =====

export interface LongitudinalComparison {
  metric: string;
  assessments: { date: string; value: number }[];
  progress: 'IMPROVING' | 'REGRESSION' | 'PLATEAU' | 'VOLATILITY' | 'INSUFFICIENT_DATA';
  totalChange: number;
  percentChange: number;
  evidence: string;
}

export function compareLongitudinal(tests: CapacityTest[]): LongitudinalComparison[] {
  return tests.map((test) => {
    const history = test.history;
    if (history.length < 2) {
      return {
        metric: test.name,
        assessments: history,
        progress: 'INSUFFICIENT_DATA',
        totalChange: 0,
        percentChange: 0,
        evidence: 'Insufficient data for longitudinal comparison.',
      };
    }

    const first = history[0];
    const last = history[history.length - 1];
    const totalChange = test.higherIsBetter ? last.value - first.value : first.value - last.value;
    const percentChange = first.value === 0 ? 0 : (totalChange / first.value) * 100;

    let progress: LongitudinalComparison['progress'];
    if (history.length < 3) {
      progress = totalChange > 0 ? 'IMPROVING' : totalChange < 0 ? 'REGRESSION' : 'PLATEAU';
    } else {
      const trendResult = calcTrend(history, test.higherIsBetter);
      const trend = trendResult.result;
      if (!trend) {
        progress = 'INSUFFICIENT_DATA';
      } else if (trend.direction === 'improving') progress = 'IMPROVING';
      else if (trend.direction === 'declining') progress = 'REGRESSION';
      else if (trend.direction === 'plateau') progress = 'PLATEAU';
      else if (trend.direction === 'variable') progress = 'VOLATILITY';
      else progress = 'PLATEAU';
    }

    return {
      metric: test.name,
      assessments: history,
      progress,
      totalChange: +totalChange.toFixed(2),
      percentChange: +percentChange.toFixed(1),
      evidence: `${test.name}: ${first.value} → ${last.value} ${test.unit} (${percentChange > 0 ? '+' : ''}${percentChange.toFixed(1)}%)`,
    };
  });
}

// ===== 12. AI GUARDRAILS =====

export function validateAIOutput(text: string, knownData: {
  metrics: string[];
  values: Record<string, number>;
}): { valid: boolean; violations: string[] } {
  const violations: string[] = [];
  const lower = text.toLowerCase();

  // Check for medical claims
  const medicalTerms = ['injury', 'injured', 'diagnos', 'medical', 'concussion', 'fracture', 'strain', 'tear'];
  for (const term of medicalTerms) {
    if (lower.includes(term)) {
      violations.push(`Potential medical claim detected: "${term}"`);
    }
  }

  // Check for certainty claims with insufficient data
  if (lower.includes('certain') || lower.includes('guaranteed') || lower.includes('definitely')) {
    violations.push('Unsupported certainty claim detected');
  }

  // Check for fabricated metrics
  const words = text.split(/\s+/);
  for (const word of words) {
    const cleanWord = word.replace(/[^a-zA-Z]/g, '');
    if (cleanWord.length > 3 && /\d/.test(word) && !knownData.metrics.some((m) => m.toLowerCase().includes(cleanWord.toLowerCase()))) {
      // Only flag if it looks like a metric-value pair not in our data
      const numMatch = word.match(/\d+\.?\d*/);
      if (numMatch) {
        const num = parseFloat(numMatch[0]);
        const matchingMetric = knownData.metrics.find((m) => text.toLowerCase().includes(m.toLowerCase()));
        if (matchingMetric) {
          const knownValue = knownData.values[matchingMetric];
          if (knownValue !== undefined && Math.abs(num - knownValue) > knownValue * 0.5) {
            violations.push(`Potential fabricated value: "${word}" for metric "${matchingMetric}" (expected ~${knownValue})`);
          }
        }
      }
    }
  }

  return { valid: violations.length === 0, violations };
}
