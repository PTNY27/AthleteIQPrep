// Demo data for Stage 4 data pipeline UI

import type { DataSourceConfig, ImportRecord, PipelineStage, AuditEntry, OutlierResult } from './dataPipeline';

export const demoDataSources: DataSourceConfig[] = [
  {
    id: 'ds1', name: 'GPS/GNSS Provider', type: 'gps', status: 'connected',
    lastSync: '2026-08-30 18:40', athletes: 10, sessions: 148, dataQuality: 94,
    syncFrequency: 'daily', provider: 'Catapult Vector',
  },
  {
    id: 'ds2', name: 'Heart Rate System', type: 'hr', status: 'connected',
    lastSync: '2026-08-30 17:15', athletes: 10, sessions: 142, dataQuality: 91,
    syncFrequency: 'daily', provider: 'Polar Team Pro',
  },
  {
    id: 'ds3', name: 'Player Tracking Platform', type: 'tracking', status: 'integration-ready',
    lastSync: null, athletes: 0, sessions: 0, dataQuality: 0,
    syncFrequency: 'manual', provider: 'STATSports',
  },
  {
    id: 'ds4', name: 'Wearable Sensor Array', type: 'sensor', status: 'demo',
    lastSync: '2026-08-29 10:00', athletes: 10, sessions: 148, dataQuality: 88,
    syncFrequency: 'manual', provider: 'Demo Data',
  },
];

export const demoImportHistory: ImportRecord[] = [
  {
    id: 'imp1', date: '2026-08-30 18:42', source: 'GPS/GNSS Provider', sourceType: 'live',
    fileName: 'session_2026_08_30.csv', records: 432, valid: 415, warnings: 12, rejected: 5,
    quality: 96, status: 'complete', athleteMappings: 10, metricMappings: 14,
  },
  {
    id: 'imp2', date: '2026-08-30 17:20', source: 'Heart Rate System', sourceType: 'live',
    fileName: 'hr_training_29.csv', records: 398, valid: 380, warnings: 14, rejected: 4,
    quality: 91, status: 'complete', athleteMappings: 10, metricMappings: 8,
  },
  {
    id: 'imp3', date: '2026-08-29 10:05', source: 'CSV Upload', sourceType: 'imported',
    fileName: 'problematic_wearable_export.csv', records: 10, valid: 6, warnings: 2, rejected: 2,
    quality: 60, status: 'requires-review', athleteMappings: 8, metricMappings: 14,
    errorReport: [
      { row: 2, column: 'HSR', level: 'warning', message: 'High-Speed Running missing', value: '' },
      { row: 4, column: 'Duration', level: 'error', message: 'Duration below plausible minimum (1 minutes)', value: '-5' },
      { row: 5, column: 'Athlete ID', level: 'error', message: 'Athlete ID not recognized', value: '#99' },
      { row: 6, column: 'Max Speed', level: 'warning', message: 'Maximum Velocity above plausible maximum (45 km/h) — review required', value: '55.0' },
      { row: 7, column: 'Date', level: 'info', message: 'Date format detected as DD/MM/YYYY — converted to ISO', value: '28/08/2026' },
      { row: 8, column: 'Athlete ID', level: 'warning', message: 'Duplicate row detected', value: 'a1' },
      { row: 10, column: 'Athlete ID', level: 'error', message: 'Athlete ID missing', value: '' },
    ],
  },
  {
    id: 'imp4', date: '2026-08-28 09:30', source: 'CSV Upload', sourceType: 'imported',
    fileName: 'valid_wearable_export.csv', records: 6, valid: 6, warnings: 0, rejected: 0,
    quality: 100, status: 'complete', athleteMappings: 6, metricMappings: 14,
  },
  {
    id: 'imp5', date: '2026-08-27 14:00', source: 'GPS/GNSS Provider', sourceType: 'live',
    fileName: 'session_2026_08_27.csv', records: 380, valid: 370, warnings: 8, rejected: 2,
    quality: 95, status: 'complete', athleteMappings: 10, metricMappings: 14,
  },
  {
    id: 'imp6', date: '2026-08-26 11:15', source: 'Heart Rate System', sourceType: 'live',
    fileName: 'hr_training_26.csv', records: 350, valid: 320, warnings: 22, rejected: 8,
    quality: 87, status: 'partial', athleteMappings: 10, metricMappings: 8,
  },
];

export const demoPipelineStages: PipelineStage[] = [
  { name: 'Ingestion', status: 'operational', recordsProcessed: 2438, lastRun: '2026-08-30 18:42' },
  { name: 'Validation', status: 'operational', recordsProcessed: 2438, lastRun: '2026-08-30 18:42' },
  { name: 'Normalization', status: 'operational', recordsProcessed: 2381, lastRun: '2026-08-30 18:42' },
  { name: 'Athlete Matching', status: 'operational', recordsProcessed: 2381, lastRun: '2026-08-30 18:42' },
  { name: 'Quality Control', status: 'operational', recordsProcessed: 2381, lastRun: '2026-08-30 18:42' },
  { name: 'Analytics', status: 'operational', recordsProcessed: 2381, lastRun: '2026-08-30 18:43' },
  { name: 'AI', status: 'operational', recordsProcessed: 2381, lastRun: '2026-08-30 18:43' },
];

export const demoAuditLog: AuditEntry[] = [
  { id: 'a1', timestamp: '2026-08-30 18:42', user: 'admin@athleteiq.io', action: 'Data Imported', object: 'session_2026_08_30.csv', details: '432 records, 96% quality' },
  { id: 'a2', timestamp: '2026-08-30 17:20', user: 'admin@athleteiq.io', action: 'Data Imported', object: 'hr_training_29.csv', details: '398 records, 91% quality' },
  { id: 'a3', timestamp: '2026-08-30 12:00', user: 'ps@athleteiq.io', action: 'AI Recommendation Accepted', object: 'Insight #i11', details: 'Sprint exposure gap — accepted' },
  { id: 'a4', timestamp: '2026-08-29 15:30', user: 'coach@athleteiq.io', action: 'AI Recommendation Rejected', object: 'Insight #i12', details: 'Load spike — rejected, athlete felt fine' },
  { id: 'a5', timestamp: '2026-08-29 10:05', user: 'ps@athleteiq.io', action: 'Data Imported', object: 'problematic_wearable_export.csv', details: '10 records, 60% quality, requires review' },
  { id: 'a6', timestamp: '2026-08-28 16:00', user: 'admin@athleteiq.io', action: 'Athlete Mapping Changed', object: '#99 → Unmatched', details: 'Manual resolution required' },
  { id: 'a7', timestamp: '2026-08-28 09:30', user: 'ps@athleteiq.io', action: 'Data Imported', object: 'valid_wearable_export.csv', details: '6 records, 100% quality' },
  { id: 'a8', timestamp: '2026-08-27 14:00', user: 'admin@athleteiq.io', action: 'Data Reprocessed', object: 'session_2026_08_27.csv', details: 'HSR mapping corrected, recalculated' },
  { id: 'a9', timestamp: '2026-08-26 11:15', user: 'admin@athleteiq.io', action: 'Data Imported', object: 'hr_training_26.csv', details: '350 records, 87% quality, partial' },
  { id: 'a10', timestamp: '2026-08-25 09:00', user: 'ps@athleteiq.io', action: 'Intervention Created', object: 'Intervention #iv5', details: 'Reduce training load spike for Liam Walsh' },
];

export const demoOutliers: OutlierResult[] = [
  { metric: 'Sprint Distance', athleteId: 'a6', value: 430, baseline: { mean: 200, std: 60 }, zScore: 3.8, level: 'level2', message: 'Unusual individual exposure detected: 430 m vs typical 200 m (z=3.8)' },
  { metric: 'Max Velocity', athleteId: 'a6', value: 55, baseline: { mean: 33, std: 1.5 }, zScore: 14.7, level: 'level2', message: 'Unusual individual exposure detected: 55 km/h vs typical 33 km/h (z=14.7) — likely sensor error' },
  { metric: 'High-Speed Running', athleteId: 'a7', value: 950, baseline: { mean: 600, std: 120 }, zScore: 2.9, level: 'level1', message: 'Statistical outlier: 950 m vs baseline 600 m (z=2.9)' },
];

export const demoSessionsNeedingReview = [
  { athleteId: 'a6', date: '2026-08-28', type: 'Training', issues: ['Max velocity 55 km/h — sensor error suspected', 'Sprint distance 430 m — unusual for position'], quality: 62, source: 'GPS/GNSS Provider' },
  { athleteId: 'a2', date: '2026-08-28', type: 'Training', issues: ['HSR data missing', 'HR completeness 71%'], quality: 71, source: 'Heart Rate System' },
  { athleteId: 'a4', date: '2026-08-28', type: 'Training', issues: ['Duration recorded as -5 min — invalid', 'Athlete ID missing on 1 row'], quality: 45, source: 'CSV Upload' },
  { athleteId: 'a8', date: '2026-08-28', type: 'Training', issues: ['Contact data incomplete', 'GPS completeness 68%'], quality: 68, source: 'GPS/GNSS Provider' },
];
