// AthleteIQ Algorithm Engine — Stage 5A
// Central algorithm layer: validation → normalization → calculation → scoring → explainability
// Wraps existing algorithms in statisticalEngine.ts and demoData.ts with a unified interface

import {
  computeDescriptiveStats, computeEffectSize, computeMDC, computeConfidenceInterval,
  detectTrend, detectChangePoint, detectAnomalies, evaluateIntervention,
  computeCorrelation, computeDevelopmentIndex, computeDemandMatrix,
  computeLoadOptimization, assessEvidenceLevel, assessDataSufficiency,
  ALGORITHM_REGISTRY,
  type DescriptiveStats, type EffectSizeResult, type MDCResult, type CIResult,
  type TrendResult, type ChangePointResult, type AnomalyResult,
  type InterventionEvaluation, type CorrelationResult, type DevelopmentIndex,
  type DemandMatrixEntry, type LoadOptimization, type EvidenceAssessment,
  type DataSufficiency,
} from './statisticalEngine';
import {
  computeLoads, computeTrainingAverages, computeMatchAverages,
  computeGapStatus, classifyLoad, getLoadStatus, computeMonotony,
  getPositionalDemand,
} from './demoData';
import type {
  TrainingSession, MatchRecord, CapacityTest, Intervention, Athlete,
  LoadStatus, LoadClassification, GapStatus,
} from './types';

// ===== ALGORITHM IDs =====

export type AlgorithmId =
  | 'TRAINING_LOAD' | 'ACWR' | 'MONOTONY' | 'LOAD_STATUS' | 'LOAD_CLASSIFICATION'
  | 'TRAINING_AVERAGES' | 'MATCH_AVERAGES' | 'GAP_STATUS'
  | 'DESCRIPTIVE_STATS' | 'EFFECT_SIZE' | 'MDC' | 'CONFIDENCE_INTERVAL'
  | 'TREND_DETECTION' | 'CHANGE_POINT' | 'ANOMALY_DETECTION'
  | 'INTERVENTION_EVALUATION' | 'CORRELATION' | 'DEVELOPMENT_INDEX'
  | 'DEMAND_MATRIX' | 'LOAD_OPTIMIZATION' | 'EVIDENCE_LEVEL'
  | 'DATA_SUFFICIENCY';

export type AlgorithmStatus = 'draft' | 'implemented' | 'tested' | 'validated' | 'frozen';

export interface AlgorithmMeta {
  id: AlgorithmId;
  name: string;
  version: string;
  status: AlgorithmStatus;
  purpose: string;
  requiredInputs: string[];
  outputUnit: string;
  knownLimitations: string[];
}

// ===== ALGORITHM METADATA REGISTRY =====
// Extends ALGORITHM_REGISTRY with structured metadata for Stage 5A

export const ALGORITHM_METADATA: AlgorithmMeta[] = [
  {
    id: 'TRAINING_LOAD', name: 'Training Load (sRPE)', version: 'v1.0', status: 'frozen',
    purpose: 'Calculate session training load as Session RPE × Duration',
    requiredInputs: ['sessionRPE', 'duration'],
    outputUnit: 'AU',
    knownLimitations: ['Depends on accurate RPE reporting', 'Subjective measure'],
  },
  {
    id: 'ACWR', name: 'Acute:Chronic Workload Ratio', version: 'v1.0', status: 'frozen',
    purpose: '7-day acute load divided by 28-day chronic load',
    requiredInputs: ['trainingLoad per session', 'date per session'],
    outputUnit: 'ratio',
    knownLimitations: ['Rolling average method has known limitations', 'Does not account for load distribution within windows'],
  },
  {
    id: 'MONOTONY', name: 'Training Monotony', version: 'v1.0', status: 'frozen',
    purpose: 'Mean training load divided by standard deviation across sessions',
    requiredInputs: ['trainingLoad per session'],
    outputUnit: 'ratio',
    knownLimitations: ['Highly sensitive to outliers in small samples', 'Requires ≥5 sessions for stability'],
  },
  {
    id: 'LOAD_STATUS', name: 'Load Status', version: 'v1.0', status: 'frozen',
    purpose: 'Classify load as LOW, OPTIMAL, HIGH, or FLAG based on ACWR',
    requiredInputs: ['acute load', 'chronic load'],
    outputUnit: 'category',
    knownLimitations: ['Threshold-based classification', 'Does not account for individual tolerance'],
  },
  {
    id: 'LOAD_CLASSIFICATION', name: 'Load Classification', version: 'v1.0', status: 'frozen',
    purpose: 'Classify load magnitude as Low, Moderate, High, or Very High',
    requiredInputs: ['acute load', 'chronic load'],
    outputUnit: 'category',
    knownLimitations: ['Absolute thresholds may not suit all sports'],
  },
  {
    id: 'TRAINING_AVERAGES', name: 'Training Averages', version: 'v1.0', status: 'frozen',
    purpose: 'Compute mean values across training sessions for all GPS/load metrics',
    requiredInputs: ['training sessions'],
    outputUnit: 'various',
    knownLimitations: ['Simple mean — does not weight by session importance'],
  },
  {
    id: 'MATCH_AVERAGES', name: 'Match Averages', version: 'v1.0', status: 'frozen',
    purpose: 'Compute mean values across match records for all GPS/load metrics',
    requiredInputs: ['match records'],
    outputUnit: 'various',
    knownLimitations: ['Does not account for minutes played per match'],
  },
  {
    id: 'GAP_STATUS', name: 'Training-Match Gap Status', version: 'v1.0', status: 'frozen',
    purpose: 'Classify training vs match exposure as UNDEREXPOSURE, APPROPRIATE, or EXCESSIVE',
    requiredInputs: ['training average', 'match average'],
    outputUnit: 'category',
    knownLimitations: ['Threshold-based', 'Does not account for match minutes variability'],
  },
  {
    id: 'DESCRIPTIVE_STATS', name: 'Descriptive Statistics', version: 'v1.0', status: 'frozen',
    purpose: 'Compute mean, median, stdDev, CV, quartiles, IQR for a set of values',
    requiredInputs: ['numeric values array'],
    outputUnit: 'various',
    knownLimitations: ['Returns null for empty arrays', 'Population stdDev (not sample stdDev)'],
  },
  {
    id: 'EFFECT_SIZE', name: "Effect Size (Cohen's d)", version: 'v1.0', status: 'frozen',
    purpose: 'Standardized mean difference between pre and post values using pooled SD',
    requiredInputs: ['preValues array', 'postValues array', 'higherIsBetter flag'],
    outputUnit: 'd',
    knownLimitations: ['Requires ≥2 values per group', 'Returns null if pooled SD is 0', 'Assumes normal distribution'],
  },
  {
    id: 'MDC', name: 'Minimal Detectable Change', version: 'v1.0', status: 'frozen',
    purpose: 'Compute MDC as 1.96 × SEM × √2 to determine if observed change is meaningful',
    requiredInputs: ['values array', 'preValue', 'postValue'],
    outputUnit: 'same as input',
    knownLimitations: ['Requires ≥2 values', 'Assumes test-retest reliability', 'SEM uses population SD'],
  },
  {
    id: 'CONFIDENCE_INTERVAL', name: 'Confidence Interval', version: 'v1.0', status: 'frozen',
    purpose: 'Compute mean ± t×SEM for a given confidence level',
    requiredInputs: ['numeric values array'],
    outputUnit: 'same as input',
    knownLimitations: ['Requires ≥3 values', 'Uses hardcoded t-values for small samples', 'Not reliable with n<10'],
  },
  {
    id: 'TREND_DETECTION', name: 'Trend Detection', version: 'v1.0', status: 'frozen',
    purpose: 'Linear regression with R² to classify trend direction and confidence',
    requiredInputs: ['time-value pairs'],
    outputUnit: 'category + slope',
    knownLimitations: ['Linear only — cannot detect non-linear trends', 'Requires ≥3 points'],
  },
  {
    id: 'CHANGE_POINT', name: 'Change-Point Detection', version: 'v0.5', status: 'tested',
    purpose: 'Half-split mean comparison to detect potential trend changes',
    requiredInputs: ['time-value pairs'],
    outputUnit: 'detection flag',
    knownLimitations: ['Experimental', 'Simple half-split method', 'Requires ≥6 points', 'Cannot pinpoint exact change date'],
  },
  {
    id: 'ANOMALY_DETECTION', name: 'Anomaly Detection', version: 'v1.0', status: 'frozen',
    purpose: 'Z-score based outlier flagging for training load, HR, and match distance',
    requiredInputs: ['training sessions', 'match records', 'capacity tests'],
    outputUnit: 'anomaly list',
    knownLimitations: ['Z-score assumes normal distribution', 'Requires ≥5 sessions for load, ≥3 for matches', 'Cannot detect subtle anomalies'],
  },
  {
    id: 'INTERVENTION_EVALUATION', name: 'Intervention Evaluation', version: 'v0.5', status: 'tested',
    purpose: 'Pre/during/post comparison with attribution assessment and limitations',
    requiredInputs: ['intervention', 'pre/during/post sessions', 'pre/post tests', 'targetMetric', 'higherIsBetter'],
    outputUnit: 'evaluation',
    knownLimitations: ['Experimental', 'Observational design — no causal inference', 'No control group comparison'],
  },
  {
    id: 'CORRELATION', name: 'Correlation (Pearson r)', version: 'v1.0', status: 'frozen',
    purpose: 'Pearson correlation coefficient between two variables',
    requiredInputs: ['x array', 'y array (≥5 paired values)'],
    outputUnit: 'r',
    knownLimitations: ['Linear only', 'Requires ≥5 paired values', 'Does not establish causation'],
  },
  {
    id: 'DEVELOPMENT_INDEX', name: 'Development Index', version: 'v0.5', status: 'tested',
    purpose: 'Composite 0-100 score from capacity, coverage, alignment, trend, and confidence',
    requiredInputs: ['5 component scores', 'dataSufficiency level'],
    outputUnit: 'score (0-100)',
    knownLimitations: ['Experimental', 'Equal weighting of components', 'Depends on quality of input scores'],
  },
  {
    id: 'DEMAND_MATRIX', name: 'Demand Matrix', version: 'v1.0', status: 'frozen',
    purpose: 'Per-demand coverage percentage and gap classification against position demands',
    requiredInputs: ['training averages', 'match averages', 'position demands', 'position weights'],
    outputUnit: 'matrix',
    knownLimitations: ['Coverage capped at 120%', 'Gap thresholds are fixed'],
  },
  {
    id: 'LOAD_OPTIMIZATION', name: 'Load Optimization', version: 'v1.0', status: 'frozen',
    purpose: 'Classify load as underexposed, aligned, overexposed, rapid change, or uncertain',
    requiredInputs: ['training avg', 'match avg', 'baseline', 'recentChange', 'dataSufficiency'],
    outputUnit: 'category + recommendations',
    knownLimitations: ['Threshold-based', 'Does not account for individual recovery capacity'],
  },
  {
    id: 'EVIDENCE_LEVEL', name: 'Evidence Hierarchy', version: 'v1.0', status: 'frozen',
    purpose: 'Assess evidence level (1-5) from observation to causal claim',
    requiredInputs: ['observations count', 'consistency', 'association', 'controlledDesign'],
    outputUnit: 'level (1-5)',
    knownLimitations: ['Descriptive classification', 'Does not replace formal research design'],
  },
  {
    id: 'DATA_SUFFICIENCY', name: 'Data Sufficiency Assessment', version: 'v1.0', status: 'frozen',
    purpose: 'Assess whether sufficient data exists for reliable analysis',
    requiredInputs: ['sessions', 'matches', 'capacityTests', 'interventions', 'dataCompleteness'],
    outputUnit: 'level + reason',
    knownLimitations: ['Threshold-based', 'Does not account for data quality beyond completeness'],
  },
];

// ===== VALIDATION =====

export type ValidationErrorCode =
  | 'MISSING_REQUIRED_INPUT' | 'INVALID_TYPE' | 'OUT_OF_RANGE' | 'EMPTY_ARRAY'
  | 'INSUFFICIENT_DATA' | 'DIVISION_BY_ZERO' | 'INVALID_VALUE' | 'DUPLICATE_DETECTED';

export interface ValidationError {
  code: ValidationErrorCode;
  field: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
}

function isNumber(v: unknown): v is number {
  return typeof v === 'number' && !isNaN(v) && isFinite(v);
}

export function validateNumeric(value: unknown, field: string, opts?: { min?: number; max?: number; required?: boolean }): ValidationError | null {
  if (value === null || value === undefined || (typeof value === 'number' && isNaN(value))) {
    if (opts?.required !== false) {
      return { code: 'MISSING_REQUIRED_INPUT', field, message: `${field} is required but missing or NaN` };
    }
    return null;
  }
  if (!isNumber(value)) {
    return { code: 'INVALID_TYPE', field, message: `${field} must be a number, got ${typeof value}` };
  }
  if (opts?.min !== undefined && value < opts.min) {
    return { code: 'OUT_OF_RANGE', field, message: `${field} = ${value} is below minimum ${opts.min}` };
  }
  if (opts?.max !== undefined && value > opts.max) {
    return { code: 'OUT_OF_RANGE', field, message: `${field} = ${value} exceeds maximum ${opts.max}` };
  }
  return null;
}

export function validateArray(values: unknown[], field: string, opts?: { minLength?: number }): ValidationError | null {
  if (!Array.isArray(values)) {
    return { code: 'INVALID_TYPE', field, message: `${field} must be an array` };
  }
  if (values.length === 0) {
    return { code: 'EMPTY_ARRAY', field, message: `${field} is empty` };
  }
  if (opts?.minLength !== undefined && values.length < opts.minLength) {
    return { code: 'INSUFFICIENT_DATA', field, message: `${field} has ${values.length} elements, need ≥${opts.minLength}` };
  }
  return null;
}

// ===== NORMALIZATION =====

export interface NormalizedInput {
  value: number;
  unit: string;
  warnings: string[];
}

export function normalizeInput(value: number, sourceUnit: string, targetUnit: string): NormalizedInput {
  const warnings: string[] = [];
  let normalized = value;

  const conversions: Record<string, number> = {
    'km→m': 1000,
    'm→km': 0.001,
    's→min': 1 / 60,
    'min→s': 60,
    'h→min': 60,
    'min→h': 1 / 60,
    'm/s→km/h': 3.6,
    'km/h→m/s': 1 / 3.6,
  };

  const key = `${sourceUnit}→${targetUnit}`;
  if (conversions[key]) {
    normalized = value * conversions[key];
  } else if (sourceUnit !== targetUnit) {
    warnings.push(`No conversion factor for ${sourceUnit}→${targetUnit}, using value as-is`);
  }

  return { value: normalized, unit: targetUnit, warnings };
}

// ===== CALCULATION RESULT WITH EXPLAINABILITY =====

export interface CalculationResult<T> {
  algorithmId: AlgorithmId;
  algorithmVersion: string;
  inputs: Record<string, unknown>;
  intermediateValues: Record<string, unknown>;
  result: T | null;
  validation: ValidationResult;
  interpretation: string;
  timestamp: string;
}

// ===== ALGORITHM EXECUTION FUNCTIONS =====

export function calcTrainingLoad(rpe: number, durationMin: number): CalculationResult<number> {
  const errors: ValidationError[] = [];
  const rpeErr = validateNumeric(rpe, 'rpe', { min: 0, max: 10 });
  const durErr = validateNumeric(durationMin, 'duration', { min: 0, max: 300 });
  if (rpeErr) errors.push(rpeErr);
  if (durErr) errors.push(durErr);

  const valid = errors.length === 0;
  const result = valid ? rpe * durationMin : null;

  return {
    algorithmId: 'TRAINING_LOAD',
    algorithmVersion: 'v1.0',
    inputs: { rpe, duration: durationMin },
    intermediateValues: { formula: 'rpe × duration' },
    result,
    validation: { valid, errors },
    interpretation: result !== null ? `${rpe} × ${durationMin} = ${result} AU` : 'Invalid inputs',
    timestamp: new Date().toISOString(),
  };
}

export function calcACWR(sessions: TrainingSession[]): CalculationResult<{ acute: number; chronic: number; acwr: number; status: LoadStatus; classification: LoadClassification }> {
  const errors: ValidationError[] = [];
  const arrErr = validateArray(sessions, 'sessions', { minLength: 1 });
  if (arrErr) errors.push(arrErr);

  const valid = errors.length === 0;
  let result: { acute: number; chronic: number; acwr: number; status: LoadStatus; classification: LoadClassification } | null = null;

  if (valid) {
    const loads = computeLoads(sessions);
    result = {
      acute: loads.acute,
      chronic: loads.chronic,
      acwr: loads.acwr,
      status: getLoadStatus(loads.acute, loads.chronic),
      classification: classifyLoad(loads.acute, loads.chronic),
    };
  }

  return {
    algorithmId: 'ACWR',
    algorithmVersion: 'v1.0',
    inputs: { sessionCount: sessions.length },
    intermediateValues: { formula: 'acute(7d) / chronic(28d)' },
    result,
    validation: { valid, errors },
    interpretation: result ? `Acute: ${result.acute} AU, Chronic: ${result.chronic} AU, ACWR: ${result.acwr.toFixed(2)} (${result.status})` : 'Insufficient sessions',
    timestamp: new Date().toISOString(),
  };
}

export function calcGapStatus(trainAvg: number, matchAvg: number): CalculationResult<{ percentDiff: number; status: GapStatus }> {
  const errors: ValidationError[] = [];
  const trainErr = validateNumeric(trainAvg, 'trainAvg');
  const matchErr = validateNumeric(matchAvg, 'matchAvg', { min: 0 });
  if (trainErr) errors.push(trainErr);
  if (matchErr) errors.push(matchErr);

  if (matchAvg === 0) {
    errors.push({ code: 'DIVISION_BY_ZERO', field: 'matchAvg', message: 'matchAvg is 0 — cannot compute gap' });
  }

  const valid = errors.length === 0;
  const result = valid ? computeGapStatus(trainAvg, matchAvg) : null;

  return {
    algorithmId: 'GAP_STATUS',
    algorithmVersion: 'v1.0',
    inputs: { trainAvg, matchAvg },
    intermediateValues: { formula: '(train - match) / match × 100' },
    result,
    validation: { valid, errors },
    interpretation: result ? `Gap: ${result.percentDiff.toFixed(1)}% (${result.status})` : 'Invalid inputs',
    timestamp: new Date().toISOString(),
  };
}

export function calcDescriptiveStats(values: number[]): CalculationResult<DescriptiveStats> {
  const errors: ValidationError[] = [];
  const arrErr = validateArray(values, 'values');
  if (arrErr) errors.push(arrErr);

  for (let i = 0; i < values.length; i++) {
    const err = validateNumeric(values[i], `values[${i}]`);
    if (err) errors.push(err);
  }

  const valid = errors.length === 0;
  const result = valid ? computeDescriptiveStats(values) : null;

  return {
    algorithmId: 'DESCRIPTIVE_STATS',
    algorithmVersion: 'v1.0',
    inputs: { count: values.length },
    intermediateValues: {},
    result,
    validation: { valid, errors },
    interpretation: result ? `Mean: ${result.mean}, SD: ${result.stdDev}, CV: ${result.cv}%` : 'Invalid inputs',
    timestamp: new Date().toISOString(),
  };
}

export function calcEffectSize(preValues: number[], postValues: number[], higherIsBetter: boolean): CalculationResult<EffectSizeResult> {
  const errors: ValidationError[] = [];
  const preErr = validateArray(preValues, 'preValues', { minLength: 2 });
  const postErr = validateArray(postValues, 'postValues', { minLength: 2 });
  if (preErr) errors.push(preErr);
  if (postErr) errors.push(postErr);

  const valid = errors.length === 0;
  const result = valid ? computeEffectSize(preValues, postValues, higherIsBetter) : null;

  return {
    algorithmId: 'EFFECT_SIZE',
    algorithmVersion: 'v1.0',
    inputs: { preCount: preValues.length, postCount: postValues.length, higherIsBetter },
    intermediateValues: { formula: "(postMean - preMean) / pooledSD" },
    result,
    validation: { valid, errors },
    interpretation: result ? result.interpretation : 'Insufficient data',
    timestamp: new Date().toISOString(),
  };
}

export function calcMDC(values: number[], preValue: number, postValue: number): CalculationResult<MDCResult> {
  const errors: ValidationError[] = [];
  const arrErr = validateArray(values, 'values', { minLength: 2 });
  if (arrErr) errors.push(arrErr);
  const preErr = validateNumeric(preValue, 'preValue');
  const postErr = validateNumeric(postValue, 'postValue');
  if (preErr) errors.push(preErr);
  if (postErr) errors.push(postErr);

  const valid = errors.length === 0;
  const result = valid ? computeMDC(values, preValue, postValue) : null;

  return {
    algorithmId: 'MDC',
    algorithmVersion: 'v1.0',
    inputs: { valueCount: values.length, preValue, postValue },
    intermediateValues: { formula: '1.96 × (SD/√2) × √2' },
    result,
    validation: { valid, errors },
    interpretation: result ? result.interpretation : 'Insufficient data',
    timestamp: new Date().toISOString(),
  };
}

export function calcConfidenceInterval(values: number[], level: number = 0.95): CalculationResult<CIResult> {
  const errors: ValidationError[] = [];
  const arrErr = validateArray(values, 'values', { minLength: 3 });
  if (arrErr) errors.push(arrErr);

  const valid = errors.length === 0;
  const result = valid ? computeConfidenceInterval(values, level) : null;

  return {
    algorithmId: 'CONFIDENCE_INTERVAL',
    algorithmVersion: 'v1.0',
    inputs: { count: values.length, level },
    intermediateValues: { formula: 'mean ± t × SEM' },
    result,
    validation: { valid, errors },
    interpretation: result ? result.interpretation : 'Insufficient data',
    timestamp: new Date().toISOString(),
  };
}

export function calcTrend(values: { date: string; value: number }[], higherIsBetter: boolean): CalculationResult<TrendResult> {
  const errors: ValidationError[] = [];
  const arrErr = validateArray(values, 'values', { minLength: 3 });
  if (arrErr) errors.push(arrErr);

  const valid = errors.length === 0;
  const result = valid ? detectTrend(values, higherIsBetter) : null;

  return {
    algorithmId: 'TREND_DETECTION',
    algorithmVersion: 'v1.0',
    inputs: { pointCount: values.length, higherIsBetter },
    intermediateValues: { method: 'linear regression with R²' },
    result,
    validation: { valid, errors },
    interpretation: result ? result.interpretation : 'Insufficient data',
    timestamp: new Date().toISOString(),
  };
}

export function calcCorrelation(x: number[], y: number[]): CalculationResult<CorrelationResult> {
  const errors: ValidationError[] = [];
  if (x.length !== y.length) {
    errors.push({ code: 'INVALID_VALUE', field: 'x,y', message: 'x and y must have equal length' });
  }
  const arrErr = validateArray(x, 'x', { minLength: 5 });
  if (arrErr) errors.push(arrErr);

  const valid = errors.length === 0;
  const result = valid ? computeCorrelation(x, y) : null;

  return {
    algorithmId: 'CORRELATION',
    algorithmVersion: 'v1.0',
    inputs: { n: x.length },
    intermediateValues: { formula: 'Pearson r', warning: 'Correlation does not establish causation' },
    result,
    validation: { valid, errors },
    interpretation: result ? result.interpretation : 'Insufficient paired data',
    timestamp: new Date().toISOString(),
  };
}

export function calcDemandMatrix(params: {
  trainAvg: Record<string, number | undefined>;
  matchAvg: Record<string, number | undefined>;
  positionDemands: { label: string; value: string; unit: string; category: string }[];
  positionWeights: Record<string, 'high' | 'medium' | 'low'>;
}): CalculationResult<DemandMatrixEntry[]> {
  const errors: ValidationError[] = [];
  const arrErr = validateArray(params.positionDemands, 'positionDemands', { minLength: 1 });
  if (arrErr) errors.push(arrErr);

  const valid = errors.length === 0;
  const result = valid ? computeDemandMatrix(params) : null;

  return {
    algorithmId: 'DEMAND_MATRIX',
    algorithmVersion: 'v1.0',
    inputs: { demandCount: params.positionDemands.length },
    intermediateValues: { formula: 'min(train/match, 1.2) × 100' },
    result,
    validation: { valid, errors },
    interpretation: result ? `${result.length} demand metrics computed` : 'Invalid inputs',
    timestamp: new Date().toISOString(),
  };
}

export function calcLoadOptimization(params: {
  trainAvg: number; matchAvg: number; baseline: number; recentChange: number;
  dataSufficiency: 'sufficient' | 'limited' | 'insufficient';
}): CalculationResult<LoadOptimization> {
  const errors: ValidationError[] = [];
  const trainErr = validateNumeric(params.trainAvg, 'trainAvg');
  const matchErr = validateNumeric(params.matchAvg, 'matchAvg');
  const baseErr = validateNumeric(params.baseline, 'baseline');
  const changeErr = validateNumeric(params.recentChange, 'recentChange');
  if (trainErr) errors.push(trainErr);
  if (matchErr) errors.push(matchErr);
  if (baseErr) errors.push(baseErr);
  if (changeErr) errors.push(changeErr);

  const valid = errors.length === 0;
  const result = valid ? computeLoadOptimization(params) : null;

  return {
    algorithmId: 'LOAD_OPTIMIZATION',
    algorithmVersion: 'v1.0',
    inputs: params,
    intermediateValues: { formula: 'gap% and baseline-deviation thresholds' },
    result,
    validation: { valid, errors },
    interpretation: result ? result.description : 'Invalid inputs',
    timestamp: new Date().toISOString(),
  };
}

export function calcDevelopmentIndex(params: {
  capacityProgression: number; demandCoverage: number; loadAlignment: number;
  performanceTrend: number; dataConfidence: number;
  dataSufficiency: 'sufficient' | 'limited' | 'insufficient';
}): CalculationResult<DevelopmentIndex> {
  const errors: ValidationError[] = [];
  const components = ['capacityProgression', 'demandCoverage', 'loadAlignment', 'performanceTrend', 'dataConfidence'] as const;
  for (const key of components) {
    const err = validateNumeric(params[key], key, { min: 0, max: 100 });
    if (err) errors.push(err);
  }

  const valid = errors.length === 0;
  const result = valid ? computeDevelopmentIndex(params) : null;

  return {
    algorithmId: 'DEVELOPMENT_INDEX',
    algorithmVersion: 'v0.5',
    inputs: params,
    intermediateValues: { formula: 'mean of 5 components' },
    result,
    validation: { valid, errors },
    interpretation: result ? `Score: ${result.score}/100 (${result.confidence} confidence)` : 'Invalid inputs',
    timestamp: new Date().toISOString(),
  };
}

export function calcEvidenceLevel(params: {
  observations: number; consistency: boolean; association: boolean; controlledDesign: boolean;
}): CalculationResult<EvidenceAssessment> {
  const errors: ValidationError[] = [];
  const obsErr = validateNumeric(params.observations, 'observations', { min: 0 });
  if (obsErr) errors.push(obsErr);

  const valid = errors.length === 0;
  const result = valid ? assessEvidenceLevel(params) : null;

  return {
    algorithmId: 'EVIDENCE_LEVEL',
    algorithmVersion: 'v1.0',
    inputs: params,
    intermediateValues: {},
    result,
    validation: { valid, errors },
    interpretation: result ? `Level ${result.level}: ${result.label}` : 'Invalid inputs',
    timestamp: new Date().toISOString(),
  };
}

export function calcDataSufficiency(params: {
  sessions: TrainingSession[]; matches: MatchRecord[];
  capacityTests: CapacityTest[]; interventions: Intervention[]; dataCompleteness?: number;
}): CalculationResult<DataSufficiency> {
  const errors: ValidationError[] = [];
  if (!params.sessions) errors.push({ code: 'MISSING_REQUIRED_INPUT', field: 'sessions', message: 'sessions array is required' });
  if (!params.matches) errors.push({ code: 'MISSING_REQUIRED_INPUT', field: 'matches', message: 'matches array is required' });

  const valid = errors.length === 0;
  const result = valid ? assessDataSufficiency(params) : null;

  return {
    algorithmId: 'DATA_SUFFICIENCY',
    algorithmVersion: 'v1.0',
    inputs: {
      sessions: params.sessions?.length ?? 0,
      matches: params.matches?.length ?? 0,
      capacityTests: params.capacityTests?.length ?? 0,
    },
    intermediateValues: {},
    result,
    validation: { valid, errors },
    interpretation: result ? `${result.level}: ${result.reason}` : 'Invalid inputs',
    timestamp: new Date().toISOString(),
  };
}

// ===== BENCHMARK LOOKUP =====

export interface BenchmarkResult {
  available: boolean;
  metric: string;
  sport?: string;
  position?: string;
  target?: string;
  range?: { min: number; max: number };
  source: string;
}

export function getBenchmark(metric: string, athlete?: Athlete): BenchmarkResult {
  if (!athlete) {
    return { available: false, metric, source: 'No athlete profile provided' };
  }

  const demands = getPositionalDemand(athlete.position);
  const demand = demands.find((d) =>
    d.label.toLowerCase().includes(metric.toLowerCase()) ||
    metric.toLowerCase().includes(d.label.toLowerCase())
  );

  if (!demand) {
    return { available: false, metric, sport: athlete.sport, position: athlete.position, source: 'No matching positional demand' };
  }

  const rangeMatch = demand.value.match(/(\d+\.?\d*)\s*[-–]\s*(\d+\.?\d*)/);
  let range: { min: number; max: number } | undefined;
  if (rangeMatch) {
    range = { min: parseFloat(rangeMatch[1]), max: parseFloat(rangeMatch[2]) };
  }

  return {
    available: true,
    metric: demand.label,
    sport: athlete.sport,
    position: athlete.position,
    target: demand.value,
    range,
    source: `Positional demands for ${athlete.position}`,
  };
}

// ===== EXPLAINABILITY =====

export function getCalculationExplanation(result: CalculationResult<unknown>): string {
  const lines: string[] = [];
  lines.push(`Algorithm: ${result.algorithmId} (${result.algorithmVersion})`);
  lines.push(`Inputs: ${JSON.stringify(result.inputs)}`);
  if (Object.keys(result.intermediateValues).length > 0) {
    lines.push(`Intermediate: ${JSON.stringify(result.intermediateValues)}`);
  }
  lines.push(`Validation: ${result.validation.valid ? 'PASSED' : 'FAILED — ' + result.validation.errors.map((e) => e.message).join('; ')}`);
  lines.push(`Result: ${result.result !== null ? JSON.stringify(result.result) : 'null'}`);
  lines.push(`Interpretation: ${result.interpretation}`);
  return lines.join('\n');
}

// ===== VERSION LOOKUP =====

export function getAlgorithmVersion(id: AlgorithmId): string {
  const meta = ALGORITHM_METADATA.find((m) => m.id === id);
  return meta?.version ?? 'unknown';
}

export function getAlgorithmStatus(id: AlgorithmId): AlgorithmStatus {
  const meta = ALGORITHM_METADATA.find((m) => m.id === id);
  return meta?.status ?? 'draft';
}

export function getAlgorithmMeta(id: AlgorithmId): AlgorithmMeta | undefined {
  return ALGORITHM_METADATA.find((m) => m.id === id);
}
