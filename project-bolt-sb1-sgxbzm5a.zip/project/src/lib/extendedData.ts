import type { Athlete, CapacityTest, TrainingSession, MatchRecord, AIInsight, Intervention, TimePeriod, ReadinessStatus, DataQualityStatus } from './types';
import { athletes as baseAthletes, capacityTests as baseTests, trainingSessions as baseSessions, matchRecords as baseMatches, aiInsights as baseInsights, computeLoads, getLoadStatus, computeTrainingAverages, computeMatchAverages, computeMonotony } from './demoData';

// 6 additional athletes (3 football, 3 rugby) to reach 5 per sport
export const extraAthletes: Athlete[] = [
  { id: 'a5', name: 'Marco Silva', sport: 'football', position: 'Centre Back', age: 27, team: 'City United FC', avatarColor: '#0891b2', initials: 'MS' },
  { id: 'a6', name: 'Liam Walsh', sport: 'football', position: 'Striker', age: 23, team: 'City United FC', avatarColor: '#ea580c', initials: 'LW' },
  { id: 'a7', name: 'Tendai Mhuri', sport: 'football', position: 'Full Back', age: 25, team: 'City United FC', avatarColor: '#65a30d', initials: 'TM' },
  { id: 'a8', name: 'Pieter Botha', sport: 'rugby', position: 'Lock', age: 24, team: 'Highland Rugby Club', avatarColor: '#9333ea', initials: 'PB' },
  { id: 'a9', name: 'Chris Williams', sport: 'rugby', position: 'Scrum-half', age: 22, team: 'Highland Rugby Club', avatarColor: '#0284c7', initials: 'CW' },
  { id: 'a10', name: 'Thabo Mokoena', sport: 'rugby', position: 'Wing', age: 21, team: 'Highland Rugby Club', avatarColor: '#dc2626', initials: 'TM' },
];

export const allAthletes: Athlete[] = [...baseAthletes, ...extraAthletes];

// Capacity tests for new athletes
export const extraCapacityTests: Record<string, CapacityTest[]> = {
  a5: [
    { id: 't24', category: 'Speed', name: '30 m Sprint', unit: 's', baseline: 4.45, latest: 4.35, previous: 4.38, benchmark: 4.20, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 4.45 }, { date: '2026-03-20', value: 4.42 }, { date: '2026-06-10', value: 4.38 }, { date: '2026-08-20', value: 4.35 }] },
    { id: 't25', category: 'Aerobic Capacity', name: 'Yo-Yo IR1', unit: 'm', baseline: 1700, latest: 2050, previous: 1950, benchmark: 2200, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 1700 }, { date: '2026-03-20', value: 1850 }, { date: '2026-06-10', value: 1950 }, { date: '2026-08-20', value: 2050 }] },
    { id: 't26', category: 'Strength / Power', name: 'Countermovement Jump', unit: 'cm', baseline: 40, latest: 45, previous: 43, benchmark: 52, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 40 }, { date: '2026-03-20', value: 42 }, { date: '2026-06-10', value: 43 }, { date: '2026-08-20', value: 45 }] },
    { id: 't27', category: 'Change of Direction', name: '505 Agility Test', unit: 's', baseline: 2.40, latest: 2.32, previous: 2.35, benchmark: 2.18, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 2.40 }, { date: '2026-03-20', value: 2.37 }, { date: '2026-06-10', value: 2.35 }, { date: '2026-08-20', value: 2.32 }] },
  ],
  a6: [
    { id: 't28', category: 'Speed', name: '30 m Sprint', unit: 's', baseline: 4.15, latest: 4.08, previous: 4.10, benchmark: 4.00, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 4.15 }, { date: '2026-03-20', value: 4.12 }, { date: '2026-06-10', value: 4.10 }, { date: '2026-08-20', value: 4.08 }] },
    { id: 't29', category: 'Speed', name: 'Maximum Velocity', unit: 'km/h', baseline: 31.5, latest: 33.0, previous: 32.5, benchmark: 34.0, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 31.5 }, { date: '2026-03-20', value: 32.0 }, { date: '2026-06-10', value: 32.5 }, { date: '2026-08-20', value: 33.0 }] },
    { id: 't30', category: 'Repeated Sprint Ability', name: 'RSA Test (6×40m)', unit: '% decrement', baseline: 7.0, latest: 4.5, previous: 5.2, benchmark: 3.0, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 7.0 }, { date: '2026-03-20', value: 6.0 }, { date: '2026-06-10', value: 5.2 }, { date: '2026-08-20', value: 4.5 }] },
    { id: 't31', category: 'Aerobic Capacity', name: 'Yo-Yo IR1', unit: 'm', baseline: 1900, latest: 2150, previous: 2050, benchmark: 2400, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 1900 }, { date: '2026-03-20', value: 2000 }, { date: '2026-06-10', value: 2050 }, { date: '2026-08-20', value: 2150 }] },
  ],
  a7: [
    { id: 't32', category: 'Speed', name: '30 m Sprint', unit: 's', baseline: 4.25, latest: 4.18, previous: 4.20, benchmark: 4.05, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 4.25 }, { date: '2026-03-20', value: 4.22 }, { date: '2026-06-10', value: 4.20 }, { date: '2026-08-20', value: 4.18 }] },
    { id: 't33', category: 'Aerobic Capacity', name: 'Yo-Yo IR1', unit: 'm', baseline: 1950, latest: 2250, previous: 2150, benchmark: 2400, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 1950 }, { date: '2026-03-20', value: 2050 }, { date: '2026-06-10', value: 2150 }, { date: '2026-08-20', value: 2250 }] },
    { id: 't34', category: 'Speed', name: 'Maximum Velocity', unit: 'km/h', baseline: 30.0, latest: 31.5, previous: 31.0, benchmark: 33.0, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 30.0 }, { date: '2026-03-20', value: 30.5 }, { date: '2026-06-10', value: 31.0 }, { date: '2026-08-20', value: 31.5 }] },
    { id: 't35', category: 'Strength / Power', name: 'Countermovement Jump', unit: 'cm', baseline: 38, latest: 44, previous: 42, benchmark: 50, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 38 }, { date: '2026-03-20', value: 40 }, { date: '2026-06-10', value: 42 }, { date: '2026-08-20', value: 44 }] },
  ],
  a8: [
    { id: 't36', category: 'Speed', name: '30 m Sprint', unit: 's', baseline: 4.60, latest: 4.48, previous: 4.52, benchmark: 4.30, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 4.60 }, { date: '2026-03-20', value: 4.55 }, { date: '2026-06-10', value: 4.52 }, { date: '2026-08-20', value: 4.48 }] },
    { id: 't37', category: 'Strength / Power', name: 'Squat 1RM', unit: 'kg', baseline: 175, latest: 200, previous: 192, benchmark: 215, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 175 }, { date: '2026-03-20', value: 185 }, { date: '2026-06-10', value: 192 }, { date: '2026-08-20', value: 200 }] },
    { id: 't38', category: 'Aerobic Capacity', name: 'Yo-Yo IR1', unit: 'm', baseline: 1450, latest: 1750, previous: 1650, benchmark: 1900, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 1450 }, { date: '2026-03-20', value: 1550 }, { date: '2026-06-10', value: 1650 }, { date: '2026-08-20', value: 1750 }] },
    { id: 't39', category: 'Strength / Power', name: 'Countermovement Jump', unit: 'cm', baseline: 35, latest: 41, previous: 39, benchmark: 46, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 35 }, { date: '2026-03-20', value: 37 }, { date: '2026-06-10', value: 39 }, { date: '2026-08-20', value: 41 }] },
  ],
  a9: [
    { id: 't40', category: 'Speed', name: '30 m Sprint', unit: 's', baseline: 4.30, latest: 4.22, previous: 4.25, benchmark: 4.10, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 4.30 }, { date: '2026-03-20', value: 4.27 }, { date: '2026-06-10', value: 4.25 }, { date: '2026-08-20', value: 4.22 }] },
    { id: 't41', category: 'Aerobic Capacity', name: 'Yo-Yo IR1', unit: 'm', baseline: 1850, latest: 2150, previous: 2050, benchmark: 2300, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 1850 }, { date: '2026-03-20', value: 1950 }, { date: '2026-06-10', value: 2050 }, { date: '2026-08-20', value: 2150 }] },
    { id: 't42', category: 'Change of Direction', name: '505 Agility Test', unit: 's', baseline: 2.38, latest: 2.30, previous: 2.33, benchmark: 2.15, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 2.38 }, { date: '2026-03-20', value: 2.35 }, { date: '2026-06-10', value: 2.33 }, { date: '2026-08-20', value: 2.30 }] },
    { id: 't43', category: 'Repeated Sprint Ability', name: 'RSA Test (6×40m)', unit: '% decrement', baseline: 7.5, latest: 5.0, previous: 5.8, benchmark: 3.5, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 7.5 }, { date: '2026-03-20', value: 6.5 }, { date: '2026-06-10', value: 5.8 }, { date: '2026-08-20', value: 5.0 }] },
  ],
  a10: [
    { id: 't44', category: 'Speed', name: '30 m Sprint', unit: 's', baseline: 4.18, latest: 4.10, previous: 4.13, benchmark: 4.00, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 4.18 }, { date: '2026-03-20', value: 4.15 }, { date: '2026-06-10', value: 4.13 }, { date: '2026-08-20', value: 4.10 }] },
    { id: 't45', category: 'Speed', name: 'Maximum Velocity', unit: 'km/h', baseline: 31.0, latest: 32.8, previous: 32.2, benchmark: 34.0, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 31.0 }, { date: '2026-03-20', value: 31.5 }, { date: '2026-06-10', value: 32.2 }, { date: '2026-08-20', value: 32.8 }] },
    { id: 't46', category: 'Aerobic Capacity', name: 'Yo-Yo IR1', unit: 'm', baseline: 1750, latest: 2000, previous: 1900, benchmark: 2200, date: '2026-08-20', higherIsBetter: true, history: [{ date: '2026-01-15', value: 1750 }, { date: '2026-03-20', value: 1850 }, { date: '2026-06-10', value: 1900 }, { date: '2026-08-20', value: 2000 }] },
    { id: 't47', category: 'Repeated Sprint Ability', name: 'RSA Test (6×40m)', unit: '% decrement', baseline: 6.8, latest: 4.3, previous: 5.0, benchmark: 3.0, date: '2026-08-20', higherIsBetter: false, history: [{ date: '2026-01-15', value: 6.8 }, { date: '2026-03-20', value: 5.8 }, { date: '2026-06-10', value: 5.0 }, { date: '2026-08-20', value: 4.3 }] },
  ],
};

// Training session generator with data quality fields
function genTrainingSessionsWithQuality(athleteId: string, base: {
  dist: number; hsr: number; sprint: number; acc: number; dec: number; hie: number;
  avgHR: number; maxHR: number; rpe: number; contacts?: number; contactLoad?: number;
}): TrainingSession[] {
  const sessions: TrainingSession[] = [];
  const types = ['Technical', 'Tactical', 'Physical', 'Speed', 'Endurance', 'Strength', 'Recovery'];
  let seed = athleteId.charCodeAt(1) * 1000 + 500;
  const rand = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };

  for (let d = 27; d >= 0; d--) {
    const date = new Date(2026, 7, 29 - d);
    const dayOfWeek = date.getDay();
    if (dayOfWeek === 0 && rand() > 0.3) continue;
    if (dayOfWeek === 3 && rand() > 0.7) continue;

    const type = types[Math.floor(rand() * types.length)];
    const duration = 60 + Math.floor(rand() * 45);
    const variance = 0.8 + rand() * 0.4;
    const isHard = rand() > 0.7;

    const totalDistance = +(base.dist * variance * (isHard ? 1.15 : 0.95)).toFixed(2);
    const relativeDistance = +((totalDistance * 1000) / duration).toFixed(1);
    const highSpeedRunning = Math.round(base.hsr * variance * (isHard ? 1.25 : 0.85));
    const sprintDistance = Math.round(base.sprint * variance * (isHard ? 1.3 : 0.8));
    const accelerations = Math.round(base.acc * variance * (isHard ? 1.2 : 0.9));
    const decelerations = Math.round(base.dec * variance * (isHard ? 1.2 : 0.9));
    const highIntensityEfforts = Math.round(base.hie * variance * (isHard ? 1.25 : 0.85));
    const playerLoad = +(totalDistance * 12 + highSpeedRunning * 0.05 + accelerations * 0.8).toFixed(1);
    const avgHeartRate = Math.round(base.avgHR + (isHard ? 8 : -5) + (rand() - 0.5) * 6);
    const maxHeartRate = Math.round(base.maxHR + (isHard ? 5 : -3) + (rand() - 0.5) * 4);
    const sessionRPE = Math.min(10, Math.max(2, Math.round(base.rpe + (isHard ? 2 : -1.5) + (rand() - 0.5) * 2)));
    const trainingLoad = sessionRPE * duration;

    const z5 = Math.max(0, Math.round((isHard ? 12 : 5) + (rand() - 0.5) * 4));
    const z4 = Math.max(0, Math.round((isHard ? 25 : 15) + (rand() - 0.5) * 6));
    const z3 = Math.max(0, Math.round(30 + (rand() - 0.5) * 8));
    const z2 = Math.max(0, Math.round(20 + (rand() - 0.5) * 5));
    const z1 = Math.max(0, 100 - z5 - z4 - z3 - z2);

    const gpsCompleteness = Math.round(88 + rand() * 12);
    const hrCompleteness = Math.round(85 + rand() * 15);

    sessions.push({
      id: `${athleteId}-s${d}`, athleteId, date: date.toISOString().split('T')[0], type, duration,
      totalDistance, relativeDistance, highSpeedRunning, sprintDistance, accelerations, decelerations,
      highIntensityEfforts, playerLoad, avgHeartRate, maxHeartRate,
      hrZonePercent: { z1, z2, z3, z4, z5 }, sessionRPE, trainingLoad,
      contacts: base.contacts ? Math.round(base.contacts * variance) : undefined,
      contactLoad: base.contactLoad ? +(base.contactLoad * variance).toFixed(1) : undefined,
      gpsCompleteness, hrCompleteness,
    });
  }
  return sessions;
}

export const extraTrainingSessions: Record<string, TrainingSession[]> = {
  a5: genTrainingSessionsWithQuality('a5', { dist: 6.8, hsr: 350, sprint: 80, acc: 28, dec: 25, hie: 38, avgHR: 142, maxHR: 182, rpe: 6 }),
  a6: genTrainingSessionsWithQuality('a6', { dist: 7.0, hsr: 480, sprint: 200, acc: 38, dec: 34, hie: 48, avgHR: 146, maxHR: 186, rpe: 6 }),
  a7: genTrainingSessionsWithQuality('a7', { dist: 7.8, hsr: 600, sprint: 220, acc: 44, dec: 38, hie: 55, avgHR: 150, maxHR: 190, rpe: 6 }),
  a8: genTrainingSessionsWithQuality('a8', { dist: 5.5, hsr: 250, sprint: 100, acc: 26, dec: 24, hie: 32, avgHR: 138, maxHR: 180, rpe: 7, contacts: 16, contactLoad: 110 }),
  a9: genTrainingSessionsWithQuality('a9', { dist: 6.5, hsr: 450, sprint: 180, acc: 38, dec: 34, hie: 42, avgHR: 144, maxHR: 184, rpe: 6, contacts: 8, contactLoad: 50 }),
  a10: genTrainingSessionsWithQuality('a10', { dist: 6.2, hsr: 520, sprint: 240, acc: 40, dec: 35, hie: 44, avgHR: 146, maxHR: 186, rpe: 6, contacts: 6, contactLoad: 40 }),
};

export const extraMatchRecords: Record<string, MatchRecord[]> = {
  a5: [
    { id: 'm16', athleteId: 'a5', date: '2026-08-24', opponent: 'Riverside FC', duration: 90, minutesPlayed: 90, totalDistance: 9.2, relativeDistance: 102, highSpeedRunning: 750, sprintDistance: 220, accelerations: 30, decelerations: 28, highIntensityEfforts: 38, avgHeartRate: 162, maxHeartRate: 186, sessionRPE: 8 },
    { id: 'm17', athleteId: 'a5', date: '2026-08-17', opponent: 'Harbor City', duration: 90, minutesPlayed: 90, totalDistance: 8.8, relativeDistance: 98, highSpeedRunning: 680, sprintDistance: 190, accelerations: 28, decelerations: 25, highIntensityEfforts: 35, avgHeartRate: 160, maxHeartRate: 184, sessionRPE: 8 },
    { id: 'm18', athleteId: 'a5', date: '2026-08-10', opponent: 'Northside United', duration: 90, minutesPlayed: 90, totalDistance: 9.5, relativeDistance: 106, highSpeedRunning: 820, sprintDistance: 250, accelerations: 32, decelerations: 30, highIntensityEfforts: 42, avgHeartRate: 164, maxHeartRate: 188, sessionRPE: 9 },
  ],
  a6: [
    { id: 'm19', athleteId: 'a6', date: '2026-08-24', opponent: 'Riverside FC', duration: 90, minutesPlayed: 75, totalDistance: 9.5, relativeDistance: 105, highSpeedRunning: 1100, sprintDistance: 520, accelerations: 42, decelerations: 38, highIntensityEfforts: 55, avgHeartRate: 164, maxHeartRate: 188, sessionRPE: 8 },
    { id: 'm20', athleteId: 'a6', date: '2026-08-17', opponent: 'Harbor City', duration: 90, minutesPlayed: 90, totalDistance: 10.2, relativeDistance: 113, highSpeedRunning: 1250, sprintDistance: 580, accelerations: 45, decelerations: 40, highIntensityEfforts: 62, avgHeartRate: 166, maxHeartRate: 190, sessionRPE: 9 },
    { id: 'm21', athleteId: 'a6', date: '2026-08-10', opponent: 'Northside United', duration: 90, minutesPlayed: 60, totalDistance: 8.5, relativeDistance: 106, highSpeedRunning: 950, sprintDistance: 450, accelerations: 38, decelerations: 34, highIntensityEfforts: 48, avgHeartRate: 162, maxHeartRate: 186, sessionRPE: 8 },
  ],
  a7: [
    { id: 'm22', athleteId: 'a7', date: '2026-08-24', opponent: 'Riverside FC', duration: 90, minutesPlayed: 90, totalDistance: 10.5, relativeDistance: 117, highSpeedRunning: 1350, sprintDistance: 480, accelerations: 48, decelerations: 42, highIntensityEfforts: 65, avgHeartRate: 167, maxHeartRate: 191, sessionRPE: 9 },
    { id: 'm23', athleteId: 'a7', date: '2026-08-17', opponent: 'Harbor City', duration: 90, minutesPlayed: 90, totalDistance: 11.0, relativeDistance: 122, highSpeedRunning: 1450, sprintDistance: 520, accelerations: 50, decelerations: 44, highIntensityEfforts: 70, avgHeartRate: 168, maxHeartRate: 192, sessionRPE: 9 },
    { id: 'm24', athleteId: 'a7', date: '2026-08-10', opponent: 'Northside United', duration: 90, minutesPlayed: 85, totalDistance: 10.2, relativeDistance: 120, highSpeedRunning: 1280, sprintDistance: 450, accelerations: 45, decelerations: 40, highIntensityEfforts: 62, avgHeartRate: 165, maxHeartRate: 189, sessionRPE: 8 },
  ],
  a8: [
    { id: 'm25', athleteId: 'a8', date: '2026-08-23', opponent: 'Valley RFC', duration: 80, minutesPlayed: 80, totalDistance: 6.5, relativeDistance: 82, highSpeedRunning: 380, sprintDistance: 130, accelerations: 28, decelerations: 25, highIntensityEfforts: 32, avgHeartRate: 158, maxHeartRate: 184, sessionRPE: 9, contacts: 20, contactLoad: 160 },
    { id: 'm26', athleteId: 'a8', date: '2026-08-16', opponent: 'Mountain Springs', duration: 80, minutesPlayed: 80, totalDistance: 6.8, relativeDistance: 85, highSpeedRunning: 420, sprintDistance: 150, accelerations: 30, decelerations: 27, highIntensityEfforts: 35, avgHeartRate: 160, maxHeartRate: 185, sessionRPE: 9, contacts: 22, contactLoad: 175 },
    { id: 'm27', athleteId: 'a8', date: '2026-08-09', opponent: 'Coastal Rugby', duration: 80, minutesPlayed: 80, totalDistance: 6.2, relativeDistance: 78, highSpeedRunning: 350, sprintDistance: 120, accelerations: 26, decelerations: 23, highIntensityEfforts: 30, avgHeartRate: 156, maxHeartRate: 182, sessionRPE: 8, contacts: 18, contactLoad: 145 },
  ],
  a9: [
    { id: 'm28', athleteId: 'a9', date: '2026-08-23', opponent: 'Valley RFC', duration: 80, minutesPlayed: 80, totalDistance: 7.5, relativeDistance: 94, highSpeedRunning: 650, sprintDistance: 320, accelerations: 42, decelerations: 38, highIntensityEfforts: 44, avgHeartRate: 163, maxHeartRate: 187, sessionRPE: 9, contacts: 12, contactLoad: 80 },
    { id: 'm29', athleteId: 'a9', date: '2026-08-16', opponent: 'Mountain Springs', duration: 80, minutesPlayed: 80, totalDistance: 7.0, relativeDistance: 88, highSpeedRunning: 580, sprintDistance: 280, accelerations: 38, decelerations: 34, highIntensityEfforts: 40, avgHeartRate: 161, maxHeartRate: 186, sessionRPE: 8, contacts: 10, contactLoad: 65 },
    { id: 'm30', athleteId: 'a9', date: '2026-08-09', opponent: 'Coastal Rugby', duration: 80, minutesPlayed: 75, totalDistance: 6.8, relativeDistance: 85, highSpeedRunning: 520, sprintDistance: 250, accelerations: 35, decelerations: 32, highIntensityEfforts: 36, avgHeartRate: 159, maxHeartRate: 184, sessionRPE: 8, contacts: 8, contactLoad: 55 },
  ],
  a10: [
    { id: 'm31', athleteId: 'a10', date: '2026-08-23', opponent: 'Valley RFC', duration: 80, minutesPlayed: 80, totalDistance: 7.0, relativeDistance: 88, highSpeedRunning: 850, sprintDistance: 420, accelerations: 38, decelerations: 34, highIntensityEfforts: 42, avgHeartRate: 162, maxHeartRate: 188, sessionRPE: 8, contacts: 6, contactLoad: 45 },
    { id: 'm32', athleteId: 'a10', date: '2026-08-16', opponent: 'Mountain Springs', duration: 80, minutesPlayed: 80, totalDistance: 7.5, relativeDistance: 94, highSpeedRunning: 920, sprintDistance: 480, accelerations: 42, decelerations: 38, highIntensityEfforts: 48, avgHeartRate: 164, maxHeartRate: 190, sessionRPE: 9, contacts: 8, contactLoad: 55 },
    { id: 'm33', athleteId: 'a10', date: '2026-08-09', opponent: 'Coastal Rugby', duration: 80, minutesPlayed: 65, totalDistance: 6.2, relativeDistance: 82, highSpeedRunning: 720, sprintDistance: 350, accelerations: 32, decelerations: 28, highIntensityEfforts: 35, avgHeartRate: 160, maxHeartRate: 186, sessionRPE: 8, contacts: 5, contactLoad: 35 },
  ],
};

// Extra AI insights with confidence and dataQuality
export const extraAiInsights: AIInsight[] = [
  { id: 'i10', athleteId: 'a5', type: 'trend', severity: 'positive', finding: 'Centre back showing consistent aerobic improvement', evidence: 'Yo-Yo IR1: 1700m → 2050m | +20.6% over 7 months', interpretation: 'Aerobic capacity is developing well for this position. The athlete is within 7% of the positional benchmark.', action: 'Continue current aerobic conditioning. Retest in 6 weeks to monitor progression toward benchmark.', metric: 'Yo-Yo IR1', confidence: 'High', dataQuality: 'GOOD' },
  { id: 'i11', athleteId: 'a5', type: 'gap', severity: 'warning', finding: 'Sprint exposure below match demands for centre back', evidence: 'Training sprint avg: 80m | Match sprint avg: 220m | Gap: -64%', interpretation: 'Training does not adequately reproduce the sprint demands of match play for this position.', action: 'Add explosive sprint drills to 2 sessions per week. Target 120-150m of sprint distance per session.', metric: 'Sprint Distance', confidence: 'Moderate', dataQuality: 'GOOD' },
  { id: 'i12', athleteId: 'a6', type: 'anomaly', severity: 'warning', finding: 'Acute load spike detected', evidence: 'Acute: 3100 AU | Chronic: 2200 AU | ACWR: 1.41', interpretation: 'The acute-to-chronic workload ratio is elevated. This warrants a load management flag.', action: 'Reduce intensity in next 1-2 sessions. Monitor recovery before next match. Load management flag, not injury prediction.', metric: 'Training Load', confidence: 'Moderate', dataQuality: 'GOOD' },
  { id: 'i13', athleteId: 'a6', type: 'trend', severity: 'positive', finding: 'Maximum velocity approaching benchmark', evidence: 'Current: 33.0 km/h | Benchmark: 34.0 km/h | Gap: 3%', interpretation: 'Speed development is progressing well. The athlete is close to the positional benchmark.', action: 'Maintain sprint training. Focus on max velocity work. Retest in 4 weeks.', metric: 'Maximum Velocity', confidence: 'High', dataQuality: 'GOOD' },
  { id: 'i14', athleteId: 'a7', type: 'optimization', severity: 'info', finding: 'Training volume well matched to match demands', evidence: 'Training distance: 7.8 km | Match distance: 10.5 km | Gap: -26%', interpretation: 'Training volume is appropriately below match volume. HSR exposure could be increased.', action: 'Consider increasing HSR exposure in 1-2 sessions to better prepare for match demands.', metric: 'High-Speed Running', confidence: 'Moderate', dataQuality: 'GOOD' },
  { id: 'i15', athleteId: 'a8', type: 'gap', severity: 'warning', finding: 'Contact load below match demands for lock forward', evidence: 'Training contact load: 110 AU | Match contact load: 160 AU | Gap: -31%', interpretation: 'Training contact exposure does not adequately prepare the athlete for set-piece and maul demands.', action: 'Add controlled contact sessions 1-2x per week. Include maul and ruck technique work.', metric: 'Contact Load', confidence: 'Moderate', dataQuality: 'PARTIAL' },
  { id: 'i16', athleteId: 'a9', type: 'trend', severity: 'positive', finding: 'Agility performance improving steadily', evidence: '505 Test: 2.38s → 2.30s | Improvement: +3.4%', interpretation: 'Change of direction capacity is developing well, important for a scrum-half.', action: 'Continue agility development. Retest in 4 weeks.', metric: '505 Agility Test', confidence: 'High', dataQuality: 'GOOD' },
  { id: 'i17', athleteId: 'a10', type: 'trend', severity: 'positive', finding: 'Sprint performance improving rapidly', evidence: '30m sprint: 4.18s → 4.10s | Max velocity: 31.0 → 32.8 km/h', interpretation: 'Speed development is progressing well for a wing position where sprinting is critical.', action: 'Maintain sprint training stimulus. Retest in 4 weeks to confirm continued progression.', metric: '30 m Sprint', confidence: 'High', dataQuality: 'GOOD' },
  { id: 'i18', athleteId: 'a10', type: 'gap', severity: 'warning', finding: 'Aerobic capacity below positional benchmark', evidence: 'Yo-Yo IR1: 2000m | Benchmark: 2200m | Gap: -9%', interpretation: 'Aerobic capacity is below what is expected for a wing. The gap is moderate and closeable.', action: 'Add 1-2 aerobic conditioning sessions per week. Focus on MAS development.', metric: 'Yo-Yo IR1', confidence: 'Moderate', dataQuality: 'GOOD' },
];

// Interventions
export const interventions: Intervention[] = [
  {
    id: 'iv1', athleteId: 'a1', objective: 'Increase sprint exposure to match competition demands', metric: 'Sprint Distance',
    startDate: '2026-08-01', endDate: '2026-08-29', durationWeeks: 4,
    startingPoint: 110, target: 200, current: 165, unit: 'm',
    strategy: 'Controlled high-speed exposure during selected sessions with progressive overload',
    status: 'active',
  },
  {
    id: 'iv2', athleteId: 'a2', objective: 'Increase contact load to match competition demands', metric: 'Contact Load',
    startDate: '2026-08-01', endDate: '2026-08-29', durationWeeks: 4,
    startingPoint: 120, target: 170, current: 145, unit: 'AU',
    strategy: 'Controlled contact sessions including wrestle, tackle technique, and collision simulation',
    status: 'active',
  },
  {
    id: 'iv3', athleteId: 'a1', objective: 'Improve 30m sprint performance', metric: '30 m Sprint',
    startDate: '2026-01-15', endDate: '2026-08-20', durationWeeks: 31,
    startingPoint: 4.35, target: 4.20, current: 4.25, unit: 's',
    strategy: 'Progressive speed development with focus on acceleration mechanics and maximum velocity training',
    status: 'completed',
    results: { targetAchieved: false, capacityChanged: true, matchPerformanceChanged: true, similarityImproved: true, beforeValue: 4.35, afterValue: 4.25 },
  },
  {
    id: 'iv4', athleteId: 'a4', objective: 'Increase squat strength to positional benchmark', metric: 'Squat 1RM',
    startDate: '2026-06-01', endDate: '2026-08-29', durationWeeks: 13,
    startingPoint: 178, target: 210, current: 195, unit: 'kg',
    strategy: 'Maximal strength development focusing on squat, deadlift, and press progressions',
    status: 'active',
  },
  {
    id: 'iv5', athleteId: 'a6', objective: 'Reduce training load spike and manage ACWR', metric: 'Training Load',
    startDate: '2026-08-25', endDate: '2026-09-08', durationWeeks: 2,
    startingPoint: 3100, target: 2400, current: 3100, unit: 'AU',
    strategy: 'Reduce intensity in next 2-3 sessions, increase recovery, monitor ACWR return to optimal range',
    status: 'planned',
  },
];

// ===== Computation utilities =====

const periodDays: Record<TimePeriod, number> = {
  '7d': 7, '14d': 14, '28d': 28, '6w': 42, '8w': 56, '12w': 84, 'season': 168,
};

export function filterSessionsByPeriod(sessions: TrainingSession[], period: TimePeriod): TrainingSession[] {
  const days = periodDays[period];
  const sorted = [...sessions].sort((a, b) => b.date.localeCompare(a.date));
  const cutoff = new Date(sorted[0]?.date || '2026-08-29');
  cutoff.setDate(cutoff.getDate() - days);
  return sorted.filter((s) => new Date(s.date) >= cutoff);
}

export function filterMatchesByPeriod(matches: MatchRecord[], period: TimePeriod): MatchRecord[] {
  const days = periodDays[period];
  const sorted = [...matches].sort((a, b) => b.date.localeCompare(a.date));
  const cutoff = new Date(sorted[0]?.date || '2026-08-29');
  cutoff.setDate(cutoff.getDate() - days);
  return sorted.filter((m) => new Date(m.date) >= cutoff);
}

// Training-Match Similarity score
export function computeSimilarity(trainAvg: ReturnType<typeof computeTrainingAverages>, matchAvg: ReturnType<typeof computeMatchAverages>): {
  overall: number;
  breakdown: { metric: string; score: number }[];
} {
  if (!trainAvg || !matchAvg) return { overall: 0, breakdown: [] };
  const metrics = [
    { metric: 'Total Distance', train: trainAvg.totalDistance, match: matchAvg.totalDistance },
    { metric: 'High-Speed Running', train: trainAvg.highSpeedRunning, match: matchAvg.highSpeedRunning },
    { metric: 'Sprint Distance', train: trainAvg.sprintDistance, match: matchAvg.sprintDistance },
    { metric: 'Accelerations', train: trainAvg.accelerations, match: matchAvg.accelerations },
    { metric: 'Decelerations', train: trainAvg.decelerations, match: matchAvg.decelerations },
    { metric: 'High-Intensity Efforts', train: trainAvg.highIntensityEfforts, match: matchAvg.highIntensityEfforts },
  ];
  const breakdown = metrics.map((m) => {
    const ratio = m.match === 0 ? 0 : Math.min(m.train / m.match, 1.2);
    const score = Math.round(Math.min(ratio, 1) * 100);
    return { metric: m.metric, score };
  });
  const overall = Math.round(breakdown.reduce((s, b) => s + b.score, 0) / breakdown.length);
  return { overall, breakdown };
}

// Readiness computation
export function computeReadiness(athleteId: string): { status: ReadinessStatus; factors: { label: string; value: string; concern: boolean }[] } {
  const sessions = getAllTrainingSessions(athleteId);
  const matches = getAllMatchRecords(athleteId);
  const { acute, chronic, acwr } = computeLoads(sessions);
  const monotony = computeMonotony(sessions);
  const status = getLoadStatus(acute, chronic);

  const factors = [
    { label: 'ACWR', value: acwr.toFixed(2), concern: acwr > 1.3 || acwr < 0.7 },
    { label: '7-Day Load', value: `${acute.toLocaleString()} AU`, concern: acwr > 1.3 },
    { label: 'Chronic Load', value: `${chronic.toLocaleString()} AU`, concern: chronic < 1000 },
    { label: 'Monotony', value: monotony.toFixed(2), concern: monotony > 1.5 },
    { label: 'Recent Matches', value: `${matches.length}`, concern: matches.length > 2 },
  ];

  const concernCount = factors.filter((f) => f.concern).length;
  let readiness: ReadinessStatus = 'READY';
  if (concernCount >= 2 || status === 'FLAG') readiness = 'REVIEW';
  else if (concernCount >= 1 || status === 'HIGH') readiness = 'MONITOR';

  return { status: readiness, factors };
}

// What Changed analysis
export function computeWhatChanged(athleteId: string): { label: string; change: string; direction: 'up' | 'down' | 'neutral' }[] {
  const sessions = getAllTrainingSessions(athleteId);
  const sorted = [...sessions].sort((a, b) => b.date.localeCompare(a.date));
  const last7 = sorted.slice(0, 7);
  const prev7 = sorted.slice(7, 14);

  if (last7.length === 0 || prev7.length === 0) return [];

  const avg = (arr: TrainingSession[], key: keyof TrainingSession) =>
    arr.reduce((s, x) => s + (x[key] as number), 0) / arr.length;

  const items: { label: string; change: string; direction: 'up' | 'down' | 'neutral' }[] = [];
  const metrics: { label: string; key: keyof TrainingSession; suffix: string }[] = [
    { label: 'Session Duration', key: 'duration', suffix: 'm' },
    { label: 'Total Distance', key: 'totalDistance', suffix: 'km' },
    { label: 'High-Speed Running', key: 'highSpeedRunning', suffix: 'm' },
    { label: 'Sprint Distance', key: 'sprintDistance', suffix: 'm' },
    { label: 'Accelerations', key: 'accelerations', suffix: '' },
    { label: 'Training Load', key: 'trainingLoad', suffix: 'AU' },
  ];

  for (const m of metrics) {
    const recent = avg(last7, m.key);
    const previous = avg(prev7, m.key);
    const pct = previous === 0 ? 0 : ((recent - previous) / previous) * 100;
    const direction: 'up' | 'down' | 'neutral' = Math.abs(pct) < 3 ? 'neutral' : pct > 0 ? 'up' : 'down';
    items.push({ label: m.label, change: `${pct > 0 ? '+' : ''}${pct.toFixed(0)}%`, direction });
  }

  return items;
}

// Data quality computation
export function computeDataQuality(athleteId: string): { status: DataQualityStatus; gps: number; hr: number } {
  const sessions = getAllTrainingSessions(athleteId);
  if (sessions.length === 0) return { status: 'POOR', gps: 0, hr: 0 };
  const gpsAvg = sessions.reduce((s, x) => s + (x.gpsCompleteness || 95), 0) / sessions.length;
  const hrAvg = sessions.reduce((s, x) => s + (x.hrCompleteness || 90), 0) / sessions.length;
  const overall = (gpsAvg + hrAvg) / 2;
  const status: DataQualityStatus = overall >= 90 ? 'GOOD' : overall >= 75 ? 'PARTIAL' : 'POOR';
  return { status, gps: Math.round(gpsAvg), hr: Math.round(hrAvg) };
}

// ===== Unified getters =====

export function getAllAthletes(): Athlete[] {
  return allAthletes;
}

export function getAthleteById(id: string): Athlete | undefined {
  return allAthletes.find((a) => a.id === id);
}

export function getAllTrainingSessions(athleteId: string): TrainingSession[] {
  return [...(baseSessions[athleteId] || []), ...(extraTrainingSessions[athleteId] || [])];
}

export function getAllMatchRecords(athleteId: string): MatchRecord[] {
  return [...(baseMatches[athleteId] || []), ...(extraMatchRecords[athleteId] || [])];
}

export function getAllCapacityTests(athleteId: string): CapacityTest[] {
  return [...(baseTests[athleteId] || []), ...(extraCapacityTests[athleteId] || [])];
}

export function getAllInsights(athleteId: string): AIInsight[] {
  return [...baseInsights, ...extraAiInsights].filter((i) => i.athleteId === athleteId);
}

export function getAllInsightsList(): AIInsight[] {
  return [...baseInsights, ...extraAiInsights];
}

export function getInterventions(athleteId: string): Intervention[] {
  return interventions.filter((i) => i.athleteId === athleteId);
}

export function getAllInterventions(): Intervention[] {
  return interventions;
}

// Squad-level computation
export function computeSquadOverview() {
  return allAthletes.map((athlete) => {
    const sessions = getAllTrainingSessions(athlete.id);
    const matches = getAllMatchRecords(athlete.id);
    const { acute, chronic, acwr } = computeLoads(sessions);
    const status = getLoadStatus(acute, chronic);
    const trainAvg = computeTrainingAverages(sessions);
    const matchAvg = computeMatchAverages(matches);
    const similarity = computeSimilarity(trainAvg, matchAvg);
    const readiness = computeReadiness(athlete.id);
    const insights = getAllInsights(athlete.id);
    const flags = insights.filter((i) => i.severity === 'critical' || i.severity === 'warning').length;
    return { athlete, sessions, matches, acute, chronic, acwr, status, trainAvg, matchAvg, similarity, readiness, insights, flags };
  });
}
