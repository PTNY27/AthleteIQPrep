// AthleteIQ Data Pipeline — Stage 4
// Device-independent data ingestion, validation, normalization, and quality scoring

import type { Sport } from './types';

// ===== STANDARDIZED METRIC DICTIONARY =====

export interface MetricDefinition {
  key: string;
  label: string;
  unit: string;
  category: 'distance' | 'speed' | 'count' | 'physiological' | 'load' | 'contact';
  sportSpecific?: Sport[];
  aliases: string[];
  plausibility: { min: number; max: number };
}

export const METRIC_DICTIONARY: MetricDefinition[] = [
  { key: 'total_distance', label: 'Total Distance', unit: 'm', category: 'distance', aliases: ['total distance', 'distance', 'total dist', 'dist'], plausibility: { min: 0, max: 20000 } },
  { key: 'relative_distance', label: 'Relative Distance', unit: 'm/min', category: 'distance', aliases: ['relative distance', 'dist/min', 'distance per min', 'rel dist'], plausibility: { min: 0, max: 200 } },
  { key: 'high_speed_running', label: 'High-Speed Running', unit: 'm', category: 'distance', aliases: ['hsr', 'high speed running', 'high speed distance', 'high-speed distance', 'hsd', 'hsr dist'], plausibility: { min: 0, max: 5000 } },
  { key: 'sprint_distance', label: 'Sprint Distance', unit: 'm', category: 'distance', aliases: ['sprint distance', 'sprint dist', 'sprints', 'sprint'], plausibility: { min: 0, max: 3000 } },
  { key: 'max_velocity', label: 'Maximum Velocity', unit: 'km/h', category: 'speed', aliases: ['max speed', 'max velocity', 'maximum velocity', 'max v', 'top speed', 'peak speed'], plausibility: { min: 0, max: 45 } },
  { key: 'accelerations', label: 'Accelerations', unit: 'count', category: 'count', aliases: ['accelerations', 'acc', 'accels', 'accel count'], plausibility: { min: 0, max: 200 } },
  { key: 'decelerations', label: 'Decelerations', unit: 'count', category: 'count', aliases: ['decelerations', 'dec', 'decs', 'decel count'], plausibility: { min: 0, max: 200 } },
  { key: 'high_intensity_efforts', label: 'High-Intensity Efforts', unit: 'count', category: 'count', aliases: ['high intensity efforts', 'hie', 'hi efforts', 'intensity efforts'], plausibility: { min: 0, max: 300 } },
  { key: 'heart_rate_avg', label: 'Average Heart Rate', unit: 'bpm', category: 'physiological', aliases: ['heart rate', 'avg hr', 'average hr', 'hr avg', 'mean hr', 'heart rate avg'], plausibility: { min: 40, max: 220 } },
  { key: 'heart_rate_max', label: 'Max Heart Rate', unit: 'bpm', category: 'physiological', aliases: ['max hr', 'maximum hr', 'hr max', 'peak hr', 'heart rate max'], plausibility: { min: 40, max: 220 } },
  { key: 'session_rpe', label: 'Session RPE', unit: '0-10', category: 'load', aliases: ['rpe', 'session rpe', 'srpe', 'rate of perceived exertion'], plausibility: { min: 0, max: 10 } },
  { key: 'duration', label: 'Session Duration', unit: 'minutes', category: 'count', aliases: ['duration', 'session duration', 'time', 'length', 'minutes'], plausibility: { min: 1, max: 300 } },
  { key: 'player_load', label: 'Player Load', unit: 'AU', category: 'load', aliases: ['player load', 'load', 'total load', 'body load'], plausibility: { min: 0, max: 1000 } },
  // Rugby-specific
  { key: 'contact_count', label: 'Contacts', unit: 'count', category: 'contact', sportSpecific: ['rugby'], aliases: ['contacts', 'contact count', 'total contacts', 'collisions'], plausibility: { min: 0, max: 100 } },
  { key: 'collision_load', label: 'Collision Load', unit: 'AU', category: 'contact', sportSpecific: ['rugby'], aliases: ['collision load', 'contact load', 'contactload', 'collisionload'], plausibility: { min: 0, max: 500 } },
  { key: 'high_intensity_contacts', label: 'High-Intensity Contacts', unit: 'count', category: 'contact', sportSpecific: ['rugby'], aliases: ['high intensity contacts', 'hic', 'hi contacts', 'heavy contacts'], plausibility: { min: 0, max: 50 } },
];

export function getMetricByKey(key: string): MetricDefinition | undefined {
  return METRIC_DICTIONARY.find((m) => m.key === key);
}

// ===== COLUMN DETECTION =====

export interface ColumnMatch {
  sourceColumn: string;
  detectedMetric: string | null;
  confidence: 'high' | 'medium' | 'low' | 'none';
  unit: string;
  suggestions: string[];
}

export function detectColumn(sourceColumn: string): ColumnMatch {
  const normalized = sourceColumn.toLowerCase().trim();
  let bestMatch: MetricDefinition | null = null;
  let bestScore = 0;

  for (const metric of METRIC_DICTIONARY) {
    for (const alias of metric.aliases) {
      const aliasNorm = alias.toLowerCase();
      if (normalized === aliasNorm) {
        return { sourceColumn, detectedMetric: metric.key, confidence: 'high', unit: metric.unit, suggestions: [] };
      }
      if (normalized.includes(aliasNorm) || aliasNorm.includes(normalized)) {
        const score = Math.min(normalized.length, aliasNorm.length) / Math.max(normalized.length, aliasNorm.length);
        if (score > bestScore) {
          bestScore = score;
          bestMatch = metric;
        }
      }
    }
  }

  if (bestMatch && bestScore > 0.5) {
    return {
      sourceColumn,
      detectedMetric: bestMatch.key,
      confidence: bestScore > 0.8 ? 'high' : 'medium',
      unit: bestMatch.unit,
      suggestions: [],
    };
  }

  // Low-confidence suggestions
  const suggestions = METRIC_DICTIONARY
    .filter((m) => !m.sportSpecific)
    .map((m) => m.key)
    .slice(0, 5);

  return { sourceColumn, detectedMetric: null, confidence: 'none', unit: '', suggestions };
}

export function detectColumns(headers: string[]): ColumnMatch[] {
  return headers.map((h) => detectColumn(h));
}

// ===== UNIT NORMALIZATION =====

export interface NormalizedValue {
  originalValue: number;
  originalUnit: string;
  standardizedValue: number;
  standardizedUnit: string;
  converted: boolean;
}

export function normalizeUnit(value: number, sourceUnit: string, targetUnit: string): NormalizedValue {
  const conversions: Record<string, number> = {
    'km>m': 1000,
    'm>m': 1,
    's>min': 1 / 60,
    'min>min': 1,
    'h>min': 60,
    'km/h>km/h': 1,
    'm/s>km/h': 3.6,
    'bpm>bpm': 1,
    'count>count': 1,
    'au>au': 1,
  };

  const key = `${sourceUnit.toLowerCase()}>${targetUnit.toLowerCase()}`;
  const factor = conversions[key];

  if (factor !== undefined) {
    return {
      originalValue: value,
      originalUnit: sourceUnit,
      standardizedValue: value * factor,
      standardizedUnit: targetUnit,
      converted: factor !== 1,
    };
  }

  return {
    originalValue: value,
    originalUnit: sourceUnit,
    standardizedValue: value,
    standardizedUnit: targetUnit,
    converted: false,
  };
}

// ===== TIMESTAMP NORMALIZATION =====

export interface NormalizedTimestamp {
  original: string;
  normalized: string;
  timezone: string;
  format: 'iso' | 'unix' | 'date-only';
}

export function normalizeTimestamp(raw: string): NormalizedTimestamp {
  const trimmed = raw.trim();

  // Unix timestamp (seconds or milliseconds)
  if (/^\d{10}$/.test(trimmed) || /^\d{13}$/.test(trimmed)) {
    const ms = trimmed.length === 10 ? parseInt(trimmed) * 1000 : parseInt(trimmed);
    const d = new Date(ms);
    return { original: raw, normalized: d.toISOString(), timezone: 'UTC', format: 'unix' };
  }

  // ISO 8601
  if (/^\d{4}-\d{2}-\d{2}T/.test(trimmed)) {
    return { original: raw, normalized: new Date(trimmed).toISOString(), timezone: 'UTC', format: 'iso' };
  }

  // Date only (YYYY-MM-DD)
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    return { original: raw, normalized: new Date(trimmed).toISOString().split('T')[0], timezone: 'local', format: 'date-only' };
  }

  // DD/MM/YYYY or MM/DD/YYYY
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(trimmed)) {
    const parts = trimmed.split('/');
    const iso = `${parts[2]}-${parts[1]}-${parts[0]}`;
    return { original: raw, normalized: iso, timezone: 'local', format: 'date-only' };
  }

  return { original: raw, normalized: trimmed, timezone: 'unknown', format: 'date-only' };
}

// ===== ATHLETE MATCHING =====

export interface AthleteMatchResult {
  sourceId: string;
  matchedAthleteId: string | null;
  confidence: 'high' | 'medium' | 'low' | 'none';
  method: 'id' | 'name' | 'jersey' | 'device' | 'none';
  suggestions: string[];
}

export function matchAthlete(
  sourceId: string,
  sourceName: string | undefined,
  knownAthletes: { id: string; name: string; initials: string }[]
): AthleteMatchResult {
  // Direct ID match
  const idMatch = knownAthletes.find((a) => a.id === sourceId);
  if (idMatch) {
    return { sourceId, matchedAthleteId: idMatch.id, confidence: 'high', method: 'id', suggestions: [] };
  }

  // Name match
  if (sourceName) {
    const nameNorm = sourceName.toLowerCase().trim();
    const nameMatch = knownAthletes.find((a) => a.name.toLowerCase() === nameNorm);
    if (nameMatch) {
      return { sourceId, matchedAthleteId: nameMatch.id, confidence: 'high', method: 'name', suggestions: [] };
    }

    // Partial name match
    const partialMatches = knownAthletes.filter((a) => {
      const an = a.name.toLowerCase();
      return an.includes(nameNorm) || nameNorm.includes(an) || a.initials.toLowerCase() === nameNorm;
    });
    if (partialMatches.length === 1) {
      return { sourceId, matchedAthleteId: partialMatches[0].id, confidence: 'medium', method: 'name', suggestions: [] };
    }
    if (partialMatches.length > 1) {
      return { sourceId, matchedAthleteId: null, confidence: 'low', method: 'name', suggestions: partialMatches.map((a) => a.id) };
    }
  }

  // Jersey number match (e.g., "#17" → athlete with id ending in 17)
  if (sourceId.startsWith('#') || sourceId.startsWith('P') || sourceId.startsWith('p')) {
    const num = sourceId.replace(/[#Pp]/, '');
    const jerseyMatch = knownAthletes.find((a) => a.id.endsWith(num));
    if (jerseyMatch) {
      return { sourceId, matchedAthleteId: jerseyMatch.id, confidence: 'medium', method: 'jersey', suggestions: [] };
    }
  }

  return {
    sourceId,
    matchedAthleteId: null,
    confidence: 'none',
    method: 'none',
    suggestions: knownAthletes.slice(0, 5).map((a) => a.id),
  };
}

// ===== DUPLICATE DETECTION =====

export interface DuplicateResult {
  isDuplicate: boolean;
  existingFile?: string;
  matchCount: number;
  overlapPercent: number;
}

export function detectDuplicate(
  fileName: string,
  recordCount: number,
  dateRange: string,
  existingImports: { fileName: string; recordCount: number; dateRange: string }[]
): DuplicateResult {
  const exactName = existingImports.find((i) => i.fileName === fileName);
  if (exactName) {
    return { isDuplicate: true, existingFile: exactName.fileName, matchCount: exactName.recordCount, overlapPercent: 100 };
  }

  const similarRange = existingImports.filter((i) => i.dateRange === dateRange && i.recordCount === recordCount);
  if (similarRange.length > 0) {
    return { isDuplicate: true, existingFile: similarRange[0].fileName, matchCount: similarRange[0].recordCount, overlapPercent: 85 };
  }

  return { isDuplicate: false, matchCount: 0, overlapPercent: 0 };
}

// ===== VALIDATION ENGINE =====

export type ValidationLevel = 'error' | 'warning' | 'info';
export type DataSource = 'live' | 'imported' | 'demo';

export interface ValidationIssue {
  row: number;
  column: string;
  level: ValidationLevel;
  message: string;
  value?: string;
}

export interface ValidatedRow {
  rowNumber: number;
  valid: boolean;
  warnings: number;
  errors: number;
  data: Record<string, string>;
  issues: ValidationIssue[];
}

export interface ValidationResult {
  totalRows: number;
  validRows: number;
  warningRows: number;
  rejectedRows: number;
  issues: ValidationIssue[];
  rows: ValidatedRow[];
  qualityScore: number;
}

export function validateRow(
  row: Record<string, string>,
  rowNumber: number,
  columnMap: Record<string, string>,
  unitMap: Record<string, string>
): ValidatedRow {
  const issues: ValidationIssue[] = [];
  let errors = 0;
  let warnings = 0;

  for (const [sourceCol, metricKey] of Object.entries(columnMap)) {
    if (!metricKey) continue;
    const metric = getMetricByKey(metricKey);
    if (!metric) continue;

    const rawValue = row[sourceCol];
    if (rawValue === undefined || rawValue === null || rawValue === '') {
      issues.push({ row: rowNumber, column: sourceCol, level: 'warning', message: `${metric.label} missing`, value: rawValue });
      warnings++;
      continue;
    }

    const numValue = parseFloat(rawValue);
    if (isNaN(numValue)) {
      issues.push({ row: rowNumber, column: sourceCol, level: 'error', message: `${metric.label} is not a number`, value: rawValue });
      errors++;
      continue;
    }

    // Plausibility check
    if (numValue < metric.plausibility.min) {
      issues.push({ row: rowNumber, column: sourceCol, level: 'error', message: `${metric.label} below plausible minimum (${metric.plausibility.min} ${metric.unit})`, value: rawValue });
      errors++;
    } else if (numValue > metric.plausibility.max) {
      issues.push({ row: rowNumber, column: sourceCol, level: 'warning', message: `${metric.label} above plausible maximum (${metric.plausibility.max} ${metric.unit}) — review required`, value: rawValue });
      warnings++;
    }
  }

  // Timestamp check
  const tsCol = Object.entries(columnMap).find(([, v]) => v === 'timestamp');
  if (tsCol) {
    const tsVal = row[tsCol[0]];
    if (!tsVal) {
      issues.push({ row: rowNumber, column: tsCol[0], level: 'error', message: 'Timestamp missing' });
      errors++;
    }
  }

  // Athlete ID check
  const athleteCol = Object.entries(columnMap).find(([, v]) => v === 'athlete_id');
  if (athleteCol) {
    const athleteVal = row[athleteCol[0]];
    if (!athleteVal) {
      issues.push({ row: rowNumber, column: athleteCol[0], level: 'error', message: 'Athlete ID missing' });
      errors++;
    }
  }

  return {
    rowNumber,
    valid: errors === 0,
    warnings,
    errors,
    data: row,
    issues,
  };
}

export function validateDataset(
  rows: Record<string, string>[],
  columnMap: Record<string, string>,
  unitMap: Record<string, string>
): ValidationResult {
  const validatedRows: ValidatedRow[] = rows.map((row, i) => validateRow(row, i + 1, columnMap, unitMap));
  const allIssues: ValidationIssue[] = validatedRows.flatMap((r) => r.issues);

  const validRows = validatedRows.filter((r) => r.valid && r.warnings === 0).length;
  const warningRows = validatedRows.filter((r) => r.valid && r.warnings > 0).length;
  const rejectedRows = validatedRows.filter((r) => !r.valid).length;
  const totalRows = validatedRows.length;

  const errorCount = allIssues.filter((i) => i.level === 'error').length;
  const warningCount = allIssues.filter((i) => i.level === 'warning').length;
  const qualityScore = totalRows === 0 ? 0 : Math.round(((totalRows - rejectedRows) / totalRows) * 100 - (warningCount / totalRows) * 10);
  const clampedScore = Math.max(0, Math.min(100, qualityScore));

  return {
    totalRows,
    validRows,
    warningRows,
    rejectedRows,
    issues: allIssues,
    rows: validatedRows,
    qualityScore: clampedScore,
  };
}

// ===== OUTLIER DETECTION =====

export interface OutlierResult {
  metric: string;
  athleteId: string;
  value: number;
  baseline: { mean: number; std: number };
  zScore: number;
  level: 'level1' | 'level2';
  message: string;
}

export function detectOutliers(
  data: { athleteId: string; metric: string; value: number }[],
  athleteBaselines: Record<string, Record<string, { mean: number; std: number }>>
): OutlierResult[] {
  const results: OutlierResult[] = [];

  for (const point of data) {
    const baseline = athleteBaselines[point.athleteId]?.[point.metric];
    if (!baseline || baseline.std === 0) continue;

    const zScore = Math.abs((point.value - baseline.mean) / baseline.std);

    if (zScore > 3) {
      results.push({
        metric: point.metric,
        athleteId: point.athleteId,
        value: point.value,
        baseline,
        zScore,
        level: 'level2',
        message: `Unusual individual exposure detected: ${point.value} vs typical ${Math.round(baseline.mean)} (z=${zScore.toFixed(1)})`,
      });
    } else if (zScore > 2) {
      results.push({
        metric: point.metric,
        athleteId: point.athleteId,
        value: point.value,
        baseline,
        zScore,
        level: 'level1',
        message: `Statistical outlier: ${point.value} vs baseline ${Math.round(baseline.mean)} (z=${zScore.toFixed(1)})`,
      });
    }
  }

  return results;
}

// ===== DATA QUALITY SCORING =====

export interface DataQualityBreakdown {
  gpsCompleteness: number;
  hrCompleteness: number;
  athleteIdentification: number;
  timestampIntegrity: number;
  metricCompleteness: number;
  overall: number;
  status: 'excellent' | 'good' | 'partial' | 'poor';
  reasons: string[];
}

export function computeDataQualityBreakdown(params: {
  gpsCompleteness: number;
  hrCompleteness: number;
  athleteIdentification: number;
  timestampIntegrity: number;
  metricCompleteness: number;
}): DataQualityBreakdown {
  const overall = Math.round(
    (params.gpsCompleteness * 0.25 +
      params.hrCompleteness * 0.20 +
      params.athleteIdentification * 0.20 +
      params.timestampIntegrity * 0.15 +
      params.metricCompleteness * 0.20)
  );

  let status: DataQualityBreakdown['status'] = 'excellent';
  if (overall < 70) status = 'poor';
  else if (overall < 85) status = 'partial';
  else if (overall < 95) status = 'good';

  const reasons: string[] = [];
  if (params.gpsCompleteness < 90) reasons.push(`GPS completeness: ${params.gpsCompleteness}%`);
  if (params.hrCompleteness < 85) reasons.push(`Heart-rate completeness: ${params.hrCompleteness}%`);
  if (params.athleteIdentification < 100) reasons.push(`Athlete identification: ${params.athleteIdentification}%`);
  if (params.timestampIntegrity < 95) reasons.push(`Timestamp integrity: ${params.timestampIntegrity}%`);
  if (params.metricCompleteness < 85) reasons.push(`Metric completeness: ${params.metricCompleteness}%`);

  return { ...params, overall, status, reasons };
}

// ===== IMPORT HISTORY TYPES =====

export interface ImportRecord {
  id: string;
  date: string;
  source: string;
  sourceType: DataSource;
  fileName: string;
  records: number;
  valid: number;
  warnings: number;
  rejected: number;
  quality: number;
  status: 'complete' | 'partial' | 'failed' | 'requires-review';
  athleteMappings: number;
  metricMappings: number;
  errorReport?: ValidationIssue[];
}

// ===== DATA SOURCE TYPES =====

export interface DataSourceConfig {
  id: string;
  name: string;
  type: 'gps' | 'hr' | 'tracking' | 'sensor' | 'platform';
  status: 'connected' | 'integration-ready' | 'demo' | 'error';
  lastSync: string | null;
  athletes: number;
  sessions: number;
  dataQuality: number;
  syncFrequency: 'manual' | 'hourly' | 'daily' | 'weekly';
  provider?: string;
}

// ===== PIPELINE STATUS =====

export interface PipelineStage {
  name: string;
  status: 'operational' | 'degraded' | 'offline';
  recordsProcessed: number;
  lastRun: string;
}

// ===== AUDIT LOG =====

export interface AuditEntry {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  object: string;
  details?: string;
}

// ===== TEST DATA GENERATOR =====

export interface TestDataCSV {
  name: string;
  content: string;
  description: string;
}

export function generateTestCSVs(): TestDataCSV[] {
  const headers = ['Athlete ID', 'Athlete Name', 'Date', 'Session Type', 'Duration', 'Total Distance', 'HSR', 'Sprint Distance', 'Max Speed', 'Accelerations', 'Decelerations', 'Avg HR', 'Max HR', 'RPE'];

  const validData = [
    ['a1', 'James Okoro', '2026-08-28', 'Training', '75', '7.2', '520', '180', '28.5', '32', '28', '145', '185', '7'],
    ['a2', 'Sipho Ndlovu', '2026-08-28', 'Training', '80', '5.8', '280', '120', '25.0', '24', '22', '140', '180', '8'],
    ['a3', 'Kwame Mensah', '2026-08-28', 'Training', '70', '6.5', '450', '160', '27.0', '30', '26', '143', '183', '6'],
    ['a4', 'Brett Carter', '2026-08-28', 'Training', '85', '5.5', '220', '90', '24.0', '22', '20', '138', '178', '7'],
    ['a5', 'Marco Silva', '2026-08-28', 'Training', '72', '6.8', '350', '80', '26.5', '28', '25', '142', '182', '6'],
    ['a6', 'Liam Walsh', '2026-08-28', 'Training', '78', '7.0', '480', '200', '33.0', '38', '34', '146', '186', '6'],
  ];

  // CSV with issues: missing values, invalid timestamps, outliers, unmatched athletes
  const problematicData = [
    ['a1', 'James Okoro', '2026-08-28', 'Training', '75', '7.2', '520', '180', '28.5', '32', '28', '145', '185', '7'],
    ['a2', 'Sipho Ndlovu', '2026-08-28', 'Training', '80', '5.8', '', '120', '25.0', '24', '22', '140', '180', '8'],
    ['a3', 'Kwame Mensah', '28/08/2026', 'Training', '70', '6.5', '450', '160', '27.0', '30', '26', '143', '183', '6'],
    ['a4', 'Brett Carter', '2026-08-28', 'Training', '-5', '5.5', '220', '90', '24.0', '22', '20', '138', '178', '7'],
    ['#99', 'Unknown Player', '2026-08-28', 'Training', '70', '6.0', '400', '150', '26.0', '28', '25', '142', '182', '6'],
    ['a6', 'Liam Walsh', '2026-08-28', 'Training', '78', '7.0', '480', '200', '55.0', '38', '34', '146', '186', '6'],
    ['a7', 'Tendai Mhuri', '2026-08-28', 'Training', '72', '7.8', '600', '220', '31.5', '44', '38', '150', '190', '6'],
    ['a1', 'James Okoro', '2026-08-28', 'Training', '75', '7.2', '520', '180', '28.5', '32', '28', '145', '185', '7'],
    ['a8', 'Pieter Botha', '2026-08-28', 'Training', '85', '5.5', '250', '100', '24.5', '26', '24', '138', '180', '7'],
    ['', '', '2026-08-28', '', '60', '5.0', '200', '50', '22.0', '15', '12', '130', '170', '5'],
  ];

  const toCSV = (rows: string[][]) => [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

  return [
    { name: 'valid_wearable_export.csv', content: toCSV(validData), description: 'Clean dataset with 6 valid records — all athletes matched, all metrics within plausible ranges.' },
    { name: 'problematic_wearable_export.csv', content: toCSV(problematicData), description: 'Contains missing values, invalid timestamps, outliers, duplicate rows, unmatched athletes, and negative duration.' },
  ];
}

// ===== CSV PARSER =====

export interface ParsedCSV {
  headers: string[];
  rows: Record<string, string>[];
  rowCount: number;
}

export function parseCSV(text: string): ParsedCSV {
  const lines = text.trim().split(/\r?\n/).filter((l) => l.trim());
  if (lines.length === 0) return { headers: [], rows: [], rowCount: 0 };

  const parseLine = (line: string): string[] => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        if (inQuotes && line[i + 1] === '"') { current += '"'; i++; }
        else { inQuotes = !inQuotes; }
      } else if (char === ',' && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  };

  const headers = parseLine(lines[0]);
  const rows: Record<string, string>[] = lines.slice(1).map((line) => {
    const values = parseLine(line);
    const row: Record<string, string> = {};
    headers.forEach((h, i) => { row[h] = values[i] || ''; });
    return row;
  });

  return { headers, rows, rowCount: rows.length };
}

// ===== SESSION TYPE CLASSIFICATION =====

export type SessionType = 'training' | 'match' | 'test' | 'recovery' | 'other';

export function classifySessionType(rawType: string): SessionType {
  const t = rawType.toLowerCase().trim();
  if (t.includes('match') || t.includes('game') || t.includes('competition')) return 'match';
  if (t.includes('test') || t.includes('assessment')) return 'test';
  if (t.includes('recovery') || t.includes('rest') || t.includes('regen')) return 'recovery';
  if (t.includes('training') || t.includes('practice') || t.includes('session') || t.includes('technical') || t.includes('tactical') || t.includes('physical') || t.includes('speed') || t.includes('endurance') || t.includes('strength')) return 'training';
  return 'other';
}

// ===== AI INPUT STRUCTURING =====

export interface AIStructuredInput {
  sport: string;
  position: string;
  competitionMetrics: Record<string, number>;
  trainingMetrics: Record<string, number>;
  gaps: Record<string, number>;
  baseline: Record<string, number>;
  dataQuality: number;
  recentPerformance: string;
}

export function structureAIInput(params: {
  sport: string;
  position: string;
  competitionMetrics: Record<string, number>;
  trainingMetrics: Record<string, number>;
  baseline: Record<string, number>;
  dataQuality: number;
  recentPerformance: string;
}): AIStructuredInput {
  const gaps: Record<string, number> = {};
  for (const key of Object.keys(params.competitionMetrics)) {
    const comp = params.competitionMetrics[key];
    const train = params.trainingMetrics[key] || 0;
    gaps[key] = comp === 0 ? 0 : Math.round(((train - comp) / comp) * 100);
  }

  return {
    sport: params.sport,
    position: params.position,
    competitionMetrics: params.competitionMetrics,
    trainingMetrics: params.trainingMetrics,
    gaps,
    baseline: params.baseline,
    dataQuality: params.dataQuality,
    recentPerformance: params.recentPerformance,
  };
}

export function formatAIInputAsText(input: AIStructuredInput): string {
  const lines: string[] = [];
  lines.push(`Sport: ${input.sport}`);
  lines.push(`Position: ${input.position}`);
  lines.push('');
  lines.push('Competition Metrics:');
  for (const [k, v] of Object.entries(input.competitionMetrics)) lines.push(`  ${k}: ${v}`);
  lines.push('');
  lines.push('Training Metrics:');
  for (const [k, v] of Object.entries(input.trainingMetrics)) lines.push(`  ${k}: ${v}`);
  lines.push('');
  lines.push('Gaps:');
  for (const [k, v] of Object.entries(input.gaps)) lines.push(`  ${k}: ${v > 0 ? '+' : ''}${v}%`);
  lines.push('');
  lines.push('28-day athlete baseline:');
  for (const [k, v] of Object.entries(input.baseline)) lines.push(`  ${k}: ${v}`);
  lines.push('');
  lines.push(`Data quality: ${input.dataQuality}%`);
  lines.push(`Recent performance: ${input.recentPerformance}`);
  return lines.join('\n');
}
