import type {
  Athlete,
  PerformanceDemand,
  CapacityTest,
  TrainingSession,
  MatchRecord,
  AIInsight,
  Sport,
  Position,
  GapStatus,
} from './types';

export const athletes: Athlete[] = [
  {
    id: 'a1',
    name: 'Alex Morgan',
    sport: 'football',
    position: 'Central Midfielder',
    age: 24,
    team: 'City United FC',
    avatarColor: '#2563eb',
    initials: 'AM',
  },
  {
    id: 'a2',
    name: 'Daniel Moyo',
    sport: 'rugby',
    position: 'Flanker',
    age: 26,
    team: 'Highland Rugby Club',
    avatarColor: '#0d9488',
    initials: 'DM',
  },
  {
    id: 'a3',
    name: 'James Okoro',
    sport: 'football',
    position: 'Winger',
    age: 22,
    team: 'City United FC',
    avatarColor: '#7c3aed',
    initials: 'JO',
  },
  {
    id: 'a4',
    name: 'Sipho Ndlovu',
    sport: 'rugby',
    position: 'Number 8',
    age: 28,
    team: 'Highland Rugby Club',
    avatarColor: '#dc2626',
    initials: 'SN',
  },
];

export const footballPositions: Position[] = [
  'Goalkeeper',
  'Centre Back',
  'Full Back',
  'Defensive Midfielder',
  'Central Midfielder',
  'Attacking Midfielder',
  'Winger',
  'Striker',
];

export const rugbyPositions: Position[] = [
  'Prop',
  'Hooker',
  'Lock',
  'Flanker',
  'Number 8',
  'Scrum-half',
  'Fly-half',
  'Centre',
  'Wing',
  'Fullback',
];

type DemandMap = Record<string, PerformanceDemand[]>;

export const performanceDemands: DemandMap = {
  // Football positions
  Goalkeeper: [
    { label: 'Total Distance', value: '4.0–5.5', unit: 'km', description: 'Lower total volume compared to outfield positions', category: 'volume' },
    { label: 'High-Speed Running', value: '150–300', unit: 'm', description: 'Occasional explosive sprints off the line', category: 'intensity' },
    { label: 'Sprint Distance', value: '50–120', unit: 'm', description: 'Short, sharp sprints for recovery and closing down angles', category: 'intensity' },
    { label: 'Accelerations', value: '15–25', unit: 'count', description: 'Frequent explosive movements from standing starts', category: 'frequency' },
    { label: 'Decelerations', value: '12–20', unit: 'count', description: 'Rapid stops after short bursts', category: 'frequency' },
    { label: 'Work/Rest Ratio', value: '1:5', unit: 'ratio', description: 'Long recovery periods between high-intensity actions', category: 'physiological' },
    { label: 'Anaerobic Demands', value: 'High', unit: '', description: 'Explosive power for diving, sprinting, and jumping', category: 'physiological' },
    { label: 'Change of Direction', value: 'High', unit: '', description: 'Rapid directional changes for shot-stopping', category: 'physiological' },
  ],
  'Centre Back': [
    { label: 'Total Distance', value: '8.5–10.0', unit: 'km', description: 'Moderate total volume with structured positioning', category: 'volume' },
    { label: 'Relative Distance', value: '95–105', unit: 'm/min', description: 'Steady movement rate with positional discipline', category: 'volume' },
    { label: 'High-Speed Running', value: '600–900', unit: 'm', description: 'Recovery runs and covering defensive spaces', category: 'intensity' },
    { label: 'Sprint Distance', value: '150–300', unit: 'm', description: 'Explosive sprints to track runners and close gaps', category: 'intensity' },
    { label: 'Accelerations', value: '25–35', unit: 'count', description: 'Frequent accelerations from standing positions', category: 'frequency' },
    { label: 'Decelerations', value: '20–30', unit: 'count', description: 'Controlled decelerations when engaging attackers', category: 'frequency' },
    { label: 'Aerobic Demands', value: 'Moderate–High', unit: '', description: 'Sustained coverage of defensive zones', category: 'physiological' },
    { label: 'Work/Rest Ratio', value: '1:7', unit: 'ratio', description: 'Extended recovery between high-intensity defensive actions', category: 'physiological' },
  ],
  'Full Back': [
    { label: 'Total Distance', value: '9.5–11.0', unit: 'km', description: 'High volume covering full flank width', category: 'volume' },
    { label: 'Relative Distance', value: '105–115', unit: 'm/min', description: 'High movement rate with continuous involvement', category: 'volume' },
    { label: 'High-Speed Running', value: '900–1300', unit: 'm', description: 'Extensive high-speed running for overlapping runs', category: 'intensity' },
    { label: 'Sprint Distance', value: '250–450', unit: 'm', description: 'Frequent sprints for attacking and recovery runs', category: 'intensity' },
    { label: 'Accelerations', value: '35–50', unit: 'count', description: 'High acceleration frequency from deep positions', category: 'frequency' },
    { label: 'Decelerations', value: '30–40', unit: 'count', description: 'Frequent decelerations when changing attacking phase', category: 'frequency' },
    { label: 'Aerobic Demands', value: 'High', unit: '', description: 'Sustained high-intensity running throughout match', category: 'physiological' },
    { label: 'Change of Direction', value: 'Moderate–High', unit: '', description: 'Directional changes for overlapping and recovery', category: 'physiological' },
  ],
  'Defensive Midfielder': [
    { label: 'Total Distance', value: '9.0–10.5', unit: 'km', description: 'High volume with central coverage responsibility', category: 'volume' },
    { label: 'Relative Distance', value: '100–110', unit: 'm/min', description: 'Consistent movement rate with positional discipline', category: 'volume' },
    { label: 'High-Speed Running', value: '700–1000', unit: 'm', description: 'Covering ground for defensive screening', category: 'intensity' },
    { label: 'Sprint Distance', value: '150–300', unit: 'm', description: 'Targeted sprints for pressing and recovery', category: 'intensity' },
    { label: 'Accelerations', value: '30–40', unit: 'count', description: 'Regular accelerations for pressing triggers', category: 'frequency' },
    { label: 'Decelerations', value: '25–35', unit: 'count', description: 'Controlled decelerations when engaging opponents', category: 'frequency' },
    { label: 'Aerobic Demands', value: 'High', unit: '', description: 'Sustained central coverage and transition play', category: 'physiological' },
    { label: 'Work/Rest Ratio', value: '1:5', unit: 'ratio', description: 'Regular high-intensity efforts with moderate recovery', category: 'physiological' },
  ],
  'Central Midfielder': [
    { label: 'Total Distance', value: '10.5–12.5', unit: 'km', description: 'Highest total volume in football — box-to-box coverage', category: 'volume' },
    { label: 'Relative Distance', value: '110–125', unit: 'm/min', description: 'High sustained movement rate throughout the match', category: 'volume' },
    { label: 'High-Speed Running', value: '1000–1500', unit: 'm', description: 'Extensive high-speed running in both phases', category: 'intensity' },
    { label: 'Sprint Distance', value: '300–600', unit: 'm', description: 'Frequent sprints for attacking support and recovery', category: 'intensity' },
    { label: 'Accelerations', value: '40–55', unit: 'count', description: 'High acceleration frequency across all zones', category: 'frequency' },
    { label: 'Decelerations', value: '35–50', unit: 'count', description: 'Frequent decelerations when changing direction', category: 'frequency' },
    { label: 'High-Intensity Efforts', value: '60–80', unit: 'count', description: 'Most high-intensity actions of any position', category: 'frequency' },
    { label: 'Aerobic Demands', value: 'Very High', unit: '', description: 'Elite aerobic capacity required for sustained output', category: 'physiological' },
    { label: 'Work/Rest Ratio', value: '1:4', unit: 'ratio', description: 'Frequent high-intensity efforts with short recovery', category: 'physiological' },
    { label: 'Change of Direction', value: 'High', unit: '', description: 'Frequent directional changes in congested central areas', category: 'physiological' },
  ],
  'Attacking Midfielder': [
    { label: 'Total Distance', value: '9.5–11.0', unit: 'km', description: 'High volume with attacking positioning focus', category: 'volume' },
    { label: 'Relative Distance', value: '105–115', unit: 'm/min', description: 'High movement rate with creative positioning', category: 'volume' },
    { label: 'High-Speed Running', value: '900–1300', unit: 'm', description: 'High-speed running for attacking transitions', category: 'intensity' },
    { label: 'Sprint Distance', value: '300–500', unit: 'm', description: 'Explosive sprints to exploit attacking spaces', category: 'intensity' },
    { label: 'Accelerations', value: '35–50', unit: 'count', description: 'Sharp accelerations to create separation', category: 'frequency' },
    { label: 'Decelerations', value: '30–40', unit: 'count', description: 'Decelerations when receiving in tight spaces', category: 'frequency' },
    { label: 'Aerobic Demands', value: 'High', unit: '', description: 'Sustained attacking involvement throughout match', category: 'physiological' },
    { label: 'Change of Direction', value: 'High', unit: '', description: 'Agility for receiving and turning in congested areas', category: 'physiological' },
  ],
  Winger: [
    { label: 'Total Distance', value: '9.5–11.5', unit: 'km', description: 'High volume with wide attacking coverage', category: 'volume' },
    { label: 'Relative Distance', value: '105–120', unit: 'm/min', description: 'High movement rate with attacking intent', category: 'volume' },
    { label: 'High-Speed Running', value: '1200–1800', unit: 'm', description: 'Most high-speed running of any position', category: 'intensity' },
    { label: 'Sprint Distance', value: '400–700', unit: 'm', description: 'Extensive sprint exposure for attacking runs', category: 'intensity' },
    { label: 'Accelerations', value: '45–60', unit: 'count', description: 'Very high acceleration frequency from wide positions', category: 'frequency' },
    { label: 'Decelerations', value: '40–50', unit: 'count', description: 'Frequent decelerations when cutting inside', category: 'frequency' },
    { label: 'Repeated Sprint Ability', value: 'High', unit: '', description: 'Frequent repeated sprints with limited recovery', category: 'physiological' },
    { label: 'Aerobic Demands', value: 'High', unit: '', description: 'Sustained high-intensity running in wide channels', category: 'physiological' },
    { label: 'Change of Direction', value: 'Moderate–High', unit: '', description: 'Directional changes for dribbling and cutting inside', category: 'physiological' },
  ],
  Striker: [
    { label: 'Total Distance', value: '8.5–10.5', unit: 'km', description: 'Moderate volume with high-intensity focus', category: 'volume' },
    { label: 'Relative Distance', value: '95–110', unit: 'm/min', description: 'Variable movement rate with explosive bursts', category: 'volume' },
    { label: 'High-Speed Running', value: '800–1200', unit: 'm', description: 'High-speed running for attacking runs behind', category: 'intensity' },
    { label: 'Sprint Distance', value: '350–600', unit: 'm', description: 'Explosive sprints to get in behind defensive lines', category: 'intensity' },
    { label: 'Accelerations', value: '35–50', unit: 'count', description: 'Sharp accelerations to create goal-scoring opportunities', category: 'frequency' },
    { label: 'Decelerations', value: '30–45', unit: 'count', description: 'Decelerations when holding up play', category: 'frequency' },
    { label: 'Repeated Sprint Ability', value: 'High', unit: '', description: 'Frequent repeated sprints with limited recovery', category: 'physiological' },
    { label: 'Anaerobic Demands', value: 'High', unit: '', description: 'Explosive power for sprinting and shooting', category: 'physiological' },
    { label: 'Change of Direction', value: 'Moderate', unit: '', description: 'Directional changes for finding space in the box', category: 'physiological' },
  ],
  // Rugby positions
  Prop: [
    { label: 'Total Distance', value: '4.5–6.0', unit: 'km', description: 'Lower total volume — scrum and contact focused', category: 'volume' },
    { label: 'Relative Distance', value: '55–70', unit: 'm/min', description: 'Low movement rate with high static exertion', category: 'volume' },
    { label: 'High-Speed Running', value: '100–250', unit: 'm', description: 'Limited high-speed running', category: 'intensity' },
    { label: 'Sprint Distance', value: '30–80', unit: 'm', description: 'Minimal sprint distance', category: 'intensity' },
    { label: 'Accelerations', value: '15–25', unit: 'count', description: 'Short accelerations into contact', category: 'frequency' },
    { label: 'Contact/Collision', value: '15–25', unit: 'count', description: 'High contact exposure — scrums, rucks, tackles', category: 'contact' },
    { label: 'Contact Load', value: 'High', unit: '', description: 'Very high static and collision load', category: 'contact' },
    { label: 'Aerobic Demands', value: 'Moderate', unit: '', description: 'Intermittent activity with heavy contact', category: 'physiological' },
    { label: 'Strength/Power', value: 'Very High', unit: '', description: 'Elite scrummaging strength required', category: 'physiological' },
  ],
  Hooker: [
    { label: 'Total Distance', value: '5.0–6.5', unit: 'km', description: 'Moderate volume with high contact involvement', category: 'volume' },
    { label: 'Relative Distance', value: '60–75', unit: 'm/min', description: 'Low-to-moderate movement rate', category: 'volume' },
    { label: 'High-Speed Running', value: '150–300', unit: 'm', description: 'Limited high-speed running', category: 'intensity' },
    { label: 'Sprint Distance', value: '50–100', unit: 'm', description: 'Short sprints around the breakdown', category: 'intensity' },
    { label: 'Accelerations', value: '20–30', unit: 'count', description: 'Accelerations into contact and breakdown', category: 'frequency' },
    { label: 'Contact/Collision', value: '18–28', unit: 'count', description: 'Very high contact exposure at breakdown', category: 'contact' },
    { label: 'Contact Load', value: 'High', unit: '', description: 'Heavy contact and scrummaging load', category: 'contact' },
    { label: 'Strength/Power', value: 'Very High', unit: '', description: 'Scrummaging and throwing power', category: 'physiological' },
  ],
  Lock: [
    { label: 'Total Distance', value: '5.5–7.0', unit: 'km', description: 'Moderate volume with lineout and maul involvement', category: 'volume' },
    { label: 'Relative Distance', value: '65–80', unit: 'm/min', description: 'Moderate movement rate', category: 'volume' },
    { label: 'High-Speed Running', value: '200–400', unit: 'm', description: 'Moderate high-speed running for a forward', category: 'intensity' },
    { label: 'Sprint Distance', value: '80–150', unit: 'm', description: 'Occasional sprints in open play', category: 'intensity' },
    { label: 'Accelerations', value: '20–35', unit: 'count', description: 'Accelerations for lineout jumps and breakdown', category: 'frequency' },
    { label: 'Contact/Collision', value: '15–25', unit: 'count', description: 'High contact in lineouts, mauls, and rucks', category: 'contact' },
    { label: 'Contact Load', value: 'High', unit: '', description: 'Heavy contact load from set-piece and maul work', category: 'contact' },
    { label: 'Strength/Power', value: 'Very High', unit: '', description: 'Lineout jumping and maul driving power', category: 'physiological' },
  ],
  Flanker: [
    { label: 'Total Distance', value: '6.0–8.0', unit: 'km', description: 'High volume for a forward — breakdown focused', category: 'volume' },
    { label: 'Relative Distance', value: '70–90', unit: 'm/min', description: 'High movement rate for a forward position', category: 'volume' },
    { label: 'High-Speed Running', value: '300–600', unit: 'm', description: 'Significant high-speed running for a forward', category: 'intensity' },
    { label: 'Sprint Distance', value: '120–250', unit: 'm', description: 'Sprints to chase kicks and hit breakdowns', category: 'intensity' },
    { label: 'Accelerations', value: '30–45', unit: 'count', description: 'High acceleration frequency for a forward', category: 'frequency' },
    { label: 'Decelerations', value: '25–40', unit: 'count', description: 'Decelerations into tackle and breakdown technique', category: 'frequency' },
    { label: 'Contact/Collision', value: '20–30', unit: 'count', description: 'Very high contact — tackling and breakdown work', category: 'contact' },
    { label: 'Contact Load', value: 'Very High', unit: '', description: 'Highest contact load among forwards', category: 'contact' },
    { label: 'Aerobic Demands', value: 'High', unit: '', description: 'Sustained work rate with heavy contact', category: 'physiological' },
    { label: 'Work/Rest Ratio', value: '1:3', unit: 'ratio', description: 'Frequent high-intensity efforts with short recovery', category: 'physiological' },
  ],
  'Number 8': [
    { label: 'Total Distance', value: '6.0–7.5', unit: 'km', description: 'Moderate-to-high volume with carrying responsibility', category: 'volume' },
    { label: 'Relative Distance', value: '70–85', unit: 'm/min', description: 'Moderate-to-high movement rate', category: 'volume' },
    { label: 'High-Speed Running', value: '300–500', unit: 'm', description: 'High-speed running for ball carrying', category: 'intensity' },
    { label: 'Sprint Distance', value: '150–300', unit: 'm', description: 'Sprints when breaking the gain line', category: 'intensity' },
    { label: 'Accelerations', value: '30–40', unit: 'count', description: 'Accelerations for carrying and support play', category: 'frequency' },
    { label: 'Contact/Collision', value: '18–28', unit: 'count', description: 'High contact from carrying and breakdown', category: 'contact' },
    { label: 'Contact Load', value: 'High', unit: '', description: 'Heavy contact from ball carrying and scrummaging', category: 'contact' },
    { label: 'Aerobic Demands', value: 'High', unit: '', description: 'Sustained work rate with repeated carrying', category: 'physiological' },
    { label: 'Strength/Power', value: 'Very High', unit: '', description: 'Explosive carrying and contact power', category: 'physiological' },
  ],
  'Scrum-half': [
    { label: 'Total Distance', value: '7.0–9.0', unit: 'km', description: 'High volume — link between forwards and backs', category: 'volume' },
    { label: 'Relative Distance', value: '85–100', unit: 'm/min', description: 'High movement rate with frequent involvement', category: 'volume' },
    { label: 'High-Speed Running', value: '500–800', unit: 'm', description: 'Significant high-speed running across the pitch', category: 'intensity' },
    { label: 'Sprint Distance', value: '200–400', unit: 'm', description: 'Sprints to support breaks and chase kicks', category: 'intensity' },
    { label: 'Accelerations', value: '40–55', unit: 'count', description: 'Very high acceleration frequency', category: 'frequency' },
    { label: 'Decelerations', value: '35–45', unit: 'count', description: 'Frequent decelerations at breakdown', category: 'frequency' },
    { label: 'Contact/Collision', value: '10–18', unit: 'count', description: 'Moderate contact exposure', category: 'contact' },
    { label: 'Aerobic Demands', value: 'High', unit: '', description: 'Sustained high work rate around the breakdown', category: 'physiological' },
    { label: 'Change of Direction', value: 'High', unit: '', description: 'Agility for quick distribution and sniping runs', category: 'physiological' },
  ],
  'Fly-half': [
    { label: 'Total Distance', value: '6.5–8.5', unit: 'km', description: 'High volume with tactical kicking and playmaking', category: 'volume' },
    { label: 'Relative Distance', value: '80–95', unit: 'm/min', description: 'High movement rate with strategic positioning', category: 'volume' },
    { label: 'High-Speed Running', value: '400–700', unit: 'm', description: 'High-speed running for attacking and positioning', category: 'intensity' },
    { label: 'Sprint Distance', value: '150–350', unit: 'm', description: 'Sprints for line breaks and chase kicks', category: 'intensity' },
    { label: 'Accelerations', value: '30–45', unit: 'count', description: 'Accelerations for tactical positioning', category: 'frequency' },
    { label: 'Contact/Collision', value: '8–15', unit: 'count', description: 'Lower contact exposure than forwards', category: 'contact' },
    { label: 'Aerobic Demands', value: 'High', unit: '', description: 'Sustained involvement in both attack and defense', category: 'physiological' },
    { label: 'Change of Direction', value: 'High', unit: '', description: 'Agility for evasive running and tactical positioning', category: 'physiological' },
  ],
  Centre: [
    { label: 'Total Distance', value: '6.5–8.5', unit: 'km', description: 'High volume with attacking and defensive responsibility', category: 'volume' },
    { label: 'Relative Distance', value: '80–95', unit: 'm/min', description: 'High movement rate with dynamic involvement', category: 'volume' },
    { label: 'High-Speed Running', value: '500–800', unit: 'm', description: 'Significant high-speed running in attack and defense', category: 'intensity' },
    { label: 'Sprint Distance', value: '200–400', unit: 'm', description: 'Sprints for line breaks and defensive tracking', category: 'intensity' },
    { label: 'Accelerations', value: '35–50', unit: 'count', description: 'High acceleration frequency', category: 'frequency' },
    { label: 'Decelerations', value: '30–40', unit: 'count', description: 'Decelerations for tackling and evasive running', category: 'frequency' },
    { label: 'Contact/Collision', value: '12–20', unit: 'count', description: 'Moderate-to-high contact in attack and defense', category: 'contact' },
    { label: 'Aerobic Demands', value: 'High', unit: '', description: 'Sustained high-intensity involvement', category: 'physiological' },
    { label: 'Change of Direction', value: 'High', unit: '', description: 'Agility for attacking lines and defensive tracking', category: 'physiological' },
  ],
  Wing: [
    { label: 'Total Distance', value: '6.0–8.0', unit: 'km', description: 'Moderate-to-high volume with attacking focus', category: 'volume' },
    { label: 'Relative Distance', value: '75–90', unit: 'm/min', description: 'Moderate-to-high movement rate', category: 'volume' },
    { label: 'High-Speed Running', value: '600–1000', unit: 'm', description: 'High high-speed running for finishing and chasing', category: 'intensity' },
    { label: 'Sprint Distance', value: '300–500', unit: 'm', description: 'Extensive sprint exposure for a rugby back', category: 'intensity' },
    { label: 'Accelerations', value: '35–50', unit: 'count', description: 'High acceleration frequency from deep positions', category: 'frequency' },
    { label: 'Decelerations', value: '30–40', unit: 'count', description: 'Decelerations when changing attacking direction', category: 'frequency' },
    { label: 'Contact/Collision', value: '8–15', unit: 'count', description: 'Lower contact exposure', category: 'contact' },
    { label: 'Repeated Sprint Ability', value: 'High', unit: '', description: 'Frequent sprints with limited recovery', category: 'physiological' },
    { label: 'Aerobic Demands', value: 'High', unit: '', description: 'Sustained high-intensity running in wide channels', category: 'physiological' },
  ],
  Fullback: [
    { label: 'Total Distance', value: '6.5–8.5', unit: 'km', description: 'High volume with defensive and attacking coverage', category: 'volume' },
    { label: 'Relative Distance', value: '80–95', unit: 'm/min', description: 'High movement rate with positional responsibility', category: 'volume' },
    { label: 'High-Speed Running', value: '600–1000', unit: 'm', description: 'High high-speed running for counter-attacking', category: 'intensity' },
    { label: 'Sprint Distance', value: '300–500', unit: 'm', description: 'Sprints for counter-attack and defensive recovery', category: 'intensity' },
    { label: 'Accelerations', value: '35–50', unit: 'count', description: 'High acceleration frequency', category: 'frequency' },
    { label: 'Decelerations', value: '30–40', unit: 'count', description: 'Decelerations for positioning and receiving', category: 'frequency' },
    { label: 'Contact/Collision', value: '8–14', unit: 'count', description: 'Lower contact exposure', category: 'contact' },
    { label: 'Aerobic Demands', value: 'High', unit: '', description: 'Sustained coverage of backfield', category: 'physiological' },
    { label: 'Change of Direction', value: 'High', unit: '', description: 'Agility for counter-attacking and defensive positioning', category: 'physiological' },
  ],
};

// Capacity tests per athlete
export const capacityTests: Record<string, CapacityTest[]> = {
  a1: [
    {
      id: 't1',
      category: 'Speed',
      name: '30 m Sprint',
      unit: 's',
      baseline: 4.35,
      previous: 4.28,
      latest: 4.25,
      benchmark: 4.10,
      date: '2026-08-20',
      higherIsBetter: false,
      history: [
        { date: '2026-01-15', value: 4.35 },
        { date: '2026-03-20', value: 4.32 },
        { date: '2026-06-10', value: 4.28 },
        { date: '2026-08-20', value: 4.25 },
      ],
    },
    {
      id: 't2',
      category: 'Speed',
      name: '20 m Sprint',
      unit: 's',
      baseline: 3.15,
      previous: 3.1,
      latest: 3.08,
      benchmark: 2.95,
      date: '2026-08-20',
      higherIsBetter: false,
      history: [
        { date: '2026-01-15', value: 3.15 },
        { date: '2026-03-20', value: 3.12 },
        { date: '2026-06-10', value: 3.10 },
        { date: '2026-08-20', value: 3.08 },
      ],
    },
    {
      id: 't3',
      category: 'Speed',
      name: 'Maximum Velocity',
      unit: 'km/h',
      baseline: 30.5,
      previous: 31.3,
      latest: 31.8,
      benchmark: 33.0,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 30.5 },
        { date: '2026-03-20', value: 30.9 },
        { date: '2026-06-10', value: 31.3 },
        { date: '2026-08-20', value: 31.8 },
      ],
    },
    {
      id: 't4',
      category: 'Aerobic Capacity',
      name: 'Yo-Yo IR1',
      unit: 'm',
      baseline: 1800,
      previous: 2080,
      latest: 2200,
      benchmark: 2400,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 1800 },
        { date: '2026-03-20', value: 1950 },
        { date: '2026-06-10', value: 2080 },
        { date: '2026-08-20', value: 2200 },
      ],
    },
    {
      id: 't5',
      category: 'Aerobic Capacity',
      name: 'MAS',
      unit: 'km/h',
      baseline: 17.5,
      previous: 18,
      latest: 18.2,
      benchmark: 19.0,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 17.5 },
        { date: '2026-03-20', value: 17.8 },
        { date: '2026-06-10', value: 18.0 },
        { date: '2026-08-20', value: 18.2 },
      ],
    },
    {
      id: 't6',
      category: 'Repeated Sprint Ability',
      name: 'RSA Test (6×40m)',
      unit: '% decrement',
      baseline: 8.5,
      previous: 6.1,
      latest: 5.2,
      benchmark: 3.0,
      date: '2026-08-20',
      higherIsBetter: false,
      history: [
        { date: '2026-01-15', value: 8.5 },
        { date: '2026-03-20', value: 7.2 },
        { date: '2026-06-10', value: 6.1 },
        { date: '2026-08-20', value: 5.2 },
      ],
    },
    {
      id: 't7',
      category: 'Change of Direction',
      name: '505 Agility Test',
      unit: 's',
      baseline: 2.35,
      previous: 2.3,
      latest: 2.28,
      benchmark: 2.15,
      date: '2026-08-20',
      higherIsBetter: false,
      history: [
        { date: '2026-01-15', value: 2.35 },
        { date: '2026-03-20', value: 2.33 },
        { date: '2026-06-10', value: 2.30 },
        { date: '2026-08-20', value: 2.28 },
      ],
    },
    {
      id: 't8',
      category: 'Strength / Power',
      name: 'Countermovement Jump',
      unit: 'cm',
      baseline: 42,
      previous: 46,
      latest: 48,
      benchmark: 55,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 42 },
        { date: '2026-03-20', value: 44 },
        { date: '2026-06-10', value: 46 },
        { date: '2026-08-20', value: 48 },
      ],
    },
  ],
  a2: [
    {
      id: 't9',
      category: 'Speed',
      name: '30 m Sprint',
      unit: 's',
      baseline: 4.50,
      previous: 4.41,
      latest: 4.38,
      benchmark: 4.20,
      date: '2026-08-20',
      higherIsBetter: false,
      history: [
        { date: '2026-01-15', value: 4.50 },
        { date: '2026-03-20', value: 4.45 },
        { date: '2026-06-10', value: 4.41 },
        { date: '2026-08-20', value: 4.38 },
      ],
    },
    {
      id: 't10',
      category: 'Speed',
      name: '20 m Sprint',
      unit: 's',
      baseline: 3.25,
      previous: 3.18,
      latest: 3.15,
      benchmark: 3.00,
      date: '2026-08-20',
      higherIsBetter: false,
      history: [
        { date: '2026-01-15', value: 3.25 },
        { date: '2026-03-20', value: 3.22 },
        { date: '2026-06-10', value: 3.18 },
        { date: '2026-08-20', value: 3.15 },
      ],
    },
    {
      id: 't11',
      category: 'Aerobic Capacity',
      name: 'Yo-Yo IR1',
      unit: 'm',
      baseline: 1500,
      previous: 1750,
      latest: 1850,
      benchmark: 2000,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 1500 },
        { date: '2026-03-20', value: 1650 },
        { date: '2026-06-10', value: 1750 },
        { date: '2026-08-20', value: 1850 },
      ],
    },
    {
      id: 't12',
      category: 'Strength / Power',
      name: 'Squat 1RM',
      unit: 'kg',
      baseline: 160,
      previous: 178,
      latest: 185,
      benchmark: 200,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 160 },
        { date: '2026-03-20', value: 170 },
        { date: '2026-06-10', value: 178 },
        { date: '2026-08-20', value: 185 },
      ],
    },
    {
      id: 't13',
      category: 'Strength / Power',
      name: 'Countermovement Jump',
      unit: 'cm',
      baseline: 38,
      previous: 42,
      latest: 44,
      benchmark: 50,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 38 },
        { date: '2026-03-20', value: 40 },
        { date: '2026-06-10', value: 42 },
        { date: '2026-08-20', value: 44 },
      ],
    },
    {
      id: 't14',
      category: 'Repeated Sprint Ability',
      name: 'RSA Test (6×40m)',
      unit: '% decrement',
      baseline: 9.8,
      previous: 7.3,
      latest: 6.5,
      benchmark: 4.0,
      date: '2026-08-20',
      higherIsBetter: false,
      history: [
        { date: '2026-01-15', value: 9.8 },
        { date: '2026-03-20', value: 8.5 },
        { date: '2026-06-10', value: 7.3 },
        { date: '2026-08-20', value: 6.5 },
      ],
    },
    {
      id: 't15',
      category: 'Change of Direction',
      name: '505 Agility Test',
      unit: 's',
      baseline: 2.45,
      previous: 2.38,
      latest: 2.35,
      benchmark: 2.20,
      date: '2026-08-20',
      higherIsBetter: false,
      history: [
        { date: '2026-01-15', value: 2.45 },
        { date: '2026-03-20', value: 2.42 },
        { date: '2026-06-10', value: 2.38 },
        { date: '2026-08-20', value: 2.35 },
      ],
    },
  ],
  a3: [
    {
      id: 't16',
      category: 'Speed',
      name: '30 m Sprint',
      unit: 's',
      baseline: 4.20,
      previous: 4.15,
      latest: 4.12,
      benchmark: 4.00,
      date: '2026-08-20',
      higherIsBetter: false,
      history: [
        { date: '2026-01-15', value: 4.20 },
        { date: '2026-03-20', value: 4.18 },
        { date: '2026-06-10', value: 4.15 },
        { date: '2026-08-20', value: 4.12 },
      ],
    },
    {
      id: 't17',
      category: 'Speed',
      name: 'Maximum Velocity',
      unit: 'km/h',
      baseline: 32.0,
      previous: 33,
      latest: 33.5,
      benchmark: 34.5,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 32.0 },
        { date: '2026-03-20', value: 32.5 },
        { date: '2026-06-10', value: 33.0 },
        { date: '2026-08-20', value: 33.5 },
      ],
    },
    {
      id: 't18',
      category: 'Aerobic Capacity',
      name: 'Yo-Yo IR1',
      unit: 'm',
      baseline: 2000,
      previous: 2200,
      latest: 2300,
      benchmark: 2400,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 2000 },
        { date: '2026-03-20', value: 2100 },
        { date: '2026-06-10', value: 2200 },
        { date: '2026-08-20', value: 2300 },
      ],
    },
    {
      id: 't19',
      category: 'Repeated Sprint Ability',
      name: 'RSA Test (6×40m)',
      unit: '% decrement',
      baseline: 6.5,
      previous: 4.8,
      latest: 4.1,
      benchmark: 3.0,
      date: '2026-08-20',
      higherIsBetter: false,
      history: [
        { date: '2026-01-15', value: 6.5 },
        { date: '2026-03-20', value: 5.5 },
        { date: '2026-06-10', value: 4.8 },
        { date: '2026-08-20', value: 4.1 },
      ],
    },
  ],
  a4: [
    {
      id: 't20',
      category: 'Speed',
      name: '30 m Sprint',
      unit: 's',
      baseline: 4.55,
      previous: 4.46,
      latest: 4.42,
      benchmark: 4.25,
      date: '2026-08-20',
      higherIsBetter: false,
      history: [
        { date: '2026-01-15', value: 4.55 },
        { date: '2026-03-20', value: 4.50 },
        { date: '2026-06-10', value: 4.46 },
        { date: '2026-08-20', value: 4.42 },
      ],
    },
    {
      id: 't21',
      category: 'Strength / Power',
      name: 'Squat 1RM',
      unit: 'kg',
      baseline: 170,
      previous: 188,
      latest: 195,
      benchmark: 210,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 170 },
        { date: '2026-03-20', value: 180 },
        { date: '2026-06-10', value: 188 },
        { date: '2026-08-20', value: 195 },
      ],
    },
    {
      id: 't22',
      category: 'Aerobic Capacity',
      name: 'Yo-Yo IR1',
      unit: 'm',
      baseline: 1400,
      previous: 1610,
      latest: 1700,
      benchmark: 1800,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 1400 },
        { date: '2026-03-20', value: 1520 },
        { date: '2026-06-10', value: 1610 },
        { date: '2026-08-20', value: 1700 },
      ],
    },
    {
      id: 't23',
      category: 'Strength / Power',
      name: 'Countermovement Jump',
      unit: 'cm',
      baseline: 36,
      previous: 40,
      latest: 42,
      benchmark: 48,
      date: '2026-08-20',
      higherIsBetter: true,
      history: [
        { date: '2026-01-15', value: 36 },
        { date: '2026-03-20', value: 38 },
        { date: '2026-06-10', value: 40 },
        { date: '2026-08-20', value: 42 },
      ],
    },
  ],
};

// Generate training sessions (28 days for each athlete)
function genTrainingSessions(athleteId: string, base: {
  dist: number; hsr: number; sprint: number; acc: number; dec: number; hie: number;
  avgHR: number; maxHR: number; rpe: number; contacts?: number; contactLoad?: number;
}): TrainingSession[] {
  const sessions: TrainingSession[] = [];
  const types = ['Technical', 'Tactical', 'Physical', 'Speed', 'Endurance', 'Strength', 'Recovery'];
  let seed = athleteId.charCodeAt(1) * 1000;
  const rand = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };

  for (let d = 27; d >= 0; d--) {
    const date = new Date(2026, 7, 29 - d);
    const dayOfWeek = date.getDay();
    // Skip some days (rest days)
    if (dayOfWeek === 0 && rand() > 0.3) continue;
    if (dayOfWeek === 3 && rand() > 0.7) continue;

    const type = types[Math.floor(rand() * types.length)];
    const duration = 60 + Math.floor(rand() * 45);
    const variance = 0.8 + rand() * 0.4;
    const isHard = rand() > 0.7;

    const totalDistance = +(base.dist * variance * (isHard ? 1.15 : 0.95)).toFixed(2);
    const relativeDistance = +((totalDistance * 1000) / duration).toFixed(1);
    const highSpeedRunning = Math.round(base.hsr * variance * (isHard ? 1.25 : 0.85));
    const sprintDistance = Math.round(base.sprint * variance * (isHard ? 1.3 : 0.8));
    const accelerations = Math.round(base.acc * variance * (isHard ? 1.2 : 0.9));
    const decelerations = Math.round(base.dec * variance * (isHard ? 1.2 : 0.9));
    const highIntensityEfforts = Math.round(base.hie * variance * (isHard ? 1.25 : 0.85));
    const playerLoad = +(totalDistance * 12 + highSpeedRunning * 0.05 + accelerations * 0.8).toFixed(1);
    const avgHeartRate = Math.round(base.avgHR + (isHard ? 8 : -5) + (rand() - 0.5) * 6);
    const maxHeartRate = Math.round(base.maxHR + (isHard ? 5 : -3) + (rand() - 0.5) * 4);
    const sessionRPE = Math.min(10, Math.max(2, Math.round(base.rpe + (isHard ? 2 : -1.5) + (rand() - 0.5) * 2)));
    const trainingLoad = sessionRPE * duration;

    const z5 = Math.max(0, Math.round((isHard ? 12 : 5) + (rand() - 0.5) * 4));
    const z4 = Math.max(0, Math.round((isHard ? 25 : 15) + (rand() - 0.5) * 6));
    const z3 = Math.max(0, Math.round(30 + (rand() - 0.5) * 8));
    const z2 = Math.max(0, Math.round(20 + (rand() - 0.5) * 5));
    const z1 = Math.max(0, 100 - z5 - z4 - z3 - z2);

    sessions.push({
      id: `${athleteId}-s${d}`,
      athleteId,
      date: date.toISOString().split('T')[0],
      type,
      duration,
      totalDistance,
      relativeDistance,
      highSpeedRunning,
      sprintDistance,
      accelerations,
      decelerations,
      highIntensityEfforts,
      playerLoad,
      avgHeartRate,
      maxHeartRate,
      hrZonePercent: { z1, z2, z3, z4, z5 },
      sessionRPE,
      trainingLoad,
      contacts: base.contacts ? Math.round(base.contacts * variance) : undefined,
      contactLoad: base.contactLoad ? +(base.contactLoad * variance).toFixed(1) : undefined,
    });
  }
  return sessions;
}

export const trainingSessions: Record<string, TrainingSession[]> = {
  a1: genTrainingSessions('a1', { dist: 7.2, hsr: 420, sprint: 110, acc: 35, dec: 30, hie: 45, avgHR: 145, maxHR: 185, rpe: 6 }),
  a2: genTrainingSessions('a2', { dist: 5.8, hsr: 280, sprint: 130, acc: 32, dec: 28, hie: 38, avgHR: 140, maxHR: 182, rpe: 7, contacts: 18, contactLoad: 120 }),
  a3: genTrainingSessions('a3', { dist: 7.5, hsr: 550, sprint: 180, acc: 42, dec: 36, hie: 52, avgHR: 148, maxHR: 188, rpe: 6 }),
  a4: genTrainingSessions('a4', { dist: 6.0, hsr: 320, sprint: 150, acc: 34, dec: 30, hie: 40, avgHR: 142, maxHR: 184, rpe: 7, contacts: 20, contactLoad: 140 }),
};

// Match records
export const matchRecords: Record<string, MatchRecord[]> = {
  a1: [
    { id: 'm1', athleteId: 'a1', date: '2026-08-24', opponent: 'Riverside FC', duration: 90, minutesPlayed: 90, totalDistance: 11.2, relativeDistance: 124, highSpeedRunning: 1280, sprintDistance: 580, accelerations: 52, decelerations: 48, highIntensityEfforts: 72, avgHeartRate: 168, maxHeartRate: 192, sessionRPE: 9 },
    { id: 'm2', athleteId: 'a1', date: '2026-08-17', opponent: 'Harbor City', duration: 90, minutesPlayed: 85, totalDistance: 10.5, relativeDistance: 118, highSpeedRunning: 1150, sprintDistance: 520, accelerations: 48, decelerations: 44, highIntensityEfforts: 65, avgHeartRate: 165, maxHeartRate: 189, sessionRPE: 8 },
    { id: 'm3', athleteId: 'a1', date: '2026-08-10', opponent: 'Northside United', duration: 90, minutesPlayed: 90, totalDistance: 11.8, relativeDistance: 131, highSpeedRunning: 1420, sprintDistance: 650, accelerations: 55, decelerations: 50, highIntensityEfforts: 78, avgHeartRate: 170, maxHeartRate: 194, sessionRPE: 9 },
    { id: 'm4', athleteId: 'a1', date: '2026-08-03', opponent: 'Eastfield Town', duration: 90, minutesPlayed: 75, totalDistance: 9.8, relativeDistance: 120, highSpeedRunning: 1050, sprintDistance: 480, accelerations: 42, decelerations: 38, highIntensityEfforts: 58, avgHeartRate: 162, maxHeartRate: 186, sessionRPE: 8 },
    { id: 'm5', athleteId: 'a1', date: '2026-07-27', opponent: 'Westbridge FC', duration: 90, minutesPlayed: 90, totalDistance: 11.5, relativeDistance: 128, highSpeedRunning: 1350, sprintDistance: 610, accelerations: 54, decelerations: 49, highIntensityEfforts: 75, avgHeartRate: 169, maxHeartRate: 193, sessionRPE: 9 },
  ],
  a2: [
    { id: 'm6', athleteId: 'a2', date: '2026-08-23', opponent: 'Valley RFC', duration: 80, minutesPlayed: 80, totalDistance: 7.2, relativeDistance: 90, highSpeedRunning: 520, sprintDistance: 210, accelerations: 38, decelerations: 34, highIntensityEfforts: 42, avgHeartRate: 162, maxHeartRate: 188, sessionRPE: 9, contacts: 24, contactLoad: 180 },
    { id: 'm7', athleteId: 'a2', date: '2026-08-16', opponent: 'Mountain Springs', duration: 80, minutesPlayed: 65, totalDistance: 6.0, relativeDistance: 85, highSpeedRunning: 420, sprintDistance: 170, accelerations: 32, decelerations: 28, highIntensityEfforts: 35, avgHeartRate: 158, maxHeartRate: 185, sessionRPE: 8, contacts: 20, contactLoad: 150 },
    { id: 'm8', athleteId: 'a2', date: '2026-08-09', opponent: 'Coastal Rugby', duration: 80, minutesPlayed: 80, totalDistance: 7.5, relativeDistance: 94, highSpeedRunning: 580, sprintDistance: 240, accelerations: 42, decelerations: 38, highIntensityEfforts: 45, avgHeartRate: 165, maxHeartRate: 190, sessionRPE: 9, contacts: 26, contactLoad: 195 },
    { id: 'm9', athleteId: 'a2', date: '2026-08-02', opponent: 'Highland Warriors', duration: 80, minutesPlayed: 80, totalDistance: 6.8, relativeDistance: 85, highSpeedRunning: 480, sprintDistance: 190, accelerations: 36, decelerations: 32, highIntensityEfforts: 38, avgHeartRate: 160, maxHeartRate: 187, sessionRPE: 9, contacts: 22, contactLoad: 165 },
  ],
  a3: [
    { id: 'm10', athleteId: 'a3', date: '2026-08-24', opponent: 'Riverside FC', duration: 90, minutesPlayed: 80, totalDistance: 10.8, relativeDistance: 120, highSpeedRunning: 1650, sprintDistance: 680, accelerations: 50, decelerations: 44, highIntensityEfforts: 68, avgHeartRate: 166, maxHeartRate: 190, sessionRPE: 8 },
    { id: 'm11', athleteId: 'a3', date: '2026-08-17', opponent: 'Harbor City', duration: 90, minutesPlayed: 90, totalDistance: 11.5, relativeDistance: 128, highSpeedRunning: 1800, sprintDistance: 720, accelerations: 55, decelerations: 48, highIntensityEfforts: 75, avgHeartRate: 168, maxHeartRate: 192, sessionRPE: 9 },
    { id: 'm12', athleteId: 'a3', date: '2026-08-10', opponent: 'Northside United', duration: 90, minutesPlayed: 65, totalDistance: 9.2, relativeDistance: 115, highSpeedRunning: 1400, sprintDistance: 550, accelerations: 42, decelerations: 36, highIntensityEfforts: 55, avgHeartRate: 164, maxHeartRate: 188, sessionRPE: 8 },
  ],
  a4: [
    { id: 'm13', athleteId: 'a4', date: '2026-08-23', opponent: 'Valley RFC', duration: 80, minutesPlayed: 80, totalDistance: 7.0, relativeDistance: 88, highSpeedRunning: 480, sprintDistance: 280, accelerations: 36, decelerations: 32, highIntensityEfforts: 40, avgHeartRate: 160, maxHeartRate: 186, sessionRPE: 9, contacts: 22, contactLoad: 170 },
    { id: 'm14', athleteId: 'a4', date: '2026-08-16', opponent: 'Mountain Springs', duration: 80, minutesPlayed: 80, totalDistance: 7.5, relativeDistance: 94, highSpeedRunning: 520, sprintDistance: 310, accelerations: 40, decelerations: 36, highIntensityEfforts: 44, avgHeartRate: 163, maxHeartRate: 189, sessionRPE: 9, contacts: 25, contactLoad: 185 },
    { id: 'm15', athleteId: 'a4', date: '2026-08-09', opponent: 'Coastal Rugby', duration: 80, minutesPlayed: 75, totalDistance: 6.8, relativeDistance: 85, highSpeedRunning: 450, sprintDistance: 260, accelerations: 34, decelerations: 30, highIntensityEfforts: 36, avgHeartRate: 159, maxHeartRate: 185, sessionRPE: 8, contacts: 20, contactLoad: 155 },
  ],
};

export const aiInsights: AIInsight[] = [
  {
    id: 'i1',
    athleteId: 'a1',
    type: 'gap',
    severity: 'warning',
    finding: 'Sprint exposure during training is consistently below match requirement',
    evidence: 'Match sprint exposure: 580 m | Training average: 110 m | Difference: -81%',
    interpretation: 'Current training does not adequately reproduce the sprint demands of competition. The athlete is being underexposed to high-speed and sprint running relative to what the match requires.',
    action: 'Consider incorporating controlled high-speed exposure into selected training sessions. Target 200–300 m of sprint distance in 2–3 sessions per week while maintaining appropriate overall load and recovery.',
    metric: 'Sprint Distance',
    confidence: 'Moderate',
    dataQuality: 'GOOD',
  },
  {
    id: 'i2',
    athleteId: 'a1',
    type: 'trend',
    severity: 'positive',
    finding: '30 m sprint performance is improving steadily',
    evidence: 'Baseline: 4.35 s → Latest: 4.25 s | Improvement: +2.3% over 7 months',
    interpretation: 'The training intervention is producing a measurable improvement in sprint performance. The rate of improvement is consistent and sustainable.',
    action: 'Continue current speed development approach. Retest in 4–6 weeks to confirm continued progression. Consider progressive overload in sprint training volume.',
    metric: '30 m Sprint',
    confidence: 'High',
    dataQuality: 'GOOD',
  },
  {
    id: 'i3',
    athleteId: 'a1',
    type: 'anomaly',
    severity: 'warning',
    finding: 'Training load spike detected in the last 7 days',
    evidence: 'Acute load: 2850 AU | Chronic load (28-day): 2100 AU | ACWR: 1.36',
    interpretation: 'The acute-to-chronic workload ratio exceeds the recommended range (0.8–1.3). This represents a meaningful deviation from the athlete\'s normal workload and warrants a load management flag.',
    action: 'Monitor closely. Consider reducing intensity in the next 1–2 sessions. Ensure adequate recovery before the upcoming match. This is a load management flag, not an injury prediction.',
    metric: 'Training Load',
    confidence: 'Moderate',
    dataQuality: 'GOOD',
  },
  {
    id: 'i4',
    athleteId: 'a1',
    type: 'optimization',
    severity: 'info',
    finding: 'High-speed running exposure in training is below positional demand',
    evidence: 'Training HSR average: 420 m | Positional demand: 1000–1500 m | Match average: 1280 m',
    interpretation: 'Training high-speed running does not adequately prepare the athlete for the high-speed demands of match play. This is a key area for training optimization.',
    action: 'Introduce targeted high-speed running drills in 2 sessions per week. Progress gradually to avoid sudden load spikes. Target 600–800 m of HSR per session.',
    metric: 'High-Speed Running',
    confidence: 'Moderate',
    dataQuality: 'GOOD',
  },
  {
    id: 'i5',
    athleteId: 'a2',
    type: 'gap',
    severity: 'critical',
    finding: 'Contact load in training significantly below match demands',
    evidence: 'Match contact load: 180 AU | Training contact load: 120 AU | Difference: -33%',
    interpretation: 'Training contact exposure does not adequately prepare the athlete for the collision demands of rugby competition. This is a meaningful underexposure for a flanker.',
    action: 'Incorporate controlled contact sessions 1–2 times per week. Include wrestle, tackle technique, and collision simulation. Progress gradually to avoid excessive load.',
    metric: 'Contact Load',
    confidence: 'Moderate',
    dataQuality: 'PARTIAL',
  },
  {
    id: 'i6',
    athleteId: 'a2',
    type: 'trend',
    severity: 'positive',
    finding: 'Aerobic capacity is improving steadily',
    evidence: 'Yo-Yo IR1: 1500 m → 1850 m | Improvement: +23% over 7 months',
    interpretation: 'Aerobic development is progressing well. The athlete is approaching the positional benchmark and the rate of improvement suggests continued gains are likely.',
    action: 'Continue current aerobic development approach. Retest in 6 weeks. The athlete is within 8% of the positional benchmark.',
    metric: 'Yo-Yo IR1',
    confidence: 'High',
    dataQuality: 'GOOD',
  },
  {
    id: 'i7',
    athleteId: 'a2',
    type: 'anomaly',
    severity: 'warning',
    finding: 'Training monotony is elevated',
    evidence: 'Training monotony: 1.8 | Recommended: < 1.5',
    interpretation: 'Day-to-day variation in training load is low, indicating a monotonous training pattern. High training monotony can reduce adaptation and increase load management concerns.',
    action: 'Introduce more variation in training intensity across the week. Ensure clear distinction between hard and easy days. Include a dedicated recovery session.',
    metric: 'Training Monotony',
    confidence: 'Moderate',
    dataQuality: 'GOOD',
  },
  {
    id: 'i8',
    athleteId: 'a3',
    type: 'trend',
    severity: 'positive',
    finding: 'Maximum velocity is approaching positional benchmark',
    evidence: 'Current: 33.5 km/h | Benchmark: 34.5 km/h | Gap: 3%',
    interpretation: 'The athlete is very close to the positional benchmark for maximum velocity. Continued speed development should close this gap.',
    action: 'Maintain sprint training stimulus. Focus on maximum velocity work in controlled environments. Retest in 4 weeks.',
    metric: 'Maximum Velocity',
    confidence: 'High',
    dataQuality: 'GOOD',
  },
  {
    id: 'i9',
    athleteId: 'a4',
    type: 'gap',
    severity: 'warning',
    finding: 'Squat strength below positional benchmark for Number 8',
    evidence: 'Current: 195 kg | Benchmark: 210 kg | Gap: -7%',
    interpretation: 'Strength levels are below what is expected for a Number 8, where scrummaging and carrying power are critical. The gap is moderate and closeable.',
    action: 'Prioritize maximal strength development in the gym. Focus on squat, deadlift, and press progressions. Target 2–3 strength sessions per week in the next block.',
    metric: 'Squat 1RM',
    confidence: 'Moderate',
    dataQuality: 'GOOD',
  },
];

// Helper: get positional demand values for comparison
export function getPositionalDemand(position: Position): PerformanceDemand[] {
  return performanceDemands[position] || [];
}

export function getAthleteById(id: string): Athlete | undefined {
  return athletes.find((a) => a.id === id);
}

export function getTrainingSessions(athleteId: string): TrainingSession[] {
  return trainingSessions[athleteId] || [];
}

export function getMatchRecords(athleteId: string): MatchRecord[] {
  return matchRecords[athleteId] || [];
}

export function getCapacityTests(athleteId: string): CapacityTest[] {
  return capacityTests[athleteId] || [];
}

export function getInsightsForAthlete(athleteId: string): AIInsight[] {
  return aiInsights.filter((i) => i.athleteId === athleteId);
}

// Compute gap status between training and match averages
export function computeGapStatus(trainingAvg: number, matchAvg: number): { status: GapStatus; percentDiff: number } {
  const percentDiff = trainingAvg === 0 ? -100 : ((trainingAvg - matchAvg) / matchAvg) * 100;
  if (percentDiff < -15) return { status: 'UNDEREXPOSURE', percentDiff };
  if (percentDiff > 25) return { status: 'EXCESSIVE', percentDiff };
  return { status: 'APPROPRIATE', percentDiff };
}

// Compute training load classification
export function classifyLoad(acuteLoad: number, chronicLoad: number): 'Low Load' | 'Moderate Load' | 'High Load' | 'Very High Load' {
  const ratio = chronicLoad === 0 ? 0 : acuteLoad / chronicLoad;
  if (ratio < 0.8) return 'Low Load';
  if (ratio < 1.0) return 'Moderate Load';
  if (ratio < 1.3) return 'High Load';
  return 'Very High Load';
}

// Compute load status
export function getLoadStatus(acuteLoad: number, chronicLoad: number): 'LOW' | 'OPTIMAL' | 'HIGH' | 'FLAG' {
  const ratio = chronicLoad === 0 ? 0 : acuteLoad / chronicLoad;
  if (ratio < 0.8) return 'LOW';
  if (ratio <= 1.3) return 'OPTIMAL';
  if (ratio <= 1.5) return 'HIGH';
  return 'FLAG';
}

// Compute training monotony
export function computeMonotony(sessions: TrainingSession[]): number {
  if (sessions.length < 2) return 0;
  const loads = sessions.map((s) => s.trainingLoad);
  const mean = loads.reduce((a, b) => a + b, 0) / loads.length;
  const stdDev = Math.sqrt(loads.reduce((sq, l) => sq + (l - mean) ** 2, 0) / loads.length);
  return stdDev === 0 ? 0 : +(mean / stdDev).toFixed(2);
}

// Compute acute (7-day) and chronic (28-day) load
export function computeLoads(sessions: TrainingSession[]): { acute: number; chronic: number; acwr: number } {
  const sorted = [...sessions].sort((a, b) => b.date.localeCompare(a.date));
  const last7 = sorted.slice(0, 7);
  const last28 = sorted.slice(0, 28);
  const acute = last7.reduce((sum, s) => sum + s.trainingLoad, 0);
  const chronic = last28.length > 0 ? (last28.reduce((sum, s) => sum + s.trainingLoad, 0) / last28.length) * 7 : 0;
  const acwr = chronic === 0 ? 0 : +(acute / chronic).toFixed(2);
  return { acute, chronic: +chronic.toFixed(0), acwr };
}

// Compute average training metrics
export function computeTrainingAverages(sessions: TrainingSession[]) {
  if (sessions.length === 0) return null;
  return {
    totalDistance: +(sessions.reduce((s, x) => s + x.totalDistance, 0) / sessions.length).toFixed(2),
    highSpeedRunning: Math.round(sessions.reduce((s, x) => s + x.highSpeedRunning, 0) / sessions.length),
    sprintDistance: Math.round(sessions.reduce((s, x) => s + x.sprintDistance, 0) / sessions.length),
    accelerations: Math.round(sessions.reduce((s, x) => s + x.accelerations, 0) / sessions.length),
    decelerations: Math.round(sessions.reduce((s, x) => s + x.decelerations, 0) / sessions.length),
    highIntensityEfforts: Math.round(sessions.reduce((s, x) => s + x.highIntensityEfforts, 0) / sessions.length),
    avgHeartRate: Math.round(sessions.reduce((s, x) => s + x.avgHeartRate, 0) / sessions.length),
    sessionRPE: +(sessions.reduce((s, x) => s + x.sessionRPE, 0) / sessions.length).toFixed(1),
    duration: Math.round(sessions.reduce((s, x) => s + x.duration, 0) / sessions.length),
    contacts: sessions[0].contacts ? Math.round(sessions.reduce((s, x) => s + (x.contacts || 0), 0) / sessions.length) : undefined,
    contactLoad: sessions[0].contactLoad ? +(sessions.reduce((s, x) => s + (x.contactLoad || 0), 0) / sessions.length).toFixed(1) : undefined,
  };
}

// Compute average match metrics
export function computeMatchAverages(matches: MatchRecord[]) {
  if (matches.length === 0) return null;
  return {
    totalDistance: +(matches.reduce((s, x) => s + x.totalDistance, 0) / matches.length).toFixed(2),
    highSpeedRunning: Math.round(matches.reduce((s, x) => s + x.highSpeedRunning, 0) / matches.length),
    sprintDistance: Math.round(matches.reduce((s, x) => s + x.sprintDistance, 0) / matches.length),
    accelerations: Math.round(matches.reduce((s, x) => s + x.accelerations, 0) / matches.length),
    decelerations: Math.round(matches.reduce((s, x) => s + x.decelerations, 0) / matches.length),
    highIntensityEfforts: Math.round(matches.reduce((s, x) => s + x.highIntensityEfforts, 0) / matches.length),
    avgHeartRate: Math.round(matches.reduce((s, x) => s + x.avgHeartRate, 0) / matches.length),
    sessionRPE: +(matches.reduce((s, x) => s + x.sessionRPE, 0) / matches.length).toFixed(1),
    duration: Math.round(matches.reduce((s, x) => s + x.duration, 0) / matches.length),
    contacts: matches[0].contacts ? Math.round(matches.reduce((s, x) => s + (x.contacts || 0), 0) / matches.length) : undefined,
    contactLoad: matches[0].contactLoad ? +(matches.reduce((s, x) => s + (x.contactLoad || 0), 0) / matches.length).toFixed(1) : undefined,
  };
}
