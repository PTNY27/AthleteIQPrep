export type Sport = 'football' | 'rugby';

export type FootballPosition =
  | 'Goalkeeper'
  | 'Centre Back'
  | 'Full Back'
  | 'Defensive Midfielder'
  | 'Central Midfielder'
  | 'Attacking Midfielder'
  | 'Winger'
  | 'Striker';

export type RugbyPosition =
  | 'Prop'
  | 'Hooker'
  | 'Lock'
  | 'Flanker'
  | 'Number 8'
  | 'Scrum-half'
  | 'Fly-half'
  | 'Centre'
  | 'Wing'
  | 'Fullback';

export type Position = FootballPosition | RugbyPosition;

export interface PerformanceDemand {
  label: string;
  value: string;
  unit: string;
  description: string;
  category: 'volume' | 'intensity' | 'frequency' | 'physiological' | 'contact';
}

export interface CapacityTest {
  id: string;
  category: 'Speed' | 'Acceleration' | 'Repeated Sprint Ability' | 'Aerobic Capacity' | 'Anaerobic Capacity' | 'Change of Direction' | 'Strength / Power';
  name: string;
  unit: string;
  baseline: number;
  latest: number;
  previous: number;
  benchmark: number;
  date: string;
  history: { date: string; value: number }[];
  higherIsBetter: boolean;
}

export interface TrainingSession {
  id: string;
  athleteId: string;
  date: string;
  type: string;
  duration: number;
  totalDistance: number;
  relativeDistance: number;
  highSpeedRunning: number;
  sprintDistance: number;
  accelerations: number;
  decelerations: number;
  highIntensityEfforts: number;
  playerLoad: number;
  avgHeartRate: number;
  maxHeartRate: number;
  hrZonePercent: { z1: number; z2: number; z3: number; z4: number; z5: number };
  sessionRPE: number;
  trainingLoad: number;
  contacts?: number;
  contactLoad?: number;
  gpsCompleteness?: number;
  hrCompleteness?: number;
}

export interface MatchRecord {
  id: string;
  athleteId: string;
  date: string;
  opponent: string;
  duration: number;
  minutesPlayed: number;
  totalDistance: number;
  relativeDistance: number;
  highSpeedRunning: number;
  sprintDistance: number;
  accelerations: number;
  decelerations: number;
  highIntensityEfforts: number;
  avgHeartRate: number;
  maxHeartRate: number;
  sessionRPE: number;
  contacts?: number;
  contactLoad?: number;
}

export interface Athlete {
  id: string;
  name: string;
  sport: Sport;
  position: Position;
  age: number;
  team: string;
  avatarColor: string;
  initials: string;
}

export type LoadStatus = 'LOW' | 'OPTIMAL' | 'HIGH' | 'FLAG';
export type LoadClassification = 'Low Load' | 'Moderate Load' | 'High Load' | 'Very High Load';
export type GapStatus = 'UNDEREXPOSURE' | 'APPROPRIATE' | 'EXCESSIVE';
export type ReadinessStatus = 'READY' | 'MONITOR' | 'REVIEW';
export type DataQualityStatus = 'GOOD' | 'PARTIAL' | 'POOR';

export interface AIInsight {
  id: string;
  athleteId: string;
  type: 'anomaly' | 'trend' | 'gap' | 'optimization' | 'pattern';
  severity: 'info' | 'warning' | 'critical' | 'positive';
  finding: string;
  evidence: string;
  interpretation: string;
  action: string;
  metric: string;
  confidence: 'Low' | 'Moderate' | 'High';
  dataQuality: DataQualityStatus;
  feedback?: 'accepted' | 'modified' | 'rejected' | null;
}

export interface Intervention {
  id: string;
  athleteId: string;
  objective: string;
  metric: string;
  startDate: string;
  endDate: string;
  durationWeeks: number;
  startingPoint: number;
  target: number;
  current: number;
  unit: string;
  strategy: string;
  status: 'active' | 'completed' | 'planned';
  results?: {
    targetAchieved: boolean;
    capacityChanged: boolean;
    matchPerformanceChanged: boolean;
    similarityImproved: boolean;
    beforeValue: number;
    afterValue: number;
  };
}

export type TimePeriod = '7d' | '14d' | '28d' | '6w' | '8w' | '12w' | 'season';

// ===== STAGE 7: COACH-CENTRED DEVELOPMENT TYPES =====

export type PlanStatus = 'DRAFT' | 'ACTIVE' | 'PAUSED' | 'COMPLETED' | 'ARCHIVED';
export type ObjectivePriority = 'HIGH' | 'MEDIUM' | 'LOW';
export type ObjectiveStatus = 'NOT_STARTED' | 'IN_PROGRESS' | 'ON_TRACK' | 'AT_RISK' | 'ACHIEVED' | 'CLOSED';
export type GoalStatus = 'NOT_STARTED' | 'IN_PROGRESS' | 'ON_TRACK' | 'AT_RISK' | 'ACHIEVED' | 'CLOSED';
export type SessionStatus = 'PLANNED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED' | 'MISSED';
export type CoachDecisionType = 'accepted' | 'edited' | 'rejected' | 'deferred';
export type CoachRecommendationType = 'priority' | 'goal' | 'session' | 'objective' | 'plan' | 'report';
export type NoteCategory = 'observation' | 'session' | 'behaviour' | 'tactical' | 'technical' | 'training_response' | 'development' | 'review';
export type NoteVisibility = 'private' | 'shared' | 'staff';
export type ReviewDecision = 'continue' | 'modify' | 'increase_difficulty' | 'reduce_difficulty' | 'change_priority' | 'close_objective' | 'create_new_objective' | 'reassess_later';

export interface DevelopmentPlan {
  id: string;
  athleteId: string;
  coachId: string;
  name: string;
  startDate: string;
  endDate: string;
  status: PlanStatus;
  objectives: string[];
  reviewDate?: string;
  reassessmentDate?: string;
  coachNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DevelopmentObjective {
  id: string;
  planId: string;
  athleteId: string;
  title: string;
  description?: string;
  priority: ObjectivePriority;
  baseline?: number;
  target?: number;
  unit?: string;
  targetDate?: string;
  status: ObjectiveStatus;
  evidence?: string;
  coachNotes?: string;
  reviewDate?: string;
  aiGenerated: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Goal {
  id: string;
  athleteId: string;
  objectiveId?: string;
  metric: string;
  baseline?: number;
  target?: number;
  unit?: string;
  targetDate: string;
  priority: ObjectivePriority;
  status: GoalStatus;
  coachNotes?: string;
  aiGenerated: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SessionBlock {
  id: string;
  name: string;
  type: string;
  duration: number;
  description?: string;
  activities?: string[];
}

export interface CoachingSession {
  id: string;
  coachId: string;
  athleteId?: string;
  groupId?: string;
  date: string;
  duration: number;
  name: string;
  objective?: string;
  priority: ObjectivePriority;
  location?: string;
  equipment?: string;
  structure: SessionBlock[];
  status: SessionStatus;
  coachNotes?: string;
  aiGenerated: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CoachNote {
  id: string;
  athleteId: string;
  coachId: string;
  category: NoteCategory;
  visibility: NoteVisibility;
  content: string;
  sessionId?: string;
  createdAt: string;
}

export interface CoachDecision {
  id: string;
  athleteId: string;
  recommendationId?: string;
  recommendationType: CoachRecommendationType;
  decision: CoachDecisionType;
  originalSuggestion: string;
  finalDecision?: string;
  rationale?: string;
  coachId: string;
  createdAt: string;
}

export interface AthleteFeedback {
  id: string;
  athleteId: string;
  sessionId?: string;
  sessionDifficulty?: number;
  perceivedEffort?: number;
  confidence?: number;
  completion?: boolean;
  comments?: string;
  createdAt: string;
}

export interface DevelopmentReview {
  id: string;
  athleteId: string;
  planId?: string;
  reviewDate: string;
  baselineSummary?: string;
  progressSummary?: string;
  completedWork?: string;
  coachObservations?: string;
  athleteFeedbackSummary?: string;
  newAssessmentSummary?: string;
  updatedInsightSummary?: string;
  coachDecision: ReviewDecision;
  aiGeneratedSummary?: string;
  aiGenerated: boolean;
  coachId: string;
  createdAt: string;
}

export interface AuditEntry {
  id: string;
  athleteId?: string;
  userId: string;
  action: string;
  entityType: string;
  entityId?: string;
  originalValue?: string;
  newValue?: string;
  aiInvolved: boolean;
  rationale?: string;
  createdAt: string;
}

// ===== STAGE 8: SCOUTING & TALENT IDENTIFICATION TYPES =====

export type ScoutingProjectStatus = 'DRAFT' | 'ACTIVE' | 'PAUSED' | 'COMPLETED' | 'ARCHIVED';
export type ScoutObservationCategory = 'technical' | 'tactical' | 'physical' | 'behavioural';
export type ScoutRecommendation = 'RECOMMEND' | 'SHORTLIST' | 'MONITOR' | 'FURTHER_ASSESSMENT' | 'DO_NOT_PROGRESS' | 'DEVELOPMENT_CANDIDATE' | 'INSUFFICIENT_EVIDENCE';
export type ShortlistStatus = 'SHORTLISTED' | 'REMOVED' | 'PROMOTED';
export type WatchlistStatus = 'WATCHING' | 'REMOVED' | 'PROMOTED';
export type RecruitmentStage = 'IDENTIFIED' | 'OBSERVING' | 'SHORTLISTED' | 'FURTHER_ASSESSMENT' | 'SCOUT_REVIEW' | 'COACH_REVIEW' | 'TRIAL' | 'RECRUITMENT_DECISION' | 'ONBOARDING';
export type ScoutingDecisionType = 'shortlist' | 'watchlist' | 'further_assessment' | 'trial' | 'progress' | 'monitor' | 'do_not_progress' | 'close' | 'recruit';
export type ScoutingDecisionAction = 'accepted' | 'edited' | 'rejected' | 'deferred';
export type ScoutingReportStatus = 'DRAFT' | 'SUBMITTED' | 'APPROVED' | 'ARCHIVED';
export type EvidenceConfidence = 'high' | 'moderate' | 'low' | 'insufficient';
export type EvidenceSource = 'performance_testing' | 'match_statistics' | 'competition_results' | 'video_analysis' | 'scout_observation' | 'coach_observation' | 'athlete_self_report' | 'training_data' | 'historical_performance' | 'external_evidence';
export type DataQualityFlag = 'verified' | 'unverified' | 'incomplete' | 'conflicting' | 'outdated';
export type ScoutTaskStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled';
export type ScoutTaskPriority = 'high' | 'medium' | 'low';
export type SportKey = 'football' | 'rugby' | 'hockey' | 'swimming' | 'cricket' | 'tennis' | 'basketball' | 'volleyball';

export interface SportConfig {
  key: SportKey;
  label: string;
  positions: string[];
  technicalAttributes: string[];
  tacticalAttributes: string[];
  physicalAttributes: string[];
  performanceMetrics: string[];
  contextFactors: string[];
  isEventBased?: boolean;
  events?: string[];
  strokes?: string[];
  formats?: string[];
}

export interface EvidenceRecord {
  id: string;
  athleteId: string;
  projectId?: string;
  source: EvidenceSource;
  date: string;
  author: string;
  context?: string;
  description: string;
  confidence: EvidenceConfidence;
  qualityFlag: DataQualityFlag;
  linkedObservationId?: string;
  createdAt: string;
}

export interface ScoutTask {
  id: string;
  title: string;
  description?: string;
  assignee: string;
  athleteId?: string;
  projectId?: string;
  dueDate?: string;
  status: ScoutTaskStatus;
  priority: ScoutTaskPriority;
  createdAt: string;
  updatedAt: string;
}

export interface ScoutingAuditEntry {
  id: string;
  user: string;
  action: string;
  entityType: string;
  entityId?: string;
  athleteId?: string;
  projectId?: string;
  previousState?: string;
  newState?: string;
  timestamp: string;
}

export interface ProfileCriterion {
  metric: string;
  requirement: 'minimum' | 'target' | 'range';
  value?: number;
  minValue?: number;
  maxValue?: number;
  unit?: string;
  description?: string;
}

export interface TargetProfile {
  id: string;
  projectId: string;
  version: string;
  name: string;
  criteria: ProfileCriterion[];
  weights: Record<string, number>;
  isActive: boolean;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface ScoutingProject {
  id: string;
  name: string;
  sport: string;
  position?: string;
  ageMin?: number;
  ageMax?: number;
  competitionLevel?: string;
  location?: string;
  description?: string;
  status: ScoutingProjectStatus;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface ScoutObservation {
  id: string;
  athleteId: string;
  projectId?: string;
  scoutId: string;
  category: ScoutObservationCategory;
  observation: string;
  rating?: number;
  context?: string;
  oppositionLevel?: string;
  conditions?: string;
  observationDate: string;
  createdAt: string;
}

export interface ScoutingReport {
  id: string;
  athleteId: string;
  projectId?: string;
  scoutId: string;
  context?: string;
  currentPerformance?: string;
  keyStrengths?: string;
  developmentAreas?: string;
  tacticalObservations?: string;
  physicalObservations?: string;
  developmentTrajectory?: string;
  profileMatch?: string;
  areasRequiringEvidence?: string;
  recommendation: ScoutRecommendation;
  nextAction?: string;
  aiGeneratedDraft?: string;
  aiGenerated: boolean;
  approvedBy?: string;
  approvedAt?: string;
  status: ScoutingReportStatus;
  createdAt: string;
  updatedAt: string;
}

export interface ShortlistEntry {
  id: string;
  athleteId: string;
  projectId: string;
  scoutId: string;
  evidenceSummary?: string;
  lastObservationDate?: string;
  nextAction?: string;
  reviewDate?: string;
  status: ShortlistStatus;
  createdAt: string;
  updatedAt: string;
}

export interface WatchlistEntry {
  id: string;
  athleteId: string;
  projectId?: string;
  scoutId: string;
  reason?: string;
  status: WatchlistStatus;
  createdAt: string;
  updatedAt: string;
}

export interface RecruitmentPipelineEntry {
  id: string;
  athleteId: string;
  projectId: string;
  stage: RecruitmentStage;
  previousStage?: string;
  decisionMaker?: string;
  rationale?: string;
  aiInvolved: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ScoutingDecision {
  id: string;
  athleteId: string;
  projectId?: string;
  decisionType: ScoutingDecisionType;
  decision: ScoutingDecisionAction;
  originalSuggestion?: string;
  finalDecision?: string;
  rationale?: string;
  decisionMaker: string;
  aiInvolved: boolean;
  createdAt: string;
}

export interface SavedScoutingView {
  id: string;
  name: string;
  scoutId: string;
  filters: Record<string, unknown>;
  createdAt: string;
}

export interface ProfileMatchResult {
  metric: string;
  athleteValue?: number;
  targetValue?: number;
  unit?: string;
  match: 'match' | 'gap' | 'exceeds' | 'no_data';
  evidence?: string;
  weight?: number;
  weightedScore?: number;
}

export interface AthleteScoutingSummary {
  athlete: Athlete;
  currentLevel: string;
  developmentTrend: string;
  assessmentCoverage: 'high' | 'medium' | 'low' | 'none';
  observationCount: number;
  scoutRating?: number;
  profileMatchScore?: number;
  matchResults?: ProfileMatchResult[];
  shortlistStatus?: ShortlistStatus;
  watchlistStatus?: WatchlistStatus;
  pipelineStage?: RecruitmentStage;
}

// ===== SETTINGS & PLATFORM CONFIGURATION TYPES =====

export type UserRole = 'ADMIN' | 'HEAD_COACH' | 'COACH' | 'SCOUT' | 'PERFORMANCE_ANALYST' | 'ACADEMY_DIRECTOR' | 'READ_ONLY';
export type AppearanceMode = 'light' | 'dark' | 'system';
export type InterfaceDensity = 'compact' | 'comfortable';
export type MeasurementSystem = 'metric' | 'imperial';
export type DateFormat = 'DD/MM/YYYY' | 'MM/DD/YYYY' | 'YYYY-MM-DD';
export type TimeFormat = '12h' | '24h';
export type NotificationChannel = 'in_app' | 'email' | 'push';
export type NotificationPriority = 'informational' | 'low' | 'moderate' | 'high' | 'critical';
export type ConfigHealth = 'healthy' | 'attention_required' | 'incomplete' | 'conflict' | 'error';
export type AgeGroupKey = 'U10' | 'U12' | 'U14' | 'U16' | 'U18' | 'U20' | 'Senior' | 'Custom';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  jobTitle: string;
  avatarColor: string;
  initials: string;
  organisationId: string;
  defaultSport?: string;
  defaultTeam?: string;
  defaultProgramme?: string;
  timezone: string;
  language: string;
  dateFormat: DateFormat;
  timeFormat: TimeFormat;
  measurementSystem: MeasurementSystem;
  firstDayOfWeek: number;
  active: boolean;
  createdAt: string;
}

export interface UserPreferences {
  userId: string;
  defaultLandingPage: string;
  defaultDashboard: string;
  defaultSport?: string;
  defaultTeam?: string;
  defaultDateRange: string;
  defaultComparisonPeriod: string;
  tableDensity: InterfaceDensity;
  chartStyle: 'bars' | 'lines' | 'area';
  sidebarCollapsed: boolean;
}

export interface AppearanceSettings {
  mode: AppearanceMode;
  density: InterfaceDensity;
  textSize: 'small' | 'medium' | 'large';
  contrast: 'standard' | 'high';
  reducedMotion: boolean;
  focusVisibility: boolean;
  colorBlindMode: boolean;
}

export interface AccessibilitySettings {
  textScaling: number;
  reducedMotion: boolean;
  keyboardNavigation: boolean;
  screenReaderMode: boolean;
  highContrast: boolean;
  focusIndicators: boolean;
  chartAccessibility: boolean;
}

export interface OrganisationProfile {
  id: string;
  name: string;
  type: string;
  country: string;
  timezone: string;
  defaultLanguage: string;
  measurementSystem: MeasurementSystem;
  defaultSport: string;
  logoColor: string;
  description: string;
  contactEmail: string;
  contactPhone: string;
}

export interface ProgrammeConfig {
  id: string;
  name: string;
  type: string;
  sport: string;
  ageMin: number;
  ageMax: number;
  objectives: string;
  reportingCycle: string;
  developmentCycle: string;
  active: boolean;
}

export interface TeamConfig {
  id: string;
  name: string;
  sport: string;
  programmeId: string;
  ageGroup: string;
  competition: string;
  coachId: string;
  active: boolean;
}

export interface AgeGroupConfig {
  key: string;
  label: string;
  minAge: number;
  maxAge: number;
  sport?: string;
  genderCategory?: string;
  custom: boolean;
  active: boolean;
}

export interface RoleConfig {
  key: UserRole;
  label: string;
  description: string;
  permissions: string[];
  scopeLevel: 'organisation' | 'programme' | 'team' | 'athlete' | 'module' | 'project';
}

export interface NotificationPreference {
  userId: string;
  channel: NotificationChannel;
  enabled: boolean;
  categories: Record<string, boolean>;
  quietHoursStart?: string;
  quietHoursEnd?: string;
}

export interface NotificationRule {
  id: string;
  eventType: string;
  label: string;
  priority: NotificationPriority;
  channels: NotificationChannel[];
  active: boolean;
}

export interface BenchmarkConfig {
  id: string;
  name: string;
  sport: string;
  source: string;
  population: string;
  methodology: string;
  version: string;
  owner: string;
  date: string;
  active: boolean;
}

export interface KPIConfig {
  id: string;
  name: string;
  definition: string;
  target: string;
  frequency: string;
  owner: string;
  sport?: string;
  scope: 'organisation' | 'programme' | 'team' | 'athlete';
  version: string;
  active: boolean;
}

export interface AIConfig {
  aiEnabled: boolean;
  explanationRequired: boolean;
  explanationDepth: 'brief' | 'standard' | 'detailed';
  responseStyle: 'concise' | 'standard' | 'comprehensive';
  confidenceDisplay: boolean;
  reviewRequired: boolean;
  loggingEnabled: boolean;
  dataScope: 'restricted' | 'standard' | 'full';
  evidenceRequired: boolean;
  humanDecisionControl: boolean;
}

export interface PrivacyConfig {
  athleteVisibility: 'organisation' | 'programme' | 'team' | 'restricted';
  scoutingVisibility: 'organisation' | 'programme' | 'team' | 'restricted';
  recruitmentVisibility: 'organisation' | 'programme' | 'team' | 'restricted';
  privateNotesVisible: 'organisation' | 'programme' | 'team' | 'restricted';
  exportAllowed: boolean;
  youthRestrictions: boolean;
  publicRankings: boolean;
}

export interface ReportConfig {
  orgName: string;
  logoColor: string;
  header: string;
  footer: string;
  contactInfo: string;
  defaultFormat: 'pdf' | 'csv' | 'excel';
  defaultOrientation: 'portrait' | 'landscape';
  sections: Record<string, boolean>;
}

export interface DataRetentionConfig {
  activeRetentionDays: number;
  archiveRetentionDays: number;
  deletionPolicy: 'soft' | 'hard' | 'legal_hold';
  autoArchiveDays: number;
}

export interface DataQualityThresholds {
  missingDataThreshold: number;
  staleDataDays: number;
  duplicateDetection: boolean;
  contradictoryAlerts: boolean;
  minSampleSize: number;
}

export interface FeatureFlag {
  key: string;
  label: string;
  enabled: boolean;
  description: string;
  module: string;
}

export interface SeasonConfig {
  id: string;
  name: string;
  sport: string;
  startDate: string;
  endDate: string;
  active: boolean;
}

export interface CompetitionConfig {
  id: string;
  name: string;
  level: string;
  seasonId: string;
  format: string;
  sport: string;
  active: boolean;
}

export interface ConfigurationVersion {
  id: string;
  configurationType: string;
  version: string;
  effectiveFrom: string;
  effectiveTo?: string;
  createdBy: string;
  createdAt: string;
  reason: string;
  status: 'active' | 'superseded' | 'rolled_back';
}

export interface SettingsAuditEntry {
  id: string;
  user: string;
  action: string;
  settingType: string;
  previousValue: string;
  newValue: string;
  timestamp: string;
  reason?: string;
}

export interface TaskConfig {
  statuses: { key: string; label: string }[];
  priorities: { key: string; label: string }[];
  defaultDueDays: number;
  escalationEnabled: boolean;
}

export interface ScoutingSettings {
  defaultEvidenceConfidence: EvidenceConfidence;
  pipelineStages: string[];
  weightingValidation: boolean;
  projectStatuses: string[];
}

export interface DevelopmentSettings {
  objectiveCategories: string[];
  interventionTypes: string[];
  reviewCycles: { label: string; days: number }[];
  reassessmentIntervalDays: number;
}

export interface PerformanceSettings {
  metricCategories: string[];
  defaultUnits: Record<string, string>;
  testingFrequency: { label: string; days: number }[];
  validationRules: boolean;
}

export interface IntegrationsConfig {
  integrations: { key: string; label: string; enabled: boolean; connected: boolean; type: string }[];
}

export interface SystemStatus {
  application: 'operational' | 'degraded' | 'down';
  database: 'operational' | 'degraded' | 'down';
  analytics: 'operational' | 'degraded' | 'down';
  ai: 'operational' | 'degraded' | 'down';
  notifications: 'operational' | 'degraded' | 'down';
}

// ===== STAGE 9: MULTI-SPORT ORGANISATIONAL INTELLIGENCE TYPES =====

export type TrendClassification = 'improving' | 'stable' | 'declining' | 'variable' | 'insufficient_evidence';
export type IntelligenceScope = 'athlete' | 'team' | 'programme' | 'organisation';
export type IntelligenceStatus = 'draft' | 'review_required' | 'reviewed' | 'actioned' | 'archived';
export type DataFreshness = 'current' | 'aging' | 'stale';
export type ActionTaskStatus = 'open' | 'assigned' | 'in_progress' | 'completed' | 'deferred' | 'cancelled';
export type ActionTaskPriority = 'high' | 'medium' | 'low';
export type AlertPriority = 'informational' | 'low' | 'moderate' | 'high' | 'critical';
export type RecommendationType =
  | 'review_recommended'
  | 'further_assessment'
  | 'data_collection'
  | 'development_review'
  | 'performance_review'
  | 'scouting_review';

export interface TrendExplanation {
  what: string;
  when: string;
  magnitude: string;
  evidence: string;
  context: string;
  dataQuality: string;
  limitations: string;
  nextStep: string;
}

export interface BeforeAfterAnalysis {
  metric: string;
  baseline: number | null;
  postIntervention: number | null;
  absoluteChange: number | null;
  relativeChange: number | null;
  sampleSize: number;
  evidenceQuality: EvidenceConfidence;
  contextualFactors: string[];
  unit: string;
  higherIsBetter: boolean;
}

export interface AnomalyFlag {
  id: string;
  athleteId: string;
  type: 'sudden_change' | 'impossible_measurement' | 'unusual_workload' | 'duplicate' | 'unexpected_result' | 'contradictory' | 'data_entry_error';
  description: string;
  metric: string;
  severity: 'info' | 'warning' | 'critical';
  detectedAt: string;
  status: 'unresolved' | 'reviewing' | 'resolved';
}

export interface PatternFlag {
  id: string;
  scope: IntelligenceScope;
  scopeId: string;
  type: 'repeated_decline' | 'repeated_improvement' | 'recurring_gap' | 'testing_weakness' | 'role_strength' | 'team_wide_change' | 'programme_wide_pattern';
  description: string;
  evidence: string;
  sampleSize: number;
  confidence: EvidenceConfidence;
  detectedAt: string;
}

export interface IntelligenceInsight {
  id: string;
  scope: IntelligenceScope;
  scopeId: string;
  scopeName: string;
  title: string;
  summary: string;
  evidence: string[];
  context: string;
  dataQuality: string;
  confidence: EvidenceConfidence;
  limitations: string;
  interpretation: string;
  recommendedAction: RecommendationType;
  createdBy: string;
  createdAt: string;
  status: IntelligenceStatus;
  aiGenerated: boolean;
  reviewedBy?: string;
  reviewedAt?: string;
}

export interface AthleteDistributionEntry {
  athleteId: string;
  athleteName: string;
  category: 'high_performer' | 'developing' | 'stable' | 'declining' | 'unusual' | 'insufficient_data';
  metric: string;
  value: number | null;
  unit: string;
}

export interface TeamIntelligenceSummary {
  teamId: string;
  teamName: string;
  sport: string;
  ageGroup: string;
  competition: string;
  coach: string;
  squadSize: number;
  activeAthletes: number;
  performanceTrend: TrendClassification;
  squadStrengths: string[];
  squadWeaknesses: string[];
  positionalCoverage: Record<string, number>;
  athleteAvailability: number;
  developmentNeeds: string[];
  performanceDistribution: {
    mean: number;
    median: number;
    min: number;
    max: number;
    stdDev: number;
    sampleSize: number;
  };
  developmentObjectives: number;
  activeInterventions: number;
  interventionCompletion: number;
  reassessmentRate: number;
  dataQualityScore: number;
  trendExplanation: TrendExplanation | null;
}

export interface ProgrammeIntelligenceSummary {
  programmeId: string;
  programmeName: string;
  programmeType: string;
  sport: string;
  teamCount: number;
  athleteCount: number;
  coachCount: number;
  activeDevelopmentPlans: number;
  scoutingActivity: number;
  athleteProgression: TrendClassification;
  teamProgression: TrendClassification;
  testingTrends: TrendClassification;
  developmentOutcomes: {
    objectivesSet: number;
    objectivesAchieved: number;
    interventionsCompleted: number;
    reassessmentRate: number;
  };
  programmeKPIs: { name: string; target: string; current: string; status: 'on_track' | 'at_risk' | 'off_track' | 'insufficient_data' }[];
  dataQualityScore: number;
  teams: TeamIntelligenceSummary[];
}

export interface SportOrganisationSummary {
  sport: string;
  programmeCount: number;
  teamCount: number;
  athleteCount: number;
  performanceTrend: TrendClassification;
  dataQualityScore: number;
  developmentActivity: number;
  scoutingActivity: number;
}

export interface OrganisationIntelligenceSummary {
  organisationName: string;
  totalAthletes: number;
  totalTeams: number;
  totalProgrammes: number;
  activeSports: string[];
  activeDevelopmentPlans: number;
  scoutingProjects: number;
  testingActivity: number;
  dataCompleteness: number;
  assessmentCompletion: number;
  developmentProgression: TrendClassification;
  organisationalTrends: {
    improving: number;
    stable: number;
    declining: number;
    insufficientEvidence: number;
  };
  sports: SportOrganisationSummary[];
  attentionRequired: AttentionItem[];
  kpis: { name: string; target: string; current: string; status: 'on_track' | 'at_risk' | 'off_track' | 'insufficient_data' }[];
  dataQuality: OrgDataQualitySummary;
}

export interface AttentionItem {
  id: string;
  type: 'data_issue' | 'overdue_assessment' | 'performance_change' | 'unresolved_disagreement' | 'incomplete_development' | 'pending_review';
  priority: ActionTaskPriority;
  description: string;
  scope: IntelligenceScope;
  scopeId: string;
  scopeName: string;
  createdAt: string;
}

export interface OrgDataQualitySummary {
  overallScore: number;
  completeness: number;
  recency: number;
  consistency: number;
  validity: number;
  contextAvailability: number;
  issues: {
    missingAthleteData: number;
    missingAssessments: number;
    missingTesting: number;
    staleRecords: number;
    duplicateAthletes: number;
    contradictoryRecords: number;
    incompleteProfiles: number;
    invalidMeasurements: number;
  };
}

export interface ActionTask {
  id: string;
  recommendation: string;
  owner: string;
  priority: ActionTaskPriority;
  dueDate: string;
  linkedScope: IntelligenceScope;
  linkedScopeId: string;
  linkedScopeName: string;
  status: ActionTaskStatus;
  completionDate?: string;
  outcome?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AlertConfig {
  id: string;
  type: 'overdue_assessment' | 'unusual_performance_change' | 'missing_testing' | 'declining_trend' | 'benchmark_movement' | 'unresolved_conflict' | 'incomplete_development' | 'pending_review';
  label: string;
  priority: AlertPriority;
  enabled: boolean;
  threshold?: number;
  createdAt: string;
}

export interface SavedView {
  id: string;
  name: string;
  scope: IntelligenceScope;
  filters: Record<string, unknown>;
  createdBy: string;
  createdAt: string;
}

export interface ReportVersion {
  id: string;
  reportType: 'athlete' | 'team' | 'programme' | 'organisation';
  scopeId: string;
  scopeName: string;
  author: string;
  date: string;
  dataPeriod: string;
  benchmarkVersion: string;
  kpiVersion?: string;
  reportVersion: string;
  includedEvidence: string[];
  modifications: string;
  createdAt: string;
}

export interface BenchmarkVersion {
  id: string;
  benchmarkId: string;
  benchmarkName: string;
  version: string;
  sport: string;
  metric: string;
  population: string;
  sampleSize: number;
  source: string;
  methodology: string;
  effectiveDate: string;
  owner: string;
  status: 'active' | 'superseded';
  createdAt: string;
}

export interface KPISnapshot {
  id: string;
  kpiId: string;
  kpiName: string;
  version: string;
  scope: IntelligenceScope;
  scopeId: string;
  target: string;
  currentValue: string;
  measurementPeriod: string;
  status: 'on_track' | 'at_risk' | 'off_track' | 'insufficient_data';
  recordedAt: string;
}
