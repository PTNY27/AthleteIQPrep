import type {
  Athlete,
  TrendClassification,
  TeamIntelligenceSummary,
  ProgrammeIntelligenceSummary,
  OrganisationIntelligenceSummary,
  SportOrganisationSummary,
  AttentionItem,
  OrgDataQualitySummary,
  ActionTask,
  AlertConfig,
  SavedView,
  ReportVersion,
  BenchmarkVersion,
  KPISnapshot,
  IntelligenceInsight,
  AnomalyFlag,
  PatternFlag,
  BeforeAfterAnalysis,
  AthleteDistributionEntry,
  EvidenceConfidence,
  IntelligenceScope,
  IntelligenceStatus,
  RecommendationType,
} from './types';
import { getAllAthletes, getAllTrainingSessions, getAllMatchRecords, getAllCapacityTests, getAllInsights, getAllInterventions, computeDataQuality, computeReadiness, computeSquadOverview } from './extendedData';
import { computeLoads, getLoadStatus, computeTrainingAverages, computeMatchAverages } from './demoData';
import { getProgrammes, getTeams, getBenchmarks, getKPIs, getOrganisation } from './settingsEngine';
import { detectTrend, computeDescriptiveStats } from './statisticalEngine';
import { getRecruitmentDashboard } from './scoutingEngine';
import { getCoachAthleteSummaries, getAttentionRequired } from './coachEngine';

// ===== IN-MEMORY STATE =====

let actionTasks: ActionTask[] = [];
let alertConfigs: AlertConfig[] = [
  { id: 'alert-1', type: 'overdue_assessment', label: 'Overdue Assessment', priority: 'moderate', enabled: true, createdAt: '2026-09-01T00:00:00Z' },
  { id: 'alert-2', type: 'unusual_performance_change', label: 'Unusual Performance Change', priority: 'high', enabled: true, threshold: 15, createdAt: '2026-09-01T00:00:00Z' },
  { id: 'alert-3', type: 'missing_testing', label: 'Missing Testing', priority: 'moderate', enabled: true, createdAt: '2026-09-01T00:00:00Z' },
  { id: 'alert-4', type: 'declining_trend', label: 'Declining Trend', priority: 'high', enabled: true, createdAt: '2026-09-01T00:00:00Z' },
  { id: 'alert-5', type: 'unresolved_conflict', label: 'Unresolved Data Conflict', priority: 'moderate', enabled: true, createdAt: '2026-09-01T00:00:00Z' },
  { id: 'alert-6', type: 'incomplete_development', label: 'Incomplete Development Cycle', priority: 'moderate', enabled: true, createdAt: '2026-09-01T00:00:00Z' },
  { id: 'alert-7', type: 'pending_review', label: 'Pending Professional Review', priority: 'moderate', enabled: true, createdAt: '2026-09-01T00:00:00Z' },
];

let savedViews: SavedView[] = [
  { id: 'view-1', name: 'U18 Football Development', scope: 'team', filters: { sport: 'football', ageGroup: 'U18' }, createdBy: 'user-1', createdAt: '2026-09-01T00:00:00Z' },
  { id: 'view-2', name: 'Academy-wide Testing', scope: 'organisation', filters: {}, createdBy: 'user-1', createdAt: '2026-09-01T00:00:00Z' },
];

let reportVersions: ReportVersion[] = [];
let benchmarkVersions: BenchmarkVersion[] = [
  { id: 'bv-1', benchmarkId: 'bm-1', benchmarkName: 'U16 Football Speed Benchmark', version: 'v1.0', sport: 'football', metric: '30 m Sprint', population: 'U16 Academy', sampleSize: 45, source: 'Organisation', methodology: '30m sprint test', effectiveDate: '2026-01-15', owner: 'user-1', status: 'active', createdAt: '2026-01-15T00:00:00Z' },
  { id: 'bv-2', benchmarkId: 'bm-2', benchmarkName: 'Senior Rugby Power Benchmark', version: 'v1.0', sport: 'rugby', metric: 'Countermovement Jump', population: 'Senior', sampleSize: 30, source: 'Sport Benchmark', methodology: 'Countermovement jump', effectiveDate: '2026-02-01', owner: 'user-1', status: 'active', createdAt: '2026-02-01T00:00:00Z' },
];

let kpiSnapshots: KPISnapshot[] = [];
let intelligenceInsights: IntelligenceInsight[] = [];
let anomalies: AnomalyFlag[] = [];
let patterns: PatternFlag[] = [];

// ===== TREND ENGINE =====

export function classifyTrend(values: number[], higherIsBetter: boolean, sampleSize: number): TrendClassification {
  if (sampleSize < 3 || values.length < 3) return 'insufficient_evidence';
  const history = values.map((v, i) => ({ date: `2026-01-${String(i + 1).padStart(2, '0')}`, value: v }));
  const trend = detectTrend(history, higherIsBetter);
  if (trend.r2 < 0.3) return 'variable';
  const slope = trend.slope;
  const threshold = 0.02;
  if (Math.abs(slope) < threshold) return 'stable';
  if (higherIsBetter) return slope > 0 ? 'improving' : 'declining';
  return slope < 0 ? 'improving' : 'declining';
}

export function classifyTrendFromHistory(
  history: { date: string; value: number }[],
  higherIsBetter: boolean
): TrendClassification {
  if (history.length < 3) return 'insufficient_evidence';
  const values = history.map((h) => h.value);
  return classifyTrend(values, higherIsBetter, values.length);
}

// ===== TREND EXPLANATION =====

export function generateTrendExplanation(
  metric: string,
  history: { date: string; value: number }[],
  higherIsBetter: boolean,
  contextFactors: string[]
): {
  what: string;
  when: string;
  magnitude: string;
  evidence: string;
  context: string;
  dataQuality: string;
  limitations: string;
  nextStep: string;
} | null {
  if (history.length < 3) return null;
  const values = history.map((h) => h.value);
  const first = values[0];
  const last = values[values.length - 1];
  const absChange = last - first;
  const relChange = first !== 0 ? (absChange / first) * 100 : 0;
  const trend = classifyTrendFromHistory(history, higherIsBetter);
  const direction = higherIsBetter ? (absChange > 0 ? 'increased' : 'decreased') : (absChange < 0 ? 'improved' : 'worsened');

  return {
    what: `${metric} ${direction} from ${first} to ${last}`,
    when: `${history[0].date} to ${history[history.length - 1].date}`,
    magnitude: `Absolute change: ${absChange.toFixed(2)} | Relative change: ${relChange.toFixed(1)}%`,
    evidence: `${history.length} data points across ${history[0].date}–${history[history.length - 1].date}`,
    context: contextFactors.length > 0 ? contextFactors.join(', ') : 'No contextual factors recorded',
    dataQuality: history.length >= 5 ? 'High — sufficient longitudinal data' : history.length >= 3 ? 'Moderate — minimum data for trend' : 'Low — insufficient data',
    limitations: 'The available data do not establish causation. Concurrent factors may explain the observed change.',
    nextStep: trend === 'declining' ? 'Review training load, athlete availability, and contextual factors alongside this trend.' : trend === 'improving' ? 'Continue current approach and reassess in 4–6 weeks.' : 'Monitor and collect additional data points for clearer trend interpretation.',
  };
}

// ===== BEFORE/AFTER ANALYSIS =====

export function computeBeforeAfter(
  metric: string,
  baseline: number | null,
  postValue: number | null,
  unit: string,
  higherIsBetter: boolean,
  sampleSize: number,
  contextualFactors: string[]
): BeforeAfterAnalysis {
  const absoluteChange = baseline !== null && postValue !== null ? postValue - baseline : null;
  const relativeChange = absoluteChange !== null && baseline !== null && baseline !== 0 ? (absoluteChange / baseline) * 100 : null;
  const evidenceQuality: EvidenceConfidence = sampleSize >= 10 ? 'high' : sampleSize >= 5 ? 'moderate' : sampleSize >= 3 ? 'low' : 'insufficient';

  return {
    metric,
    baseline,
    postIntervention: postValue,
    absoluteChange,
    relativeChange,
    sampleSize,
    evidenceQuality,
    contextualFactors,
    unit,
    higherIsBetter,
  };
}

// ===== ANOMALY DETECTION =====

export function detectOrgAnomalies(): AnomalyFlag[] {
  const flags: AnomalyFlag[] = [];
  const athletes = getAllAthletes();

  for (const athlete of athletes) {
    const tests = getAllCapacityTests(athlete.id);
    const sessions = getAllTrainingSessions(athlete.id);

    for (const test of tests) {
      if (test.history.length >= 2) {
        const recent = test.history[test.history.length - 1].value;
        const previous = test.history[test.history.length - 2].value;
        const pctChange = previous !== 0 ? Math.abs((recent - previous) / previous) * 100 : 0;
        if (pctChange > 20) {
          flags.push({
            id: `anom-${athlete.id}-${test.id}`,
            athleteId: athlete.id,
            type: 'sudden_change',
            description: `${test.name}: ${pctChange.toFixed(0)}% change between assessments (${previous} → ${recent} ${test.unit})`,
            metric: test.name,
            severity: pctChange > 30 ? 'critical' : 'warning',
            detectedAt: test.date,
            status: 'unresolved',
          });
        }
      }
    }

    if (sessions.length > 0) {
      const loads = sessions.map((s) => s.trainingLoad);
      const avg = loads.reduce((a, b) => a + b, 0) / loads.length;
      const maxLoad = Math.max(...loads);
      if (avg > 0 && maxLoad > avg * 2.5) {
        flags.push({
          id: `anom-${athlete.id}-load`,
          athleteId: athlete.id,
          type: 'unusual_workload',
          description: `Training load spike: ${maxLoad} AU vs average ${Math.round(avg)} AU`,
          metric: 'Training Load',
          severity: 'warning',
          detectedAt: sessions[0].date,
          status: 'unresolved',
        });
      }
    }
  }

  return flags;
}

// ===== PATTERN DETECTION =====

export function detectOrgPatterns(): PatternFlag[] {
  const flags: PatternFlag[] = [];
  const athletes = getAllAthletes();
  const sportGroups = new Map<string, Athlete[]>();

  for (const a of athletes) {
    const group = sportGroups.get(a.sport) || [];
    group.push(a);
    sportGroups.set(a.sport, group);
  }

  for (const [sport, group] of sportGroups) {
    let improving = 0;
    let declining = 0;
    let total = 0;

    for (const athlete of group) {
      const tests = getAllCapacityTests(athlete.id);
      for (const test of tests) {
        if (test.history.length >= 3) {
          const trend = classifyTrendFromHistory(test.history, test.higherIsBetter);
          total++;
          if (trend === 'improving') improving++;
          if (trend === 'declining') declining++;
        }
      }
    }

    if (total >= 4) {
      if (declining >= Math.ceil(total * 0.4)) {
        flags.push({
          id: `pat-${sport}-decline`,
          scope: 'organisation',
          scopeId: sport,
          type: 'team_wide_change',
          description: `${sport}: ${declining} of ${total} test trends are declining`,
          evidence: `${Math.round((declining / total) * 100)}% of ${sport} capacity tests show declining trends`,
          sampleSize: total,
          confidence: total >= 10 ? 'high' : 'moderate',
          detectedAt: new Date().toISOString().split('T')[0],
        });
      }
      if (improving >= Math.ceil(total * 0.5)) {
        flags.push({
          id: `pat-${sport}-improve`,
          scope: 'organisation',
          scopeId: sport,
          type: 'repeated_improvement',
          description: `${sport}: ${improving} of ${total} test trends are improving`,
          evidence: `${Math.round((improving / total) * 100)}% of ${sport} capacity tests show improving trends`,
          sampleSize: total,
          confidence: total >= 10 ? 'high' : 'moderate',
          detectedAt: new Date().toISOString().split('T')[0],
        });
      }
    }
  }

  return flags;
}

// ===== ATHLETE DISTRIBUTION =====

export function computeAthleteDistribution(metric: string, unit: string): AthleteDistributionEntry[] {
  const athletes = getAllAthletes();
  const entries: AthleteDistributionEntry[] = [];

  for (const athlete of athletes) {
    const tests = getAllCapacityTests(athlete.id);
    const test = tests.find((t) => t.name === metric || t.category === metric);
    if (!test || test.history.length < 3) {
      entries.push({
        athleteId: athlete.id,
        athleteName: athlete.name,
        category: 'insufficient_data',
        metric,
        value: null,
        unit,
      });
      continue;
    }

    const trend = classifyTrendFromHistory(test.history, test.higherIsBetter);
    const latest = test.latest;
    const benchmark = test.benchmark;
    const ratio = benchmark !== 0 ? latest / benchmark : 1;

    let category: AthleteDistributionEntry['category'];
    if (trend === 'insufficient_evidence') category = 'insufficient_data';
    else if (test.higherIsBetter ? ratio >= 0.95 : ratio <= 1.05) category = 'high_performer';
    else if (trend === 'improving') category = 'developing';
    else if (trend === 'declining') category = 'declining';
    else if (trend === 'variable') category = 'unusual';
    else category = 'stable';

    entries.push({
      athleteId: athlete.id,
      athleteName: athlete.name,
      category,
      metric,
      value: latest,
      unit,
    });
  }

  return entries;
}

// ===== TEAM INTELLIGENCE =====

export function getTeamIntelligence(): TeamIntelligenceSummary[] {
  const teams = getTeams();
  const athletes = getAllAthletes();

  return teams.map((team) => {
    const teamAthletes = athletes.filter((a) => a.team === team.name || a.sport === team.sport);
    const squadSize = teamAthletes.length;
    const activeAthletes = teamAthletes.filter((a) => {
      const sessions = getAllTrainingSessions(a.id);
      return sessions.length > 0;
    }).length;

    let trendCount = { improving: 0, stable: 0, declining: 0, variable: 0, insufficient: 0 };
    const strengths: string[] = [];
    const weaknesses: string[] = [];
    const positionalCoverage: Record<string, number> = {};
    let totalLoadValues: number[] = [];
    let totalDataQuality = 0;
    let developmentObjectives = 0;
    let activeInterventions = 0;
    let completedInterventions = 0;
    let reassessmentCount = 0;

    for (const athlete of teamAthletes) {
      positionalCoverage[athlete.position] = (positionalCoverage[athlete.position] || 0) + 1;

      const tests = getAllCapacityTests(athlete.id);
      for (const test of tests) {
        if (test.history.length >= 3) {
          const trend = classifyTrendFromHistory(test.history, test.higherIsBetter);
          if (trend === 'improving') { trendCount.improving++; strengths.push(`${athlete.name}: ${test.name}`); }
          else if (trend === 'declining') { trendCount.declining++; weaknesses.push(`${athlete.name}: ${test.name}`); }
          else if (trend === 'stable') trendCount.stable++;
          else if (trend === 'variable') trendCount.variable++;
          else trendCount.insufficient++;
        }
      }

      const sessions = getAllTrainingSessions(athlete.id);
      if (sessions.length > 0) {
        const loads = sessions.map((s) => s.trainingLoad);
        totalLoadValues = [...totalLoadValues, ...loads];
      }

      const dq = computeDataQuality(athlete.id);
      totalDataQuality += dq.status === 'GOOD' ? 100 : dq.status === 'PARTIAL' ? 75 : 50;

      const interventions = getAllInterventions().filter((i) => i.athleteId === athlete.id);
      activeInterventions += interventions.filter((i) => i.status === 'active' || i.status === 'planned').length;
      completedInterventions += interventions.filter((i) => i.status === 'completed').length;
      developmentObjectives += interventions.length;
      reassessmentCount += tests.filter((t) => t.history.length >= 2).length;
    }

    const avgDataQuality = squadSize > 0 ? Math.round(totalDataQuality / squadSize) : 0;
    const performanceTrend: TrendClassification =
      trendCount.improving > trendCount.declining + trendCount.stable ? 'improving' :
      trendCount.declining > trendCount.improving + trendCount.stable ? 'declining' :
      trendCount.insufficient > trendCount.improving + trendCount.declining + trendCount.stable ? 'insufficient_evidence' :
      trendCount.variable > trendCount.stable ? 'variable' : 'stable';

    const stats = computeDescriptiveStats(totalLoadValues) ?? { mean: 0, median: 0, min: 0, max: 0, stdDev: 0 };

    const interventionCompletion = developmentObjectives > 0 ? Math.round((completedInterventions / developmentObjectives) * 100) : 0;
    const reassessmentRate = developmentObjectives > 0 ? Math.round((reassessmentCount / (developmentObjectives * 2)) * 100) : 0;
    const athleteAvailability = squadSize > 0 ? Math.round((activeAthletes / squadSize) * 100) : 0;

    const developmentNeeds = weaknesses.slice(0, 5);

    let trendExplanation = null;
    if (teamAthletes.length > 0) {
      const firstAthlete = teamAthletes[0];
      const firstTests = getAllCapacityTests(firstAthlete.id);
      if (firstTests.length > 0 && firstTests[0].history.length >= 3) {
        trendExplanation = generateTrendExplanation(
          firstTests[0].name,
          firstTests[0].history,
          firstTests[0].higherIsBetter,
          [`Team: ${team.name}`, `Sport: ${team.sport}`, `Age group: ${team.ageGroup}`]
        );
      }
    }

    return {
      teamId: team.id,
      teamName: team.name,
      sport: team.sport,
      ageGroup: team.ageGroup,
      competition: team.competition,
      coach: team.coachId,
      squadSize,
      activeAthletes,
      performanceTrend,
      squadStrengths: strengths.slice(0, 5),
      squadWeaknesses: weaknesses.slice(0, 5),
      positionalCoverage,
      athleteAvailability,
      developmentNeeds,
      performanceDistribution: {
        mean: Math.round(stats.mean),
        median: Math.round(stats.median),
        min: Math.round(stats.min),
        max: Math.round(stats.max),
        stdDev: Math.round(stats.stdDev),
        sampleSize: totalLoadValues.length,
      },
      developmentObjectives,
      activeInterventions,
      interventionCompletion,
      reassessmentRate,
      dataQualityScore: avgDataQuality,
      trendExplanation,
    };
  });
}

// ===== PROGRAMME INTELLIGENCE =====

export function getProgrammeIntelligence(): ProgrammeIntelligenceSummary[] {
  const programmes = getProgrammes();
  const teams = getTeams();
  const athletes = getAllAthletes();
  const teamIntel = getTeamIntelligence();

  return programmes.map((prog) => {
    const progTeams = teams.filter((t) => t.programmeId === prog.id);
    const progTeamIntel = teamIntel.filter((ti) => progTeams.some((t) => t.id === ti.teamId));
    const progAthletes = athletes.filter((a) => progTeams.some((t) => t.sport === a.sport));
    const coachCount = new Set(progTeams.map((t) => t.coachId)).size;

    let activePlans = 0;
    let objectivesSet = 0;
    let objectivesAchieved = 0;
    let interventionsCompleted = 0;
    let reassessmentCount = 0;
    let totalDQ = 0;

    for (const athlete of progAthletes) {
      const interventions = getAllInterventions().filter((i) => i.athleteId === athlete.id);
      activePlans += interventions.filter((i) => i.status === 'active' || i.status === 'planned').length;
      objectivesSet += interventions.length;
      objectivesAchieved += interventions.filter((i) => i.status === 'completed' && i.results?.targetAchieved).length;
      interventionsCompleted += interventions.filter((i) => i.status === 'completed').length;
      const tests = getAllCapacityTests(athlete.id);
      reassessmentCount += tests.filter((t) => t.history.length >= 2).length;
      const dq = computeDataQuality(athlete.id);
      totalDQ += dq.status === 'GOOD' ? 100 : dq.status === 'PARTIAL' ? 75 : 50;
    }

    const athleteProgression: TrendClassification = progTeamIntel.filter((t) => t.performanceTrend === 'improving').length >
      progTeamIntel.filter((t) => t.performanceTrend === 'declining').length ? 'improving' :
      progTeamIntel.filter((t) => t.performanceTrend === 'declining').length >
      progTeamIntel.filter((t) => t.performanceTrend === 'improving').length ? 'declining' : 'stable';

    const teamProgression: TrendClassification = athleteProgression;

    const testingTrends: TrendClassification = progAthletes.length > 0
      ? athleteProgression
      : 'insufficient_evidence';

    const reassessmentRate = objectivesSet > 0 ? Math.round((reassessmentCount / (objectivesSet * 2)) * 100) : 0;
    const dataQualityScore = progAthletes.length > 0 ? Math.round(totalDQ / progAthletes.length) : 0;

    const kpis = getKPIs().filter((k) => k.scope === 'programme' || k.scope === 'organisation').map((k) => ({
      name: k.name,
      target: k.target,
      current: k.scope === 'organisation' ? '87%' : '82%',
      status: 'on_track' as const,
    }));

    return {
      programmeId: prog.id,
      programmeName: prog.name,
      programmeType: prog.type,
      sport: prog.sport,
      teamCount: progTeams.length,
      athleteCount: progAthletes.length,
      coachCount,
      activeDevelopmentPlans: activePlans,
      scoutingActivity: 0,
      athleteProgression,
      teamProgression,
      testingTrends,
      developmentOutcomes: {
        objectivesSet,
        objectivesAchieved,
        interventionsCompleted,
        reassessmentRate,
      },
      programmeKPIs: kpis,
      dataQualityScore,
      teams: progTeamIntel,
    };
  });
}

// ===== ORGANISATION INTELLIGENCE =====

export function getOrganisationIntelligence(): OrganisationIntelligenceSummary {
  const org = getOrganisation();
  const athletes = getAllAthletes();
  const teams = getTeams();
  const programmes = getProgrammes();
  const teamIntel = getTeamIntelligence();
  const programmeIntel = getProgrammeIntelligence();
  const allInsights = [...new Set([...athletes.map((a) => a.id)])].flatMap((id) => getAllInsights(id));
  const interventions = getAllInterventions();

  const activeSports = [...new Set(athletes.map((a) => a.sport))];
  const activeDevelopmentPlans = interventions.filter((i) => i.status === 'active' || i.status === 'planned').length;
  const testingActivity = athletes.reduce((sum, a) => sum + getAllCapacityTests(a.id).length, 0);

  const sports: SportOrganisationSummary[] = activeSports.map((sport) => {
    const sportAthletes = athletes.filter((a) => a.sport === sport);
    const sportTeams = teams.filter((t) => t.sport === sport);
    const sportProgrammes = programmes.filter((p) => p.sport === sport);
    const sportTeamIntel = teamIntel.filter((ti) => ti.sport === sport);
    const sportDQ = sportAthletes.length > 0
      ? Math.round(sportAthletes.reduce((s, a) => {
          const dq = computeDataQuality(a.id);
          return s + (dq.status === 'GOOD' ? 100 : dq.status === 'PARTIAL' ? 75 : 50);
        }, 0) / sportAthletes.length)
      : 0;

    const improving = sportTeamIntel.filter((t) => t.performanceTrend === 'improving').length;
    const declining = sportTeamIntel.filter((t) => t.performanceTrend === 'declining').length;
    const trend: TrendClassification = improving > declining ? 'improving' : declining > improving ? 'declining' : 'stable';

    return {
      sport,
      programmeCount: sportProgrammes.length,
      teamCount: sportTeams.length,
      athleteCount: sportAthletes.length,
      performanceTrend: trend,
      dataQualityScore: sportDQ,
      developmentActivity: sportAthletes.reduce((s, a) => s + getAllInterventions().filter((i) => i.athleteId === a.id).length, 0),
      scoutingActivity: 0,
    };
  });

  const trends = {
    improving: teamIntel.filter((t) => t.performanceTrend === 'improving').length,
    stable: teamIntel.filter((t) => t.performanceTrend === 'stable').length,
    declining: teamIntel.filter((t) => t.performanceTrend === 'declining').length,
    insufficientEvidence: teamIntel.filter((t) => t.performanceTrend === 'insufficient_evidence' || t.performanceTrend === 'variable').length,
  };

  const developmentProgression: TrendClassification =
    trends.improving > trends.declining ? 'improving' :
    trends.declining > trends.improving ? 'declining' : 'stable';

  const dataQuality = computeOrgDataQuality();

  const attentionItems = generateAttentionItems();

  const kpis = getKPIs().filter((k) => k.scope === 'organisation').map((k) => ({
    name: k.name,
    target: k.target,
    current: '87%',
    status: 'on_track' as const,
  }));

  const assessmentCompletion = Math.round(
    (athletes.filter((a) => getAllCapacityTests(a.id).length > 0).length / Math.max(athletes.length, 1)) * 100
  );

  return {
    organisationName: org.name,
    totalAthletes: athletes.length,
    totalTeams: teams.length,
    totalProgrammes: programmes.length,
    activeSports,
    activeDevelopmentPlans,
    scoutingProjects: 0,
    testingActivity,
    dataCompleteness: dataQuality.overallScore,
    assessmentCompletion,
    developmentProgression,
    organisationalTrends: trends,
    sports,
    attentionRequired: attentionItems,
    kpis,
    dataQuality,
  };
}

// ===== DATA QUALITY =====

export function computeOrgDataQuality(): OrgDataQualitySummary {
  const athletes = getAllAthletes();
  let missingAthleteData = 0;
  let missingAssessments = 0;
  let missingTesting = 0;
  let staleRecords = 0;
  let duplicateAthletes = 0;
  let contradictoryRecords = 0;
  let incompleteProfiles = 0;
  let invalidMeasurements = 0;

  let totalCompleteness = 0;
  let totalRecency = 0;
  let totalConsistency = 0;
  let totalValidity = 0;
  let totalContext = 0;

  const seenNames = new Map<string, number>();

  for (const athlete of athletes) {
    const tests = getAllCapacityTests(athlete.id);
    const sessions = getAllTrainingSessions(athlete.id);
    const matches = getAllMatchRecords(athlete.id);

    if (tests.length === 0) missingTesting++;
    if (sessions.length === 0) missingAthleteData++;
    if (tests.length === 0 && sessions.length === 0) incompleteProfiles++;

    const seen = seenNames.get(athlete.name);
    if (seen !== undefined) {
      duplicateAthletes++;
      seenNames.set(athlete.name, seen + 1);
    } else {
      seenNames.set(athlete.name, 1);
    }

    for (const test of tests) {
      if (test.history.length < 2) missingAssessments++;
      const lastDate = new Date(test.date);
      const daysSince = (Date.now() - lastDate.getTime()) / (1000 * 60 * 60 * 24);
      if (daysSince > 90) staleRecords++;
      if (test.latest < 0 || test.benchmark < 0) invalidMeasurements++;
      if (test.history.length >= 2) {
        const recent = test.history[test.history.length - 1].value;
        const prev = test.history[test.history.length - 2].value;
        if (prev !== 0 && Math.abs((recent - prev) / prev) > 0.5) contradictoryRecords++;
      }
    }

    const dq = computeDataQuality(athlete.id);
    const completeness = tests.length > 0 && sessions.length > 0 ? 100 : 50;
    const recency = sessions.length > 0 ? 90 : 30;
    const consistency = dq.status === 'GOOD' ? 100 : dq.status === 'PARTIAL' ? 70 : 40;
    const validity = invalidMeasurements === 0 ? 100 : 70;
    const context = matches.length > 0 ? 80 : 40;

    totalCompleteness += completeness;
    totalRecency += recency;
    totalConsistency += consistency;
    totalValidity += validity;
    totalContext += context;
  }

  const n = Math.max(athletes.length, 1);
  const overallScore = Math.round((totalCompleteness + totalRecency + totalConsistency + totalValidity + totalContext) / (5 * n));

  return {
    overallScore,
    completeness: Math.round(totalCompleteness / n),
    recency: Math.round(totalRecency / n),
    consistency: Math.round(totalConsistency / n),
    validity: Math.round(totalValidity / n),
    contextAvailability: Math.round(totalContext / n),
    issues: {
      missingAthleteData,
      missingAssessments,
      missingTesting,
      staleRecords,
      duplicateAthletes,
      contradictoryRecords,
      incompleteProfiles,
      invalidMeasurements,
    },
  };
}

// ===== ATTENTION ITEMS =====

export function generateAttentionItems(): AttentionItem[] {
  const items: AttentionItem[] = [];
  const athletes = getAllAthletes();
  const teamIntel = getTeamIntelligence();

  for (const athlete of athletes) {
    const tests = getAllCapacityTests(athlete.id);
    const sessions = getAllTrainingSessions(athlete.id);

    if (tests.length === 0) {
      items.push({
        id: `att-${athlete.id}-testing`,
        type: 'overdue_assessment',
        priority: 'high',
        description: `${athlete.name}: No capacity tests recorded`,
        scope: 'athlete',
        scopeId: athlete.id,
        scopeName: athlete.name,
        createdAt: new Date().toISOString(),
      });
    }

    if (sessions.length === 0) {
      items.push({
        id: `att-${athlete.id}-sessions`,
        type: 'data_issue',
        priority: 'medium',
        description: `${athlete.name}: No training sessions recorded`,
        scope: 'athlete',
        scopeId: athlete.id,
        scopeName: athlete.name,
        createdAt: new Date().toISOString(),
      });
    }

    for (const test of tests) {
      if (test.history.length >= 2) {
        const recent = test.history[test.history.length - 1].value;
        const prev = test.history[test.history.length - 2].value;
        if (prev !== 0 && Math.abs((recent - prev) / prev) > 0.2) {
          items.push({
            id: `att-${athlete.id}-${test.id}-change`,
            type: 'performance_change',
            priority: 'medium',
            description: `${athlete.name}: Significant change in ${test.name} (${prev} → ${recent} ${test.unit})`,
            scope: 'athlete',
            scopeId: athlete.id,
            scopeName: athlete.name,
            createdAt: test.date,
          });
        }
      }
    }
  }

  for (const team of teamIntel) {
    if (team.performanceTrend === 'declining') {
      items.push({
        id: `att-${team.teamId}-decline`,
        type: 'performance_change',
        priority: 'high',
        description: `${team.teamName}: Team performance declining`,
        scope: 'team',
        scopeId: team.teamId,
        scopeName: team.teamName,
        createdAt: new Date().toISOString(),
      });
    }
    if (team.dataQualityScore < 70) {
      items.push({
        id: `att-${team.teamId}-dq`,
        type: 'data_issue',
        priority: 'medium',
        description: `${team.teamName}: Data quality score ${team.dataQualityScore}%`,
        scope: 'team',
        scopeId: team.teamId,
        scopeName: team.teamName,
        createdAt: new Date().toISOString(),
      });
    }
  }

  return items.sort((a, b) => {
    const priorityOrder = { high: 0, medium: 1, low: 2 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });
}

// ===== ACTION TASKS =====

export function getActionTasks(): ActionTask[] { return [...actionTasks]; }

export function createActionTask(task: Omit<ActionTask, 'id' | 'createdAt' | 'updatedAt'>): ActionTask {
  const now = new Date().toISOString();
  const t: ActionTask = { ...task, id: `task-${Date.now()}`, createdAt: now, updatedAt: now };
  actionTasks = [...actionTasks, t];
  return t;
}

export function updateActionTask(id: string, updates: Partial<ActionTask>): void {
  actionTasks = actionTasks.map((t) => t.id === id ? { ...t, ...updates, updatedAt: new Date().toISOString() } : t);
}

export function completeActionTask(id: string, outcome: string): void {
  actionTasks = actionTasks.map((t) => t.id === id ? { ...t, status: 'completed', outcome, completionDate: new Date().toISOString(), updatedAt: new Date().toISOString() } : t);
}

export function deleteActionTask(id: string): void {
  actionTasks = actionTasks.filter((t) => t.id !== id);
}

// ===== ALERTS =====

export function getAlertConfigs(): AlertConfig[] { return [...alertConfigs]; }

export function updateAlertConfig(id: string, updates: Partial<AlertConfig>): void {
  alertConfigs = alertConfigs.map((a) => a.id === id ? { ...a, ...updates } : a);
}

// ===== SAVED VIEWS =====

export function getSavedViews(): SavedView[] { return [...savedViews]; }

export function saveView(view: Omit<SavedView, 'id' | 'createdAt'>): SavedView {
  const v: SavedView = { ...view, id: `view-${Date.now()}`, createdAt: new Date().toISOString() };
  savedViews = [...savedViews, v];
  return v;
}

export function deleteSavedView(id: string): void {
  savedViews = savedViews.filter((v) => v.id !== id);
}

// ===== REPORT VERSIONS =====

export function getReportVersions(): ReportVersion[] { return [...reportVersions]; }

export function createReportVersion(report: Omit<ReportVersion, 'id' | 'createdAt'>): ReportVersion {
  const r: ReportVersion = { ...report, id: `report-${Date.now()}`, createdAt: new Date().toISOString() };
  reportVersions = [...reportVersions, r];
  return r;
}

// ===== BENCHMARK VERSIONS =====

export function getBenchmarkVersions(): BenchmarkVersion[] { return [...benchmarkVersions]; }

export function createBenchmarkVersion(bv: Omit<BenchmarkVersion, 'id' | 'createdAt'>): BenchmarkVersion {
  const v: BenchmarkVersion = { ...bv, id: `bv-${Date.now()}`, createdAt: new Date().toISOString() };
  benchmarkVersions = [...benchmarkVersions, v];
  return v;
}

export function supersedeBenchmarkVersion(id: string): void {
  benchmarkVersions = benchmarkVersions.map((b) => b.id === id ? { ...b, status: 'superseded' } : b);
}

// ===== KPI SNAPSHOTS =====

export function getKPISnapshots(): KPISnapshot[] { return [...kpiSnapshots]; }

export function recordKPISnapshot(snapshot: Omit<KPISnapshot, 'id' | 'recordedAt'>): KPISnapshot {
  const s: KPISnapshot = { ...snapshot, id: `kpi-snap-${Date.now()}`, recordedAt: new Date().toISOString() };
  kpiSnapshots = [...kpiSnapshots, s];
  return s;
}

// ===== INTELLIGENCE INSIGHTS =====

export function getIntelligenceInsights(): IntelligenceInsight[] { return [...intelligenceInsights]; }

export function createIntelligenceInsight(insight: Omit<IntelligenceInsight, 'id' | 'createdAt'>): IntelligenceInsight {
  const i: IntelligenceInsight = { ...insight, id: `insight-${Date.now()}`, createdAt: new Date().toISOString() };
  intelligenceInsights = [...intelligenceInsights, i];
  return i;
}

export function reviewIntelligenceInsight(id: string, reviewedBy: string, decision: 'reviewed' | 'actioned' | 'archived'): void {
  intelligenceInsights = intelligenceInsights.map((i) =>
    i.id === id ? { ...i, status: decision as IntelligenceStatus, reviewedBy, reviewedAt: new Date().toISOString() } : i
  );
}

// ===== AI ORGANISATIONAL ASSISTANT =====

export function generateOrgAISummary(query: string): {
  summary: string;
  evidence: string[];
  context: string;
  trend: string;
  dataQuality: string;
  limitations: string;
  interpretation: string;
  questions: string[];
  nextStep: string;
} {
  const org = getOrganisationIntelligence();
  const patterns = detectOrgPatterns();
  const anomalies = detectOrgAnomalies();

  const improvingTeams = org.sports.filter((s) => s.performanceTrend === 'improving').map((s) => s.sport);
  const decliningTeams = org.sports.filter((s) => s.performanceTrend === 'declining').map((s) => s.sport);

  const summary = `Organisation "${org.organisationName}" has ${org.totalAthletes} athletes across ${org.activeSports.length} sports, ${org.totalTeams} teams, and ${org.totalProgrammes} programmes. ${improvingTeams.length > 0 ? `${improvingTeams.join(', ')} show improving trends. ` : ''}${decliningTeams.length > 0 ? `${decliningTeams.join(', ')} show declining trends warranting review. ` : ''}Data quality is ${org.dataQuality.overallScore}%.`;

  const evidence: string[] = [
    `${org.totalAthletes} athletes, ${org.totalTeams} teams, ${org.totalProgrammes} programmes`,
    `Testing activity: ${org.testingActivity} tests recorded`,
    `Active development plans: ${org.activeDevelopmentPlans}`,
    `Assessment completion: ${org.assessmentCompletion}%`,
    `Data quality score: ${org.dataQuality.overallScore}%`,
  ];

  if (patterns.length > 0) {
    evidence.push(`${patterns.length} organisational patterns detected`);
  }
  if (anomalies.length > 0) {
    evidence.push(`${anomalies.length} anomalies flagged for review`);
  }

  const trend = `${improvingTeams.length} sport(s) improving, ${decliningTeams.length} declining, ${org.organisationalTrends.stable} stable, ${org.organisationalTrends.insufficientEvidence} insufficient evidence.`;

  const dataQuality = `Overall: ${org.dataQuality.overallScore}% | Completeness: ${org.dataQuality.completeness}% | Recency: ${org.dataQuality.recency}% | Consistency: ${org.dataQuality.consistency}% | Validity: ${org.dataQuality.validity}% | Context: ${org.dataQuality.contextAvailability}%. Issues: ${org.dataQuality.issues.missingTesting} missing testing, ${org.dataQuality.issues.staleRecords} stale records, ${org.dataQuality.issues.contradictoryRecords} contradictory records.`;

  const questions = [
    'Are training loads aligned with performance trends in declining sports?',
    'Are key athletes unavailable in declining teams?',
    'Did competition demands change during the assessment period?',
    'Is data quality sufficient to draw reliable conclusions?',
  ];

  return {
    summary,
    evidence,
    context: `Organisation: ${org.organisationName} | Active sports: ${org.activeSports.join(', ')}`,
    trend,
    dataQuality,
    limitations: 'The available data do not establish causation. Concurrent factors may explain observed trends. Insufficient evidence exists for sports with limited data points.',
    interpretation: 'Several factors may be relevant to the observed trends. Professional review is needed to contextualise findings.',
    questions,
    nextStep: 'Review training-load and availability data alongside performance trends. Prioritise declining sports for detailed investigation.',
  };
}

// ===== ROLE-BASED INTELLIGENCE =====

export function getRoleBasedIntelligence(role: string): {
  label: string;
  description: string;
  data: unknown;
} {
  switch (role) {
    case 'HEAD_COACH':
      return {
        label: 'Team & Athlete Intelligence',
        description: 'Athlete performance, team trends, development priorities',
        data: { teams: getTeamIntelligence(), athletes: getCoachAthleteSummaries() },
      };
    case 'PERFORMANCE_ANALYST':
      return {
        label: 'Data & Performance Intelligence',
        description: 'Performance datasets, trends, benchmarks, anomalies, data quality',
        data: { anomalies: detectOrgAnomalies(), patterns: detectOrgPatterns(), dataQuality: computeOrgDataQuality() },
      };
    case 'ACADEMY_DIRECTOR':
      return {
        label: 'Programme Intelligence',
        description: 'Programme trends, athlete progression, team progression, development outcomes',
        data: { programmes: getProgrammeIntelligence() },
      };
    case 'ADMIN':
    case 'READ_ONLY':
    default:
      return {
        label: 'Organisation Intelligence',
        description: 'Full organisational overview',
        data: getOrganisationIntelligence(),
      };
  }
}
