import type {
  UserAccount, UserPreferences, AppearanceSettings, AccessibilitySettings,
  OrganisationProfile, ProgrammeConfig, TeamConfig, AgeGroupConfig, RoleConfig,
  NotificationPreference, NotificationRule, BenchmarkConfig, KPIConfig,
  AIConfig, PrivacyConfig, ReportConfig, DataRetentionConfig, DataQualityThresholds,
  FeatureFlag, SeasonConfig, CompetitionConfig, ConfigurationVersion,
  SettingsAuditEntry, TaskConfig, ScoutingSettings, DevelopmentSettings,
  PerformanceSettings, IntegrationsConfig, SystemStatus, UserRole,
  MeasurementSystem, DateFormat, TimeFormat, ConfigHealth,
} from './types';

// ===== DEFAULT USER =====
const DEFAULT_USER: UserAccount = {
  id: 'user-1',
  name: 'Coach Smith',
  email: 'coach@athleteiq.org',
  role: 'HEAD_COACH',
  jobTitle: 'Head Coach',
  avatarColor: '#3b82f6',
  initials: 'CS',
  organisationId: 'org-1',
  defaultSport: 'football',
  timezone: 'Europe/London',
  language: 'en-GB',
  dateFormat: 'DD/MM/YYYY',
  timeFormat: '24h',
  measurementSystem: 'metric',
  firstDayOfWeek: 1,
  active: true,
  createdAt: '2026-01-01T00:00:00Z',
};

let currentUser: UserAccount = { ...DEFAULT_USER };

export function getCurrentUser(): UserAccount { return { ...currentUser }; }
export function updateCurrentUser(updates: Partial<UserAccount>): UserAccount {
  const prev = { ...currentUser };
  currentUser = { ...currentUser, ...updates };
  recordSettingsAudit({
    action: 'updated',
    settingType: 'account',
    previousValue: JSON.stringify(prev),
    newValue: JSON.stringify(currentUser),
  });
  return { ...currentUser };
}

// ===== USER PREFERENCES =====
let userPrefs: UserPreferences = {
  userId: 'user-1',
  defaultLandingPage: 'coach-dashboard',
  defaultDashboard: 'coach-dashboard',
  defaultSport: 'football',
  defaultDateRange: '28d',
  defaultComparisonPeriod: 'previous_period',
  tableDensity: 'comfortable',
  chartStyle: 'bars',
  sidebarCollapsed: false,
};

export function getUserPreferences(): UserPreferences { return { ...userPrefs }; }
export function updateUserPreferences(updates: Partial<UserPreferences>): UserPreferences {
  const prev = { ...userPrefs };
  userPrefs = { ...userPrefs, ...updates };
  recordSettingsAudit({ action: 'updated', settingType: 'preferences', previousValue: JSON.stringify(prev), newValue: JSON.stringify(userPrefs) });
  return { ...userPrefs };
}

// ===== APPEARANCE =====
let appearance: AppearanceSettings = {
  mode: 'system',
  density: 'comfortable',
  textSize: 'medium',
  contrast: 'standard',
  reducedMotion: false,
  focusVisibility: true,
  colorBlindMode: false,
};

export function getAppearance(): AppearanceSettings { return { ...appearance }; }
export function updateAppearance(updates: Partial<AppearanceSettings>): AppearanceSettings {
  const prev = { ...appearance };
  appearance = { ...appearance, ...updates };
  recordSettingsAudit({ action: 'updated', settingType: 'appearance', previousValue: JSON.stringify(prev), newValue: JSON.stringify(appearance) });
  return { ...appearance };
}

// ===== ACCESSIBILITY =====
let accessibility: AccessibilitySettings = {
  textScaling: 1,
  reducedMotion: false,
  keyboardNavigation: false,
  screenReaderMode: false,
  highContrast: false,
  focusIndicators: true,
  chartAccessibility: true,
};

export function getAccessibility(): AccessibilitySettings { return { ...accessibility }; }
export function updateAccessibility(updates: Partial<AccessibilitySettings>): AccessibilitySettings {
  const prev = { ...accessibility };
  accessibility = { ...accessibility, ...updates };
  recordSettingsAudit({ action: 'updated', settingType: 'accessibility', previousValue: JSON.stringify(prev), newValue: JSON.stringify(accessibility) });
  return { ...accessibility };
}

// ===== ORGANISATION =====
let organisation: OrganisationProfile = {
  id: 'org-1',
  name: 'AthleteIQ Academy',
  type: 'Academy',
  country: 'United Kingdom',
  timezone: 'Europe/London',
  defaultLanguage: 'en-GB',
  measurementSystem: 'metric',
  defaultSport: 'football',
  logoColor: '#3b82f6',
  description: 'Elite youth development academy',
  contactEmail: 'info@athleteiq.org',
  contactPhone: '+44 20 1234 5678',
};

export function getOrganisation(): OrganisationProfile { return { ...organisation }; }
export function updateOrganisation(updates: Partial<OrganisationProfile>): OrganisationProfile {
  const prev = { ...organisation };
  organisation = { ...organisation, ...updates };
  recordSettingsAudit({ action: 'updated', settingType: 'organisation', previousValue: JSON.stringify(prev), newValue: JSON.stringify(organisation) });
  return { ...organisation };
}

// ===== PROGRAMMES =====
let programmes: ProgrammeConfig[] = [
  { id: 'prog-1', name: 'Youth Development', type: 'Development', sport: 'football', ageMin: 14, ageMax: 18, objectives: 'Technical and tactical development', reportingCycle: 'Monthly', developmentCycle: '12 weeks', active: true },
  { id: 'prog-2', name: 'Senior Performance', type: 'Performance', sport: 'football', ageMin: 18, ageMax: 25, objectives: 'Competitive performance', reportingCycle: 'Weekly', developmentCycle: '8 weeks', active: true },
];

export function getProgrammes(): ProgrammeConfig[] { return [...programmes]; }
export function createProgramme(p: Omit<ProgrammeConfig, 'id'>): ProgrammeConfig {
  const prog = { ...p, id: `prog-${Date.now()}` };
  programmes = [...programmes, prog];
  recordSettingsAudit({ action: 'created', settingType: 'programme', previousValue: '', newValue: prog.name });
  return prog;
}
export function updateProgramme(id: string, updates: Partial<ProgrammeConfig>): void {
  programmes = programmes.map((p) => p.id === id ? { ...p, ...updates } : p);
}
export function deleteProgramme(id: string): void {
  programmes = programmes.filter((p) => p.id !== id);
}

// ===== TEAMS =====
let teams: TeamConfig[] = [
  { id: 'team-1', name: 'U16 Academy', sport: 'football', programmeId: 'prog-1', ageGroup: 'U16', competition: 'Academy League', coachId: 'user-1', active: true },
  { id: 'team-2', name: 'U18 Development', sport: 'football', programmeId: 'prog-1', ageGroup: 'U18', competition: 'Youth Cup', coachId: 'user-1', active: true },
];

export function getTeams(): TeamConfig[] { return [...teams]; }
export function createTeam(t: Omit<TeamConfig, 'id'>): TeamConfig {
  const team = { ...t, id: `team-${Date.now()}` };
  teams = [...teams, team];
  recordSettingsAudit({ action: 'created', settingType: 'team', previousValue: '', newValue: team.name });
  return team;
}
export function updateTeam(id: string, updates: Partial<TeamConfig>): void {
  teams = teams.map((t) => t.id === id ? { ...t, ...updates } : t);
}
export function deleteTeam(id: string): void {
  teams = teams.filter((t) => t.id !== id);
}

// ===== AGE GROUPS =====
let ageGroups: AgeGroupConfig[] = [
  { key: 'U10', label: 'Under 10', minAge: 8, maxAge: 10, custom: false, active: true },
  { key: 'U12', label: 'Under 12', minAge: 10, maxAge: 12, custom: false, active: true },
  { key: 'U14', label: 'Under 14', minAge: 12, maxAge: 14, custom: false, active: true },
  { key: 'U16', label: 'Under 16', minAge: 14, maxAge: 16, custom: false, active: true },
  { key: 'U18', label: 'Under 18', minAge: 16, maxAge: 18, custom: false, active: true },
  { key: 'U20', label: 'Under 20', minAge: 18, maxAge: 20, custom: false, active: true },
  { key: 'Senior', label: 'Senior', minAge: 18, maxAge: 99, custom: false, active: true },
];

export function getAgeGroups(): AgeGroupConfig[] { return [...ageGroups]; }
export function createAgeGroup(a: Omit<AgeGroupConfig, 'key'>): AgeGroupConfig {
  const key = `custom-${Date.now()}`;
  const ag = { ...a, key };
  ageGroups = [...ageGroups, ag];
  recordSettingsAudit({ action: 'created', settingType: 'age_group', previousValue: '', newValue: ag.label });
  return ag;
}
export function updateAgeGroup(key: string, updates: Partial<AgeGroupConfig>): void {
  ageGroups = ageGroups.map((a) => a.key === key ? { ...a, ...updates } : a);
}
export function deleteAgeGroup(key: string): void {
  ageGroups = ageGroups.filter((a) => a.key !== key);
}

// ===== ROLES =====
export const ROLE_CONFIGS: RoleConfig[] = [
  { key: 'ADMIN', label: 'Administrator', description: 'Full configuration access', permissions: ['all'], scopeLevel: 'organisation' },
  { key: 'HEAD_COACH', label: 'Head Coach', description: 'View, assess, compare, make final decisions', permissions: ['view', 'assess', 'compare', 'decide', 'report'], scopeLevel: 'organisation' },
  { key: 'COACH', label: 'Coach', description: 'View assigned athletes, assess, submit observations', permissions: ['view', 'assess', 'observe'], scopeLevel: 'team' },
  { key: 'SCOUT', label: 'Scout', description: 'Scouting projects, observations, candidate evaluation', permissions: ['view', 'scout', 'observe', 'shortlist'], scopeLevel: 'project' },
  { key: 'PERFORMANCE_ANALYST', label: 'Performance Analyst', description: 'Performance evidence, analytics, data validation', permissions: ['view', 'analyse', 'validate'], scopeLevel: 'organisation' },
  { key: 'ACADEMY_DIRECTOR', label: 'Academy Director', description: 'Programme-wide scouting visibility, decision review', permissions: ['view', 'review', 'report'], scopeLevel: 'organisation' },
  { key: 'READ_ONLY', label: 'Read-Only', description: 'View authorised records only', permissions: ['view'], scopeLevel: 'organisation' },
];

export function getRoles(): RoleConfig[] { return [...ROLE_CONFIGS]; }

export function hasPermission(user: UserAccount, permission: string): boolean {
  const role = ROLE_CONFIGS.find((r) => r.key === user.role);
  if (!role) return false;
  return role.permissions.includes('all') || role.permissions.includes(permission);
}

// ===== NOTIFICATIONS =====
let notificationPrefs: NotificationPreference[] = [
  { userId: 'user-1', channel: 'in_app', enabled: true, categories: { task_assigned: true, task_overdue: true, assessment_due: true, coach_review_required: true, data_quality_issue: true, report_ready: true, system_announcement: true } },
  { userId: 'user-1', channel: 'email', enabled: true, categories: { task_assigned: true, task_overdue: true, assessment_due: false, coach_review_required: true, data_quality_issue: false, report_ready: true, system_announcement: true } },
  { userId: 'user-1', channel: 'push', enabled: false, categories: { task_assigned: false, task_overdue: true, assessment_due: false, coach_review_required: false, data_quality_issue: false, report_ready: false, system_announcement: false } },
];

export function getNotificationPreferences(): NotificationPreference[] { return [...notificationPrefs]; }
export function updateNotificationPreference(channel: string, updates: Partial<NotificationPreference>): void {
  notificationPrefs = notificationPrefs.map((p) => p.channel === channel ? { ...p, ...updates } : p);
}

let notificationRules: NotificationRule[] = [
  { id: 'nr-1', eventType: 'task_assigned', label: 'Task Assigned', priority: 'moderate', channels: ['in_app', 'email'], active: true },
  { id: 'nr-2', eventType: 'task_overdue', label: 'Task Overdue', priority: 'high', channels: ['in_app', 'email', 'push'], active: true },
  { id: 'nr-3', eventType: 'assessment_due', label: 'Assessment Due', priority: 'moderate', channels: ['in_app'], active: true },
  { id: 'nr-4', eventType: 'coach_review_required', label: 'Coach Review Required', priority: 'high', channels: ['in_app', 'email'], active: true },
  { id: 'nr-5', eventType: 'data_quality_issue', label: 'Data Quality Issue', priority: 'moderate', channels: ['in_app'], active: true },
  { id: 'nr-6', eventType: 'report_ready', label: 'Report Ready', priority: 'informational', channels: ['in_app', 'email'], active: true },
  { id: 'nr-7', eventType: 'system_announcement', label: 'System Announcement', priority: 'informational', channels: ['in_app'], active: true },
];

export function getNotificationRules(): NotificationRule[] { return [...notificationRules]; }
export function updateNotificationRule(id: string, updates: Partial<NotificationRule>): void {
  notificationRules = notificationRules.map((r) => r.id === id ? { ...r, ...updates } : r);
}

// ===== BENCHMARKS =====
let benchmarks: BenchmarkConfig[] = [
  { id: 'bm-1', name: 'U16 Football Speed Benchmark', sport: 'football', source: 'Organisation', population: 'U16 Academy', methodology: '30m sprint test', version: 'v1.0', owner: 'user-1', date: '2026-01-15', active: true },
  { id: 'bm-2', name: 'Senior Rugby Power Benchmark', sport: 'rugby', source: 'Sport Benchmark', population: 'Senior', methodology: 'Countermovement jump', version: 'v1.0', owner: 'user-1', date: '2026-02-01', active: true },
];

export function getBenchmarks(): BenchmarkConfig[] { return [...benchmarks]; }
export function createBenchmark(b: Omit<BenchmarkConfig, 'id'>): BenchmarkConfig {
  const bm = { ...b, id: `bm-${Date.now()}` };
  benchmarks = [...benchmarks, bm];
  recordSettingsAudit({ action: 'created', settingType: 'benchmark', previousValue: '', newValue: bm.name });
  return bm;
}
export function updateBenchmark(id: string, updates: Partial<BenchmarkConfig>): void {
  benchmarks = benchmarks.map((b) => b.id === id ? { ...b, ...updates } : b);
}
export function archiveBenchmark(id: string): void {
  benchmarks = benchmarks.map((b) => b.id === id ? { ...b, active: false } : b);
}

// ===== KPIs =====
let kpis: KPIConfig[] = [
  { id: 'kpi-1', name: 'Athlete Availability', definition: 'Percentage of athletes available for selection', target: '95%', frequency: 'Weekly', owner: 'user-1', scope: 'organisation', version: 'v1.0', active: true },
  { id: 'kpi-2', name: 'Assessment Completion Rate', definition: 'Percentage of scheduled assessments completed', target: '90%', frequency: 'Monthly', owner: 'user-1', scope: 'organisation', version: 'v1.0', active: true },
];

export function getKPIs(): KPIConfig[] { return [...kpis]; }
export function createKPI(k: Omit<KPIConfig, 'id'>): KPIConfig {
  const kpi = { ...k, id: `kpi-${Date.now()}` };
  kpis = [...kpis, kpi];
  recordSettingsAudit({ action: 'created', settingType: 'kpi', previousValue: '', newValue: kpi.name });
  return kpi;
}
export function updateKPI(id: string, updates: Partial<KPIConfig>): void {
  kpis = kpis.map((k) => k.id === id ? { ...k, ...updates } : k);
}
export function deleteKPI(id: string): void {
  kpis = kpis.filter((k) => k.id !== id);
}

// ===== AI CONFIG =====
let aiConfig: AIConfig = {
  aiEnabled: true,
  explanationRequired: true,
  explanationDepth: 'standard',
  responseStyle: 'standard',
  confidenceDisplay: true,
  reviewRequired: true,
  loggingEnabled: true,
  dataScope: 'standard',
  evidenceRequired: true,
  humanDecisionControl: true,
};

export function getAIConfig(): AIConfig { return { ...aiConfig }; }
export function updateAIConfig(updates: Partial<AIConfig>): AIConfig {
  const prev = { ...aiConfig };
  const safe: Partial<AIConfig> = { ...updates };
  if (updates.evidenceRequired === false) safe.evidenceRequired = true;
  if (updates.humanDecisionControl === false) safe.humanDecisionControl = true;
  aiConfig = { ...aiConfig, ...safe };
  recordSettingsAudit({ action: 'updated', settingType: 'ai_config', previousValue: JSON.stringify(prev), newValue: JSON.stringify(aiConfig) });
  return { ...aiConfig };
}

// ===== PRIVACY =====
let privacyConfig: PrivacyConfig = {
  athleteVisibility: 'organisation',
  scoutingVisibility: 'organisation',
  recruitmentVisibility: 'programme',
  privateNotesVisible: 'team',
  exportAllowed: true,
  youthRestrictions: true,
  publicRankings: false,
};

export function getPrivacyConfig(): PrivacyConfig { return { ...privacyConfig }; }
export function updatePrivacyConfig(updates: Partial<PrivacyConfig>): PrivacyConfig {
  const prev = { ...privacyConfig };
  const safe: Partial<PrivacyConfig> = { ...updates };
  if (updates.youthRestrictions === false) safe.youthRestrictions = true;
  if (updates.publicRankings === true) safe.publicRankings = false;
  privacyConfig = { ...privacyConfig, ...safe };
  recordSettingsAudit({ action: 'updated', settingType: 'privacy', previousValue: JSON.stringify(prev), newValue: JSON.stringify(privacyConfig) });
  return { ...privacyConfig };
}

// ===== REPORT CONFIG =====
let reportConfig: ReportConfig = {
  orgName: 'AthleteIQ Academy',
  logoColor: '#3b82f6',
  header: 'AthleteIQ Academy Performance Report',
  footer: 'Confidential — AthleteIQ Academy',
  contactInfo: 'info@athleteiq.org',
  defaultFormat: 'pdf',
  defaultOrientation: 'portrait',
  sections: { summary: true, performance: true, development: true, scouting: false, recommendations: true, appendix: false },
};

export function getReportConfig(): ReportConfig { return { ...reportConfig }; }
export function updateReportConfig(updates: Partial<ReportConfig>): ReportConfig {
  const prev = { ...reportConfig };
  reportConfig = { ...reportConfig, ...updates };
  recordSettingsAudit({ action: 'updated', settingType: 'report_config', previousValue: JSON.stringify(prev), newValue: JSON.stringify(reportConfig) });
  return { ...reportConfig };
}

// ===== DATA RETENTION =====
let dataRetention: DataRetentionConfig = {
  activeRetentionDays: 365,
  archiveRetentionDays: 2555,
  deletionPolicy: 'soft',
  autoArchiveDays: 365,
};

export function getDataRetention(): DataRetentionConfig { return { ...dataRetention }; }
export function updateDataRetention(updates: Partial<DataRetentionConfig>): DataRetentionConfig {
  const prev = { ...dataRetention };
  dataRetention = { ...dataRetention, ...updates };
  recordSettingsAudit({ action: 'updated', settingType: 'data_retention', previousValue: JSON.stringify(prev), newValue: JSON.stringify(dataRetention) });
  return { ...dataRetention };
}

// ===== DATA QUALITY THRESHOLDS =====
let dataQualityThresholds: DataQualityThresholds = {
  missingDataThreshold: 20,
  staleDataDays: 90,
  duplicateDetection: true,
  contradictoryAlerts: true,
  minSampleSize: 3,
};

export function getDataQualityThresholds(): DataQualityThresholds { return { ...dataQualityThresholds }; }
export function updateDataQualityThresholds(updates: Partial<DataQualityThresholds>): DataQualityThresholds {
  const prev = { ...dataQualityThresholds };
  dataQualityThresholds = { ...dataQualityThresholds, ...updates };
  recordSettingsAudit({ action: 'updated', settingType: 'data_quality', previousValue: JSON.stringify(prev), newValue: JSON.stringify(dataQualityThresholds) });
  return { ...dataQualityThresholds };
}

// ===== FEATURE FLAGS =====
let featureFlags: FeatureFlag[] = [
  { key: 'stage8_scouting', label: 'Scouting & Recruitment', enabled: true, description: 'Stage 8 scouting workspace', module: 'Scouting' },
  { key: 'ai_insights', label: 'AI Insights', enabled: true, description: 'AI-powered performance insights', module: 'AI' },
  { key: 'research_mode', label: 'Research Mode', enabled: true, description: 'Advanced research tools', module: 'Intelligence' },
  { key: 'video_analysis', label: 'Video Analysis', enabled: false, description: 'Video evidence linking (beta)', module: 'Scouting' },
  { key: 'wearable_sync', label: 'Wearable Sync', enabled: false, description: 'Wearable device integration (beta)', module: 'Data' },
  { key: 'export_advanced', label: 'Advanced Exports', enabled: true, description: 'Multi-format data export', module: 'Data' },
];

export function getFeatureFlags(): FeatureFlag[] { return [...featureFlags]; }
export function updateFeatureFlag(key: string, enabled: boolean): void {
  featureFlags = featureFlags.map((f) => f.key === key ? { ...f, enabled } : f);
  recordSettingsAudit({ action: 'updated', settingType: 'feature_flag', previousValue: key, newValue: `${enabled}` });
}

// ===== SEASONS =====
let seasons: SeasonConfig[] = [
  { id: 'season-1', name: '2026 Season', sport: 'football', startDate: '2026-08-01', endDate: '2027-05-31', active: true },
];

export function getSeasons(): SeasonConfig[] { return [...seasons]; }
export function createSeason(s: Omit<SeasonConfig, 'id'>): SeasonConfig {
  const season = { ...s, id: `season-${Date.now()}` };
  seasons = [...seasons, season];
  return season;
}
export function updateSeason(id: string, updates: Partial<SeasonConfig>): void {
  seasons = seasons.map((s) => s.id === id ? { ...s, ...updates } : s);
}

// ===== COMPETITIONS =====
let competitions: CompetitionConfig[] = [
  { id: 'comp-1', name: 'Academy League', level: 'Academy', seasonId: 'season-1', format: 'League', sport: 'football', active: true },
  { id: 'comp-2', name: 'Youth Cup', level: 'Regional', seasonId: 'season-1', format: 'Knockout', sport: 'football', active: true },
];

export function getCompetitions(): CompetitionConfig[] { return [...competitions]; }
export function createCompetition(c: Omit<CompetitionConfig, 'id'>): CompetitionConfig {
  const comp = { ...c, id: `comp-${Date.now()}` };
  competitions = [...competitions, comp];
  return comp;
}

// ===== TASK CONFIG =====
let taskConfig: TaskConfig = {
  statuses: [
    { key: 'open', label: 'Open' },
    { key: 'assigned', label: 'Assigned' },
    { key: 'in_progress', label: 'In Progress' },
    { key: 'completed', label: 'Completed' },
    { key: 'deferred', label: 'Deferred' },
    { key: 'cancelled', label: 'Cancelled' },
  ],
  priorities: [
    { key: 'high', label: 'High' },
    { key: 'medium', label: 'Medium' },
    { key: 'low', label: 'Low' },
  ],
  defaultDueDays: 7,
  escalationEnabled: true,
};

export function getTaskConfig(): TaskConfig { return { ...taskConfig }; }
export function updateTaskConfig(updates: Partial<TaskConfig>): TaskConfig {
  taskConfig = { ...taskConfig, ...updates };
  return { ...taskConfig };
}

// ===== SCOUTING SETTINGS =====
let scoutingSettings: ScoutingSettings = {
  defaultEvidenceConfidence: 'moderate',
  pipelineStages: ['IDENTIFIED', 'OBSERVING', 'SHORTLISTED', 'FURTHER_ASSESSMENT', 'SCOUT_REVIEW', 'COACH_REVIEW', 'TRIAL', 'RECRUITMENT_DECISION', 'ONBOARDING'],
  weightingValidation: true,
  projectStatuses: ['DRAFT', 'ACTIVE', 'PAUSED', 'COMPLETED', 'ARCHIVED'],
};

export function getScoutingSettings(): ScoutingSettings { return { ...scoutingSettings }; }
export function updateScoutingSettings(updates: Partial<ScoutingSettings>): ScoutingSettings {
  scoutingSettings = { ...scoutingSettings, ...updates };
  return { ...scoutingSettings };
}

// ===== DEVELOPMENT SETTINGS =====
let developmentSettings: DevelopmentSettings = {
  objectiveCategories: ['Technical', 'Tactical', 'Physical', 'Mental', 'Lifestyle'],
  interventionTypes: ['Training Modification', 'Load Management', 'Skill Development', 'Conditioning', 'Recovery'],
  reviewCycles: [
    { label: 'Weekly', days: 7 },
    { label: 'Fortnightly', days: 14 },
    { label: 'Monthly', days: 30 },
  ],
  reassessmentIntervalDays: 90,
};

export function getDevelopmentSettings(): DevelopmentSettings { return { ...developmentSettings }; }
export function updateDevelopmentSettings(updates: Partial<DevelopmentSettings>): DevelopmentSettings {
  developmentSettings = { ...developmentSettings, ...updates };
  return { ...developmentSettings };
}

// ===== PERFORMANCE SETTINGS =====
let performanceSettings: PerformanceSettings = {
  metricCategories: ['Speed', 'Acceleration', 'Aerobic Capacity', 'Anaerobic Capacity', 'Change of Direction', 'Strength / Power'],
  defaultUnits: { distance: 'm', speed: 'm/s', time: 's', weight: 'kg', volume: 'ml/kg/min' },
  testingFrequency: [
    { label: 'Monthly', days: 30 },
    { label: 'Quarterly', days: 90 },
    { label: 'Bi-annual', days: 180 },
  ],
  validationRules: true,
};

export function getPerformanceSettings(): PerformanceSettings { return { ...performanceSettings }; }
export function updatePerformanceSettings(updates: Partial<PerformanceSettings>): PerformanceSettings {
  performanceSettings = { ...performanceSettings, ...updates };
  return { ...performanceSettings };
}

// ===== INTEGRATIONS =====
let integrationsConfig: IntegrationsConfig = {
  integrations: [
    { key: 'gps_provider', label: 'GPS Provider', enabled: false, connected: false, type: 'Data' },
    { key: 'wearable_system', label: 'Wearable System', enabled: false, connected: false, type: 'Data' },
    { key: 'video_platform', label: 'Video Platform', enabled: false, connected: false, type: 'Video' },
    { key: 'calendar_system', label: 'Calendar System', enabled: false, connected: false, type: 'Calendar' },
    { key: 'email_service', label: 'Email Service', enabled: true, connected: true, type: 'Notification' },
  ],
};

export function getIntegrations(): IntegrationsConfig { return { ...integrationsConfig }; }
export function updateIntegration(key: string, enabled: boolean): void {
  integrationsConfig = {
    ...integrationsConfig,
    integrations: integrationsConfig.integrations.map((i) => i.key === key ? { ...i, enabled } : i),
  };
}

// ===== SYSTEM STATUS =====
export function getSystemStatus(): SystemStatus {
  return {
    application: 'operational',
    database: 'operational',
    analytics: 'operational',
    ai: 'operational',
    notifications: 'operational',
  };
}

// ===== CONFIGURATION VERSIONS =====
let configVersions: ConfigurationVersion[] = [
  { id: 'cv-1', configurationType: 'organisation', version: 'v1.0', effectiveFrom: '2026-01-01', createdBy: 'user-1', createdAt: '2026-01-01T00:00:00Z', reason: 'Initial configuration', status: 'active' },
];

export function getConfigVersions(): ConfigurationVersion[] { return [...configVersions]; }
export function createConfigVersion(type: string, reason: string): ConfigurationVersion {
  const latest = configVersions.filter((v) => v.configurationType === type).length;
  const version = `v${latest + 1}.0`;
  const prev = configVersions.find((v) => v.configurationType === type && v.status === 'active');
  if (prev) {
    configVersions = configVersions.map((v) => v.id === prev.id ? { ...v, status: 'superseded', effectiveTo: new Date().toISOString() } : v);
  }
  const cv: ConfigurationVersion = {
    id: `cv-${Date.now()}`,
    configurationType: type,
    version,
    effectiveFrom: new Date().toISOString(),
    createdBy: currentUser.id,
    createdAt: new Date().toISOString(),
    reason,
    status: 'active',
  };
  configVersions = [...configVersions, cv];
  return cv;
}

// ===== SETTINGS AUDIT LOG =====
let settingsAuditLog: SettingsAuditEntry[] = [];

export function recordSettingsAudit(params: {
  action: string;
  settingType: string;
  previousValue: string;
  newValue: string;
  reason?: string;
}): void {
  settingsAuditLog.unshift({
    id: `sa-${Date.now()}-${settingsAuditLog.length}`,
    user: currentUser.name,
    action: params.action,
    settingType: params.settingType,
    previousValue: params.previousValue,
    newValue: params.newValue,
    timestamp: new Date().toISOString(),
    reason: params.reason,
  });
}

export function getSettingsAuditLog(): SettingsAuditEntry[] { return [...settingsAuditLog]; }

// ===== CONFIGURATION HEALTH =====
export function getConfigurationHealth(): { category: string; status: ConfigHealth; detail: string }[] {
  return [
    { category: 'Sports', status: 'healthy', detail: '8 sports configured' },
    { category: 'Age Groups', status: 'healthy', detail: '7 age groups active' },
    { category: 'Permissions', status: 'healthy', detail: '7 roles configured' },
    { category: 'Benchmarks', status: 'attention_required', detail: '2 active benchmarks — consider adding sport-specific benchmarks' },
    { category: 'Notifications', status: 'healthy', detail: '7 notification rules active' },
    { category: 'Reports', status: 'healthy', detail: 'Report templates configured' },
    { category: 'AI', status: 'healthy', detail: 'AI enabled with safety controls' },
    { category: 'Integrations', status: 'attention_required', detail: '4 integrations not connected' },
    { category: 'Data Quality', status: 'healthy', detail: 'Quality thresholds configured' },
    { category: 'Privacy', status: 'healthy', detail: 'Youth safeguards active' },
  ];
}

// ===== CONFIGURATION RESOLUTION =====
export function resolveSetting<T>(userValue: T | undefined, orgValue: T | undefined, systemDefault: T): T {
  if (userValue !== undefined) return userValue;
  if (orgValue !== undefined) return orgValue;
  return systemDefault;
}

export function resolveMeasurementSystem(): MeasurementSystem {
  return resolveSetting(currentUser.measurementSystem, organisation.measurementSystem, 'metric');
}

export function resolveTimezone(): string {
  return resolveSetting(currentUser.timezone, organisation.timezone, 'UTC');
}

export function resolveDateFormat(): DateFormat {
  return resolveSetting(currentUser.dateFormat, undefined, 'DD/MM/YYYY');
}

export function resolveTimeFormat(): TimeFormat {
  return resolveSetting(currentUser.timeFormat, undefined, '24h');
}

// ===== UNIT CONVERSION =====
export function convertUnit(value: number, fromUnit: string, toUnit: string): number {
  const conversions: Record<string, number> = {
    'm->ft': 3.28084,
    'ft->m': 0.3048,
    'kg->lb': 2.20462,
    'lb->kg': 0.453592,
    'km->mi': 0.621371,
    'mi->km': 1.60934,
    'cm->in': 0.393701,
    'in->cm': 2.54,
  };
  const key = `${fromUnit}->${toUnit}`;
  return conversions[key] ? value * conversions[key] : value;
}

export function formatValue(value: number, unit: string, targetSystem: MeasurementSystem): string {
  if (targetSystem === 'imperial') {
    if (unit === 'm') return `${convertUnit(value, 'm', 'ft').toFixed(1)} ft`;
    if (unit === 'kg') return `${convertUnit(value, 'kg', 'lb').toFixed(1)} lb`;
    if (unit === 'km') return `${convertUnit(value, 'km', 'mi').toFixed(1)} mi`;
  }
  return `${value} ${unit}`;
}

// ===== USERS LIST (for user management) =====
let users: UserAccount[] = [
  { ...DEFAULT_USER },
  { id: 'user-2', name: 'Analyst Jones', email: 'analyst@athleteiq.org', role: 'PERFORMANCE_ANALYST', jobTitle: 'Performance Analyst', avatarColor: '#10b981', initials: 'AJ', organisationId: 'org-1', timezone: 'Europe/London', language: 'en-GB', dateFormat: 'DD/MM/YYYY', timeFormat: '24h', measurementSystem: 'metric', firstDayOfWeek: 1, active: true, createdAt: '2026-01-15T00:00:00Z' },
  { id: 'user-3', name: 'Scout Brown', email: 'scout@athleteiq.org', role: 'SCOUT', jobTitle: 'Talent Scout', avatarColor: '#f59e0b', initials: 'SB', organisationId: 'org-1', timezone: 'Europe/London', language: 'en-GB', dateFormat: 'DD/MM/YYYY', timeFormat: '24h', measurementSystem: 'metric', firstDayOfWeek: 1, active: true, createdAt: '2026-02-01T00:00:00Z' },
];

export function getUsers(): UserAccount[] { return [...users]; }
export function updateUserRole(userId: string, role: UserRole): void {
  users = users.map((u) => u.id === userId ? { ...u, role } : u);
  recordSettingsAudit({ action: 'updated', settingType: 'user_role', previousValue: userId, newValue: role });
}
export function toggleUserActive(userId: string): void {
  users = users.map((u) => u.id === userId ? { ...u, active: !u.active } : u);
}

// ===== ROLE LABELS HELPER =====
export function getRoleLabel(role: UserRole): string {
  return ROLE_CONFIGS.find((r) => r.key === role)?.label ?? role;
}
