// AthleteIQ Statistical Engine — Stage 5
// Data sufficiency, descriptive statistics, effect sizes, MDC, confidence intervals,
// trend detection, change-point detection, anomaly detection, intervention evaluation

import type { TrainingSession, MatchRecord, CapacityTest, Intervention, Athlete, AIInsight } from './types';
import type { TimePeriod } from './types';

// ===== DATA SUFFICIENCY =====

export type DataSufficiencyLevel = 'sufficient' | 'limited' | 'insufficient';

export interface DataSufficiency {
  level: DataSufficiencyLevel;
  sessions: number;
  matches: number;
  capacityTests: number;
  interventions: number;
  timeSpanDays: number;
  dataCompleteness: number;
  missingVariables: string[];
  reason: string;
}

export function assessDataSufficiency(params: {
  sessions: TrainingSession[];
  matches: MatchRecord[];
  capacityTests: CapacityTest[];
  interventions: Intervention[];
  dataCompleteness?: number;
}): DataSufficiency {
  const { sessions, matches, capacityTests, interventions, dataCompleteness = 95 } = params;
  const missingVariables: string[] = [];

  if (sessions.length === 0) missingVariables.push('Training sessions');
  if (matches.length === 0) missingVariables.push('Match records');
  if (capacityTests.length === 0) missingVariables.push('Capacity tests');

  const allDates = [
    ...sessions.map((s) => s.date),
    ...matches.map((m) => m.date),
    ...capacityTests.map((t) => t.date),
  ].sort();
  const timeSpanDays = allDates.length > 1
    ? Math.round((new Date(allDates[allDates.length - 1]).getTime() - new Date(allDates[0]).getTime()) / 86400000)
    : 0;

  let level: DataSufficiencyLevel = 'sufficient';
  let reason = 'Adequate data for analysis.';

  if (sessions.length < 5 || matches.length < 2) {
    level = 'insufficient';
    reason = 'Insufficient data for reliable longitudinal interpretation.';
  } else if (sessions.length < 10 || matches.length < 3 || capacityTests.length < 2 || dataCompleteness < 85) {
    level = 'limited';
    reason = 'Analysis possible but confidence reduced due to limited observations.';
  }

  return {
    level,
    sessions: sessions.length,
    matches: matches.length,
    capacityTests: capacityTests.length,
    interventions: interventions.length,
    timeSpanDays,
    dataCompleteness,
    missingVariables,
    reason,
  };
}

// ===== DESCRIPTIVE STATISTICS =====

export interface DescriptiveStats {
  mean: number;
  median: number;
  stdDev: number;
  cv: number; // coefficient of variation %
  min: number;
  max: number;
  count: number;
  range: number;
  q1: number;
  q3: number;
  iqr: number;
}

export function computeDescriptiveStats(values: number[]): DescriptiveStats | null {
  if (values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const n = sorted.length;
  const mean = values.reduce((a, b) => a + b, 0) / n;
  const stdDev = Math.sqrt(values.reduce((sq, v) => sq + (v - mean) ** 2, 0) / n);
  const cv = mean === 0 ? 0 : (stdDev / Math.abs(mean)) * 100;

  const percentile = (p: number) => {
    const idx = (p / 100) * (n - 1);
    const lo = Math.floor(idx);
    const hi = Math.ceil(idx);
    if (lo === hi) return sorted[lo];
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
  };

  return {
    mean: +mean.toFixed(2),
    median: +percentile(50).toFixed(2),
    stdDev: +stdDev.toFixed(2),
    cv: +cv.toFixed(1),
    min: sorted[0],
    max: sorted[n - 1],
    count: n,
    range: +(sorted[n - 1] - sorted[0]).toFixed(2),
    q1: +percentile(25).toFixed(2),
    q3: +percentile(75).toFixed(2),
    iqr: +(percentile(75) - percentile(25)).toFixed(2),
  };
}

// ===== EFFECT SIZE (Cohen's d) =====

export interface EffectSizeResult {
  cohenD: number;
  magnitude: 'negligible' | 'small' | 'medium' | 'large' | 'very large';
  direction: 'improvement' | 'decline' | 'neutral';
  interpretation: string;
}

export function computeEffectSize(preValues: number[], postValues: number[], higherIsBetter: boolean): EffectSizeResult | null {
  if (preValues.length < 2 || postValues.length < 2) return null;

  const preMean = preValues.reduce((a, b) => a + b, 0) / preValues.length;
  const postMean = postValues.reduce((a, b) => a + b, 0) / postValues.length;
  const preStd = Math.sqrt(preValues.reduce((sq, v) => sq + (v - preMean) ** 2, 0) / preValues.length);
  const postStd = Math.sqrt(postValues.reduce((sq, v) => sq + (v - postMean) ** 2, 0) / postValues.length);
  const pooledStd = Math.sqrt((preStd ** 2 + postStd ** 2) / 2);

  if (pooledStd === 0) return null;

  const d = (postMean - preMean) / pooledStd;
  const absD = Math.abs(d);

  let magnitude: EffectSizeResult['magnitude'] = 'negligible';
  if (absD >= 2.0) magnitude = 'very large';
  else if (absD >= 0.8) magnitude = 'large';
  else if (absD >= 0.5) magnitude = 'medium';
  else if (absD >= 0.2) magnitude = 'small';

  const improved = higherIsBetter ? postMean > preMean : postMean < preMean;
  const direction: EffectSizeResult['direction'] = absD < 0.2 ? 'neutral' : improved ? 'improvement' : 'decline';

  const interpretation = `${magnitude} effect (${direction === 'improvement' ? 'improvement' : direction === 'decline' ? 'decline' : 'no meaningful change'} of ${Math.abs(((postMean - preMean) / preMean) * 100).toFixed(1)}%)`;

  return { cohenD: +d.toFixed(2), magnitude, direction, interpretation };
}

// ===== MINIMAL DETECTABLE CHANGE (MDC) =====

export interface MDCResult {
  mdc: number;
  sem: number; // standard error of measurement
  observedChange: number;
  meaningful: boolean;
  interpretation: string;
}

export function computeMDC(values: number[], preValue: number, postValue: number): MDCResult | null {
  if (values.length < 2) return null;

  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  const stdDev = Math.sqrt(values.reduce((sq, v) => sq + (v - mean) ** 2, 0) / values.length);
  const sem = stdDev / Math.sqrt(2);
  const mdc = 1.96 * sem * Math.SQRT2;
  const observedChange = Math.abs(postValue - preValue);
  const meaningful = observedChange > mdc;

  const interpretation = meaningful
    ? `Observed change (${observedChange.toFixed(2)}) exceeds MDC (${mdc.toFixed(2)}) — likely meaningful.`
    : `Observed change (${observedChange.toFixed(2)}) may fall within expected measurement variation (MDC: ${mdc.toFixed(2)}).`;

  return { mdc: +mdc.toFixed(3), sem: +sem.toFixed(3), observedChange: +observedChange.toFixed(3), meaningful, interpretation };
}

// ===== CONFIDENCE INTERVAL =====

export interface CIResult {
  mean: number;
  lower: number;
  upper: number;
  level: number;
  n: number;
  reliable: boolean;
  interpretation: string;
}

export function computeConfidenceInterval(values: number[], level: number = 0.95): CIResult | null {
  if (values.length < 3) return null;

  const n = values.length;
  const mean = values.reduce((a, b) => a + b, 0) / n;
  const stdDev = Math.sqrt(values.reduce((sq, v) => sq + (v - mean) ** 2, 0) / n);
  const sem = stdDev / Math.sqrt(n);

  // t-distribution approximation for small samples
  const tValue = level === 0.95
    ? n >= 30 ? 1.96 : n >= 10 ? 2.228 : n >= 5 ? 2.776 : 3.182
    : n >= 30 ? 2.576 : n >= 10 ? 3.169 : 3.495;

  const margin = tValue * sem;
  const reliable = n >= 10;

  const interpretation = reliable
    ? `Estimated range: ${Math.round((mean - margin) * 10) / 10}–${Math.round((mean + margin) * 10) / 10} (95% CI).`
    : 'Confidence interval not reliable with current data.';

  return {
    mean: +mean.toFixed(2),
    lower: +(mean - margin).toFixed(2),
    upper: +(mean + margin).toFixed(2),
    level,
    n,
    reliable,
    interpretation,
  };
}

// ===== TREND DETECTION =====

export type TrendDirection = 'improving' | 'stable' | 'plateau' | 'declining' | 'variable' | 'insufficient';

export interface TrendResult {
  direction: TrendDirection;
  slope: number;
  r2: number;
  confidence: 'Low' | 'Moderate' | 'High';
  interpretation: string;
}

export function detectTrend(values: { date: string; value: number }[], higherIsBetter: boolean): TrendResult {
  if (values.length < 3) {
    return { direction: 'insufficient', slope: 0, r2: 0, confidence: 'Low', interpretation: 'Insufficient data for trend analysis.' };
  }

  // Linear regression
  const n = values.length;
  const x = values.map((_, i) => i);
  const y = values.map((v) => v.value);
  const xMean = x.reduce((a, b) => a + b, 0) / n;
  const yMean = y.reduce((a, b) => a + b, 0) / n;

  let numSum = 0, denSum = 0;
  for (let i = 0; i < n; i++) {
    numSum += (x[i] - xMean) * (y[i] - yMean);
    denSum += (x[i] - xMean) ** 2;
  }
  const slope = denSum === 0 ? 0 : numSum / denSum;
  const intercept = yMean - slope * xMean;

  let ssRes = 0, ssTot = 0;
  for (let i = 0; i < n; i++) {
    const predicted = slope * x[i] + intercept;
    ssRes += (y[i] - predicted) ** 2;
    ssTot += (y[i] - yMean) ** 2;
  }
  const r2 = ssTot === 0 ? 0 : 1 - ssRes / ssTot;

  const absSlope = Math.abs(slope);
  const totalChange = slope * (n - 1);
  const pctChange = yMean === 0 ? 0 : (totalChange / Math.abs(yMean)) * 100;

  let direction: TrendDirection = 'stable';
  let interpretation = '';

  if (Math.abs(pctChange) < 2) {
    direction = 'plateau';
    interpretation = 'Values have plateaued — minimal change over the observation period.';
  } else if (r2 < 0.3 && values.length > 4) {
    direction = 'variable';
    interpretation = 'High variability — no clear linear trend.';
  } else if (slope > 0) {
    direction = higherIsBetter ? 'improving' : 'declining';
    interpretation = higherIsBetter
      ? `Improving trend (+${pctChange.toFixed(1)}% over period, R²=${r2.toFixed(2)}).`
      : `Declining trend (+${pctChange.toFixed(1)}% but lower is better, R²=${r2.toFixed(2)}).`;
  } else if (slope < 0) {
    direction = higherIsBetter ? 'declining' : 'improving';
    interpretation = higherIsBetter
      ? `Declining trend (${pctChange.toFixed(1)}% over period, R²=${r2.toFixed(2)}).`
      : `Improving trend (${pctChange.toFixed(1)}% but lower is better, R²=${r2.toFixed(2)}).`;
  }

  let confidence: 'Low' | 'Moderate' | 'High' = 'Low';
  if (r2 >= 0.7 && n >= 5) confidence = 'High';
  else if (r2 >= 0.4 && n >= 4) confidence = 'Moderate';

  return { direction, slope: +slope.toFixed(4), r2: +r2.toFixed(2), confidence, interpretation };
}

// ===== CHANGE-POINT DETECTION =====

export interface ChangePointResult {
  detected: boolean;
  index: number | null;
  date: string | null;
  description: string;
}

export function detectChangePoint(values: { date: string; value: number }[]): ChangePointResult {
  if (values.length < 6) return { detected: false, index: null, date: null, description: 'Insufficient data for change-point detection.' };

  // Simple approach: compare mean of first half vs second half
  const mid = Math.floor(values.length / 2);
  const firstHalf = values.slice(0, mid).map((v) => v.value);
  const secondHalf = values.slice(mid).map((v) => v.value);

  const firstMean = firstHalf.reduce((a, b) => a + b, 0) / firstHalf.length;
  const secondMean = secondHalf.reduce((a, b) => a + b, 0) / secondHalf.length;
  const firstStd = Math.sqrt(firstHalf.reduce((sq, v) => sq + (v - firstMean) ** 2, 0) / firstHalf.length);
  const secondStd = Math.sqrt(secondHalf.reduce((sq, v) => sq + (v - secondMean) ** 2, 0) / secondHalf.length);

  const pooledStd = Math.sqrt((firstStd ** 2 + secondStd ** 2) / 2);
  if (pooledStd === 0) return { detected: false, index: null, date: null, description: 'No variation detected.' };

  const effectSize = Math.abs(secondMean - firstMean) / pooledStd;

  if (effectSize > 0.8) {
    return {
      detected: true,
      index: mid,
      date: values[mid].date,
      description: `Potential change in performance trend detected around ${values[mid].date}. Mean shifted from ${firstMean.toFixed(2)} to ${secondMean.toFixed(2)} (effect size: ${effectSize.toFixed(2)}).`,
    };
  }

  return { detected: false, index: null, date: null, description: 'No significant change point detected.' };
}

// ===== ANOMALY DETECTION =====

export interface AnomalyResult {
  type: 'load' | 'response' | 'performance' | 'data' | 'multivariate';
  severity: 'info' | 'warning' | 'critical';
  metric: string;
  value: number;
  expected: string;
  description: string;
  date: string;
}

export function detectAnomalies(params: {
  sessions: TrainingSession[];
  matches: MatchRecord[];
  capacityTests: CapacityTest[];
}): AnomalyResult[] {
  const { sessions, matches, capacityTests } = params;
  const anomalies: AnomalyResult[] = [];

  // Training load anomalies (z-score based)
  const loads = sessions.map((s) => s.trainingLoad);
  if (loads.length >= 5) {
    const mean = loads.reduce((a, b) => a + b, 0) / loads.length;
    const std = Math.sqrt(loads.reduce((sq, l) => sq + (l - mean) ** 2, 0) / loads.length);
    if (std > 0) {
      sessions.forEach((s) => {
        const z = Math.abs((s.trainingLoad - mean) / std);
        if (z > 2.5) {
          anomalies.push({
            type: 'load',
            severity: z > 3 ? 'critical' : 'warning',
            metric: 'Training Load',
            value: s.trainingLoad,
            expected: `Typical range: ${Math.round(mean - 2 * std)}–${Math.round(mean + 2 * std)} AU`,
            description: `Unusual training load of ${s.trainingLoad} AU on ${s.date} (z-score: ${z.toFixed(1)}).`,
            date: s.date,
          });
        }
      });
    }
  }

  // HR response anomalies
  const hrValues = sessions.map((s) => s.avgHeartRate).filter((v) => v > 0);
  if (hrValues.length >= 5) {
    const mean = hrValues.reduce((a, b) => a + b, 0) / hrValues.length;
    const std = Math.sqrt(hrValues.reduce((sq, v) => sq + (v - mean) ** 2, 0) / hrValues.length);
    if (std > 0) {
      sessions.forEach((s) => {
        if (s.avgHeartRate > 0) {
          const z = Math.abs((s.avgHeartRate - mean) / std);
          if (z > 2) {
            anomalies.push({
              type: 'response',
              severity: 'warning',
              metric: 'Average Heart Rate',
              value: s.avgHeartRate,
              expected: `Typical range: ${Math.round(mean - 2 * std)}–${Math.round(mean + 2 * std)} bpm`,
              description: `Unusual HR response of ${s.avgHeartRate} bpm on ${s.date} (z-score: ${z.toFixed(1)}).`,
              date: s.date,
            });
          }
        }
      });
    }
  }

  // Match load anomalies
  const matchLoads = matches.map((m) => m.totalDistance);
  if (matchLoads.length >= 3) {
    const mean = matchLoads.reduce((a, b) => a + b, 0) / matchLoads.length;
    const std = Math.sqrt(matchLoads.reduce((sq, v) => sq + (v - mean) ** 2, 0) / matchLoads.length);
    if (std > 0) {
      matches.forEach((m) => {
        const z = Math.abs((m.totalDistance - mean) / std);
        if (z > 2) {
          anomalies.push({
            type: 'load',
            severity: 'warning',
            metric: 'Match Total Distance',
            value: m.totalDistance,
            expected: `Typical range: ${(mean - 2 * std).toFixed(1)}–${(mean + 2 * std).toFixed(1)} km`,
            description: `Unusual match distance of ${m.totalDistance} km vs ${m.opponent} on ${m.date} (z-score: ${z.toFixed(1)}).`,
            date: m.date,
          });
        }
      });
    }
  }

  // Data quality anomalies
  sessions.forEach((s) => {
    if ((s.gpsCompleteness ?? 100) < 80) {
      anomalies.push({
        type: 'data',
        severity: 'warning',
        metric: 'GPS Completeness',
        value: s.gpsCompleteness ?? 0,
        expected: '> 80%',
        description: `GPS data completeness at ${s.gpsCompleteness}% on ${s.date} — below threshold.`,
        date: s.date,
      });
    }
    if ((s.hrCompleteness ?? 100) < 75) {
      anomalies.push({
        type: 'data',
        severity: 'info',
        metric: 'HR Completeness',
        value: s.hrCompleteness ?? 0,
        expected: '> 75%',
        description: `HR data completeness at ${s.hrCompleteness}% on ${s.date} — below threshold.`,
        date: s.date,
      });
    }
  });

  return anomalies.sort((a, b) => b.date.localeCompare(a.date));
}

// ===== INTERVENTION EVALUATION =====

export type InterventionOutcome = 'positive' | 'partial' | 'no_change' | 'negative' | 'insufficient';
export type EvidenceStrength = 'low' | 'moderate' | 'strong';

export interface InterventionEvaluation {
  interventionId: string;
  outcome: InterventionOutcome;
  evidenceStrength: EvidenceStrength;
  temporalAssociation: boolean;
  exposureChanged: boolean;
  performanceChanged: boolean;
  alternativeFactors: string[];
  preValue: number;
  postValue: number;
  percentChange: number;
  effectSize: EffectSizeResult | null;
  mdc: MDCResult | null;
  interpretation: string;
  limitations: string[];
}

export function evaluateIntervention(params: {
  intervention: Intervention;
  preSessions: TrainingSession[];
  duringSessions: TrainingSession[];
  postSessions: TrainingSession[];
  preTests: CapacityTest[];
  postTests: CapacityTest[];
  targetMetric: string;
  higherIsBetter: boolean;
}): InterventionEvaluation {
  const { intervention, preSessions, duringSessions, postSessions, preTests, postTests, targetMetric, higherIsBetter } = params;

  // Get pre and post values from capacity tests
  const preTest = preTests.find((t) => t.name === targetMetric || t.category === targetMetric);
  const postTest = postTests.find((t) => t.name === targetMetric || t.category === targetMetric);

  const preValue = preTest?.latest ?? intervention.startingPoint;
  const postValue = postTest?.latest ?? intervention.current;

  const percentChange = preValue === 0 ? 0 : ((postValue - preValue) / preValue) * 100;

  // Check if exposure actually changed during intervention
  const preLoadAvg = preSessions.length > 0 ? preSessions.reduce((s, x) => s + x.trainingLoad, 0) / preSessions.length : 0;
  const duringLoadAvg = duringSessions.length > 0 ? duringSessions.reduce((s, x) => s + x.trainingLoad, 0) / duringSessions.length : 0;
  const exposureChanged = Math.abs(duringLoadAvg - preLoadAvg) > preLoadAvg * 0.1;

  // Check if performance changed
  const performanceChanged = Math.abs(percentChange) > 2;

  // Temporal association: did change occur after intervention start?
  const temporalAssociation = performanceChanged && postValue !== preValue;

  // Alternative factors
  const alternativeFactors: string[] = [];
  if (postSessions.length < 3) alternativeFactors.push('Limited post-intervention data');
  if (preTests.length < 2) alternativeFactors.push('Limited pre-intervention testing');
  if (duringSessions.length < 3) alternativeFactors.push('Limited during-intervention session data');

  // Effect size
  const preValues = preTests.map((t) => t.latest);
  const postValues = postTests.map((t) => t.latest);
  const effectSize = preValues.length >= 2 && postValues.length >= 2
    ? computeEffectSize(preValues, postValues, higherIsBetter)
    : null;

  // MDC
  const allTestValues = [...preTests, ...postTests].map((t) => t.latest);
  const mdc = allTestValues.length >= 2 ? computeMDC(allTestValues, preValue, postValue) : null;

  // Determine outcome
  let outcome: InterventionOutcome = 'insufficient';
  if (preTests.length < 2 || postTests.length < 1) {
    outcome = 'insufficient';
  } else if (mdc?.meaningful && ((higherIsBetter && postValue > preValue) || (!higherIsBetter && postValue < preValue))) {
    outcome = 'positive';
  } else if (Math.abs(percentChange) > 1 && ((higherIsBetter && postValue > preValue) || (!higherIsBetter && postValue < preValue))) {
    outcome = 'partial';
  } else if (Math.abs(percentChange) < 1) {
    outcome = 'no_change';
  } else {
    outcome = 'negative';
  }

  // Evidence strength
  let evidenceStrength: EvidenceStrength = 'low';
  if (temporalAssociation && exposureChanged && effectSize && effectSize.magnitude !== 'negligible' && alternativeFactors.length === 0) {
    evidenceStrength = 'strong';
  } else if (temporalAssociation && (exposureChanged || performanceChanged)) {
    evidenceStrength = 'moderate';
  }

  // Interpretation
  const direction = higherIsBetter ? (postValue > preValue ? 'improved' : 'did not improve') : (postValue < preValue ? 'improved' : 'did not improve');
  const interpretation = outcome === 'insufficient'
    ? 'Insufficient data to evaluate intervention outcome.'
    : outcome === 'positive'
    ? `${targetMetric} ${direction} meaningfully during the intervention period. The temporal association is encouraging, but the available data does not establish causality.`
    : outcome === 'partial'
    ? `${targetMetric} showed some improvement during the intervention period, but the change may not exceed measurement variation.`
    : outcome === 'no_change'
    ? `No meaningful change in ${targetMetric} was observed during the intervention period.`
    : `${targetMetric} moved in an undesired direction during the intervention period. Review the intervention strategy.`;

  // Limitations
  const limitations: string[] = [
    'Observational design — no control group or randomization.',
    'Multiple factors may influence performance beyond the targeted intervention.',
  ];
  if (alternativeFactors.length > 0) limitations.push(...alternativeFactors);
  if (!exposureChanged) limitations.push('Targeted training exposure did not measurably change during the intervention period.');

  return {
    interventionId: intervention.id,
    outcome,
    evidenceStrength,
    temporalAssociation,
    exposureChanged,
    performanceChanged,
    alternativeFactors,
    preValue,
    postValue,
    percentChange: +percentChange.toFixed(1),
    effectSize,
    mdc,
    interpretation,
    limitations,
  };
}

// ===== CORRELATION =====

export interface CorrelationResult {
  r: number;
  n: number;
  interpretation: string;
  warning: string;
}

export function computeCorrelation(x: number[], y: number[]): CorrelationResult | null {
  if (x.length !== y.length || x.length < 5) return null;
  const n = x.length;
  const xMean = x.reduce((a, b) => a + b, 0) / n;
  const yMean = y.reduce((a, b) => a + b, 0) / n;

  let num = 0, denX = 0, denY = 0;
  for (let i = 0; i < n; i++) {
    num += (x[i] - xMean) * (y[i] - yMean);
    denX += (x[i] - xMean) ** 2;
    denY += (y[i] - yMean) ** 2;
  }
  const r = denX === 0 || denY === 0 ? 0 : num / Math.sqrt(denX * denY);

  let strength = 'weak';
  const absR = Math.abs(r);
  if (absR >= 0.7) strength = 'strong';
  else if (absR >= 0.4) strength = 'moderate';

  const direction = r > 0 ? 'positive' : 'negative';

  return {
    r: +r.toFixed(3),
    n,
    interpretation: `${strength} ${direction} correlation (r=${r.toFixed(2)}, n=${n}).`,
    warning: 'Correlation does not establish causation. Multiple confounding factors may exist.',
  };
}

// ===== ATHLETE DEVELOPMENT INDEX =====

export interface DevelopmentIndex {
  score: number;
  confidence: 'Low' | 'Moderate' | 'High';
  components: {
    label: string;
    score: number;
    description: string;
  }[];
  reason: string;
}

export function computeDevelopmentIndex(params: {
  capacityProgression: number;
  demandCoverage: number;
  loadAlignment: number;
  performanceTrend: number;
  dataConfidence: number;
  dataSufficiency: DataSufficiencyLevel;
}): DevelopmentIndex {
  const components = [
    { label: 'Capacity Progression', score: params.capacityProgression, description: 'Improvement in physical capacity tests over time.' },
    { label: 'Demand Coverage', score: params.demandCoverage, description: 'How well training exposure covers competition demands.' },
    { label: 'Load Alignment', score: params.loadAlignment, description: 'Training load relative to individual baseline and competition needs.' },
    { label: 'Performance Trend', score: params.performanceTrend, description: 'Direction and consistency of performance change.' },
    { label: 'Data Confidence', score: params.dataConfidence, description: 'Quality and quantity of underlying data.' },
  ];

  const score = Math.round(components.reduce((sum, c) => sum + c.score, 0) / components.length);

  let confidence: 'Low' | 'Moderate' | 'High' = 'High';
  if (params.dataSufficiency === 'insufficient') confidence = 'Low';
  else if (params.dataSufficiency === 'limited' || params.dataConfidence < 70) confidence = 'Moderate';

  const reason = confidence === 'Low'
    ? 'Insufficient data for reliable development assessment.'
    : confidence === 'Moderate'
    ? 'Limited capacity-testing observations reduce confidence.'
    : 'Adequate data across all components.';

  return { score, confidence, components, reason };
}

// ===== PERFORMANCE DEMAND MATRIX =====

export interface DemandMatrixEntry {
  demand: string;
  importance: 'high' | 'medium' | 'low';
  coverage: number;
  gap: 'large' | 'moderate' | 'small' | 'none';
  trainingValue: number;
  matchValue: number;
  unit: string;
}

export function computeDemandMatrix(params: {
  trainAvg: Record<string, number | undefined>;
  matchAvg: Record<string, number | undefined>;
  positionDemands: { label: string; value: string; unit: string; category: string }[];
  positionWeights: Record<string, 'high' | 'medium' | 'low'>;
}): DemandMatrixEntry[] {
  const { trainAvg, matchAvg, positionDemands, positionWeights } = params;

  return positionDemands.map((demand) => {
    const importance = positionWeights[demand.label] || 'medium';
    const trainVal = trainAvg[demand.label];
    const matchVal = matchAvg[demand.label];

    if (trainVal === undefined || matchVal === undefined || matchVal === 0) {
      return { demand: demand.label, importance, coverage: 0, gap: 'large', trainingValue: trainVal ?? 0, matchValue: matchVal ?? 0, unit: demand.unit };
    }

    const coverage = Math.round(Math.min(trainVal / matchVal, 1.2) * 100);
    const gapPct = ((trainVal - matchVal) / matchVal) * 100;
    const gap: DemandMatrixEntry['gap'] = gapPct < -25 ? 'large' : gapPct < -10 ? 'moderate' : gapPct < 10 ? 'small' : 'none';

    return { demand: demand.label, importance, coverage, gap, trainingValue: trainVal, matchValue: matchVal, unit: demand.unit };
  });
}

// ===== LOAD OPTIMIZATION =====

export type LoadOptimizationStatus = 'underexposed' | 'aligned' | 'overexposed' | 'rapid_change' | 'uncertain';

export interface LoadOptimization {
  status: LoadOptimizationStatus;
  description: string;
  tradeoffs: string[];
  recommendations: string[];
}

export function computeLoadOptimization(params: {
  trainAvg: number;
  matchAvg: number;
  baseline: number;
  recentChange: number;
  dataSufficiency: DataSufficiencyLevel;
}): LoadOptimization {
  const { trainAvg, matchAvg, baseline, recentChange, dataSufficiency } = params;
  const gapPct = matchAvg === 0 ? 0 : ((trainAvg - matchAvg) / matchAvg) * 100;
  const baselineDeviation = baseline === 0 ? 0 : ((trainAvg - baseline) / baseline) * 100;

  let status: LoadOptimizationStatus = 'aligned';
  let description = 'Training exposure appears aligned with competition demands.';
  const tradeoffs: string[] = [];
  const recommendations: string[] = [];

  if (dataSufficiency === 'insufficient') {
    status = 'uncertain';
    description = 'Insufficient evidence to determine optimal load.';
  } else if (Math.abs(recentChange) > 30) {
    status = 'rapid_change';
    description = `Large change in training load (${recentChange > 0 ? '+' : ''}${recentChange.toFixed(0)}%) relative to recent history.`;
    recommendations.push('Review progression rate to avoid excessive rapid change.');
    recommendations.push('Consider stabilizing load before further progression.');
  } else if (gapPct < -25) {
    status = 'underexposed';
    description = `Training exposure is ${Math.abs(gapPct).toFixed(0)}% below competition demand.`;
    recommendations.push('Consider reviewing whether additional controlled exposure is appropriate.');
    recommendations.push('Progress gradually to avoid sudden load spikes.');
    tradeoffs.push('Increasing volume may require reducing intensity or frequency.');
  } else if (gapPct > 25 || baselineDeviation > 30) {
    status = 'overexposed';
    description = `Training exposure is ${gapPct.toFixed(0)}% above competition demand or ${baselineDeviation.toFixed(0)}% above individual baseline.`;
    recommendations.push('Review total exposure and recovery.');
    tradeoffs.push('Reducing volume may allow higher quality intensity work.');
  } else {
    recommendations.push('Continue current training approach with ongoing monitoring.');
  }

  return { status, description, tradeoffs, recommendations };
}

// ===== EVIDENCE HIERARCHY =====

export type EvidenceLevel = 1 | 2 | 3 | 4 | 5;

export interface EvidenceAssessment {
  level: EvidenceLevel;
  label: string;
  description: string;
}

export function assessEvidenceLevel(params: {
  observations: number;
  consistency: boolean;
  association: boolean;
  controlledDesign: boolean;
}): EvidenceAssessment {
  const { observations, consistency, association, controlledDesign } = params;

  if (controlledDesign && observations > 20) {
    return { level: 5, label: 'Causal Claim', description: 'Study design supports causal inference.' };
  }
  if (association && consistency && observations >= 10) {
    return { level: 4, label: 'Stronger Inference', description: 'Repeated observations with adequate data and methodology.' };
  }
  if (association && observations >= 5) {
    return { level: 3, label: 'Association', description: 'Measurable relationship between variables.' };
  }
  if (consistency && observations >= 3) {
    return { level: 2, label: 'Pattern', description: 'Repeated observation across multiple sessions.' };
  }
  return { level: 1, label: 'Observation', description: 'A single observation.' };
}

// ===== ALGORITHM REGISTRY =====

export interface AlgorithmEntry {
  name: string;
  version: string;
  date: string;
  status: 'production' | 'experimental' | 'deprecated';
  description: string;
}

export const ALGORITHM_REGISTRY: AlgorithmEntry[] = [
  { name: 'Training Load', version: 'v1.0', date: '2026-01-01', status: 'production', description: 'Session RPE × Duration' },
  { name: 'Acute:Chronic Workload Ratio', version: 'v1.0', date: '2026-01-01', status: 'production', description: '7-day / 28-day rolling average' },
  { name: 'Training-Match Similarity', version: 'v1.0', date: '2026-01-01', status: 'production', description: 'Weighted metric coverage ratio' },
  { name: 'Demand Coverage', version: 'v1.0', date: '2026-01-01', status: 'production', description: 'Training exposure / match demand per metric' },
  { name: 'Development Index', version: 'v0.5', date: '2026-08-01', status: 'experimental', description: 'Composite of capacity, coverage, alignment, trend, confidence' },
  { name: 'Effect Size (Cohen\'s d)', version: 'v1.0', date: '2026-08-01', status: 'production', description: 'Standardized mean difference' },
  { name: 'Minimal Detectable Change', version: 'v1.0', date: '2026-08-01', status: 'production', description: 'SEM × 1.96 × √2' },
  { name: 'Trend Detection', version: 'v1.0', date: '2026-08-01', status: 'production', description: 'Linear regression with R²' },
  { name: 'Change-Point Detection', version: 'v0.5', date: '2026-08-01', status: 'experimental', description: 'Half-split mean comparison' },
  { name: 'Anomaly Detection', version: 'v1.0', date: '2026-08-01', status: 'production', description: 'Z-score based outlier flagging' },
  { name: 'Intervention Evaluation', version: 'v0.5', date: '2026-08-01', status: 'experimental', description: 'Pre/during/post comparison with attribution' },
];

// ===== DECISION LOG =====

export interface DecisionRecord {
  id: string;
  date: string;
  athleteId: string;
  athleteName: string;
  finding: string;
  evidence: string;
  recommendation: string;
  confidence: 'Low' | 'Moderate' | 'High';
  coachDecision: 'accepted' | 'modified' | 'rejected';
  interventionId?: string;
  outcome?: InterventionOutcome;
  followUp?: string;
}

// ===== DEMO DECISION LOG DATA =====

export const demoDecisionLog: DecisionRecord[] = [
  {
    id: 'd1', date: '2026-08-20', athleteId: 'a1', athleteName: 'Alex Morgan',
    finding: 'Sprint exposure below match demands',
    evidence: 'Training sprint avg: 110m | Match sprint avg: 580m | Gap: -81%',
    recommendation: 'Increase controlled sprint exposure to 200-300m in 2-3 sessions/week',
    confidence: 'Moderate', coachDecision: 'accepted',
    interventionId: 'iv1', outcome: 'partial',
    followUp: 'Sprint exposure increased to 165m average. Sprint test improved 4.35→4.25s.',
  },
  {
    id: 'd2', date: '2026-08-15', athleteId: 'a2', athleteName: 'Daniel Moyo',
    finding: 'Contact load below match demands for flanker',
    evidence: 'Training contact load: 120 AU | Match contact load: 180 AU | Gap: -33%',
    recommendation: 'Add controlled contact sessions 1-2x per week',
    confidence: 'Moderate', coachDecision: 'accepted',
    interventionId: 'iv2', outcome: 'partial',
    followUp: 'Contact load increased to 145 AU. Still below match demand.',
  },
  {
    id: 'd3', date: '2026-08-25', athleteId: 'a6', athleteName: 'Liam Walsh',
    finding: 'Acute load spike detected',
    evidence: 'ACWR: 1.41 | Acute: 3100 AU | Chronic: 2200 AU',
    recommendation: 'Reduce intensity in next 1-2 sessions, monitor recovery',
    confidence: 'Moderate', coachDecision: 'rejected',
    followUp: 'Coach assessed athlete felt fine. Load maintained.',
  },
  {
    id: 'd4', date: '2026-08-10', athleteId: 'a1', athleteName: 'Alex Morgan',
    finding: '30m sprint performance improving steadily',
    evidence: '4.35s → 4.25s over 7 months (+2.3%)',
    recommendation: 'Continue current speed development approach',
    confidence: 'High', coachDecision: 'accepted',
    interventionId: 'iv3', outcome: 'positive',
    followUp: 'Sprint improved to 4.25s. Target of 4.20s not yet achieved but trend positive.',
  },
  {
    id: 'd5', date: '2026-08-22', athleteId: 'a4', athleteName: 'Sipho Ndlovu',
    finding: 'Squat strength below positional benchmark',
    evidence: 'Current: 195kg | Benchmark: 210kg | Gap: -7%',
    recommendation: 'Prioritize maximal strength development, 2-3 sessions/week',
    confidence: 'Moderate', coachDecision: 'modified',
    interventionId: 'iv4', outcome: 'no_change',
    followUp: 'Coach modified to 2 sessions/week instead of 3. Still progressing.',
  },
];

// ===== RECOMMENDATION OUTCOME HISTORY =====

export interface RecommendationHistory {
  total: number;
  accepted: number;
  modified: number;
  rejected: number;
  positiveOutcomes: number;
  partialOutcomes: number;
  noChangeOutcomes: number;
  unknownOutcomes: number;
}

export function computeRecommendationHistory(log: DecisionRecord[]): RecommendationHistory {
  return {
    total: log.length,
    accepted: log.filter((d) => d.coachDecision === 'accepted').length,
    modified: log.filter((d) => d.coachDecision === 'modified').length,
    rejected: log.filter((d) => d.coachDecision === 'rejected').length,
    positiveOutcomes: log.filter((d) => d.outcome === 'positive').length,
    partialOutcomes: log.filter((d) => d.outcome === 'partial').length,
    noChangeOutcomes: log.filter((d) => d.outcome === 'no_change').length,
    unknownOutcomes: log.filter((d) => !d.outcome).length,
  };
}
