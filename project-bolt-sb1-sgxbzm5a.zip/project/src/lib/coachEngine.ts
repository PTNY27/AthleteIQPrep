import { generateAthleteProfile } from './intelligenceEngine';
import { getAllAthletes, getAllTrainingSessions, getAllMatchRecords, getAllCapacityTests, getAllInsights, computeSquadOverview, computeReadiness } from './extendedData';
import { computeLoads, getLoadStatus } from './demoData';
import type {
  Athlete, DevelopmentPlan, DevelopmentObjective, Goal, CoachingSession,
  CoachNote, CoachDecision, AthleteFeedback, DevelopmentReview, AuditEntry,
  PlanStatus, ObjectivePriority, ObjectiveStatus, GoalStatus, SessionStatus,
  CoachDecisionType, CoachRecommendationType, NoteCategory, NoteVisibility,
  ReviewDecision, SessionBlock,
} from './types';

const COACH_ID = 'coach-1';

let planCounter = 0;
let objectiveCounter = 0;
let goalCounter = 0;
let sessionCounter = 0;
let noteCounter = 0;
let decisionCounter = 0;
let feedbackCounter = 0;
let reviewCounter = 0;

function genId(prefix: string, counter: number): string {
  return `${prefix}-${Date.now()}-${counter}`;
}

const plans: Map<string, DevelopmentPlan> = new Map();
const objectives: Map<string, DevelopmentObjective> = new Map();
const goals: Map<string, Goal> = new Map();
const sessions: Map<string, CoachingSession> = new Map();
const notes: Map<string, CoachNote> = new Map();
const decisions: Map<string, CoachDecision> = new Map();
const feedback: Map<string, AthleteFeedback> = new Map();
const reviews: Map<string, DevelopmentReview> = new Map();
const audit: AuditEntry[] = [];

function recordAudit(entry: Omit<AuditEntry, 'id' | 'createdAt'>): void {
  audit.push({
    id: `audit-${Date.now()}-${audit.length}`,
    createdAt: new Date().toISOString(),
    ...entry,
  });
}

// ===== COACH ATHLETES =====

export function getCoachAthletes(): Athlete[] {
  return getAllAthletes();
}

export interface CoachAthleteSummary {
  athlete: Athlete;
  readiness: ReturnType<typeof computeReadiness>;
  loadStatus: ReturnType<typeof getLoadStatus>;
  activePlanCount: number;
  activeGoalCount: number;
  pendingDecisionCount: number;
  attentionFlags: string[];
  lastSessionDate?: string;
  nextReviewDate?: string;
}

export function getCoachAthleteSummaries(): CoachAthleteSummary[] {
  const squad = computeSquadOverview();
  return squad.map((s) => {
    const athleteId = s.athlete.id;
    const athletePlans = Array.from(plans.values()).filter((p) => p.athleteId === athleteId);
    const athleteGoals = Array.from(goals.values()).filter((g) => g.athleteId === athleteId);
    const athleteDecisions = Array.from(decisions.values()).filter((d) => d.athleteId === athleteId && d.decision === 'deferred');
    const athleteSessions = Array.from(sessions.values()).filter((sess) => sess.athleteId === athleteId);

    const flags: string[] = [];
    if (s.readiness.status === 'REVIEW') flags.push('Load review required');
    if (s.flags > 0) flags.push(`${s.flags} critical insights`);
    const activePlan = athletePlans.find((p) => p.status === 'ACTIVE');
    if (activePlan?.reviewDate) {
      const daysToReview = Math.ceil((new Date(activePlan.reviewDate).getTime() - Date.now()) / 86400000);
      if (daysToReview <= 7 && daysToReview >= 0) flags.push('Plan review due soon');
    }
    const atRiskGoals = athleteGoals.filter((g) => g.status === 'AT_RISK');
    if (atRiskGoals.length > 0) flags.push(`${atRiskGoals.length} goals at risk`);

    return {
      athlete: s.athlete,
      readiness: s.readiness,
      loadStatus: s.status,
      activePlanCount: athletePlans.filter((p) => p.status === 'ACTIVE').length,
      activeGoalCount: athleteGoals.filter((g) => g.status === 'IN_PROGRESS' || g.status === 'ON_TRACK').length,
      pendingDecisionCount: athleteDecisions.length,
      attentionFlags: flags,
      lastSessionDate: athleteSessions.length > 0
        ? athleteSessions.sort((a, b) => b.date.localeCompare(a.date))[0].date
        : undefined,
      nextReviewDate: activePlan?.reviewDate,
    };
  });
}

// ===== ATTENTION REQUIRED =====

export interface AttentionItem {
  athleteId: string;
  athleteName: string;
  type: 'assessment_overdue' | 'target_at_risk' | 'performance_change' | 'plan_review' | 'missed_session' | 'reassessment_due' | 'load_review' | 'critical_insight';
  message: string;
  severity: 'high' | 'medium' | 'low';
}

export function getAttentionRequired(): AttentionItem[] {
  const items: AttentionItem[] = [];
  const summaries = getCoachAthleteSummaries();

  for (const s of summaries) {
    const athlete = s.athlete;
    if (s.readiness.status === 'REVIEW') {
      items.push({ athleteId: athlete.id, athleteName: athlete.name, type: 'load_review', message: 'Load status requires coach review', severity: 'high' });
    }
    if (s.pendingDecisionCount > 0) {
      items.push({ athleteId: athlete.id, athleteName: athlete.name, type: 'plan_review', message: `${s.pendingDecisionCount} deferred decisions awaiting review`, severity: 'medium' });
    }
    const athleteGoals = Array.from(goals.values()).filter((g) => g.athleteId === athlete.id);
    for (const g of athleteGoals) {
      if (g.status === 'AT_RISK') {
        items.push({ athleteId: athlete.id, athleteName: athlete.name, type: 'target_at_risk', message: `Goal "${g.metric}" is at risk`, severity: 'high' });
      }
    }
    const athleteSessions = Array.from(sessions.values()).filter((sess) => sess.athleteId === athlete.id);
    for (const sess of athleteSessions) {
      if (sess.status === 'MISSED') {
        items.push({ athleteId: athlete.id, athleteName: athlete.name, type: 'missed_session', message: `Session "${sess.name}" was missed`, severity: 'medium' });
      }
    }
    const athleteInsights = getAllInsights(athlete.id);
    const criticalInsights = athleteInsights.filter((i) => i.severity === 'critical' && !i.feedback);
    for (const ci of criticalInsights) {
      items.push({ athleteId: athlete.id, athleteName: athlete.name, type: 'critical_insight', message: ci.finding, severity: 'high' });
    }
    const activePlan = Array.from(plans.values()).find((p) => p.athleteId === athlete.id && p.status === 'ACTIVE');
    if (activePlan?.reassessmentDate) {
      const daysToReassess = Math.ceil((new Date(activePlan.reassessmentDate).getTime() - Date.now()) / 86400000);
      if (daysToReassess <= 7 && daysToReassess >= 0) {
        items.push({ athleteId: athlete.id, athleteName: athlete.name, type: 'reassessment_due', message: 'Reassessment due soon', severity: 'medium' });
      }
    }
  }

  return items.sort((a, b) => {
    const sev = { high: 0, medium: 1, low: 2 };
    return sev[a.severity] - sev[b.severity];
  });
}

// ===== DEVELOPMENT PRIORITIES (consumes Stage 6) =====

export interface DevelopmentPrioritySuggestion {
  metric: string;
  priority: string;
  evidence: string;
  recommendation: string;
  targetValue?: number;
  targetUnit?: string;
  confidence: string;
  aiGenerated: boolean;
}

export function getDevelopmentPriorities(athleteId: string): DevelopmentPrioritySuggestion[] {
  const athlete = getAllAthletes().find((a) => a.id === athleteId);
  if (!athlete) return [];
  const sessions = getAllTrainingSessions(athleteId);
  const matches = getAllMatchRecords(athleteId);
  const tests = getAllCapacityTests(athleteId);
  const profile = generateAthleteProfile({ athlete, sessions, matches, tests, interventions: [] });
  return profile.priorities
    .filter((p) => p.priority !== 'INSUFFICIENT_DATA')
    .map((p) => {
      const rec = profile.recommendations.find((r) => r.metric === p.metric);
      const gap = profile.gaps.find((g) => g.metric === p.metric);
      return {
        metric: p.metric,
        priority: p.priority,
        evidence: p.evidence,
        recommendation: rec?.recommendedAction ?? 'No specific recommendation',
        targetValue: rec?.targetValue,
        targetUnit: rec?.targetUnit,
        confidence: p.confidence,
        aiGenerated: true,
      };
    });
}

// ===== DEVELOPMENT PLANS =====

export function getAthleteDevelopmentPlans(athleteId: string): DevelopmentPlan[] {
  return Array.from(plans.values()).filter((p) => p.athleteId === athleteId);
}

export function getDevelopmentPlan(planId: string): DevelopmentPlan | undefined {
  return plans.get(planId);
}

export function createDevelopmentPlan(params: {
  athleteId: string;
  name: string;
  startDate: string;
  endDate: string;
  objectives?: string[];
  reviewDate?: string;
  reassessmentDate?: string;
  coachNotes?: string;
}): DevelopmentPlan {
  const plan: DevelopmentPlan = {
    id: genId('plan', planCounter++),
    athleteId: params.athleteId,
    coachId: COACH_ID,
    name: params.name,
    startDate: params.startDate,
    endDate: params.endDate,
    status: 'DRAFT',
    objectives: params.objectives ?? [],
    reviewDate: params.reviewDate,
    reassessmentDate: params.reassessmentDate,
    coachNotes: params.coachNotes,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  plans.set(plan.id, plan);
  recordAudit({ athleteId: params.athleteId, userId: COACH_ID, action: 'create_plan', entityType: 'development_plan', entityId: plan.id, newValue: plan.name, aiInvolved: false });
  return plan;
}

export function updateDevelopmentPlan(planId: string, updates: Partial<DevelopmentPlan>): DevelopmentPlan | undefined {
  const plan = plans.get(planId);
  if (!plan) return undefined;
  const updated = { ...plan, ...updates, updatedAt: new Date().toISOString() };
  plans.set(planId, updated);
  recordAudit({ athleteId: plan.athleteId, userId: COACH_ID, action: 'update_plan', entityType: 'development_plan', entityId: planId, originalValue: JSON.stringify(plan), newValue: JSON.stringify(updated), aiInvolved: false });
  return updated;
}

export function activatePlan(planId: string): DevelopmentPlan | undefined {
  return updateDevelopmentPlan(planId, { status: 'ACTIVE' });
}

export function pausePlan(planId: string): DevelopmentPlan | undefined {
  return updateDevelopmentPlan(planId, { status: 'PAUSED' });
}

export function completePlan(planId: string): DevelopmentPlan | undefined {
  return updateDevelopmentPlan(planId, { status: 'COMPLETED' });
}

export function archivePlan(planId: string): DevelopmentPlan | undefined {
  return updateDevelopmentPlan(planId, { status: 'ARCHIVED' });
}

// ===== DEVELOPMENT OBJECTIVES =====

export function getObjectivesForPlan(planId: string): DevelopmentObjective[] {
  return Array.from(objectives.values()).filter((o) => o.planId === planId);
}

export function getObjectivesForAthlete(athleteId: string): DevelopmentObjective[] {
  return Array.from(objectives.values()).filter((o) => o.athleteId === athleteId);
}

export function createObjective(params: {
  planId: string;
  athleteId: string;
  title: string;
  description?: string;
  priority?: ObjectivePriority;
  baseline?: number;
  target?: number;
  unit?: string;
  targetDate?: string;
  evidence?: string;
  coachNotes?: string;
  reviewDate?: string;
  aiGenerated?: boolean;
}): DevelopmentObjective {
  const obj: DevelopmentObjective = {
    id: genId('obj', objectiveCounter++),
    planId: params.planId,
    athleteId: params.athleteId,
    title: params.title,
    description: params.description,
    priority: params.priority ?? 'MEDIUM',
    baseline: params.baseline,
    target: params.target,
    unit: params.unit,
    targetDate: params.targetDate,
    status: 'NOT_STARTED',
    evidence: params.evidence,
    coachNotes: params.coachNotes,
    reviewDate: params.reviewDate,
    aiGenerated: params.aiGenerated ?? false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  objectives.set(obj.id, obj);
  recordAudit({ athleteId: params.athleteId, userId: COACH_ID, action: 'create_objective', entityType: 'development_objective', entityId: obj.id, newValue: obj.title, aiInvolved: obj.aiGenerated });
  return obj;
}

export function updateObjective(objectiveId: string, updates: Partial<DevelopmentObjective>): DevelopmentObjective | undefined {
  const obj = objectives.get(objectiveId);
  if (!obj) return undefined;
  const updated = { ...obj, ...updates, updatedAt: new Date().toISOString() };
  objectives.set(objectiveId, updated);
  recordAudit({ athleteId: obj.athleteId, userId: COACH_ID, action: 'update_objective', entityType: 'development_objective', entityId: objectiveId, originalValue: JSON.stringify(obj), newValue: JSON.stringify(updated), aiInvolved: false });
  return updated;
}

// ===== GOALS =====

export function getGoalsForAthlete(athleteId: string): Goal[] {
  return Array.from(goals.values()).filter((g) => g.athleteId === athleteId);
}

export function getGoalsForObjective(objectiveId: string): Goal[] {
  return Array.from(goals.values()).filter((g) => g.objectiveId === objectiveId);
}

export function createGoal(params: {
  athleteId: string;
  objectiveId?: string;
  metric: string;
  baseline?: number;
  target?: number;
  unit?: string;
  targetDate: string;
  priority?: ObjectivePriority;
  coachNotes?: string;
  aiGenerated?: boolean;
}): Goal {
  const goal: Goal = {
    id: genId('goal', goalCounter++),
    athleteId: params.athleteId,
    objectiveId: params.objectiveId,
    metric: params.metric,
    baseline: params.baseline,
    target: params.target,
    unit: params.unit,
    targetDate: params.targetDate,
    priority: params.priority ?? 'MEDIUM',
    status: 'NOT_STARTED',
    coachNotes: params.coachNotes,
    aiGenerated: params.aiGenerated ?? false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  goals.set(goal.id, goal);
  recordAudit({ athleteId: params.athleteId, userId: COACH_ID, action: 'create_goal', entityType: 'goal', entityId: goal.id, newValue: `${goal.metric}: ${goal.baseline ?? '?'} → ${goal.target ?? '?'}`, aiInvolved: goal.aiGenerated });
  return goal;
}

export function updateGoal(goalId: string, updates: Partial<Goal>): Goal | undefined {
  const goal = goals.get(goalId);
  if (!goal) return undefined;
  const updated = { ...goal, ...updates, updatedAt: new Date().toISOString() };
  goals.set(goalId, updated);
  recordAudit({ athleteId: goal.athleteId, userId: COACH_ID, action: 'update_goal', entityType: 'goal', entityId: goalId, originalValue: JSON.stringify(goal), newValue: JSON.stringify(updated), aiInvolved: false });
  return updated;
}

// ===== COACHING SESSIONS =====

export function getSessionsForAthlete(athleteId: string): CoachingSession[] {
  return Array.from(sessions.values()).filter((s) => s.athleteId === athleteId);
}

export function createSession(params: {
  athleteId?: string;
  groupId?: string;
  date: string;
  duration: number;
  name: string;
  objective?: string;
  priority?: ObjectivePriority;
  location?: string;
  equipment?: string;
  structure?: SessionBlock[];
  coachNotes?: string;
  aiGenerated?: boolean;
}): CoachingSession {
  const session: CoachingSession = {
    id: genId('sess', sessionCounter++),
    coachId: COACH_ID,
    athleteId: params.athleteId,
    groupId: params.groupId,
    date: params.date,
    duration: params.duration,
    name: params.name,
    objective: params.objective,
    priority: params.priority ?? 'MEDIUM',
    location: params.location,
    equipment: params.equipment,
    structure: params.structure ?? [],
    status: 'PLANNED',
    coachNotes: params.coachNotes,
    aiGenerated: params.aiGenerated ?? false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  sessions.set(session.id, session);
  if (params.athleteId) {
    recordAudit({ athleteId: params.athleteId, userId: COACH_ID, action: 'create_session', entityType: 'coaching_session', entityId: session.id, newValue: session.name, aiInvolved: session.aiGenerated });
  }
  return session;
}

export function updateSession(sessionId: string, updates: Partial<CoachingSession>): CoachingSession | undefined {
  const session = sessions.get(sessionId);
  if (!session) return undefined;
  const updated = { ...session, ...updates, updatedAt: new Date().toISOString() };
  sessions.set(sessionId, updated);
  if (session.athleteId) {
    recordAudit({ athleteId: session.athleteId, userId: COACH_ID, action: 'update_session', entityType: 'coaching_session', entityId: sessionId, originalValue: JSON.stringify(session), newValue: JSON.stringify(updated), aiInvolved: false });
  }
  return updated;
}

export function completeSession(sessionId: string, coachNotes?: string): CoachingSession | undefined {
  return updateSession(sessionId, { status: 'COMPLETED', coachNotes });
}

export function cancelSession(sessionId: string): CoachingSession | undefined {
  return updateSession(sessionId, { status: 'CANCELLED' });
}

// ===== AI SESSION SUGGESTION =====

export function suggestSessionStructure(athleteId: string, objective: string): {
  blocks: SessionBlock[];
  aiGenerated: boolean;
} {
  const athlete = getAllAthletes().find((a) => a.id === athleteId);
  if (!athlete) return { blocks: [], aiGenerated: false };

  const blocks: SessionBlock[] = [
    { id: 'blk-1', name: 'Warm-up', type: 'warmup', duration: 15, description: 'General warm-up and mobility', activities: ['Jog', 'Dynamic stretching'] },
    { id: 'blk-2', name: 'Activation', type: 'activation', duration: 10, description: 'Neuromuscular activation', activities: ['Sprints', 'Plyometrics'] },
    { id: 'blk-3', name: 'Main Activity', type: 'main', duration: 30, description: `Focus: ${objective}`, activities: ['Sport-specific drills'] },
    { id: 'blk-4', name: 'Secondary Activity', type: 'secondary', duration: 20, description: 'Supporting development work', activities: ['Conditioning'] },
    { id: 'blk-5', name: 'Cool-down', type: 'cooldown', duration: 10, description: 'Recovery and debrief', activities: ['Static stretching', 'Review'] },
  ];

  return { blocks, aiGenerated: true };
}

// ===== COACH NOTES =====

export function getNotesForAthlete(athleteId: string): CoachNote[] {
  return Array.from(notes.values())
    .filter((n) => n.athleteId === athleteId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function createNote(params: {
  athleteId: string;
  category: NoteCategory;
  visibility?: NoteVisibility;
  content: string;
  sessionId?: string;
}): CoachNote {
  const note: CoachNote = {
    id: genId('note', noteCounter++),
    athleteId: params.athleteId,
    coachId: COACH_ID,
    category: params.category,
    visibility: params.visibility ?? 'private',
    content: params.content,
    sessionId: params.sessionId,
    createdAt: new Date().toISOString(),
  };
  notes.set(note.id, note);
  recordAudit({ athleteId: params.athleteId, userId: COACH_ID, action: 'create_note', entityType: 'coach_note', entityId: note.id, aiInvolved: false });
  return note;
}

export function deleteNote(noteId: string): boolean {
  const note = notes.get(noteId);
  if (!note) return false;
  notes.delete(noteId);
  recordAudit({ athleteId: note.athleteId, userId: COACH_ID, action: 'delete_note', entityType: 'coach_note', entityId: noteId, aiInvolved: false });
  return true;
}

// ===== COACH DECISION GATE =====

export function recordCoachDecision(params: {
  athleteId: string;
  recommendationId?: string;
  recommendationType: CoachRecommendationType;
  decision: CoachDecisionType;
  originalSuggestion: string;
  finalDecision?: string;
  rationale?: string;
}): CoachDecision {
  const dec: CoachDecision = {
    id: genId('dec', decisionCounter++),
    athleteId: params.athleteId,
    recommendationId: params.recommendationId,
    recommendationType: params.recommendationType,
    decision: params.decision,
    originalSuggestion: params.originalSuggestion,
    finalDecision: params.finalDecision,
    rationale: params.rationale,
    coachId: COACH_ID,
    createdAt: new Date().toISOString(),
  };
  decisions.set(dec.id, dec);
  recordAudit({
    athleteId: params.athleteId,
    userId: COACH_ID,
    action: `decision_${params.decision}`,
    entityType: 'coach_decision',
    entityId: dec.id,
    originalValue: params.originalSuggestion,
    newValue: params.finalDecision ?? params.decision,
    aiInvolved: true,
    rationale: params.rationale,
  });
  return dec;
}

export function getDecisionsForAthlete(athleteId: string): CoachDecision[] {
  return Array.from(decisions.values())
    .filter((d) => d.athleteId === athleteId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

// ===== ATHLETE FEEDBACK =====

export function getFeedbackForAthlete(athleteId: string): AthleteFeedback[] {
  return Array.from(feedback.values())
    .filter((f) => f.athleteId === athleteId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function recordAthleteFeedback(params: {
  athleteId: string;
  sessionId?: string;
  sessionDifficulty?: number;
  perceivedEffort?: number;
  confidence?: number;
  completion?: boolean;
  comments?: string;
}): AthleteFeedback {
  const fb: AthleteFeedback = {
    id: genId('fb', feedbackCounter++),
    athleteId: params.athleteId,
    sessionId: params.sessionId,
    sessionDifficulty: params.sessionDifficulty,
    perceivedEffort: params.perceivedEffort,
    confidence: params.confidence,
    completion: params.completion,
    comments: params.comments,
    createdAt: new Date().toISOString(),
  };
  feedback.set(fb.id, fb);
  return fb;
}

// ===== PROGRESS MONITORING =====

export interface ProgressSummary {
  metric: string;
  baseline?: number;
  current?: number;
  target?: number;
  unit?: string;
  progress: number;
  status: 'ON_TRACK' | 'IMPROVING' | 'STABLE' | 'BEHIND' | 'AT_RISK' | 'ACHIEVED' | 'NO_DATA';
  trend: 'up' | 'down' | 'stable' | 'unknown';
}

export function getDevelopmentProgress(athleteId: string): ProgressSummary[] {
  const athleteGoals = getGoalsForAthlete(athleteId);
  const athleteObjectives = getObjectivesForAthlete(athleteId);
  const tests = getAllCapacityTests(athleteId);

  const summaries: ProgressSummary[] = [];

  for (const goal of athleteGoals) {
    const test = tests.find((t) => t.name === goal.metric);
    const current = test?.latest ?? goal.baseline;
    const baseline = goal.baseline ?? test?.baseline;
    const target = goal.target;
    let progress = 0;
    if (baseline !== undefined && target !== undefined && current !== undefined) {
      const totalChange = target - baseline;
      const currentChange = current - baseline;
      progress = totalChange !== 0 ? Math.max(0, Math.min(100, (currentChange / totalChange) * 100)) : 0;
    }
    let status: ProgressSummary['status'] = 'NO_DATA';
    if (goal.status === 'ACHIEVED') status = 'ACHIEVED';
    else if (goal.status === 'AT_RISK') status = 'AT_RISK';
    else if (progress >= 75) status = 'ON_TRACK';
    else if (progress >= 50) status = 'IMPROVING';
    else if (progress >= 25) status = 'STABLE';
    else if (progress > 0) status = 'BEHIND';

    let trend: ProgressSummary['trend'] = 'unknown';
    if (test) {
      const change = test.higherIsBetter ? test.latest - test.baseline : test.baseline - test.latest;
      trend = change > 0 ? 'up' : change < 0 ? 'down' : 'stable';
    }

    summaries.push({ metric: goal.metric, baseline, current, target, unit: goal.unit, progress, status, trend });
  }

  for (const obj of athleteObjectives) {
    if (summaries.find((s) => s.metric === obj.title)) continue;
    const test = tests.find((t) => t.name.toLowerCase().includes(obj.title.toLowerCase()));
    summaries.push({
      metric: obj.title,
      baseline: obj.baseline,
      current: test?.latest,
      target: obj.target,
      unit: obj.unit,
      progress: 0,
      status: obj.status === 'ACHIEVED' ? 'ACHIEVED' : obj.status === 'AT_RISK' ? 'AT_RISK' : 'NO_DATA',
      trend: 'unknown',
    });
  }

  return summaries;
}

// ===== PLAN VS ACTUAL =====

export interface PlanVsActual {
  planned: number;
  completed: number;
  missed: number;
  cancelled: number;
  completionRate: number;
}

export function getPlanVsActual(athleteId: string): PlanVsActual {
  const athleteSessions = getSessionsForAthlete(athleteId);
  const planned = athleteSessions.length;
  const completed = athleteSessions.filter((s) => s.status === 'COMPLETED').length;
  const missed = athleteSessions.filter((s) => s.status === 'MISSED').length;
  const cancelled = athleteSessions.filter((s) => s.status === 'CANCELLED').length;
  const completionRate = planned > 0 ? Math.round((completed / planned) * 100) : 0;
  return { planned, completed, missed, cancelled, completionRate };
}

// ===== DEVELOPMENT REVIEWS =====

export function getReviewsForAthlete(athleteId: string): DevelopmentReview[] {
  return Array.from(reviews.values())
    .filter((r) => r.athleteId === athleteId)
    .sort((a, b) => b.reviewDate.localeCompare(a.reviewDate));
}

export function createDevelopmentReview(params: {
  athleteId: string;
  planId?: string;
  reviewDate: string;
  baselineSummary?: string;
  progressSummary?: string;
  completedWork?: string;
  coachObservations?: string;
  athleteFeedbackSummary?: string;
  newAssessmentSummary?: string;
  updatedInsightSummary?: string;
  coachDecision: ReviewDecision;
  aiGeneratedSummary?: string;
  aiGenerated?: boolean;
}): DevelopmentReview {
  const review: DevelopmentReview = {
    id: genId('rev', reviewCounter++),
    athleteId: params.athleteId,
    planId: params.planId,
    reviewDate: params.reviewDate,
    baselineSummary: params.baselineSummary,
    progressSummary: params.progressSummary,
    completedWork: params.completedWork,
    coachObservations: params.coachObservations,
    athleteFeedbackSummary: params.athleteFeedbackSummary,
    newAssessmentSummary: params.newAssessmentSummary,
    updatedInsightSummary: params.updatedInsightSummary,
    coachDecision: params.coachDecision,
    aiGeneratedSummary: params.aiGeneratedSummary,
    aiGenerated: params.aiGenerated ?? false,
    coachId: COACH_ID,
    createdAt: new Date().toISOString(),
  };
  reviews.set(review.id, review);
  recordAudit({ athleteId: params.athleteId, userId: COACH_ID, action: 'create_review', entityType: 'development_review', entityId: review.id, aiInvolved: review.aiGenerated });
  return review;
}

// ===== AI REVIEW ASSISTANCE =====

export function generateReviewSummary(athleteId: string): {
  summary: string;
  aiGenerated: boolean;
} {
  const athlete = getAllAthletes().find((a) => a.id === athleteId);
  if (!athlete) return { summary: 'Unable to generate summary — athlete not found.', aiGenerated: false };

  const sessions = getAllTrainingSessions(athleteId);
  const matches = getAllMatchRecords(athleteId);
  const tests = getAllCapacityTests(athleteId);
  const profile = generateAthleteProfile({ athlete, sessions, matches, tests, interventions: [] });
  const progress = getDevelopmentProgress(athleteId);
  const planVsActual = getPlanVsActual(athleteId);
  const athleteNotes = getNotesForAthlete(athleteId);
  const athleteFeedback = getFeedbackForAthlete(athleteId);

  const lines: string[] = [];
  lines.push(`REVIEW SUMMARY — ${athlete.name} (${athlete.position})`);
  lines.push('');
  lines.push('PROGRESS:');
  for (const p of progress.slice(0, 5)) {
    lines.push(`- ${p.metric}: ${p.status} (${Math.round(p.progress)}% progress)`);
  }
  lines.push('');
  lines.push('COMPLETED WORK:');
  lines.push(`- ${planVsActual.completed} of ${planVsActual.planned} sessions completed (${planVsActual.completionRate}% completion rate)`);
  lines.push('');
  lines.push('PERFORMANCE CHANGES:');
  for (const t of profile.trends.slice(0, 5)) {
    lines.push(`- ${t.metric}: ${t.trend} — ${t.evidence}`);
  }
  lines.push('');
  lines.push('POSITIVE DEVELOPENTS:');
  for (const s of profile.strengths.slice(0, 3)) {
    lines.push(`- ${s.metric}: ${s.level} (${Math.round(s.percentOfBenchmark ?? 0)}% of benchmark)`);
  }
  lines.push('');
  lines.push('AREAS REQUIRING ATTENTION:');
  for (const d of profile.developmentAreas.slice(0, 3)) {
    lines.push(`- ${d.metric}: ${d.level} (${Math.round(d.percentOfBenchmark ?? 0)}% of benchmark)`);
  }
  lines.push('');
  lines.push('SUGGESTED DISCUSSION POINTS:');
  for (const r of profile.recommendations.slice(0, 3)) {
    lines.push(`- ${r.metric}: ${r.recommendedAction}`);
  }

  return { summary: lines.join('\n'), aiGenerated: true };
}

// ===== AI REPORT DRAFT =====

export function draftDevelopmentReport(athleteId: string): {
  report: string;
  aiGenerated: boolean;
} {
  const athlete = getAllAthletes().find((a) => a.id === athleteId);
  if (!athlete) return { report: 'Unable to generate report — athlete not found.', aiGenerated: false };

  const sessions = getAllTrainingSessions(athleteId);
  const matches = getAllMatchRecords(athleteId);
  const tests = getAllCapacityTests(athleteId);
  const profile = generateAthleteProfile({ athlete, sessions, matches, tests, interventions: [] });
  const progress = getDevelopmentProgress(athleteId);
  const planVsActual = getPlanVsActual(athleteId);
  const athleteGoals = getGoalsForAthlete(athleteId);
  const athleteNotes = getNotesForAthlete(athleteId);
  const athleteFeedback = getFeedbackForAthlete(athleteId);

  const sections: string[] = [];
  sections.push(`ATHLETE DEVELOPMENT REPORT — ${athlete.name}`);
  sections.push(`Sport: ${athlete.sport} | Position: ${athlete.position} | Age: ${athlete.age}`);
  sections.push(`Date: ${new Date().toLocaleDateString()}`);
  sections.push('');
  sections.push('PERFORMANCE SUMMARY:');
  sections.push(`Overall Level: ${profile.overallLevel}`);
  sections.push(`Overall Confidence: ${profile.overallConfidence}`);
  sections.push('');
  sections.push('STRENGTHS:');
  for (const s of profile.strengths) {
    sections.push(`- ${s.metric}: ${s.level} (${Math.round(s.percentOfBenchmark ?? 0)}% of benchmark)`);
  }
  sections.push('');
  sections.push('DEVELOPMENT PRIORITIES:');
  for (const p of profile.priorities.filter((p) => p.priority !== 'INSUFFICIENT_DATA')) {
    sections.push(`- ${p.metric} (${p.priority}): ${p.evidence}`);
  }
  sections.push('');
  sections.push('ACTIVE GOALS:');
  for (const g of athleteGoals) {
    sections.push(`- ${g.metric}: ${g.baseline ?? '?'} → ${g.target ?? '?'} ${g.unit ?? ''} by ${g.targetDate} [${g.status}]`);
  }
  sections.push('');
  sections.push('TRAINING COMPLETION:');
  sections.push(`- ${planVsActual.completed} of ${planVsActual.planned} sessions completed (${planVsActual.completionRate}%)`);
  sections.push('');
  sections.push('PROGRESS:');
  for (const p of progress) {
    sections.push(`- ${p.metric}: ${p.status} (${Math.round(p.progress)}%)`);
  }
  sections.push('');
  sections.push('COACH OBSERVATIONS:');
  for (const n of athleteNotes.slice(0, 5)) {
    sections.push(`- [${n.category}] ${n.content}`);
  }
  sections.push('');
  sections.push('ATHLETE FEEDBACK:');
  for (const f of athleteFeedback.slice(0, 5)) {
    sections.push(`- Difficulty: ${f.sessionDifficulty ?? 'N/A'}/10, Effort: ${f.perceivedEffort ?? 'N/A'}/10, Confidence: ${f.confidence ?? 'N/A'}/10`);
    if (f.comments) sections.push(`  Comments: ${f.comments}`);
  }
  sections.push('');
  sections.push('NEXT STEPS:');
  for (const r of profile.recommendations.slice(0, 3)) {
    sections.push(`- ${r.metric}: ${r.recommendedAction}`);
  }

  return { report: sections.join('\n'), aiGenerated: true };
}

// ===== AUDIT TRAIL =====

export function getAuditTrail(athleteId?: string): AuditEntry[] {
  return athleteId
    ? audit.filter((a) => a.athleteId === athleteId)
    : audit;
}

// ===== RECENT ACTIVITY =====

export interface ActivityItem {
  type: 'assessment' | 'plan_update' | 'training' | 'note' | 'feedback' | 'goal_progress' | 'reassessment' | 'decision';
  athleteId: string;
  athleteName: string;
  description: string;
  timestamp: string;
}

export function getRecentActivity(limit = 10): ActivityItem[] {
  const items: ActivityItem[] = [];
  const athletes = getAllAthletes();
  const nameMap = new Map(athletes.map((a) => [a.id, a.name]));

  for (const note of Array.from(notes.values()).slice(-20)) {
    items.push({ type: 'note', athleteId: note.athleteId, athleteName: nameMap.get(note.athleteId) ?? 'Unknown', description: `Coach note: ${note.content.slice(0, 60)}...`, timestamp: note.createdAt });
  }
  for (const sess of Array.from(sessions.values()).slice(-20)) {
    if (sess.athleteId) {
      items.push({ type: 'training', athleteId: sess.athleteId, athleteName: nameMap.get(sess.athleteId) ?? 'Unknown', description: `Session "${sess.name}" ${sess.status.toLowerCase()}`, timestamp: sess.createdAt });
    }
  }
  for (const dec of Array.from(decisions.values()).slice(-20)) {
    items.push({ type: 'decision', athleteId: dec.athleteId, athleteName: nameMap.get(dec.athleteId) ?? 'Unknown', description: `Decision: ${dec.decision} — ${dec.originalSuggestion.slice(0, 60)}`, timestamp: dec.createdAt });
  }
  for (const goal of Array.from(goals.values()).slice(-20)) {
    items.push({ type: 'goal_progress', athleteId: goal.athleteId, athleteName: nameMap.get(goal.athleteId) ?? 'Unknown', description: `Goal "${goal.metric}" — ${goal.status}`, timestamp: goal.updatedAt });
  }
  for (const fb of Array.from(feedback.values()).slice(-20)) {
    items.push({ type: 'feedback', athleteId: fb.athleteId, athleteName: nameMap.get(fb.athleteId) ?? 'Unknown', description: `Athlete feedback recorded`, timestamp: fb.createdAt });
  }
  for (const rev of Array.from(reviews.values()).slice(-20)) {
    items.push({ type: 'reassessment', athleteId: rev.athleteId, athleteName: nameMap.get(rev.athleteId) ?? 'Unknown', description: `Development review: ${rev.coachDecision}`, timestamp: rev.createdAt });
  }

  return items.sort((a, b) => b.timestamp.localeCompare(a.timestamp)).slice(0, limit);
}

// ===== UPCOMING =====

export interface UpcomingItem {
  type: 'session' | 'reassessment' | 'review' | 'goal_deadline';
  athleteId: string;
  athleteName: string;
  description: string;
  date: string;
}

export function getUpcoming(limit = 10): UpcomingItem[] {
  const items: UpcomingItem[] = [];
  const athletes = getAllAthletes();
  const nameMap = new Map(athletes.map((a) => [a.id, a.name]));
  const today = new Date().toISOString().slice(0, 10);

  for (const sess of Array.from(sessions.values())) {
    if (sess.athleteId && sess.date >= today && sess.status === 'PLANNED') {
      items.push({ type: 'session', athleteId: sess.athleteId, athleteName: nameMap.get(sess.athleteId) ?? 'Unknown', description: `Session: ${sess.name}`, date: sess.date });
    }
  }
  for (const plan of Array.from(plans.values())) {
    if (plan.status === 'ACTIVE' && plan.reviewDate && plan.reviewDate >= today) {
      items.push({ type: 'review', athleteId: plan.athleteId, athleteName: nameMap.get(plan.athleteId) ?? 'Unknown', description: `Plan review: ${plan.name}`, date: plan.reviewDate });
    }
    if (plan.status === 'ACTIVE' && plan.reassessmentDate && plan.reassessmentDate >= today) {
      items.push({ type: 'reassessment', athleteId: plan.athleteId, athleteName: nameMap.get(plan.athleteId) ?? 'Unknown', description: `Reassessment: ${plan.name}`, date: plan.reassessmentDate });
    }
  }
  for (const goal of Array.from(goals.values())) {
    if (goal.targetDate >= today && goal.status !== 'ACHIEVED' && goal.status !== 'CLOSED') {
      items.push({ type: 'goal_deadline', athleteId: goal.athleteId, athleteName: nameMap.get(goal.athleteId) ?? 'Unknown', description: `Goal deadline: ${goal.metric}`, date: goal.targetDate });
    }
  }

  return items.sort((a, b) => a.date.localeCompare(b.date)).slice(0, limit);
}

// ===== SEED DEMO DATA =====

export function seedDemoCoachingData(): void {
  const athletes = getAllAthletes();
  for (const athlete of athletes.slice(0, 2)) {
    const plan = createDevelopmentPlan({
      athleteId: athlete.id,
      name: `${athlete.name.split(' ')[0]}'s Development Plan`,
      startDate: '2026-08-01',
      endDate: '2026-12-31',
      reviewDate: '2026-09-15',
      reassessmentDate: '2026-10-01',
    });
    activatePlan(plan.id);

    const priorities = getDevelopmentPriorities(athlete.id);
    for (const p of priorities.slice(0, 2)) {
      const obj = createObjective({
        planId: plan.id,
        athleteId: athlete.id,
        title: p.metric,
        description: p.evidence,
        priority: p.priority === 'HIGH' ? 'HIGH' : 'MEDIUM',
        evidence: p.evidence,
        aiGenerated: true,
        reviewDate: '2026-09-15',
      });
      if (p.targetValue !== undefined) {
        createGoal({
          athleteId: athlete.id,
          objectiveId: obj.id,
          metric: p.metric,
          target: p.targetValue,
          unit: p.targetUnit,
          targetDate: '2026-10-01',
          priority: p.priority === 'HIGH' ? 'HIGH' : 'MEDIUM',
          aiGenerated: true,
        });
      }
    }

    createSession({
      athleteId: athlete.id,
      date: '2026-09-05',
      duration: 90,
      name: `${athlete.sport === 'football' ? 'Speed' : 'Contact'} Development Session`,
      objective: 'Acceleration improvement',
      priority: 'HIGH',
      location: 'Main pitch',
    });

    createNote({
      athleteId: athlete.id,
      category: 'observation',
      content: `${athlete.name} showing good engagement in recent sessions. Acceleration work responding well.`,
    });
  }
}

// Initialize demo data on module load
seedDemoCoachingData();
