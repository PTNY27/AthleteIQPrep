import { useState } from 'react';
import { Sidebar } from '@/components/Sidebar';
import type { PageKey } from '@/components/Sidebar';
import { Dashboard } from '@/pages/Dashboard';
import { CoachDashboard } from '@/pages/CoachDashboard';
import { AthleteWorkspace } from '@/pages/AthleteWorkspace';
import { AthletesPage } from '@/pages/Athletes';
import { AthleteProfile } from '@/pages/AthleteProfile';
import { PerformanceDemands } from '@/pages/PerformanceDemands';
import { CapacityTesting } from '@/pages/CapacityTesting';
import { TrainingLoad } from '@/pages/TrainingLoad';
import { MatchLoad } from '@/pages/MatchLoad';
import { LoadComparison } from '@/pages/LoadComparison';
import { Interventions } from '@/pages/Interventions';
import { AIInsights } from '@/pages/AIInsights';
import { PerformanceIntelligence } from '@/pages/PerformanceIntelligence';
import { InterventionEvaluationPage } from '@/pages/InterventionEvaluation';
import { ResearchMode } from '@/pages/ResearchMode';
import { DecisionLog } from '@/pages/DecisionLog';
import { ValidationLab } from '@/pages/ValidationLab';
import { ScoutingWorkspace } from '@/pages/ScoutingWorkspace';
import { DataSources } from '@/pages/DataSources';
import { ImportData } from '@/pages/ImportData';
import { ImportHistory } from '@/pages/ImportHistory';
import { DataQualityCentre } from '@/pages/DataQualityCentre';
import { SettingsPage } from '@/pages/SettingsPage';

function App() {
  const [page, setPage] = useState<PageKey>('coach-dashboard');
  const [selectedAthlete, setSelectedAthlete] = useState('a1');

  const handleSelectAthlete = (id: string) => {
    setSelectedAthlete(id);
    setPage('profile');
  };

  const renderPage = () => {
    switch (page) {
      case 'coach-dashboard':
        return <CoachDashboard selectedAthleteId={selectedAthlete} onNavigate={setPage} onSelectAthlete={setSelectedAthlete} />;
      case 'dashboard':
        return <Dashboard selectedAthleteId={selectedAthlete} onNavigate={setPage} onSelectAthlete={setSelectedAthlete} />;
      case 'athletes':
        return <AthletesPage onSelectAthlete={handleSelectAthlete} />;
      case 'profile':
        return <AthleteWorkspace athleteId={selectedAthlete} onNavigate={setPage} />;
      case 'athlete-profile':
        return <AthleteProfile athleteId={selectedAthlete} onNavigate={setPage} />;
      case 'demands':
        return <PerformanceDemands />;
      case 'capacity':
        return <CapacityTesting athleteId={selectedAthlete} onSelectAthlete={setSelectedAthlete} />;
      case 'training':
        return <TrainingLoad athleteId={selectedAthlete} onSelectAthlete={setSelectedAthlete} />;
      case 'match':
        return <MatchLoad athleteId={selectedAthlete} onSelectAthlete={setSelectedAthlete} />;
      case 'comparison':
        return <LoadComparison athleteId={selectedAthlete} onSelectAthlete={setSelectedAthlete} />;
      case 'interventions':
        return <Interventions athleteId={selectedAthlete} onSelectAthlete={setSelectedAthlete} />;
      case 'ai':
        return <AIInsights athleteId={selectedAthlete} onSelectAthlete={setSelectedAthlete} />;
      case 'intelligence':
        return <PerformanceIntelligence athleteId={selectedAthlete} onSelectAthlete={setSelectedAthlete} />;
      case 'intervention-eval':
        return <InterventionEvaluationPage athleteId={selectedAthlete} onSelectAthlete={setSelectedAthlete} />;
      case 'research':
        return <ResearchMode />;
      case 'decision-log':
        return <DecisionLog />;
      case 'validation-lab':
        return <ValidationLab />;
      case 'scouting':
        return <ScoutingWorkspace />;
      case 'data-sources':
        return <DataSources />;
      case 'import-data':
        return <ImportData />;
      case 'import-history':
        return <ImportHistory />;
      case 'data-quality':
        return <DataQualityCentre />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <CoachDashboard selectedAthleteId={selectedAthlete} onNavigate={setPage} onSelectAthlete={setSelectedAthlete} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-[rgb(var(--bg))]">
      <Sidebar current={page} onNavigate={setPage} />
      <main className="flex-1 min-w-0 p-4 lg:p-8 pt-20 lg:pt-8 overflow-x-hidden">
        {renderPage()}
      </main>
    </div>
  );
}

export default App;
