import { useState } from 'react';
import { demoImportHistory } from '@/lib/dataPipelineData';
import { SectionTitle } from '@/components/ui';
import { CheckCircle2, AlertTriangle, XCircle, FileWarning, Eye, Download, RefreshCw, Search, X, FileText, Clock } from 'lucide-react';
import type { ImportRecord, ValidationIssue } from '@/lib/dataPipeline';

export function ImportHistory() {
  const [search, setSearch] = useState('');
  const [selectedImport, setSelectedImport] = useState<ImportRecord | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filtered = demoImportHistory.filter((imp) => {
    const matchesSearch = imp.fileName.toLowerCase().includes(search.toLowerCase()) || imp.source.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'all' || imp.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalRecords = demoImportHistory.reduce((sum, i) => sum + i.records, 0);
  const avgQuality = Math.round(demoImportHistory.reduce((sum, i) => sum + i.quality, 0) / demoImportHistory.length);
  const totalRejected = demoImportHistory.reduce((sum, i) => sum + i.rejected, 0);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Import History</h1>
        <p className="text-sm text-muted mt-1">All data imports with quality and status tracking</p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="card p-5">
          <div className="text-xs text-muted uppercase tracking-wider mb-2">Total Imports</div>
          <div className="text-3xl font-bold text-[rgb(var(--text))]">{demoImportHistory.length}</div>
        </div>
        <div className="card p-5">
          <div className="text-xs text-muted uppercase tracking-wider mb-2">Total Records</div>
          <div className="text-3xl font-bold text-[rgb(var(--text))]">{totalRecords.toLocaleString()}</div>
        </div>
        <div className="card p-5">
          <div className="text-xs text-muted uppercase tracking-wider mb-2">Avg Quality</div>
          <div className="text-3xl font-bold text-emerald-500">{avgQuality}%</div>
        </div>
        <div className="card p-5">
          <div className="text-xs text-muted uppercase tracking-wider mb-2">Total Rejected</div>
          <div className="text-3xl font-bold text-red-500">{totalRejected}</div>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
            <input
              type="text"
              placeholder="Search by file name or source..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full surface-2 rounded-lg pl-10 pr-4 py-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] outline-none"
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-[rgb(var(--text))]">
                <X size={16} />
              </button>
            )}
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="surface-2 rounded-lg px-4 py-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="complete">Complete</option>
            <option value="partial">Partial</option>
            <option value="requires-review">Requires Review</option>
            <option value="failed">Failed</option>
          </select>
        </div>
      </div>

      {/* Import table */}
      <div className="card p-5">
        <SectionTitle title="Import Records" subtitle={`${filtered.length} imports`} />
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgb(var(--border))]">
                <th className="text-left py-3 px-3 font-medium text-muted">Date</th>
                <th className="text-left py-3 px-3 font-medium text-muted">Source</th>
                <th className="text-left py-3 px-3 font-medium text-muted hidden md:table-cell">File</th>
                <th className="text-right py-3 px-3 font-medium text-muted">Records</th>
                <th className="text-right py-3 px-3 font-medium text-muted hidden sm:table-cell">Valid</th>
                <th className="text-right py-3 px-3 font-medium text-muted hidden sm:table-cell">Warn</th>
                <th className="text-right py-3 px-3 font-medium text-muted hidden sm:table-cell">Reject</th>
                <th className="text-right py-3 px-3 font-medium text-muted">Quality</th>
                <th className="text-center py-3 px-3 font-medium text-muted">Status</th>
                <th className="text-center py-3 px-3 font-medium text-muted">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((imp) => (
                <tr key={imp.id} className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))] transition-colors">
                  <td className="py-3 px-3 text-muted whitespace-nowrap">{imp.date}</td>
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2">
                      <span className="text-[rgb(var(--text))]">{imp.source}</span>
                      <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium ${
                        imp.sourceType === 'live' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' :
                        imp.sourceType === 'imported' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300' :
                        'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300'
                      }`}>
                        {imp.sourceType}
                      </span>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-muted hidden md:table-cell">{imp.fileName}</td>
                  <td className="py-3 px-3 text-right text-muted">{imp.records}</td>
                  <td className="py-3 px-3 text-right text-emerald-500 hidden sm:table-cell">{imp.valid}</td>
                  <td className="py-3 px-3 text-right text-amber-500 hidden sm:table-cell">{imp.warnings}</td>
                  <td className="py-3 px-3 text-right text-red-500 hidden sm:table-cell">{imp.rejected}</td>
                  <td className="py-3 px-3 text-right font-semibold text-[rgb(var(--text))]">{imp.quality}%</td>
                  <td className="py-3 px-3 text-center">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                      imp.status === 'complete' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' :
                      imp.status === 'partial' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' :
                      imp.status === 'requires-review' ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300' :
                      'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
                    }`}>
                      {imp.status === 'complete' && <CheckCircle2 size={12} />}
                      {imp.status === 'partial' && <AlertTriangle size={12} />}
                      {imp.status === 'requires-review' && <FileWarning size={12} />}
                      {imp.status === 'failed' && <XCircle size={12} />}
                      {imp.status}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => setSelectedImport(imp)} className="p-1.5 rounded-lg surface-2 hover:bg-[rgb(var(--surface-3))] text-muted hover:text-[rgb(var(--text))] transition-colors" title="Inspect">
                        <Eye size={16} />
                      </button>
                      <button className="p-1.5 rounded-lg surface-2 hover:bg-[rgb(var(--surface-3))] text-muted hover:text-[rgb(var(--text))] transition-colors" title="Reprocess">
                        <RefreshCw size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Data source labels legend */}
      <div className="card p-5">
        <SectionTitle title="Data Source Labels" subtitle="How AthleteIQ identifies data origin" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="surface-2 rounded-xl p-4">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Live
            </span>
            <p className="text-xs text-muted mt-2">Actual connected wearable data from an API integration.</p>
          </div>
          <div className="surface-2 rounded-xl p-4">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-500" /> Imported
            </span>
            <p className="text-xs text-muted mt-2">Data uploaded by the user via CSV file.</p>
          </div>
          <div className="surface-2 rounded-xl p-4">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500" /> Demo
            </span>
            <p className="text-xs text-muted mt-2">Synthetic data used for demonstration. Never mixed with real data without clear labelling.</p>
          </div>
        </div>
      </div>

      {/* Inspection modal */}
      {selectedImport && <ImportInspectModal importRecord={selectedImport} onClose={() => setSelectedImport(null)} />}
    </div>
  );
}

function ImportInspectModal({ importRecord, onClose }: { importRecord: ImportRecord; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 animate-fade-in" onClick={onClose}>
      <div className="card rounded-2xl p-6 max-w-2xl w-full animate-scale-in max-h-[85vh] overflow-y-auto scrollbar-thin" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[rgb(var(--primary-light))] flex items-center justify-center text-[rgb(var(--primary))]">
              <FileText size={20} />
            </div>
            <div>
              <h3 className="text-lg font-bold text-[rgb(var(--text))]">{importRecord.fileName}</h3>
              <p className="text-sm text-muted flex items-center gap-1.5">
                <Clock size={12} /> {importRecord.date}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-muted hover:text-[rgb(var(--text))] text-xl">✕</button>
        </div>

        {/* Summary stats */}
        <div className="grid grid-cols-4 gap-3 mb-4">
          <div className="surface-2 rounded-lg p-3 text-center">
            <div className="text-xs text-muted">Records</div>
            <div className="text-lg font-bold text-[rgb(var(--text))]">{importRecord.records}</div>
          </div>
          <div className="surface-2 rounded-lg p-3 text-center">
            <div className="text-xs text-muted">Valid</div>
            <div className="text-lg font-bold text-emerald-500">{importRecord.valid}</div>
          </div>
          <div className="surface-2 rounded-lg p-3 text-center">
            <div className="text-xs text-muted">Warnings</div>
            <div className="text-lg font-bold text-amber-500">{importRecord.warnings}</div>
          </div>
          <div className="surface-2 rounded-lg p-3 text-center">
            <div className="text-xs text-muted">Rejected</div>
            <div className="text-lg font-bold text-red-500">{importRecord.rejected}</div>
          </div>
        </div>

        {/* Mapping info */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="surface-2 rounded-lg p-3">
            <div className="text-xs text-muted">Athlete Mappings</div>
            <div className="text-lg font-bold text-[rgb(var(--text))]">{importRecord.athleteMappings}</div>
          </div>
          <div className="surface-2 rounded-lg p-3">
            <div className="text-xs text-muted">Metric Mappings</div>
            <div className="text-lg font-bold text-[rgb(var(--text))]">{importRecord.metricMappings}</div>
          </div>
        </div>

        {/* Quality score */}
        <div className="surface-2 rounded-xl p-4 mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-[rgb(var(--text))]">Data Quality Score</span>
            <span className={`text-lg font-bold ${
              importRecord.quality >= 90 ? 'text-emerald-500' :
              importRecord.quality >= 75 ? 'text-amber-500' : 'text-red-500'
            }`}>{importRecord.quality}%</span>
          </div>
          <div className="h-2.5 bg-[rgb(var(--surface-3))] rounded-full overflow-hidden">
            <div className="h-full rounded-full transition-all duration-700" style={{
              width: `${importRecord.quality}%`,
              backgroundColor: importRecord.quality >= 90 ? 'rgb(var(--success))' :
                importRecord.quality >= 75 ? 'rgb(var(--warning))' : 'rgb(var(--error))',
            }} />
          </div>
        </div>

        {/* Error report */}
        {importRecord.errorReport && importRecord.errorReport.length > 0 && (
          <div>
            <h4 className="text-xs text-muted uppercase tracking-wider mb-2">Error Report ({importRecord.errorReport.length} issues)</h4>
            <div className="space-y-2 max-h-48 overflow-y-auto scrollbar-thin">
              {importRecord.errorReport.map((issue: ValidationIssue, i) => (
                <div key={i} className={`flex items-start gap-2 rounded-lg p-3 text-sm ${
                  issue.level === 'error' ? 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300' :
                  issue.level === 'warning' ? 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300' :
                  'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
                }`}>
                  {issue.level === 'error' ? <XCircle size={16} className="shrink-0 mt-0.5" /> :
                   issue.level === 'warning' ? <AlertTriangle size={16} className="shrink-0 mt-0.5" /> :
                   <FileText size={16} className="shrink-0 mt-0.5" />}
                  <div>
                    <span className="font-semibold">Row {issue.row} · {issue.column}:</span> {issue.message}
                    {issue.value !== undefined && issue.value !== '' && <span className="ml-1 opacity-70">({issue.value})</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="mt-4 flex justify-end gap-2">
          <button className="btn-ghost text-xs flex items-center gap-1.5">
            <Download size={14} /> Download Report
          </button>
          <button className="btn-ghost text-xs flex items-center gap-1.5">
            <RefreshCw size={14} /> Reprocess
          </button>
          <button onClick={onClose} className="btn-primary text-xs">Close</button>
        </div>
      </div>
    </div>
  );
}
