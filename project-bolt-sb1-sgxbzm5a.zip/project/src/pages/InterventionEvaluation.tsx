import { useState, useMemo } from 'react';
import { getAllAthletes, getAllTrainingSessions, getAllCapacityTests, getInterventions } from '@/lib/extendedData';
import { evaluateIntervention, type InterventionEvaluation, type InterventionOutcome, type EvidenceStrength } from '@/lib/statisticalEngine';
import { SectionTitle, Avatar } from '@/components/ui';
import { FlaskConical, TrendingUp, TrendingDown, Minus, AlertCircle, CheckCircle2, XCircle, Activity, FileText, Lightbulb } from 'lucide-react';

export function InterventionEvaluationPage({ athleteId, onSelectAthlete }: { athleteId: string; onSelectAthlete: (id: string) => void }) {
  const athletes = getAllAthletes();
  const [selectedId, setSelectedId] = useState(athleteId);

  const currentAthlete = athletes.find((a) => a.id === selectedId) || athletes[0];
  const interventions = getInterventions(selectedId);
  const allSessions = getAllTrainingSessions(selectedId);
  const allTests = getAllCapacityTests(selectedId);

  const evaluations = useMemo(() => {
    return interventions.map((iv) => {
      const startDate = new Date(iv.startDate);
      const endDate = new Date(iv.endDate);

      const preSessions = allSessions.filter((s) => new Date(s.date) < startDate);
      const duringSessions = allSessions.filter((s) => {
        const d = new Date(s.date);
        return d >= startDate && d <= endDate;
      });
      const postSessions = allSessions.filter((s) => new Date(s.date) > endDate);

      const preTests = allTests.filter((t) => new Date(t.date) < startDate);
      const postTests = allTests.filter((t) => new Date(t.date) >= startDate);

      const targetMetric = iv.metric;
      const testForMetric = allTests.find((t) => t.name === targetMetric || t.category === targetMetric);
      const higherIsBetter = testForMetric?.higherIsBetter ?? true;

      return evaluateIntervention({
        intervention: iv,
        preSessions, duringSessions, postSessions, preTests, postTests,
        targetMetric, higherIsBetter,
      });
    });
  }, [interventions, allSessions, allTests]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Intervention Evaluation</h1>
          <p className="text-sm text-muted mt-1">Pre/during/post analysis with attribution assessment</p>
        </div>
        <select
          value={selectedId}
          onChange={(e) => { setSelectedId(e.target.value); onSelectAthlete(e.target.value); }}
          className="surface-2 rounded-lg px-4 py-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] outline-none"
        >
          {athletes.map((a) => (
            <option key={a.id} value={a.id}>{a.name} — {a.position}</option>
          ))}
        </select>
      </div>

      {interventions.length === 0 ? (
        <div className="card p-8 text-center">
          <FlaskConical size={40} className="mx-auto text-muted mb-3" />
          <h3 className="font-semibold text-[rgb(var(--text))]">No interventions recorded</h3>
          <p className="text-sm text-muted mt-1">Interventions created for this athlete will be evaluated here with full pre/during/post analysis.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {interventions.map((iv, idx) => {
            const evalResult = evaluations[idx];
            return <InterventionCard key={iv.id} intervention={iv} evaluation={evalResult} athlete={currentAthlete} />;
          })}
        </div>
      )}

      {/* Attribution Framework */}
      <div className="card p-5">
        <SectionTitle title="Attribution Framework" subtitle="How AthleteIQ evaluates intervention evidence" />
        <div className="space-y-2">
          <div className="surface-2 rounded-lg p-3">
            <h4 className="text-sm font-semibold text-[rgb(var(--text))] mb-1">Temporal Association</h4>
            <p className="text-xs text-muted">Did the improvement occur after the intervention began? This is the minimum requirement for any attribution claim.</p>
          </div>
          <div className="surface-2 rounded-lg p-3">
            <h4 className="text-sm font-semibold text-[rgb(var(--text))] mb-1">Exposure Change</h4>
            <p className="text-xs text-muted">Did the targeted training variable actually change during the intervention? Without exposure change, any performance change is unlikely to be related.</p>
          </div>
          <div className="surface-2 rounded-lg p-3">
            <h4 className="text-sm font-semibold text-[rgb(var(--text))] mb-1">Performance Change</h4>
            <p className="text-xs text-muted">Did the target metric change beyond expected measurement variation? Assessed using Minimal Detectable Change (MDC).</p>
          </div>
          <div className="surface-2 rounded-lg p-3">
            <h4 className="text-sm font-semibold text-[rgb(var(--text))] mb-1">Alternative Factors</h4>
            <p className="text-xs text-muted">Were other major changes present? Multiple factors can influence performance simultaneously.</p>
          </div>
        </div>
        <div className="mt-3 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
          <div className="flex items-start gap-2">
            <AlertCircle size={16} className="text-amber-500 shrink-0 mt-0.5" />
            <p className="text-sm text-amber-700 dark:text-amber-300">
              AthleteIQ does not claim "the intervention caused the improvement." It assesses temporal association, exposure change, and performance change to determine evidence strength.
            </p>
          </div>
        </div>
      </div>

      {/* Outcome Feedback */}
      <div className="card p-5">
        <SectionTitle title="Outcome Tracking" subtitle="Did the intervention achieve its intended outcome?" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[
            { label: 'Positive', desc: 'Target metric improved meaningfully', icon: <CheckCircle2 size={20} className="text-emerald-500" /> },
            { label: 'Partial', desc: 'Some improvement but target not fully achieved', icon: <Activity size={20} className="text-amber-500" /> },
            { label: 'No Clear Change', desc: 'No meaningful change observed', icon: <Minus size={20} className="text-blue-500" /> },
            { label: 'Negative', desc: 'Performance moved in an undesired direction', icon: <XCircle size={20} className="text-red-500" /> },
            { label: 'Insufficient Data', desc: 'Not enough evidence to evaluate', icon: <FileText size={20} className="text-muted" /> },
          ].map((o) => (
            <div key={o.label} className="surface-2 rounded-xl p-4 flex items-start gap-3">
              {o.icon}
              <div>
                <div className="text-sm font-semibold text-[rgb(var(--text))]">{o.label}</div>
                <div className="text-xs text-muted">{o.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function InterventionCard({ intervention, evaluation, athlete }: {
  intervention: ReturnType<typeof getInterventions>[0];
  evaluation: InterventionEvaluation;
  athlete: ReturnType<typeof getAllAthletes>[0];
}) {
  const outcomeConfig: Record<InterventionOutcome, { color: string; icon: React.ReactNode; label: string }> = {
    positive: { color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300', icon: <TrendingUp size={16} />, label: 'Positive' },
    partial: { color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300', icon: <Activity size={16} />, label: 'Partial' },
    no_change: { color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300', icon: <Minus size={16} />, label: 'No Clear Change' },
    negative: { color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300', icon: <TrendingDown size={16} />, label: 'Negative' },
    insufficient: { color: 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400', icon: <FileText size={16} />, label: 'Insufficient Data' },
  };

  const evidenceConfig: Record<EvidenceStrength, { color: string; label: string }> = {
    strong: { color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300', label: 'Strong' },
    moderate: { color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300', label: 'Moderate' },
    low: { color: 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400', label: 'Low' },
  };

  const oc = outcomeConfig[evaluation.outcome];
  const ec = evidenceConfig[evaluation.evidenceStrength];

  return (
    <div className="card p-5">
      <div className="flex items-start justify-between gap-3 mb-4">
        <div className="flex items-center gap-3">
          <Avatar initials={athlete.initials} color={athlete.avatarColor} size={40} />
          <div>
            <h3 className="font-bold text-[rgb(var(--text))]">{intervention.objective}</h3>
            <p className="text-xs text-muted">{intervention.metric} · {intervention.startDate} → {intervention.endDate}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${oc.color}`}>
            {oc.icon} {oc.label}
          </span>
          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${ec.color}`}>
            Evidence: {ec.label}
          </span>
        </div>
      </div>

      {/* Pre/Post comparison */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        <div className="surface-2 rounded-lg p-3 text-center">
          <div className="text-xs text-muted">Pre-Intervention</div>
          <div className="text-lg font-bold text-[rgb(var(--text))]">{evaluation.preValue} {intervention.unit}</div>
        </div>
        <div className="surface-2 rounded-lg p-3 text-center">
          <div className="text-xs text-muted">Post-Intervention</div>
          <div className="text-lg font-bold text-[rgb(var(--text))]">{evaluation.postValue} {intervention.unit}</div>
        </div>
        <div className="surface-2 rounded-lg p-3 text-center">
          <div className="text-xs text-muted">% Change</div>
          <div className={`text-lg font-bold ${evaluation.percentChange > 0 ? 'text-emerald-500' : evaluation.percentChange < 0 ? 'text-red-500' : 'text-muted'}`}>
            {evaluation.percentChange > 0 ? '+' : ''}{evaluation.percentChange}%
          </div>
        </div>
        <div className="surface-2 rounded-lg p-3 text-center">
          <div className="text-xs text-muted">Target</div>
          <div className="text-lg font-bold text-[rgb(var(--text))]">{intervention.target} {intervention.unit}</div>
        </div>
      </div>

      {/* Attribution checks */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
        <AttributionCheck label="Temporal Association" passed={evaluation.temporalAssociation} />
        <AttributionCheck label="Exposure Changed" passed={evaluation.exposureChanged} />
        <AttributionCheck label="Performance Changed" passed={evaluation.performanceChanged} />
        <AttributionCheck label="No Alternative Factors" passed={evaluation.alternativeFactors.length === 0} />
      </div>

      {/* Effect size & MDC */}
      {(evaluation.effectSize || evaluation.mdc) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
          {evaluation.effectSize && (
            <div className="surface-2 rounded-lg p-3">
              <div className="text-xs text-muted uppercase tracking-wider mb-1">Effect Size (Cohen's d)</div>
              <div className="text-lg font-bold text-[rgb(var(--text))]">{evaluation.effectSize.cohenD}</div>
              <div className="text-xs text-muted">{evaluation.effectSize.interpretation}</div>
            </div>
          )}
          {evaluation.mdc && (
            <div className="surface-2 rounded-lg p-3">
              <div className="text-xs text-muted uppercase tracking-wider mb-1">Minimal Detectable Change</div>
              <div className="text-sm text-[rgb(var(--text))]">{evaluation.mdc.interpretation}</div>
              <div className="text-xs text-muted mt-1">MDC: {evaluation.mdc.mdc} · SEM: {evaluation.mdc.sem}</div>
            </div>
          )}
        </div>
      )}

      {/* Interpretation */}
      <div className="surface-2 rounded-xl p-4 mb-3">
        <div className="flex items-start gap-2">
          <Lightbulb size={16} className="text-[rgb(var(--primary))] shrink-0 mt-0.5" />
          <p className="text-sm text-[rgb(var(--text))]">{evaluation.interpretation}</p>
        </div>
      </div>

      {/* Limitations */}
      {evaluation.limitations.length > 0 && (
        <div>
          <h4 className="text-xs text-muted uppercase tracking-wider mb-2">Limitations</h4>
          <div className="space-y-1">
            {evaluation.limitations.map((lim, i) => (
              <div key={i} className="flex items-start gap-1.5 text-xs text-muted">
                <span className="text-amber-500 shrink-0">⚠</span> {lim}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function AttributionCheck({ label, passed }: { label: string; passed: boolean }) {
  return (
    <div className={`surface-2 rounded-lg p-3 flex items-center gap-2 ${passed ? 'border-l-4 border-l-emerald-500' : 'border-l-4 border-l-gray-300 dark:border-l-gray-600'}`}>
      {passed ? <CheckCircle2 size={16} className="text-emerald-500" /> : <XCircle size={16} className="text-muted" />}
      <span className="text-sm text-[rgb(var(--text))]">{label}</span>
    </div>
  );
}
