import { useState } from 'react';
import { getAllAthletes, getAllTrainingSessions, getAllMatchRecords, computeSimilarity } from '@/lib/extendedData';
import { computeTrainingAverages, computeMatchAverages, computeGapStatus } from '@/lib/demoData';
import { Avatar, GapBadge, SectionTitle, SportBadge } from '@/components/ui';
import { ComparisonBar } from '@/components/charts/Charts';
import { AlertTriangle, CheckCircle2, ArrowUpCircle, Activity } from 'lucide-react';
import type { GapStatus } from '@/lib/types';

export function LoadComparison({ athleteId, onSelectAthlete }: { athleteId: string; onSelectAthlete: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === athleteId) || athletes[0];
  const sessions = getAllTrainingSessions(athlete.id);
  const matches = getAllMatchRecords(athlete.id);
  const trainAvg = computeTrainingAverages(sessions);
  const matchAvg = computeMatchAverages(matches);

  if (!trainAvg || !matchAvg) {
    return (
      <div className="space-y-6 animate-fade-in">
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Load Comparison</h1>
        <div className="card p-12 text-center">
          <Activity size={48} className="mx-auto text-subtle mb-4" />
          <p className="text-muted">No training or match data available for comparison.</p>
        </div>
      </div>
    );
  }

  const comparisonMetrics = [
    { label: 'Total Distance', train: trainAvg.totalDistance, match: matchAvg.totalDistance, unit: 'km' },
    { label: 'High-Speed Running', train: trainAvg.highSpeedRunning, match: matchAvg.highSpeedRunning, unit: 'm' },
    { label: 'Sprint Distance', train: trainAvg.sprintDistance, match: matchAvg.sprintDistance, unit: 'm' },
    { label: 'Accelerations', train: trainAvg.accelerations, match: matchAvg.accelerations, unit: '' },
    { label: 'Decelerations', train: trainAvg.decelerations, match: matchAvg.decelerations, unit: '' },
    { label: 'High-Intensity Efforts', train: trainAvg.highIntensityEfforts, match: matchAvg.highIntensityEfforts, unit: '' },
  ];

  if (trainAvg.contacts !== undefined && matchAvg.contacts !== undefined) {
    comparisonMetrics.push({ label: 'Contacts', train: trainAvg.contacts, match: matchAvg.contacts, unit: '' });
  }
  if (trainAvg.contactLoad !== undefined && matchAvg.contactLoad !== undefined) {
    comparisonMetrics.push({ label: 'Contact Load', train: trainAvg.contactLoad, match: matchAvg.contactLoad, unit: 'AU' });
  }

  const gaps = comparisonMetrics.map((m) => {
    const { status, percentDiff } = computeGapStatus(m.train, m.match);
    return { ...m, status, percentDiff };
  });

  const similarity = computeSimilarity(trainAvg, matchAvg);

  const underexposure = gaps.filter((g) => g.status === 'UNDEREXPOSURE');
  const appropriate = gaps.filter((g) => g.status === 'APPROPRIATE');
  const excessive = gaps.filter((g) => g.status === 'EXCESSIVE');

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Load Comparison</h1>
          <p className="text-sm text-muted mt-1">Training exposure vs competition demands</p>
        </div>
        <AthleteDropdown selectedId={athleteId} onSelect={onSelectAthlete} />
      </div>

      {/* Athlete header */}
      <div className="card p-5 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-3">
          <Avatar initials={athlete.initials} color={athlete.avatarColor} size={48} />
          <div>
            <h3 className="font-bold text-[rgb(var(--text)]">{athlete.name}</h3>
            <div className="flex items-center gap-2 mt-1">
              <SportBadge sport={athlete.sport} />
              <span className="text-sm text-muted">{athlete.position}</span>
            </div>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-3">
          <GapSummary count={underexposure.length} label="Underexposure" color="amber" />
          <GapSummary count={appropriate.length} label="Appropriate" color="emerald" />
          <GapSummary count={excessive.length} label="Excessive" color="red" />
        </div>
      </div>

      {/* Training → Match Similarity Score */}
      <div className="card p-5">
        <SectionTitle title="Training → Match Similarity" subtitle="How closely training reproduces competition demands" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="flex flex-col items-center justify-center">
            <div className="relative w-40 h-40">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 160 160">
                <circle cx="80" cy="80" r="68" fill="none" stroke="rgb(var(--surface-2))" strokeWidth="12" />
                <circle
                  cx="80" cy="80" r="68" fill="none"
                  stroke={similarity.overall >= 75 ? 'rgb(var(--success))' : similarity.overall >= 50 ? 'rgb(var(--warning))' : 'rgb(var(--error))'}
                  strokeWidth="12" strokeLinecap="round"
                  strokeDasharray={`${(similarity.overall / 100) * 427} 427`}
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-bold text-[rgb(var(--text))]">{similarity.overall}%</span>
                <span className="text-xs text-muted mt-1">Similarity</span>
              </div>
            </div>
            <p className="text-xs text-muted mt-4 text-center max-w-xs">
              Training exposure reproduced approximately <span className="font-semibold text-[rgb(var(--text))]">{similarity.overall}%</span> of the selected key competition demands.
            </p>
          </div>
          <div className="space-y-3">
            {similarity.breakdown.map((b) => (
              <div key={b.metric}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-[rgb(var(--text))]">{b.metric}</span>
                  <span className="text-sm font-semibold text-[rgb(var(--text))]">{b.score}%</span>
                </div>
                <div className="h-2.5 bg-[rgb(var(--surface-2))] rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-700" style={{
                    width: `${b.score}%`,
                    backgroundColor: b.score >= 75 ? 'rgb(var(--success))' : b.score >= 50 ? 'rgb(var(--warning))' : 'rgb(var(--error))',
                  }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Summary table */}
      <div className="card p-5">
        <SectionTitle title="Training vs Match Comparison" subtitle="Is training adequately reproducing competition demands?" />
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgb(var(--border))]">
                <th className="text-left py-3 px-4 font-medium text-muted">Metric</th>
                <th className="text-right py-3 px-4 font-medium text-muted">Training Avg</th>
                <th className="text-right py-3 px-4 font-medium text-muted">Match Avg</th>
                <th className="text-right py-3 px-4 font-medium text-muted">Gap</th>
                <th className="text-center py-3 px-4 font-medium text-muted">Status</th>
              </tr>
            </thead>
            <tbody>
              {gaps.map((g) => (
                <tr key={g.label} className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))] transition-colors">
                  <td className="py-3 px-4 font-medium text-[rgb(var(--text))]">{g.label}</td>
                  <td className="py-3 px-4 text-right text-muted">{g.train.toFixed(g.train < 10 ? 1 : 0)} {g.unit}</td>
                  <td className="py-3 px-4 text-right text-muted">{g.match.toFixed(g.match < 10 ? 1 : 0)} {g.unit}</td>
                  <td className={`py-3 px-4 text-right font-bold ${g.percentDiff < -15 ? 'text-amber-500' : g.percentDiff > 25 ? 'text-red-500' : 'text-emerald-500'}`}>
                    {g.percentDiff > 0 ? '+' : ''}{g.percentDiff.toFixed(0)}%
                  </td>
                  <td className="py-3 px-4 text-center"><GapBadge status={g.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Visual comparison bars */}
      <div className="card p-5">
        <SectionTitle title="Visual Comparison" subtitle="Training vs match exposure per metric" />
        <div className="space-y-5">
          {gaps.map((g) => (
            <ComparisonBar
              key={g.label}
              label={g.label}
              trainingValue={g.train}
              matchValue={g.match}
              unit={g.unit}
              gapPercent={g.percentDiff}
              status={g.status}
            />
          ))}
        </div>
      </div>

      {/* Gap analysis cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Underexposure */}
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle size={20} className="text-amber-500" />
            <h3 className="font-semibold text-[rgb(var(--text))]">Underexposure</h3>
          </div>
          <p className="text-xs text-muted mb-3">Training does not adequately reproduce an important competition demand.</p>
          {underexposure.length > 0 ? (
            <div className="space-y-2">
              {underexposure.map((g) => (
                <div key={g.label} className="surface-2 rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-[rgb(var(--text))]">{g.label}</span>
                    <span className="text-sm font-bold text-amber-500">{g.percentDiff.toFixed(0)}%</span>
                  </div>
                  <div className="text-xs text-muted mt-1">Training: {g.train} {g.unit} → Match: {g.match} {g.unit}</div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-subtle">No underexposure detected.</p>
          )}
        </div>

        {/* Appropriate */}
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle2 size={20} className="text-emerald-500" />
            <h3 className="font-semibold text-[rgb(var(--text))]">Appropriate Exposure</h3>
          </div>
          <p className="text-xs text-muted mb-3">Training provides an appropriate stimulus relative to competition.</p>
          {appropriate.length > 0 ? (
            <div className="space-y-2">
              {appropriate.map((g) => (
                <div key={g.label} className="surface-2 rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-[rgb(var(--text))]">{g.label}</span>
                    <span className="text-sm font-bold text-emerald-500">{g.percentDiff > 0 ? '+' : ''}{g.percentDiff.toFixed(0)}%</span>
                  </div>
                  <div className="text-xs text-muted mt-1">Training: {g.train} {g.unit} → Match: {g.match} {g.unit}</div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-subtle">No metrics in the appropriate range.</p>
          )}
        </div>

        {/* Excessive */}
        <div className="card p-5">
          <div className="flex items-center gap-2 mb-4">
            <ArrowUpCircle size={20} className="text-red-500" />
            <h3 className="font-semibold text-[rgb(var(--text))]">Excessive Exposure</h3>
          </div>
          <p className="text-xs text-muted mb-3">Training exposure may be unnecessarily high relative to the athlete's capacity and competition requirements.</p>
          {excessive.length > 0 ? (
            <div className="space-y-2">
              {excessive.map((g) => (
                <div key={g.label} className="surface-2 rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-[rgb(var(--text))]">{g.label}</span>
                    <span className="text-sm font-bold text-red-500">+{g.percentDiff.toFixed(0)}%</span>
                  </div>
                  <div className="text-xs text-muted mt-1">Training: {g.train} {g.unit} → Match: {g.match} {g.unit}</div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-subtle">No excessive exposure detected.</p>
          )}
        </div>
      </div>

      {/* Interpretation */}
      <div className="card p-5">
        <SectionTitle title="Interpretation" subtitle="What this comparison tells the coach" />
        <div className="space-y-3 text-sm text-muted">
          <p>
            The comparison between training and match load reveals whether the athlete is being adequately prepared for the demands of competition.
            Training should aim to reproduce — and occasionally exceed — the key physical demands of match play, while managing overall load to optimize adaptation and recovery.
          </p>
          {underexposure.length > 0 && (
            <p className="text-amber-600 dark:text-amber-400">
              <span className="font-semibold">Underexposure detected:</span> {underexposure.map((g) => g.label).join(', ')} are below what the match demands.
              Consider incorporating targeted drills to address these gaps.
            </p>
          )}
          {excessive.length > 0 && (
            <p className="text-red-600 dark:text-red-400">
              <span className="font-semibold">Excessive exposure detected:</span> {excessive.map((g) => g.label).join(', ')} exceed match demands.
              Monitor to ensure this is intentional and not creating unnecessary load.
            </p>
          )}
          {appropriate.length > 0 && (
            <p className="text-emerald-600 dark:text-emerald-400">
              <span className="font-semibold">Appropriate exposure:</span> {appropriate.map((g) => g.label).join(', ')} are well-matched to competition demands.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function GapSummary({ count, label, color }: { count: number; label: string; color: 'amber' | 'emerald' | 'red' }) {
  const styles = {
    amber: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
    emerald: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    red: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300',
  };
  return (
    <div className={`px-4 py-2 rounded-xl text-center ${styles[color]}`}>
      <div className="text-2xl font-bold">{count}</div>
      <div className="text-xs font-medium">{label}</div>
    </div>
  );
}

function AthleteDropdown({ selectedId, onSelect }: { selectedId: string; onSelect: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === selectedId) || athletes[0];
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 surface rounded-xl px-3 py-2 hover:border-[rgb(var(--primary))] transition-colors"
      >
        <Avatar initials={athlete.initials} color={athlete.avatarColor} size={32} />
        <span className="text-sm font-medium text-[rgb(var(--text))]">{athlete.name}</span>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-2 z-20 w-64 card rounded-xl shadow-lg overflow-hidden animate-scale-in">
            {athletes.map((a) => (
              <button
                key={a.id}
                onClick={() => { onSelect(a.id); setOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-[rgb(var(--surface-2))] transition-colors text-left ${a.id === selectedId ? 'bg-[rgb(var(--surface-2))]' : ''}`}
              >
                <Avatar initials={a.initials} color={a.avatarColor} size={36} />
                <div>
                  <div className="text-sm font-medium text-[rgb(var(--text))]">{a.name}</div>
                  <div className="text-xs text-muted">{a.position}</div>
                </div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
