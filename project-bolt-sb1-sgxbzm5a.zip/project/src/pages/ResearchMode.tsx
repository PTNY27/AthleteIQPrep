import { useState, useMemo } from 'react';
import { getAllAthletes, getAllTrainingSessions, getAllMatchRecords, getAllCapacityTests } from '@/lib/extendedData';
import { computeCorrelation, type CorrelationResult } from '@/lib/statisticalEngine';
import { SectionTitle, Avatar, SportBadge } from '@/components/ui';
import { Search, Database, Download, AlertTriangle, FlaskConical, BarChart3, FileText, Lock } from 'lucide-react';

export function ResearchMode() {
  const athletes = getAllAthletes();
  const [selectedAthleteId, setSelectedAthleteId] = useState(athletes[0].id);
  const [exposureVar, setExposureVar] = useState('highSpeedRunning');
  const [outcomeVar, setOutcomeVar] = useState('sprintDistance');
  const [showAnonymized, setShowAnonymized] = useState(false);

  const sessions = getAllTrainingSessions(selectedAthleteId);
  const matches = getAllMatchRecords(selectedAthleteId);
  const tests = getAllCapacityTests(selectedAthleteId);

  // Available variables
  const exposureVars = [
    { key: 'highSpeedRunning', label: 'High-Speed Running (m)' },
    { key: 'sprintDistance', label: 'Sprint Distance (m)' },
    { key: 'totalDistance', label: 'Total Distance (km)' },
    { key: 'accelerations', label: 'Accelerations (count)' },
    { key: 'decelerations', label: 'Decelerations (count)' },
    { key: 'trainingLoad', label: 'Training Load (AU)' },
    { key: 'sessionRPE', label: 'Session RPE (0-10)' },
    { key: 'avgHeartRate', label: 'Average HR (bpm)' },
  ];

  const outcomeVars = [
    { key: 'sprintDistance', label: 'Sprint Distance (m)' },
    { key: 'highSpeedRunning', label: 'High-Speed Running (m)' },
    { key: 'totalDistance', label: 'Total Distance (km)' },
    { key: 'highIntensityEfforts', label: 'High-Intensity Efforts (count)' },
    { key: 'maxHeartRate', label: 'Max HR (bpm)' },
  ];

  // Compute correlation between exposure and outcome
  const correlation = useMemo(() => {
    const x = sessions.map((s) => (s as unknown as Record<string, unknown>)[exposureVar] as number).filter((v) => v !== undefined && !isNaN(v));
    const y = sessions.map((s) => (s as unknown as Record<string, unknown>)[outcomeVar] as number).filter((v) => v !== undefined && !isNaN(v));
    const minLen = Math.min(x.length, y.length);
    if (minLen < 5) return null;
    return computeCorrelation(x.slice(0, minLen), y.slice(0, minLen));
  }, [sessions, exposureVar, outcomeVar]);

  // Research dataset preview
  const datasetPreview = useMemo(() => {
    return athletes.map((a, i) => {
      const aSessions = getAllTrainingSessions(a.id);
      const aMatches = getAllMatchRecords(a.id);
      const aTests = getAllCapacityTests(a.id);
      const trainAvg = aSessions.length > 0 ? aSessions.reduce((s, x) => s + x.highSpeedRunning, 0) / aSessions.length : 0;
      const matchAvg = aMatches.length > 0 ? aMatches.reduce((s, x) => s + x.highSpeedRunning, 0) / aMatches.length : 0;
      const sprintTest = aTests.find((t) => t.name === '30 m Sprint');
      return {
        participantId: showAnonymized ? `PARTICIPANT-${String(i + 1).padStart(3, '0')}` : a.id,
        name: showAnonymized ? `—` : a.name,
        sport: a.sport,
        position: a.position,
        sessions: aSessions.length,
        matches: aMatches.length,
        capacityTests: aTests.length,
        trainHSR: Math.round(trainAvg),
        matchHSR: Math.round(matchAvg),
        sprint30m: sprintTest?.latest ?? null,
        sprintBaseline: sprintTest?.baseline ?? null,
        sprintChange: sprintTest ? +(((sprintTest.latest - sprintTest.baseline) / sprintTest.baseline) * 100).toFixed(1) : null,
      };
    });
  }, [athletes, showAnonymized]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Research Mode</h1>
        <p className="text-sm text-muted mt-1">Structured investigation of wearable monitoring and performance development</p>
      </div>

      {/* Research Question */}
      <div className="card p-5 bg-gradient-to-br from-[rgb(var(--primary-light))] to-transparent">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-[rgb(var(--primary))] flex items-center justify-center text-white shrink-0">
            <Search size={20} />
          </div>
          <div>
            <h2 className="font-bold text-[rgb(var(--text))]">Central Research Question</h2>
            <p className="text-sm text-[rgb(var(--text))] mt-1 italic">
              "How does the use of wearable electronic monitoring devices influence training outcomes and performance development in athletics?"
            </p>
            <p className="text-xs text-muted mt-2">
              AthleteIQ helps investigate this question by providing structured evidence — not by claiming that wearable monitoring causes improved performance.
            </p>
          </div>
        </div>
      </div>

      {/* Variable Builder */}
      <div className="card p-5">
        <SectionTitle title="Research Variable Builder" subtitle="Select exposure and outcome variables to explore relationships" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="text-xs text-muted uppercase tracking-wider mb-2 block">Exposure Variable</label>
            <select
              value={exposureVar}
              onChange={(e) => setExposureVar(e.target.value)}
              className="w-full surface-2 rounded-lg px-4 py-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] outline-none"
            >
              {exposureVars.map((v) => <option key={v.key} value={v.key}>{v.label}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs text-muted uppercase tracking-wider mb-2 block">Outcome Variable</label>
            <select
              value={outcomeVar}
              onChange={(e) => setOutcomeVar(e.target.value)}
              className="w-full surface-2 rounded-lg px-4 py-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] outline-none"
            >
              {outcomeVars.map((v) => <option key={v.key} value={v.key}>{v.label}</option>)}
            </select>
          </div>
        </div>

        <div className="mb-4">
          <label className="text-xs text-muted uppercase tracking-wider mb-2 block">Athlete</label>
          <select
            value={selectedAthleteId}
            onChange={(e) => setSelectedAthleteId(e.target.value)}
            className="w-full md:w-auto surface-2 rounded-lg px-4 py-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] outline-none"
          >
            {athletes.map((a) => <option key={a.id} value={a.id}>{a.name} — {a.position}</option>)}
          </select>
        </div>

        {/* Correlation result */}
        {correlation ? (
          <div className="surface-2 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <BarChart3 size={18} className="text-[rgb(var(--primary))]" />
              <h4 className="text-sm font-semibold text-[rgb(var(--text))]">Correlation Analysis</h4>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
              <div><span className="text-xs text-muted">r = </span><span className="text-lg font-bold text-[rgb(var(--text))]">{correlation.r}</span></div>
              <div><span className="text-xs text-muted">n = </span><span className="text-lg font-bold text-[rgb(var(--text))]">{correlation.n}</span></div>
              <div><span className="text-xs text-muted">Direction = </span><span className="text-sm font-semibold text-[rgb(var(--text))]">{correlation.r > 0 ? 'Positive' : 'Negative'}</span></div>
              <div><span className="text-xs text-muted">Strength = </span><span className="text-sm font-semibold text-[rgb(var(--text))]">{Math.abs(correlation.r) >= 0.7 ? 'Strong' : Math.abs(correlation.r) >= 0.4 ? 'Moderate' : 'Weak'}</span></div>
            </div>
            <p className="text-sm text-[rgb(var(--text))]">{correlation.interpretation}</p>
            <div className="mt-3 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg flex items-start gap-2">
              <AlertTriangle size={16} className="text-amber-500 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-700 dark:text-amber-300">{correlation.warning}</p>
            </div>
          </div>
        ) : (
          <div className="surface-2 rounded-xl p-4 text-center">
            <FileText size={24} className="mx-auto text-muted mb-2" />
            <p className="text-sm text-muted">Analysis unavailable — insufficient observations (minimum 5 required).</p>
          </div>
        )}
      </div>

      {/* Research Dataset */}
      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <SectionTitle title="Research Dataset" subtitle="Structured data export for analysis" />
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAnonymized(!showAnonymized)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                showAnonymized ? 'bg-[rgb(var(--primary))] text-white' : 'surface-2 text-muted hover:text-[rgb(var(--text))]'
              }`}
            >
              <Lock size={14} /> {showAnonymized ? 'Anonymized' : 'Identifiable'}
            </button>
            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium surface-2 text-muted hover:text-[rgb(var(--text))] transition-all">
              <Download size={14} /> Export CSV
            </button>
          </div>
        </div>
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgb(var(--border))]">
                <th className="text-left py-2 px-3 font-medium text-muted">Participant ID</th>
                {!showAnonymized && <th className="text-left py-2 px-3 font-medium text-muted">Name</th>}
                <th className="text-left py-2 px-3 font-medium text-muted">Sport</th>
                <th className="text-left py-2 px-3 font-medium text-muted">Position</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Sessions</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Matches</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Train HSR</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Match HSR</th>
                <th className="text-right py-2 px-3 font-medium text-muted">30m Sprint</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Sprint Change</th>
              </tr>
            </thead>
            <tbody>
              {datasetPreview.map((row) => (
                <tr key={row.participantId} className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))] transition-colors">
                  <td className="py-2 px-3 text-[rgb(var(--text))] font-mono text-xs">{row.participantId}</td>
                  {!showAnonymized && <td className="py-2 px-3 text-muted">{row.name}</td>}
                  <td className="py-2 px-3"><SportBadge sport={row.sport} /></td>
                  <td className="py-2 px-3 text-muted">{row.position}</td>
                  <td className="py-2 px-3 text-right text-muted">{row.sessions}</td>
                  <td className="py-2 px-3 text-right text-muted">{row.matches}</td>
                  <td className="py-2 px-3 text-right text-muted">{row.trainHSR}m</td>
                  <td className="py-2 px-3 text-right text-muted">{row.matchHSR}m</td>
                  <td className="py-2 px-3 text-right text-muted">{row.sprint30m !== null ? `${row.sprint30m}s` : '—'}</td>
                  <td className="py-2 px-3 text-right">
                    {row.sprintChange !== null ? (
                      <span className={`font-semibold ${row.sprintChange < 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                        {row.sprintChange > 0 ? '+' : ''}{row.sprintChange}%
                      </span>
                    ) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-xs text-muted mt-3">
          {showAnonymized
            ? 'Athlete names replaced with participant IDs. Analytical relationships preserved without unnecessary identity exposure.'
            : 'Showing identifiable data. Toggle anonymization for research export.'}
        </p>
      </div>

      {/* Analysis Pathways */}
      <div className="card p-5">
        <SectionTitle title="Analysis Pathways" subtitle="Structured ways to investigate the research question" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[
            { title: 'Exposure → Outcome', desc: 'Does wearable-derived training exposure relate to performance outcomes?', icon: <BarChart3 size={20} /> },
            { title: 'Training → Match', desc: 'Does training exposure prepare athletes for competition demands?', icon: <Database size={20} /> },
            { title: 'Intervention → Outcome', desc: 'Do training interventions produce measurable performance changes?', icon: <FlaskConical size={20} /> },
            { title: 'Capacity → Competition', desc: 'Does physical capacity relate to ability to meet match demands?', icon: <Search size={20} /> },
          ].map((path) => (
            <div key={path.title} className="surface-2 rounded-xl p-4 flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-[rgb(var(--primary-light))] flex items-center justify-center text-[rgb(var(--primary))] shrink-0">
                {path.icon}
              </div>
              <div>
                <h4 className="text-sm font-semibold text-[rgb(var(--text))]">{path.title}</h4>
                <p className="text-xs text-muted mt-1">{path.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
