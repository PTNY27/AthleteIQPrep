import { useState } from 'react';
import { getAllAthletes, getInterventions, getAllInterventions } from '@/lib/extendedData';
import { Avatar, SectionTitle, SportBadge } from '@/components/ui';
import { FlaskConical, Target, TrendingUp, CheckCircle2, Clock, ArrowRight, Activity } from 'lucide-react';
import type { Intervention } from '@/lib/types';

export function Interventions({ athleteId, onSelectAthlete }: { athleteId: string; onSelectAthlete: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === athleteId) || athletes[0];
  const [selectedAthlete, setSelectedAthlete] = useState(athlete.id);
  const athleteInterventions = getInterventions(selectedAthlete);
  const allInterventions = getAllInterventions();

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Intervention Tracker</h1>
          <p className="text-sm text-muted mt-1">Training stimulus → Athlete response → Performance adaptation</p>
        </div>
        <AthleteDropdown selectedId={selectedAthlete} onSelect={(id) => { setSelectedAthlete(id); onSelectAthlete(id); }} />
      </div>

      {/* Principle banner */}
      <div className="card p-5 bg-gradient-to-r from-[rgb(var(--primary-light))] to-transparent">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-[rgb(var(--primary))] flex items-center justify-center shrink-0">
            <FlaskConical size={20} className="text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-[rgb(var(--text))]">Before → During → After → Evaluate</h3>
            <p className="text-sm text-muted mt-1">
              Track whether training interventions produce measurable outcomes. Did the target exposure occur? Did capacity change?
              Did match performance change? Did training-match similarity improve?
            </p>
          </div>
        </div>
      </div>

      {/* Athlete header */}
      <div className="card p-5 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-3">
          <Avatar initials={athlete.initials} color={athlete.avatarColor} size={48} />
          <div>
            <h3 className="font-bold text-[rgb(var(--text))]">{athlete.name}</h3>
            <div className="flex items-center gap-2 mt-1">
              <SportBadge sport={athlete.sport} />
              <span className="text-sm text-muted">{athlete.position}</span>
            </div>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-6">
          <div className="text-right">
            <div className="text-xs text-muted uppercase tracking-wider">Active</div>
            <div className="text-lg font-bold text-[rgb(var(--text))]">{athleteInterventions.filter((i) => i.status === 'active').length}</div>
          </div>
          <div className="text-right">
            <div className="text-xs text-muted uppercase tracking-wider">Completed</div>
            <div className="text-lg font-bold text-[rgb(var(--text))]">{athleteInterventions.filter((i) => i.status === 'completed').length}</div>
          </div>
          <div className="text-right">
            <div className="text-xs text-muted uppercase tracking-wider">Planned</div>
            <div className="text-lg font-bold text-[rgb(var(--text))]">{athleteInterventions.filter((i) => i.status === 'planned').length}</div>
          </div>
        </div>
      </div>

      {/* Intervention cards */}
      {athleteInterventions.length > 0 ? (
        <div className="space-y-4">
          {athleteInterventions.map((iv) => <InterventionCard key={iv.id} intervention={iv} />)}
        </div>
      ) : (
        <div className="card p-12 text-center">
          <FlaskConical size={48} className="mx-auto text-subtle mb-4" />
          <p className="text-muted">No interventions tracked for this athlete yet.</p>
        </div>
      )}

      {/* All interventions overview */}
      <div className="card p-5">
        <SectionTitle title="All Squad Interventions" subtitle="Cross-athlete intervention tracking" />
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgb(var(--border))]">
                <th className="text-left py-3 px-4 font-medium text-muted">Athlete</th>
                <th className="text-left py-3 px-4 font-medium text-muted">Objective</th>
                <th className="text-left py-3 px-4 font-medium text-muted">Metric</th>
                <th className="text-right py-3 px-4 font-medium text-muted">Start</th>
                <th className="text-right py-3 px-4 font-medium text-muted">Target</th>
                <th className="text-right py-3 px-4 font-medium text-muted">Current</th>
                <th className="text-center py-3 px-4 font-medium text-muted">Status</th>
              </tr>
            </thead>
            <tbody>
              {allInterventions.map((iv) => {
                const a = athletes.find((at) => at.id === iv.athleteId);
                if (!a) return null;
                const progress = iv.target !== iv.startingPoint ? Math.round(((iv.current - iv.startingPoint) / (iv.target - iv.startingPoint)) * 100) : 0;
                return (
                  <tr key={iv.id} className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))] transition-colors cursor-pointer" onClick={() => { setSelectedAthlete(iv.athleteId); onSelectAthlete(iv.athleteId); }}>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <Avatar initials={a.initials} color={a.avatarColor} size={28} />
                        <span className="font-medium text-[rgb(var(--text))]">{a.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-muted">{iv.objective}</td>
                    <td className="py-3 px-4 text-muted">{iv.metric}</td>
                    <td className="py-3 px-4 text-right text-muted">{iv.startingPoint} {iv.unit}</td>
                    <td className="py-3 px-4 text-right text-muted">{iv.target} {iv.unit}</td>
                    <td className="py-3 px-4 text-right font-semibold text-[rgb(var(--text))]">{iv.current} {iv.unit}</td>
                    <td className="py-3 px-4 text-center">
                      <StatusBadge status={iv.status} progress={progress} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function InterventionCard({ intervention: iv }: { intervention: Intervention }) {
  const a = getAllAthletes().find((at) => at.id === iv.athleteId);
  const progress = iv.target !== iv.startingPoint ? Math.round(((iv.current - iv.startingPoint) / (iv.target - iv.startingPoint)) * 100) : 0;
  const clampedProgress = Math.max(0, Math.min(100, progress));

  const statusStyles = {
    active: { bg: 'bg-blue-50 dark:bg-blue-900/20', border: 'border-blue-200 dark:border-blue-800', icon: <Clock size={16} className="text-blue-500" />, label: 'Active' },
    completed: { bg: 'bg-emerald-50 dark:bg-emerald-900/20', border: 'border-emerald-200 dark:border-emerald-800', icon: <CheckCircle2 size={16} className="text-emerald-500" />, label: 'Completed' },
    planned: { bg: 'bg-amber-50 dark:bg-amber-900/20', border: 'border-amber-200 dark:border-amber-800', icon: <Clock size={16} className="text-amber-500" />, label: 'Planned' },
  };
  const s = statusStyles[iv.status];

  return (
    <div className={`card p-5 border-l-4 ${s.bg} ${s.border}`} style={{ borderLeftColor: iv.status === 'active' ? 'rgb(37,99,235)' : iv.status === 'completed' ? 'rgb(22,163,74)' : 'rgb(234,179,8)' }}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          {a && <Avatar initials={a.initials} color={a.avatarColor} size={40} />}
          <div>
            <h3 className="font-semibold text-[rgb(var(--text))]">{iv.objective}</h3>
            <p className="text-xs text-muted mt-0.5">{iv.metric} · {iv.durationWeeks} weeks · {iv.startDate} → {iv.endDate}</p>
          </div>
        </div>
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${s.bg}`}>
          {s.icon}
          {s.label}
        </span>
      </div>

      {/* Progress bar */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-muted">Progress</span>
          <span className="text-xs font-semibold text-[rgb(var(--text))]">{progress}%</span>
        </div>
        <div className="h-3 bg-[rgb(var(--surface-2))] rounded-full overflow-hidden">
          <div className="h-full rounded-full transition-all duration-700" style={{ width: `${clampedProgress}%`, backgroundColor: iv.status === 'completed' ? 'rgb(var(--success))' : 'rgb(var(--primary))' }} />
        </div>
        <div className="flex items-center justify-between mt-2 text-xs text-muted">
          <span>Start: {iv.startingPoint} {iv.unit}</span>
          <span>Current: {iv.current} {iv.unit}</span>
          <span>Target: {iv.target} {iv.unit}</span>
        </div>
      </div>

      {/* Strategy */}
      <div className="surface-2 rounded-xl p-3 mb-4">
        <div className="flex items-start gap-2">
          <Target size={14} className="text-[rgb(var(--primary))] mt-0.5 shrink-0" />
          <div>
            <span className="text-xs font-semibold text-[rgb(var(--text))]">Strategy: </span>
            <span className="text-xs text-muted">{iv.strategy}</span>
          </div>
        </div>
      </div>

      {/* Results (if completed) */}
      {iv.results && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <ResultBox label="Target Achieved" value={iv.results.targetAchieved ? 'Yes' : 'No'} positive={iv.results.targetAchieved} />
          <ResultBox label="Capacity Changed" value={iv.results.capacityChanged ? 'Yes' : 'No'} positive={iv.results.capacityChanged} />
          <ResultBox label="Match Performance" value={iv.results.matchPerformanceChanged ? 'Improved' : 'No change'} positive={iv.results.matchPerformanceChanged} />
          <ResultBox label="Similarity Improved" value={iv.results.similarityImproved ? 'Yes' : 'No'} positive={iv.results.similarityImproved} />
        </div>
      )}

      {/* Before/After */}
      {iv.results && (
        <div className="mt-4 pt-4 border-t border-[rgb(var(--border))]">
          <div className="flex items-center gap-4 justify-center">
            <div className="text-center">
              <div className="text-xs text-muted">Before</div>
              <div className="text-lg font-bold text-[rgb(var(--text))]">{iv.results.beforeValue} {iv.unit}</div>
            </div>
            <ArrowRight size={20} className="text-subtle" />
            <div className="text-center">
              <div className="text-xs text-muted">After</div>
              <div className="text-lg font-bold text-emerald-500">{iv.results.afterValue} {iv.unit}</div>
            </div>
            <div className="text-center ml-4">
              <div className="text-xs text-muted">Change</div>
              <div className="text-lg font-bold text-emerald-500">
                {iv.results.afterValue < iv.results.beforeValue ? '' : '+'}{(iv.results.afterValue - iv.results.beforeValue).toFixed(2)} {iv.unit}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ResultBox({ label, value, positive }: { label: string; value: string; positive: boolean }) {
  return (
    <div className="surface-2 rounded-xl p-3 text-center">
      <div className="text-xs text-muted mb-1">{label}</div>
      <div className={`text-sm font-bold ${positive ? 'text-emerald-500' : 'text-muted'}`}>{value}</div>
    </div>
  );
}

function StatusBadge({ status, progress }: { status: string; progress: number }) {
  const styles: Record<string, string> = {
    active: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
    completed: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
    planned: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
  };
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status]}`}>
      {status === 'active' ? `${progress}%` : status}
    </span>
  );
}

function AthleteDropdown({ selectedId, onSelect }: { selectedId: string; onSelect: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === selectedId) || athletes[0];
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 surface rounded-xl px-3 py-2 hover:border-[rgb(var(--primary))] transition-colors"
      >
        <Avatar initials={athlete.initials} color={athlete.avatarColor} size={32} />
        <span className="text-sm font-medium text-[rgb(var(--text))]">{athlete.name}</span>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-2 z-20 w-64 card rounded-xl shadow-lg overflow-hidden animate-scale-in max-h-80 overflow-y-auto scrollbar-thin">
            {athletes.map((a) => (
              <button
                key={a.id}
                onClick={() => { onSelect(a.id); setOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-[rgb(var(--surface-2))] transition-colors text-left ${a.id === selectedId ? 'bg-[rgb(var(--surface-2))]' : ''}`}
              >
                <Avatar initials={a.initials} color={a.avatarColor} size={36} />
                <div>
                  <div className="text-sm font-medium text-[rgb(var(--text))]">{a.name}</div>
                  <div className="text-xs text-muted">{a.position}</div>
                </div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
