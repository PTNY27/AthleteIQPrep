import { useState } from 'react';
import { getAllAthletes, getAllTrainingSessions, getAllMatchRecords, getAllCapacityTests, computeReadiness, computeWhatChanged, computeDataQuality, computeSimilarity } from '@/lib/extendedData';
import { performanceDemands, footballPositions, rugbyPositions, computeLoads, getLoadStatus, computeTrainingAverages, computeMatchAverages } from '@/lib/demoData';
import { Avatar, SportBadge, StatusBadge, SectionTitle, ReadinessBadge, DataQualityBadge } from '@/components/ui';
import { RadarChart } from '@/components/charts/Charts';
import { TrendingUp, TrendingDown, Minus, ChevronRight, Target, Dumbbell, Trophy, HeartPulse, Zap, Activity, ArrowUp, ArrowDown, ShieldCheck, AlertTriangle } from 'lucide-react';

interface AthleteProfileProps {
  athleteId: string;
  onNavigate: (page: 'dashboard' | 'athletes' | 'demands' | 'capacity' | 'training' | 'match' | 'comparison' | 'interventions' | 'ai') => void;
}

export function AthleteProfile({ athleteId, onNavigate }: AthleteProfileProps) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === athleteId) || athletes[0];
  const sessions = getAllTrainingSessions(athlete.id);
  const matches = getAllMatchRecords(athlete.id);
  const tests = getAllCapacityTests(athlete.id);
  const { acute, chronic, acwr } = computeLoads(sessions);
  const status = getLoadStatus(acute, chronic);
  const trainAvg = computeTrainingAverages(sessions);
  const matchAvg = computeMatchAverages(matches);
  const readiness = computeReadiness(athlete.id);
  const whatChanged = computeWhatChanged(athlete.id);
  const dataQuality = computeDataQuality(athlete.id);
  const similarity = computeSimilarity(trainAvg, matchAvg);

  const navItems = [
    { label: 'Training Load', page: 'training' as const, icon: <Dumbbell size={18} />, value: `${acute.toLocaleString()} AU` },
    { label: 'Match Load', page: 'match' as const, icon: <Trophy size={18} />, value: `${matches.length} matches` },
    { label: 'Load Comparison', page: 'comparison' as const, icon: <Activity size={18} />, value: `ACWR ${acwr.toFixed(2)}` },
    { label: 'Capacity Testing', page: 'capacity' as const, icon: <Target size={18} />, value: `${tests.length} tests` },
  ];

  // Radar data for capacity
  const radarData = tests.slice(0, 6).map((t) => ({
    label: t.name.length > 12 ? t.name.split(' ')[0] : t.name,
    value: t.higherIsBetter ? (t.latest / t.benchmark) * 100 : (t.benchmark / t.latest) * 100,
    max: 100,
  }));

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="card p-6">
        <div className="flex flex-col lg:flex-row lg:items-center gap-4">
          <Avatar initials={athlete.initials} color={athlete.avatarColor} size={64} />
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-[rgb(var(--text))]">{athlete.name}</h1>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <SportBadge sport={athlete.sport} />
              <span className="text-sm text-muted">{athlete.position}</span>
              <span className="text-sm text-subtle">·</span>
              <span className="text-sm text-muted">{athlete.age} years old</span>
              <span className="text-sm text-subtle">·</span>
              <span className="text-sm text-muted">{athlete.team}</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs text-muted uppercase tracking-wider">Load Status</div>
              <div className="mt-1"><StatusBadge status={status} /></div>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted uppercase tracking-wider">ACWR</div>
              <div className="text-lg font-bold text-[rgb(var(--text))]">{acwr.toFixed(2)}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick nav */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {navItems.map((item) => (
          <button
            key={item.page}
            onClick={() => onNavigate(item.page)}
            className="card p-4 flex items-center gap-3 hover:border-[rgb(var(--primary))] transition-all group"
          >
            <div className="w-10 h-10 rounded-lg bg-[rgb(var(--primary-light))] flex items-center justify-center text-[rgb(var(--primary))]">
              {item.icon}
            </div>
            <div className="flex-1 text-left">
              <div className="text-sm font-medium text-[rgb(var(--text))]">{item.label}</div>
              <div className="text-xs text-muted">{item.value}</div>
            </div>
            <ChevronRight size={16} className="text-subtle group-hover:translate-x-1 transition-transform" />
          </button>
        ))}
      </div>

      {/* Capacity radar + development */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <SectionTitle title="Capacity Profile" subtitle="Performance vs positional benchmark" />
          <RadarChart data={radarData} size={280} />
          <p className="text-xs text-muted text-center mt-2">% of positional benchmark achieved</p>
        </div>

        <div className="card p-5">
          <SectionTitle title="Performance Development" subtitle="Latest test progression" />
          <div className="space-y-3">
            {tests.slice(0, 6).map((test) => {
              const change = test.higherIsBetter
                ? ((test.latest - test.baseline) / test.baseline) * 100
                : ((test.baseline - test.latest) / test.baseline) * 100;
              const improving = test.higherIsBetter ? test.latest > test.baseline : test.latest < test.baseline;
              return (
                <div key={test.id} className="flex items-center gap-3 surface-2 rounded-xl p-3">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                    improving ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-red-100 dark:bg-red-900/30'
                  }`}>
                    {improving ? <TrendingUp size={16} className="text-emerald-500" /> : <TrendingDown size={16} className="text-red-500" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-[rgb(var(--text))]">{test.name}</div>
                    <div className="text-xs text-muted">{test.baseline} → {test.latest} {test.unit}</div>
                  </div>
                  <div className={`text-sm font-bold ${improving ? 'text-emerald-500' : 'text-red-500'}`}>
                    {improving ? '+' : ''}{change.toFixed(1)}%
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Readiness + What Changed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <SectionTitle title="Readiness" subtitle="Load-management decision support (not injury prediction)" />
          <div className="flex items-center gap-4 mb-4">
            <ReadinessBadge status={readiness.status} />
            <span className="text-xs text-muted">Based on recent load, ACWR, monotony, and match frequency</span>
          </div>
          <div className="space-y-2">
            {readiness.factors.map((f) => (
              <div key={f.label} className="flex items-center justify-between surface-2 rounded-lg p-2.5">
                <span className="text-sm text-[rgb(var(--text))]">{f.label}</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-[rgb(var(--text))]">{f.value}</span>
                  {f.concern ? <AlertTriangle size={14} className="text-amber-500" /> : <ShieldCheck size={14} className="text-emerald-500" />}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <SectionTitle title="What Changed?" subtitle="Week-over-week training comparison" />
          {whatChanged.length > 0 ? (
            <div className="space-y-2">
              {whatChanged.map((c) => (
                <div key={c.label} className="flex items-center justify-between surface-2 rounded-lg p-2.5">
                  <span className="text-sm text-[rgb(var(--text))]">{c.label}</span>
                  <div className="flex items-center gap-2">
                    {c.direction === 'up' ? <ArrowUp size={14} className="text-emerald-500" /> : c.direction === 'down' ? <ArrowDown size={14} className="text-red-500" /> : <Minus size={14} className="text-subtle" />}
                    <span className={`text-sm font-semibold ${c.direction === 'up' ? 'text-emerald-500' : c.direction === 'down' ? 'text-red-500' : 'text-muted'}`}>{c.change}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted">Insufficient data for week-over-week comparison.</p>
          )}
        </div>
      </div>

      {/* Training summary */}
      <div className="card p-5">
        <SectionTitle title="Training Summary" subtitle="Current training exposure" />
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <MetricBox label="7-Day Load" value={acute.toLocaleString()} unit="AU" icon={<Dumbbell size={16} />} />
          <MetricBox label="28-Day Avg" value={chronic.toLocaleString()} unit="AU/wk" />
          <MetricBox label="Total Distance" value={(trainAvg?.totalDistance || 0).toString()} unit="km" />
          <MetricBox label="HSR" value={(trainAvg?.highSpeedRunning || 0).toString()} unit="m" />
          <MetricBox label="Sprints" value={(trainAvg?.sprintDistance || 0).toString()} unit="m" />
          <MetricBox label="Avg HR" value={(trainAvg?.avgHeartRate || 0).toString()} unit="bpm" icon={<HeartPulse size={16} />} />
        </div>
      </div>

      {/* Competition summary */}
      <div className="card p-5">
        <SectionTitle title="Competition Summary" subtitle="Recent match load and competition demand" />
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <MetricBox label="Matches" value={matches.length.toString()} unit="" icon={<Trophy size={16} />} />
          <MetricBox label="Avg Distance" value={(matchAvg?.totalDistance || 0).toString()} unit="km" />
          <MetricBox label="Avg HSR" value={(matchAvg?.highSpeedRunning || 0).toString()} unit="m" />
          <MetricBox label="Avg Sprints" value={(matchAvg?.sprintDistance || 0).toString()} unit="m" />
          <MetricBox label="Avg RPE" value={(matchAvg?.sessionRPE || 0).toString()} unit="/10" />
          {matchAvg?.contacts !== undefined && (
            <MetricBox label="Avg Contacts" value={(matchAvg.contacts || 0).toString()} unit="" />
          )}
        </div>
      </div>
    </div>
  );
}

function MetricBox({ label, value, unit, icon }: { label: string; value: string; unit: string; icon?: React.ReactNode }) {
  return (
    <div className="surface-2 rounded-xl p-3">
      <div className="flex items-center gap-1.5 mb-1">
        {icon && <span className="text-subtle">{icon}</span>}
        <span className="text-xs text-muted">{label}</span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="text-lg font-bold text-[rgb(var(--text))]">{value}</span>
        {unit && <span className="text-xs text-muted">{unit}</span>}
      </div>
    </div>
  );
}
