import { useState } from 'react';
import { getAllAthletes, getAllMatchRecords } from '@/lib/extendedData';
import { computeMatchAverages } from '@/lib/demoData';
import { Avatar, SectionTitle, SportBadge } from '@/components/ui';
import { BarChart, HBarChart } from '@/components/charts/Charts';
import { Trophy, Clock, Zap, Gauge, Activity, HeartPulse, Shield, Target } from 'lucide-react';
import type { MatchRecord } from '@/lib/types';

export function MatchLoad({ athleteId, onSelectAthlete }: { athleteId: string; onSelectAthlete: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === athleteId) || athletes[0];
  const matches = getAllMatchRecords(athlete.id);
  const avg = computeMatchAverages(matches);
  const [selectedMatch, setSelectedMatch] = useState<MatchRecord | null>(null);

  // Match distance chart
  const matchDistData = [...matches].reverse().map((m) => ({
    label: new Date(m.date).toLocaleDateString('en', { day: 'numeric', month: 'short' }),
    value: m.totalDistance,
  }));

  // HSR chart
  const matchHsrData = [...matches].reverse().map((m) => ({
    label: new Date(m.date).toLocaleDateString('en', { day: 'numeric', month: 'short' }),
    value: m.highSpeedRunning,
  }));

  // Competition demand profile
  const demandMetrics = avg ? [
    { label: 'Total Distance', value: avg.totalDistance, unit: ' km', color: 'rgb(var(--chart-1))' },
    { label: 'High-Speed Running', value: avg.highSpeedRunning, unit: ' m', color: 'rgb(var(--chart-3))' },
    { label: 'Sprint Distance', value: avg.sprintDistance, unit: ' m', color: 'rgb(var(--chart-2))' },
    { label: 'Accelerations', value: avg.accelerations, unit: '', color: 'rgb(var(--chart-4))' },
    { label: 'Decelerations', value: avg.decelerations, unit: '', color: 'rgb(var(--chart-5))' },
    { label: 'High-Intensity Efforts', value: avg.highIntensityEfforts, unit: '', color: 'rgb(168, 85, 247)' },
    ...(avg.contacts !== undefined ? [{ label: 'Contacts', value: avg.contacts, unit: '', color: 'rgb(220, 38, 38)' }] : []),
    ...(avg.contactLoad !== undefined ? [{ label: 'Contact Load', value: avg.contactLoad, unit: ' AU', color: 'rgb(249, 115, 22)' }] : []),
  ] : [];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Match Load</h1>
          <p className="text-sm text-muted mt-1">Competition demand analysis</p>
        </div>
        <AthleteDropdown selectedId={athleteId} onSelect={onSelectAthlete} />
      </div>

      {/* Athlete header */}
      <div className="card p-5 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-3">
          <Avatar initials={athlete.initials} color={athlete.avatarColor} size={48} />
          <div>
            <h3 className="font-bold text-[rgb(var(--text))]">{athlete.name}</h3>
            <div className="flex items-center gap-2 mt-1">
              <SportBadge sport={athlete.sport} />
              <span className="text-sm text-muted">{athlete.position}</span>
            </div>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-6">
          <div className="text-right">
            <div className="text-xs text-muted uppercase tracking-wider">Matches Recorded</div>
            <div className="text-lg font-bold text-[rgb(var(--text))]">{matches.length}</div>
          </div>
          <div className="text-right">
            <div className="text-xs text-muted uppercase tracking-wider">Avg Minutes</div>
            <div className="text-lg font-bold text-[rgb(var(--text))]">{Math.round(matches.reduce((s, m) => s + m.minutesPlayed, 0) / matches.length)}</div>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <SectionTitle title="Match Total Distance" subtitle="Per match" />
          <BarChart data={matchDistData} unit="km" height={220} />
        </div>
        <div className="card p-5">
          <SectionTitle title="Match High-Speed Running" subtitle="Per match" />
          <BarChart data={matchHsrData} unit="m" height={220} />
        </div>
      </div>

      {/* Competition Demand Profile */}
      <div className="card p-5">
        <SectionTitle title="Competition Demand Profile" subtitle="What competition actually demands from this athlete" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <HBarChart data={demandMetrics} height={300} />
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <MetricBox label="Avg Distance" value={avg?.totalDistance || 0} unit="km" icon={<Activity size={14} />} />
            <MetricBox label="Rel Distance" value={Math.round(((avg?.totalDistance || 0) * 1000) / (avg?.duration || 1))} unit="m/min" icon={<Gauge size={14} />} />
            <MetricBox label="HSR" value={avg?.highSpeedRunning || 0} unit="m" icon={<Zap size={14} />} />
            <MetricBox label="Sprints" value={avg?.sprintDistance || 0} unit="m" icon={<Gauge size={14} />} />
            <MetricBox label="Accelerations" value={avg?.accelerations || 0} unit="" icon={<Zap size={14} />} />
            <MetricBox label="Decelerations" value={avg?.decelerations || 0} unit="" icon={<Zap size={14} />} />
            <MetricBox label="HIE" value={avg?.highIntensityEfforts || 0} unit="" icon={<Activity size={14} />} />
            <MetricBox label="Avg HR" value={avg?.avgHeartRate || 0} unit="bpm" icon={<HeartPulse size={14} />} />
            <MetricBox label="Avg RPE" value={avg?.sessionRPE || 0} unit="/10" icon={<Gauge size={14} />} />
            {avg?.contacts !== undefined && <MetricBox label="Contacts" value={avg.contacts} unit="" icon={<Shield size={14} />} />}
            {avg?.contactLoad !== undefined && <MetricBox label="Contact Load" value={avg.contactLoad} unit="AU" icon={<Shield size={14} />} />}
          </div>
        </div>
      </div>

      {/* Match table */}
      <div className="card p-5">
        <SectionTitle title="Match Records" subtitle={`${matches.length} matches`} />
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgb(var(--border))]">
                <th className="text-left py-2 px-3 font-medium text-muted">Date</th>
                <th className="text-left py-2 px-3 font-medium text-muted">Opponent</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Min Played</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Distance</th>
                <th className="text-right py-2 px-3 font-medium text-muted">HSR</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Sprint</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Acc</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Avg HR</th>
                <th className="text-right py-2 px-3 font-medium text-muted">RPE</th>
                {athlete.sport === 'rugby' && <th className="text-right py-2 px-3 font-medium text-muted">Contacts</th>}
              </tr>
            </thead>
            <tbody>
              {matches.map((m) => (
                <tr
                  key={m.id}
                  onClick={() => setSelectedMatch(m)}
                  className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))] cursor-pointer transition-colors"
                >
                  <td className="py-2 px-3 text-muted">{new Date(m.date).toLocaleDateString('en', { day: 'numeric', month: 'short' })}</td>
                  <td className="py-2 px-3 font-medium text-[rgb(var(--text))]">{m.opponent}</td>
                  <td className="py-2 px-3 text-right text-muted">{m.minutesPlayed}'</td>
                  <td className="py-2 px-3 text-right text-muted">{m.totalDistance} km</td>
                  <td className="py-2 px-3 text-right text-muted">{m.highSpeedRunning}m</td>
                  <td className="py-2 px-3 text-right text-muted">{m.sprintDistance}m</td>
                  <td className="py-2 px-3 text-right text-muted">{m.accelerations}</td>
                  <td className="py-2 px-3 text-right text-muted">{m.avgHeartRate}</td>
                  <td className="py-2 px-3 text-right text-muted">{m.sessionRPE}</td>
                  {athlete.sport === 'rugby' && <td className="py-2 px-3 text-right text-muted">{m.contacts || '—'}</td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Match detail modal */}
      {selectedMatch && (
        <MatchDetailModal match={selectedMatch} onClose={() => setSelectedMatch(null)} />
      )}
    </div>
  );
}

function MatchDetailModal({ match, onClose }: { match: MatchRecord; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 animate-fade-in" onClick={onClose}>
      <div className="card rounded-2xl p-6 max-w-lg w-full animate-scale-in max-h-[90vh] overflow-y-auto scrollbar-thin" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Trophy size={18} className="text-[rgb(var(--chart-3))]" />
              <h3 className="text-lg font-bold text-[rgb(var(--text))]">vs {match.opponent}</h3>
            </div>
            <p className="text-sm text-muted">{new Date(match.date).toLocaleDateString('en', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</p>
          </div>
          <button onClick={onClose} className="text-muted hover:text-[rgb(var(--text))] text-xl">✕</button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <DetailItem label="Match Duration" value={`${match.duration} min`} />
          <DetailItem label="Minutes Played" value={`${match.minutesPlayed} min`} />
          <DetailItem label="Total Distance" value={`${match.totalDistance} km`} />
          <DetailItem label="Relative Distance" value={`${match.relativeDistance} m/min`} />
          <DetailItem label="High-Speed Running" value={`${match.highSpeedRunning} m`} />
          <DetailItem label="Sprint Distance" value={`${match.sprintDistance} m`} />
          <DetailItem label="Accelerations" value={match.accelerations.toString()} />
          <DetailItem label="Decelerations" value={match.decelerations.toString()} />
          <DetailItem label="High-Intensity Efforts" value={match.highIntensityEfforts.toString()} />
          <DetailItem label="Avg Heart Rate" value={`${match.avgHeartRate} bpm`} />
          <DetailItem label="Max Heart Rate" value={`${match.maxHeartRate} bpm`} />
          <DetailItem label="Session RPE" value={`${match.sessionRPE}/10`} />
          {match.contacts !== undefined && <DetailItem label="Contacts" value={match.contacts.toString()} />}
          {match.contactLoad !== undefined && <DetailItem label="Contact Load" value={`${match.contactLoad} AU`} />}
        </div>
      </div>
    </div>
  );
}

function DetailItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="surface-2 rounded-lg p-3">
      <div className="text-xs text-muted">{label}</div>
      <div className="text-sm font-semibold text-[rgb(var(--text))] mt-0.5">{value}</div>
    </div>
  );
}

function MetricBox({ label, value, unit, icon }: { label: string; value: number; unit: string; icon: React.ReactNode }) {
  return (
    <div className="surface-2 rounded-xl p-3">
      <div className="flex items-center gap-1.5 mb-1">
        <span className="text-subtle">{icon}</span>
        <span className="text-xs text-muted">{label}</span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="text-lg font-bold text-[rgb(var(--text))]">{value.toFixed(value < 10 ? 1 : 0)}</span>
        {unit && <span className="text-xs text-muted">{unit}</span>}
      </div>
    </div>
  );
}

function AthleteDropdown({ selectedId, onSelect }: { selectedId: string; onSelect: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === selectedId) || athletes[0];
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 surface rounded-xl px-3 py-2 hover:border-[rgb(var(--primary))] transition-colors"
      >
        <Avatar initials={athlete.initials} color={athlete.avatarColor} size={32} />
        <span className="text-sm font-medium text-[rgb(var(--text))]">{athlete.name}</span>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-2 z-20 w-64 card rounded-xl shadow-lg overflow-hidden animate-scale-in">
            {athletes.map((a) => (
              <button
                key={a.id}
                onClick={() => { onSelect(a.id); setOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-[rgb(var(--surface-2))] transition-colors text-left ${a.id === selectedId ? 'bg-[rgb(var(--surface-2))]' : ''}`}
              >
                <Avatar initials={a.initials} color={a.avatarColor} size={36} />
                <div>
                  <div className="text-sm font-medium text-[rgb(var(--text))]">{a.name}</div>
                  <div className="text-xs text-muted">{a.position}</div>
                </div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
