import { useState } from 'react';
import { getAllAthletes, getAllInsightsList, getAllInsights } from '@/lib/extendedData';
import { Avatar, SectionTitle, SportBadge } from '@/components/ui';
import { Sparkles, AlertTriangle, TrendingUp, TrendingDown, Target, Zap, Brain, Lightbulb } from 'lucide-react';
import type { AIInsight } from '@/lib/types';

const typeIcons: Record<string, React.ReactNode> = {
  anomaly: <AlertTriangle size={18} />,
  trend: <TrendingUp size={18} />,
  gap: <Target size={18} />,
  optimization: <Lightbulb size={18} />,
  pattern: <Brain size={18} />,
};

const severityStyles: Record<string, { bg: string; border: string; iconColor: string; label: string }> = {
  info: { bg: 'bg-blue-50 dark:bg-blue-900/20', border: 'border-blue-200 dark:border-blue-800', iconColor: 'text-blue-500', label: 'Info' },
  warning: { bg: 'bg-amber-50 dark:bg-amber-900/20', border: 'border-amber-200 dark:border-amber-800', iconColor: 'text-amber-500', label: 'Warning' },
  critical: { bg: 'bg-red-50 dark:bg-red-900/20', border: 'border-red-200 dark:border-red-800', iconColor: 'text-red-500', label: 'Critical' },
  positive: { bg: 'bg-emerald-50 dark:bg-emerald-900/20', border: 'border-emerald-200 dark:border-emerald-800', iconColor: 'text-emerald-500', label: 'Positive' },
};

export function AIInsights({ athleteId, onSelectAthlete }: { athleteId: string; onSelectAthlete: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === athleteId) || athletes[0];
  const [filter, setFilter] = useState<'all' | 'anomaly' | 'trend' | 'gap' | 'optimization' | 'pattern'>('all');

  const allInsights = getAllInsights(athlete.id);
  const filtered = filter === 'all' ? allInsights : allInsights.filter((i) => i.type === filter);

  const counts = {
    anomaly: allInsights.filter((i) => i.type === 'anomaly').length,
    trend: allInsights.filter((i) => i.type === 'trend').length,
    gap: allInsights.filter((i) => i.type === 'gap').length,
    optimization: allInsights.filter((i) => i.type === 'optimization').length,
    pattern: allInsights.filter((i) => i.type === 'pattern').length,
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[rgb(var(--text))]">AI Insights</h1>
          <p className="text-sm text-muted mt-1">Analytical decision-support — the coach remains the decision-maker</p>
        </div>
        <AthleteDropdown selectedId={athleteId} onSelect={onSelectAthlete} />
      </div>

      {/* AI principle banner */}
      <div className="card p-5 bg-gradient-to-r from-[rgb(var(--primary-light))] to-transparent">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-[rgb(var(--primary))] flex items-center justify-center shrink-0">
            <Sparkles size={20} className="text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-[rgb(var(--text))]">Finding → Evidence → Interpretation → Suggested Action</h3>
            <p className="text-sm text-muted mt-1">
              Every recommendation shows its reasoning. The AI identifies patterns and anomalies — the coach decides what to act on.
              Load management flags are not injury predictions.
            </p>
          </div>
        </div>
      </div>

      {/* Athlete header */}
      <div className="card p-5 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-3">
          <Avatar initials={athlete.initials} color={athlete.avatarColor} size={48} />
          <div>
            <h3 className="font-bold text-[rgb(var(--text))]">{athlete.name}</h3>
            <div className="flex items-center gap-2 mt-1">
              <SportBadge sport={athlete.sport} />
              <span className="text-sm text-muted">{athlete.position}</span>
            </div>
          </div>
        </div>
        <div className="ml-auto text-right">
          <div className="text-xs text-muted uppercase tracking-wider">Total Findings</div>
          <div className="text-2xl font-bold text-[rgb(var(--text))]">{allInsights.length}</div>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex flex-wrap gap-2">
        <FilterButton label="All" count={allInsights.length} active={filter === 'all'} onClick={() => setFilter('all')} />
        <FilterButton label="Anomalies" count={counts.anomaly} active={filter === 'anomaly'} onClick={() => setFilter('anomaly')} icon={<AlertTriangle size={14} />} />
        <FilterButton label="Trends" count={counts.trend} active={filter === 'trend'} onClick={() => setFilter('trend')} icon={<TrendingUp size={14} />} />
        <FilterButton label="Gaps" count={counts.gap} active={filter === 'gap'} onClick={() => setFilter('gap')} icon={<Target size={14} />} />
        <FilterButton label="Optimization" count={counts.optimization} active={filter === 'optimization'} onClick={() => setFilter('optimization')} icon={<Lightbulb size={14} />} />
      </div>

      {/* Insight cards */}
      <div className="space-y-4">
        {filtered.length > 0 ? (
          filtered.map((insight) => <InsightCard key={insight.id} insight={insight} />)
        ) : (
          <div className="card p-12 text-center">
            <Sparkles size={48} className="mx-auto text-subtle mb-4" />
            <p className="text-muted">No insights in this category for this athlete.</p>
          </div>
        )}
      </div>

      {/* All athletes overview */}
      <div className="card p-5">
        <SectionTitle title="All Athletes Overview" subtitle="Cross-athlete findings" />
        <div className="space-y-3">
          {getAllInsightsList()
            .filter((i) => i.athleteId !== athlete.id)
            .slice(0, 4)
            .map((insight) => {
              const a = athletes.find((at) => at.id === insight.athleteId);
              if (!a) return null;
              return (
                <div key={insight.id} className="flex items-start gap-3 surface-2 rounded-xl p-4">
                  <Avatar initials={a.initials} color={a.avatarColor} size={36} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-[rgb(var(--text))]">{a.name}</span>
                      <span className="text-xs text-subtle">·</span>
                      <span className="text-xs text-muted">{insight.metric}</span>
                    </div>
                    <p className="text-sm text-muted mt-1">{insight.finding}</p>
                  </div>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
}

function InsightCard({ insight }: { insight: AIInsight }) {
  const s = severityStyles[insight.severity];

  return (
    <div className={`card p-5 border-l-4 ${s.bg} ${s.border}`} style={{ borderLeftColor: insight.severity === 'critical' ? 'rgb(220,38,38)' : insight.severity === 'warning' ? 'rgb(234,179,8)' : insight.severity === 'positive' ? 'rgb(22,163,74)' : 'rgb(37,99,235)' }}>
      <div className="flex items-start gap-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${s.bg} ${s.iconColor}`}>
          {typeIcons[insight.type]}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-muted">{insight.type}</span>
            <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${s.bg} ${s.iconColor}`}>{s.label}</span>
            <span className="text-xs text-subtle">·</span>
            <span className="text-xs text-muted">{insight.metric}</span>
          </div>

          <h3 className="font-semibold text-[rgb(var(--text))] mb-3">{insight.finding}</h3>

          <div className="space-y-2.5">
            <div>
              <span className="text-xs font-semibold text-[rgb(var(--text))]">Evidence: </span>
              <span className="text-sm text-muted">{insight.evidence}</span>
            </div>
            <div>
              <span className="text-xs font-semibold text-[rgb(var(--text))]">Interpretation: </span>
              <span className="text-sm text-muted">{insight.interpretation}</span>
            </div>
            <div className="pt-2 border-t border-[rgb(var(--border))]">
              <div className="flex items-start gap-1.5">
                <Lightbulb size={14} className="text-[rgb(var(--primary))] mt-0.5 shrink-0" />
                <div>
                  <span className="text-xs font-semibold text-[rgb(var(--text))]">Suggested action: </span>
                  <span className="text-sm text-muted">{insight.action}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FilterButton({ label, count, active, onClick, icon }: { label: string; count: number; active: boolean; onClick: () => void; icon?: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
        active ? 'bg-[rgb(var(--primary))] text-white' : 'surface-2 text-muted hover:text-[rgb(var(--text))]'
      }`}
    >
      {icon}
      {label}
      <span className={`px-1.5 py-0.5 rounded-full text-xs ${active ? 'bg-white/20' : 'bg-[rgb(var(--border))]'}`}>{count}</span>
    </button>
  );
}

function AthleteDropdown({ selectedId, onSelect }: { selectedId: string; onSelect: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === selectedId) || athletes[0];
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 surface rounded-xl px-3 py-2 hover:border-[rgb(var(--primary))] transition-colors"
      >
        <Avatar initials={athlete.initials} color={athlete.avatarColor} size={32} />
        <span className="text-sm font-medium text-[rgb(var(--text))]">{athlete.name}</span>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-2 z-20 w-64 card rounded-xl shadow-lg overflow-hidden animate-scale-in">
            {athletes.map((a) => (
              <button
                key={a.id}
                onClick={() => { onSelect(a.id); setOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-[rgb(var(--surface-2))] transition-colors text-left ${a.id === selectedId ? 'bg-[rgb(var(--surface-2))]' : ''}`}
              >
                <Avatar initials={a.initials} color={a.avatarColor} size={36} />
                <div>
                  <div className="text-sm font-medium text-[rgb(var(--text))]">{a.name}</div>
                  <div className="text-xs text-muted">{a.position}</div>
                </div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
