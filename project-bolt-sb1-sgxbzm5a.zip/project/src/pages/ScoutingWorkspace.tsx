import { useState } from 'react';
import {
  getScoutingProjects, createScoutingProject, activateProject, pauseProject, completeProject,
  getActiveTargetProfile, getTargetProfiles, createTargetProfile,
  discoverCandidates, getAthleteScoutingSummary, matchAthleteToProfile,
  getObservationsForAthlete, createObservation, deleteObservation,
  getReportsForAthlete, createReport, draftScoutingReport, approveReport,
  addToShortlist, removeFromShortlist, getShortlistsForProject,
  addToWatchlist, removeFromWatchlist, getWatchlist,
  getPipelineForProject, advancePipeline, STAGE_ORDER, getNextStage,
  getScoutingDecisionsForAthlete, recordScoutingDecision,
  generateScoutingSummary,
  getEvidenceForAthlete, createEvidence, deleteEvidence, getEvidenceConfidenceSummary,
  getTasksForProject, createTask, updateTaskStatus, deleteTask,
  getAuditTrail, getAuditForProject,
  detectDisagreements,
  getRecruitmentDashboard,
  isYouthAthlete, getYouthSafeguardWarnings,
  getFairnessWarnings,
  type CandidateFilter,
} from '@/lib/scoutingEngine';
import { getAllAthletes, getAthleteById, getAllCapacityTests, getAllTrainingSessions, getAllMatchRecords, computeReadiness, computeDataQuality } from '@/lib/extendedData';
import { generateAthleteProfile } from '@/lib/intelligenceEngine';
import { SPORT_LIST, getSportPositions, getSportAttributes, isEventBasedSport, getSportEvents, getSportStrokes, getSportFormats } from '@/lib/sportConfig';
import { Avatar, SportBadge, SectionTitle, ReadinessBadge, DataQualityBadge } from '@/components/ui';
import { RadarChart } from '@/components/charts/Charts';
import {
  Search, Plus, Flag, Target, FileText, Eye, Star, CheckCircle2, XCircle,
  Clock, Sparkles, ClipboardList, Filter, Users, TrendingUp, AlertTriangle,
  ChevronRight, Bookmark, ArrowRight, ShieldCheck, RefreshCw, LayoutDashboard,
  ListTodo, ScrollText, AlertCircle, Link2,
} from 'lucide-react';
import type {
  ScoutingProject, TargetProfile, ProfileCriterion, ScoutObservationCategory,
  ScoutRecommendation, RecruitmentStage, AthleteScoutingSummary,
  EvidenceSource, EvidenceConfidence, ScoutTaskStatus, ScoutTaskPriority,
} from '@/lib/types';

type Tab = 'dashboard' | 'projects' | 'candidates' | 'compare' | 'pipeline' | 'tasks' | 'audit';

export function ScoutingWorkspace() {
  const [tab, setTab] = useState<Tab>('dashboard');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [selectedAthleteId, setSelectedAthleteId] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const refresh = () => setRefreshKey((k) => k + 1);

  const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={16} /> },
    { key: 'projects', label: 'Projects', icon: <ClipboardList size={16} /> },
    { key: 'candidates', label: 'Candidates', icon: <Users size={16} /> },
    { key: 'compare', label: 'Compare', icon: <TrendingUp size={16} /> },
    { key: 'pipeline', label: 'Pipeline', icon: <Flag size={16} /> },
    { key: 'tasks', label: 'Tasks', icon: <ListTodo size={16} /> },
    { key: 'audit', label: 'Audit', icon: <ScrollText size={16} /> },
  ];

  return (
    <div className="space-y-6 animate-fade-in" key={refreshKey}>
      <div>
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Scouting Workspace</h1>
        <p className="text-sm text-muted mt-1">Talent identification, recruitment and prospect management</p>
      </div>

      <div className="flex items-center gap-2 text-xs text-muted surface rounded-xl p-3">
        <ShieldCheck size={14} className="text-emerald-500" />
        <span><strong>Decision Support:</strong> AthleteIQ provides evidence and analysis. The scout, coach or authorised professional makes all final decisions.</span>
      </div>

      <div className="flex flex-wrap gap-1 surface rounded-xl p-1.5">
        {tabs.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === t.key ? 'bg-[rgb(var(--primary))] text-white shadow-sm' : 'text-muted hover:bg-[rgb(var(--surface-2))] hover:text-[rgb(var(--text))]'
            }`}>
            {t.icon}<span className="hidden sm:inline">{t.label}</span>
          </button>
        ))}
      </div>

      {tab === 'dashboard' && <DashboardTab onSelectProject={setSelectedProjectId} onNavigate={setTab} />}
      {tab === 'projects' && <ProjectsTab selectedProjectId={selectedProjectId} onSelectProject={setSelectedProjectId} onRefresh={refresh} />}
      {tab === 'candidates' && <CandidatesTab selectedProjectId={selectedProjectId} selectedAthleteId={selectedAthleteId} onSelectAthlete={setSelectedAthleteId} onRefresh={refresh} />}
      {tab === 'compare' && <CompareTab projectId={selectedProjectId} />}
      {tab === 'pipeline' && <PipelineTab projectId={selectedProjectId} onRefresh={refresh} />}
      {tab === 'tasks' && <TasksTab projectId={selectedProjectId} onRefresh={refresh} />}
      {tab === 'audit' && <AuditTab projectId={selectedProjectId} />}
    </div>
  );
}

// ===== PROJECTS TAB =====
function ProjectsTab({ selectedProjectId, onSelectProject, onRefresh }: {
  selectedProjectId: string | null;
  onSelectProject: (id: string) => void;
  onRefresh: () => void;
}) {
  const projects = getScoutingProjects();
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [sport, setSport] = useState('football');
  const [position, setPosition] = useState('');
  const [ageMin, setAgeMin] = useState('');
  const [ageMax, setAgeMax] = useState('');
  const [description, setDescription] = useState('');

  const handleCreate = () => {
    if (!name) return;
    const project = createScoutingProject({
      name, sport, position: position || undefined,
      ageMin: ageMin ? parseInt(ageMin) : undefined,
      ageMax: ageMax ? parseInt(ageMax) : undefined,
      description: description || undefined,
    });
    onSelectProject(project.id);
    setName(''); setPosition(''); setAgeMin(''); setAgeMax(''); setDescription('');
    setShowCreate(false);
    onRefresh();
  };

  const statusColors: Record<string, string> = {
    DRAFT: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
    ACTIVE: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    PAUSED: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
    COMPLETED: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
    ARCHIVED: 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400',
  };

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <SectionTitle title="Scouting Projects" subtitle="Manage recruitment and scouting projects" action={
          <button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1">
            <Plus size={14} /> New Project
          </button>
        } />

        {showCreate && (
          <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Project name" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            <div className="grid grid-cols-2 gap-3">
              <select value={sport} onChange={(e) => setSport(e.target.value)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none">
                {SPORT_LIST.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
              </select>
              {isEventBasedSport(sport) ? (
                <select value={position} onChange={(e) => setPosition(e.target.value)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none">
                  <option value="">Select event</option>
                  {getSportEvents(sport).map((e) => <option key={e} value={e}>{e}</option>)}
                </select>
              ) : (
                <select value={position} onChange={(e) => setPosition(e.target.value)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none">
                  <option value="">Select position</option>
                  {getSportPositions(sport).map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              )}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <input value={ageMin} onChange={(e) => setAgeMin(e.target.value)} placeholder="Min age" type="number" className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
              <input value={ageMax} onChange={(e) => setAgeMax(e.target.value)} placeholder="Max age" type="number" className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            </div>
            <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Description" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none min-h-[60px]" />
            <div className="flex gap-2">
              <button onClick={handleCreate} className="btn-primary text-xs">Create as Draft</button>
              <button onClick={() => setShowCreate(false)} className="btn-ghost text-xs">Cancel</button>
            </div>
          </div>
        )}

        {projects.length === 0 ? (
          <p className="text-sm text-muted py-4">No scouting projects yet.</p>
        ) : (
          <div className="space-y-3">
            {projects.map((p) => {
              const profiles = getTargetProfiles(p.id);
              const shortlists = getShortlistsForProject(p.id);
              return (
                <div key={p.id} className={`surface-2 rounded-xl p-4 cursor-pointer transition-all ${selectedProjectId === p.id ? 'border-[rgb(var(--primary))]' : ''}`} onClick={() => onSelectProject(p.id)}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-[rgb(var(--text))]">{p.name}</span>
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${statusColors[p.status]}`}>{p.status}</span>
                  </div>
                  <div className="text-xs text-muted mb-2">
                    {p.sport} · {p.position ?? 'Any position'} · Ages {p.ageMin ?? '?'}–{p.ageMax ?? '?'}
                    {p.competitionLevel && ` · ${p.competitionLevel}`}
                  </div>
                  {p.description && <p className="text-xs text-muted italic mb-2">{p.description}</p>}
                  <div className="flex items-center gap-3 text-xs text-muted">
                    <span>{profiles.length} profile version(s)</span>
                    <span>{shortlists.length} shortlisted</span>
                  </div>
                  {selectedProjectId === p.id && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {p.status === 'DRAFT' && <button onClick={(e) => { e.stopPropagation(); activateProject(p.id); onRefresh(); }} className="btn-primary text-xs">Activate</button>}
                      {p.status === 'ACTIVE' && <button onClick={(e) => { e.stopPropagation(); pauseProject(p.id); onRefresh(); }} className="btn-ghost text-xs">Pause</button>}
                      {p.status === 'ACTIVE' && <button onClick={(e) => { e.stopPropagation(); completeProject(p.id); onRefresh(); }} className="btn-ghost text-xs">Complete</button>}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {selectedProjectId && <TargetProfileSection projectId={selectedProjectId} onRefresh={onRefresh} />}
    </div>
  );
}

function TargetProfileSection({ projectId, onRefresh }: { projectId: string; onRefresh: () => void }) {
  const profiles = getTargetProfiles(projectId);
  const activeProfile = getActiveTargetProfile(projectId);
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [criteria, setCriteria] = useState<ProfileCriterion[]>([]);
  const [metricName, setMetricName] = useState('');
  const [metricValue, setMetricValue] = useState('');
  const [metricUnit, setMetricUnit] = useState('');

  const addCriterion = () => {
    if (!metricName) return;
    setCriteria([...criteria, { metric: metricName, requirement: 'minimum', value: parseFloat(metricValue), unit: metricUnit }]);
    setMetricName(''); setMetricValue(''); setMetricUnit('');
  };

  const handleCreate = () => {
    if (!name || criteria.length === 0) return;
    const weights: Record<string, number> = {};
    const perWeight = Math.floor(100 / criteria.length);
    criteria.forEach((c, i) => { weights[c.metric] = i === 0 ? 100 - perWeight * (criteria.length - 1) : perWeight; });
    createTargetProfile({ projectId, name, criteria, weights });
    setName(''); setCriteria([]);
    setShowCreate(false);
    onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Target Profiles" subtitle="Versioned recruitment criteria profiles" action={
        <button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1">
          <Plus size={14} /> New Profile Version
        </button>
      } />

      {showCreate && (
        <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Profile name (e.g. U16 Midfielder v2)" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
          {criteria.length > 0 && (
            <div className="space-y-1">
              {criteria.map((c, i) => (
                <div key={i} className="flex items-center gap-2 text-xs surface rounded-lg p-2">
                  <span className="font-medium text-[rgb(var(--text))]">{c.metric}</span>
                  <span className="text-muted">min {c.value} {c.unit}</span>
                </div>
              ))}
            </div>
          )}
          <div className="flex flex-wrap gap-2">
            <input value={metricName} onChange={(e) => setMetricName(e.target.value)} placeholder="Metric" className="flex-1 surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            <input value={metricValue} onChange={(e) => setMetricValue(e.target.value)} placeholder="Value" type="number" className="w-24 surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            <input value={metricUnit} onChange={(e) => setMetricUnit(e.target.value)} placeholder="Unit" className="w-20 surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            <button onClick={addCriterion} className="btn-ghost text-xs">Add Criterion</button>
          </div>
          <div className="flex gap-2">
            <button onClick={handleCreate} className="btn-primary text-xs">Create Profile</button>
            <button onClick={() => setShowCreate(false)} className="btn-ghost text-xs">Cancel</button>
          </div>
        </div>
      )}

      {profiles.length === 0 ? (
        <p className="text-sm text-muted py-4">No target profiles yet. Create one to define recruitment criteria.</p>
      ) : (
        <div className="space-y-3">
          {profiles.map((p) => (
            <div key={p.id} className={`surface-2 rounded-xl p-4 ${p.isActive ? 'border-l-4 border-l-emerald-500' : 'opacity-60'}`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-bold text-[rgb(var(--text))]">{p.name}</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted">{p.version}</span>
                  {p.isActive && <span className="text-xs font-semibold text-emerald-500">ACTIVE</span>}
                </div>
              </div>
              <div className="space-y-1">
                {p.criteria.map((c, i) => (
                  <div key={i} className="flex items-center justify-between surface rounded-lg p-2 text-xs">
                    <span className="text-[rgb(var(--text))]">{c.metric}</span>
                    <span className="text-muted">min {c.value} {c.unit}</span>
                  </div>
                ))}
              </div>
              {Object.keys(p.weights).length > 0 && (
                <div className="mt-2 flex flex-wrap gap-2">
                  {Object.entries(p.weights).map(([metric, weight]) => (
                    <span key={metric} className="text-xs surface rounded-full px-2 py-0.5 text-muted">{metric}: {weight}%</span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ===== CANDIDATES TAB =====
function CandidatesTab({ selectedProjectId, selectedAthleteId, onSelectAthlete, onRefresh }: {
  selectedProjectId: string | null;
  selectedAthleteId: string | null;
  onSelectAthlete: (id: string | null) => void;
  onRefresh: () => void;
}) {
  const [filter, setFilter] = useState<CandidateFilter>({});
  const [showFilters, setShowFilters] = useState(false);

  const candidates = discoverCandidates({ ...filter, projectId: selectedProjectId ?? undefined });

  if (selectedAthleteId) {
    return <AthleteScoutingProfile athleteId={selectedAthleteId} projectId={selectedProjectId} onBack={() => onSelectAthlete(null)} onRefresh={onRefresh} />;
  }

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <SectionTitle title="Candidate Discovery" subtitle="Search and filter athletes for scouting" action={
          <button onClick={() => setShowFilters(!showFilters)} className="btn-ghost text-xs flex items-center gap-1">
            <Filter size={14} /> Filters
          </button>
        } />

        {showFilters && (
          <div className="surface-2 rounded-xl p-4 mb-4 grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <label className="text-xs text-muted block mb-1">Sport</label>
              <select value={filter.sport ?? ''} onChange={(e) => setFilter({ ...filter, sport: e.target.value || undefined })} className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
                <option value="">All</option>
                <option value="football">Football</option>
                <option value="rugby">Rugby</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-muted block mb-1">Min Age</label>
              <input type="number" value={filter.ageMin ?? ''} onChange={(e) => setFilter({ ...filter, ageMin: e.target.value ? parseInt(e.target.value) : undefined })} className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
            </div>
            <div>
              <label className="text-xs text-muted block mb-1">Max Age</label>
              <input type="number" value={filter.ageMax ?? ''} onChange={(e) => setFilter({ ...filter, ageMax: e.target.value ? parseInt(e.target.value) : undefined })} className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
            </div>
            <div className="flex items-end gap-2">
              <label className="flex items-center gap-1.5 text-xs text-muted">
                <input type="checkbox" checked={filter.shortlistedOnly ?? false} onChange={(e) => setFilter({ ...filter, shortlistedOnly: e.target.checked || undefined })} className="accent-[rgb(var(--primary))]" />
                Shortlisted only
              </label>
            </div>
            <div className="flex items-end">
              <label className="flex items-center gap-1.5 text-xs text-muted">
                <input type="checkbox" checked={filter.watchlistOnly ?? false} onChange={(e) => setFilter({ ...filter, watchlistOnly: e.target.checked || undefined })} className="accent-[rgb(var(--primary))]" />
                Watchlist only
              </label>
            </div>
          </div>
        )}

        {candidates.length === 0 ? (
          <p className="text-sm text-muted py-4">No candidates match the current filters.</p>
        ) : (
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[rgb(var(--border))]">
                  <th className="text-left py-3 px-3 font-medium text-muted">Athlete</th>
                  <th className="text-center py-3 px-3 font-medium text-muted">Level</th>
                  <th className="text-center py-3 px-3 font-medium text-muted hidden sm:table-cell">Trend</th>
                  <th className="text-center py-3 px-3 font-medium text-muted hidden md:table-cell">Coverage</th>
                  <th className="text-center py-3 px-3 font-medium text-muted hidden md:table-cell">Obs</th>
                  <th className="text-center py-3 px-3 font-medium text-muted hidden lg:table-cell">Match</th>
                  <th className="text-center py-3 px-3 font-medium text-muted">Status</th>
                </tr>
              </thead>
              <tbody>
                {candidates.map((c) => (
                  <tr key={c.athlete.id} className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))] transition-colors cursor-pointer" onClick={() => onSelectAthlete(c.athlete.id)}>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <Avatar initials={c.athlete.initials} color={c.athlete.avatarColor} size={32} />
                        <div>
                          <div className="font-medium text-[rgb(var(--text))]">{c.athlete.name}</div>
                          <div className="text-xs text-muted">{c.athlete.position} · {c.athlete.age}y</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-center text-[rgb(var(--text))]">{c.currentLevel}</td>
                    <td className="py-3 px-3 text-center hidden sm:table-cell text-[rgb(var(--text))]">{c.developmentTrend}</td>
                    <td className="py-3 px-3 text-center hidden md:table-cell">
                      <span className={`text-xs font-semibold ${c.assessmentCoverage === 'high' ? 'text-emerald-500' : c.assessmentCoverage === 'medium' ? 'text-amber-500' : 'text-red-500'}`}>{c.assessmentCoverage}</span>
                    </td>
                    <td className="py-3 px-3 text-center hidden md:table-cell text-[rgb(var(--text))]">{c.observationCount}</td>
                    <td className="py-3 px-3 text-center hidden lg:table-cell">
                      {c.profileMatchScore !== undefined ? (
                        <span className={`text-xs font-semibold ${c.profileMatchScore >= 70 ? 'text-emerald-500' : c.profileMatchScore >= 50 ? 'text-amber-500' : 'text-red-500'}`}>{c.profileMatchScore}%</span>
                      ) : <span className="text-xs text-muted">—</span>}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {c.shortlistStatus === 'SHORTLISTED' && <span className="text-xs bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 px-2 py-0.5 rounded-full">Shortlisted</span>}
                        {c.watchlistStatus === 'WATCHING' && <span className="text-xs bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 px-2 py-0.5 rounded-full">Watching</span>}
                        {c.pipelineStage && <span className="text-xs text-muted">{c.pipelineStage}</span>}
                        {!c.shortlistStatus && !c.watchlistStatus && !c.pipelineStage && <span className="text-xs text-muted">—</span>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// ===== ATHLETE SCOUTING PROFILE =====
function AthleteScoutingProfile({ athleteId, projectId, onBack, onRefresh }: {
  athleteId: string;
  projectId: string | null;
  onBack: () => void;
  onRefresh: () => void;
}) {
  const [subTab, setSubTab] = useState<'overview' | 'observations' | 'report' | 'match'>('overview');
  const athlete = getAthleteById(athleteId)!;
  const summary = getAthleteScoutingSummary(athleteId, projectId ?? undefined);
  const sessions = getAllTrainingSessions(athleteId);
  const matches = getAllMatchRecords(athleteId);
  const tests = getAllCapacityTests(athleteId);
  const profile = generateAthleteProfile({ athlete, sessions, matches, tests, interventions: [] });
  const readiness = computeReadiness(athleteId);
  const dataQuality = computeDataQuality(athleteId);

  const subTabs = [
    { key: 'overview' as const, label: 'Overview', icon: <Eye size={16} /> },
    { key: 'observations' as const, label: 'Observations', icon: <ClipboardList size={16} /> },
    { key: 'match' as const, label: 'Profile Match', icon: <Target size={16} /> },
    { key: 'report' as const, label: 'Report', icon: <FileText size={16} /> },
  ];

  return (
    <div className="space-y-4">
      <button onClick={onBack} className="btn-ghost text-xs flex items-center gap-1">
        <ChevronRight size={14} className="rotate-180" /> Back to Candidates
      </button>

      <div className="card p-6">
        <div className="flex flex-col lg:flex-row lg:items-center gap-4">
          <Avatar initials={athlete.initials} color={athlete.avatarColor} size={64} />
          <div className="flex-1">
            <h2 className="text-2xl font-bold text-[rgb(var(--text))]">{athlete.name}</h2>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <SportBadge sport={athlete.sport} />
              <span className="text-sm text-muted">{athlete.position}</span>
              <span className="text-sm text-subtle">·</span>
              <span className="text-sm text-muted">{athlete.age} years</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs text-muted uppercase">Current Level</div>
              <div className="text-lg font-bold text-[rgb(var(--text))]">{summary.currentLevel}</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted uppercase">Trend</div>
              <div className="text-lg font-bold text-[rgb(var(--text))]">{summary.developmentTrend}</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted uppercase">Coverage</div>
              <div className="text-lg font-bold text-[rgb(var(--text))]">{summary.assessmentCoverage}</div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-1 surface rounded-xl p-1.5">
        {subTabs.map((t) => (
          <button key={t.key} onClick={() => setSubTab(t.key)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              subTab === t.key ? 'bg-[rgb(var(--primary))] text-white shadow-sm' : 'text-muted hover:bg-[rgb(var(--surface-2))] hover:text-[rgb(var(--text))]'
            }`}>
            {t.icon}<span className="hidden sm:inline">{t.label}</span>
          </button>
        ))}
      </div>

      {subTab === 'overview' && <ScoutingOverview athleteId={athleteId} summary={summary} profile={profile} tests={tests} />}
      {subTab === 'observations' && <ObservationsSection athleteId={athleteId} projectId={projectId} onRefresh={onRefresh} />}
      {subTab === 'match' && <ProfileMatchSection athleteId={athleteId} projectId={projectId} summary={summary} />}
      {subTab === 'report' && <ReportSection athleteId={athleteId} projectId={projectId} onRefresh={onRefresh} />}
    </div>
  );
}

function ScoutingOverview({ athleteId, summary, profile, tests }: {
  athleteId: string;
  summary: AthleteScoutingSummary;
  profile: ReturnType<typeof generateAthleteProfile>;
  tests: ReturnType<typeof getAllCapacityTests>;
}) {
  const radarData = tests.slice(0, 6).map((t) => ({
    label: t.name.length > 12 ? t.name.split(' ')[0] : t.name,
    value: t.higherIsBetter ? (t.latest / t.benchmark) * 100 : (t.benchmark / t.latest) * 100,
    max: 100,
  }));

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <SectionTitle title="Capacity Profile" subtitle="Validated performance vs benchmark" />
          <RadarChart data={radarData} size={280} />
        </div>
        <div className="card p-5">
          <SectionTitle title="Current Ability vs Development Trajectory" subtitle="Evidence-based assessment" />
          <div className="space-y-3">
            <div className="surface-2 rounded-xl p-3">
              <div className="text-xs font-semibold text-emerald-500 uppercase mb-1">Current Performance (Validated)</div>
              <p className="text-sm text-[rgb(var(--text))]">Overall Level: {profile.overallLevel} · Confidence: {profile.overallConfidence}</p>
            </div>
            <div className="surface-2 rounded-xl p-3">
              <div className="text-xs font-semibold text-blue-500 uppercase mb-1">Development Trajectory</div>
              <p className="text-sm text-[rgb(var(--text))]">{summary.developmentTrend}</p>
              {profile.trends.slice(0, 3).map((t, i) => (
                <p key={i} className="text-xs text-muted mt-1">{t.metric}: {t.trend}</p>
              ))}
            </div>
            <div className="surface-2 rounded-xl p-3">
              <div className="text-xs font-semibold text-amber-500 uppercase mb-1">Scout Observations</div>
              <p className="text-sm text-[rgb(var(--text))]">{summary.observationCount} observation(s) recorded</p>
              {summary.scoutRating && <p className="text-xs text-muted mt-1">Average rating: {summary.scoutRating}/10</p>}
            </div>
          </div>
        </div>
      </div>
      <div className="card p-5">
        <SectionTitle title="Strengths & Development Areas" subtitle="From Stage 6 validated analysis" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <div className="text-xs font-semibold text-emerald-500 uppercase mb-2">Strengths</div>
            {profile.strengths.slice(0, 5).map((s, i) => (
              <div key={i} className="surface-2 rounded-lg p-2.5 mb-1.5 flex items-center justify-between">
                <span className="text-sm text-[rgb(var(--text))]">{s.metric}</span>
                <span className="text-xs font-semibold text-emerald-500">{s.level}</span>
              </div>
            ))}
          </div>
          <div>
            <div className="text-xs font-semibold text-amber-500 uppercase mb-2">Development Areas</div>
            {profile.developmentAreas.slice(0, 5).map((d, i) => (
              <div key={i} className="surface-2 rounded-lg p-2.5 mb-1.5 flex items-center justify-between">
                <span className="text-sm text-[rgb(var(--text))]">{d.metric}</span>
                <span className="text-xs font-semibold text-amber-500">{d.level}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function ObservationsSection({ athleteId, projectId, onRefresh }: { athleteId: string; projectId: string | null; onRefresh: () => void }) {
  const observations = getObservationsForAthlete(athleteId);
  const [category, setCategory] = useState<ScoutObservationCategory>('technical');
  const [content, setContent] = useState('');
  const [rating, setRating] = useState('');
  const [context, setContext] = useState('');
  const [obsDate, setObsDate] = useState('');

  const handleAdd = () => {
    if (!content || !obsDate) return;
    createObservation({
      athleteId, projectId: projectId ?? undefined,
      category, observation: content,
      rating: rating ? parseInt(rating) : undefined,
      context: context || undefined,
      observationDate: obsDate,
    });
    setContent(''); setRating(''); setContext(''); setObsDate('');
    onRefresh();
  };

  const catLabels: Record<ScoutObservationCategory, string> = {
    technical: 'Technical', tactical: 'Tactical', physical: 'Physical', behavioural: 'Behavioural',
  };
  const catColors: Record<ScoutObservationCategory, string> = {
    technical: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
    tactical: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300',
    physical: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    behavioural: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Scout Observations" subtitle="Structured professional observations" />

      <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
        <div className="flex flex-wrap gap-2">
          <select value={category} onChange={(e) => setCategory(e.target.value as ScoutObservationCategory)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            {(Object.keys(catLabels) as ScoutObservationCategory[]).map((c) => <option key={c} value={c}>{catLabels[c]}</option>)}
          </select>
          <input type="date" value={obsDate} onChange={(e) => setObsDate(e.target.value)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
          <input value={rating} onChange={(e) => setRating(e.target.value)} placeholder="Rating 1-10" type="number" min="1" max="10" className="w-24 surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
          <input value={context} onChange={(e) => setContext(e.target.value)} placeholder="Context (match/training)" className="flex-1 surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
        </div>
        <textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Observation..." className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none min-h-[60px]" />
        <button onClick={handleAdd} className="btn-primary text-xs flex items-center gap-1"><Plus size={14} /> Add Observation</button>
      </div>

      {observations.length === 0 ? (
        <p className="text-sm text-muted py-4">No observations recorded yet.</p>
      ) : (
        <div className="space-y-2">
          {observations.map((o) => (
            <div key={o.id} className="surface-2 rounded-xl p-3">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${catColors[o.category]}`}>{catLabels[o.category]}</span>
                  {o.rating && <span className="text-xs text-muted">Rating: {o.rating}/10</span>}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted">{o.observationDate}</span>
                  <button onClick={() => { deleteObservation(o.id); onRefresh(); }} className="text-muted hover:text-red-500"><XCircle size={14} /></button>
                </div>
              </div>
              <p className="text-sm text-[rgb(var(--text))]">{o.observation}</p>
              {o.context && <p className="text-xs text-muted mt-1">Context: {o.context}</p>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ProfileMatchSection({ athleteId, projectId, summary }: { athleteId: string; projectId: string | null; summary: AthleteScoutingSummary }) {
  if (!projectId || !summary.matchResults) {
    return (
      <div className="card p-5">
        <SectionTitle title="Profile Match" subtitle="Athlete vs target profile comparison" />
        <p className="text-sm text-muted py-4">Select a scouting project with an active target profile to see match analysis.</p>
      </div>
    );
  }

  const matchColors: Record<string, string> = {
    match: 'text-emerald-500', exceeds: 'text-emerald-500', gap: 'text-red-500', no_data: 'text-muted',
  };
  const matchLabels: Record<string, string> = {
    match: 'Match', exceeds: 'Exceeds', gap: 'Gap', no_data: 'No Data',
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Profile Match Analysis" subtitle="Athlete vs target profile — evidence-based comparison" />

      {summary.profileMatchScore !== undefined && (
        <div className="surface-2 rounded-xl p-4 mb-4 text-center">
          <div className="text-xs text-muted uppercase">Profile Match Score</div>
          <div className={`text-4xl font-bold mt-1 ${summary.profileMatchScore >= 70 ? 'text-emerald-500' : summary.profileMatchScore >= 50 ? 'text-amber-500' : 'text-red-500'}`}>{summary.profileMatchScore}%</div>
          <div className="text-xs text-muted mt-1">This is a profile match indicator, not a prediction of future success.</div>
        </div>
      )}

      <div className="space-y-2">
        {summary.matchResults.map((m, i) => (
          <div key={i} className="surface-2 rounded-xl p-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-medium text-[rgb(var(--text))]">{m.metric}</span>
              <span className={`text-xs font-semibold ${matchColors[m.match]}`}>{matchLabels[m.match]}</span>
            </div>
            <p className="text-xs text-muted">{m.evidence}</p>
            {m.weight !== undefined && m.weight > 0 && (
              <div className="text-xs text-muted mt-1">Weight: {m.weight}% · Weighted score: {m.weightedScore ?? 0}</div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-4 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3">
        <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1">AI ASSISTED ANALYSIS</div>
        <p className="text-xs text-[rgb(var(--text))]">
          {summary.matchResults.filter((m) => m.match === 'no_data').length > 0
            ? 'Some criteria have no validated data. Missing data should not be treated as a negative — it indicates further assessment is needed.'
            : 'All criteria have validated data. Profile match is based on evidence from Stage 5A assessments.'}
        </p>
      </div>
    </div>
  );
}

function ReportSection({ athleteId, projectId, onRefresh }: { athleteId: string; projectId: string | null; onRefresh: () => void }) {
  const reports = getReportsForAthlete(athleteId);
  const [showCreate, setShowCreate] = useState(false);
  const [aiDraft, setAiDraft] = useState('');
  const [recommendation, setRecommendation] = useState<ScoutRecommendation>('MONITOR');
  const [nextAction, setNextAction] = useState('');

  const handleGenerateAI = () => {
    const result = draftScoutingReport(athleteId, projectId ?? undefined);
    setAiDraft(result.draft);
  };

  const handleCreate = () => {
    createReport({
      athleteId, projectId: projectId ?? undefined,
      recommendation,
      nextAction: nextAction || undefined,
      aiGeneratedDraft: aiDraft || undefined,
      aiGenerated: aiDraft !== '',
    });
    setAiDraft(''); setNextAction(''); setRecommendation('MONITOR');
    setShowCreate(false);
    onRefresh();
  };

  const recColors: Record<string, string> = {
    RECOMMEND: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    SHORTLIST: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
    MONITOR: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
    FURTHER_ASSESSMENT: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300',
    DO_NOT_PROGRESS: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300',
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Scouting Reports" subtitle="Structured scouting reports with recommendations" action={
        <button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1">
          <Plus size={14} /> New Report
        </button>
      } />

      {showCreate && (
        <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
          <button onClick={handleGenerateAI} className="btn-ghost text-xs flex items-center gap-1">
            <Sparkles size={14} className="text-amber-500" /> Generate AI Draft
          </button>
          {aiDraft && (
            <div className="rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3">
              <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1">AI-GENERATED DRAFT — Scout must review and approve</div>
              <pre className="text-xs text-[rgb(var(--text))] whitespace-pre-wrap max-h-60 overflow-y-auto">{aiDraft}</pre>
            </div>
          )}
          <select value={recommendation} onChange={(e) => setRecommendation(e.target.value as ScoutRecommendation)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            <option value="RECOMMEND">Recommend</option>
            <option value="SHORTLIST">Shortlist</option>
            <option value="MONITOR">Monitor</option>
            <option value="FURTHER_ASSESSMENT">Further Assessment</option>
            <option value="DO_NOT_PROGRESS">Do Not Progress</option>
          </select>
          <input value={nextAction} onChange={(e) => setNextAction(e.target.value)} placeholder="Next action" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
          <div className="flex gap-2">
            <button onClick={handleCreate} className="btn-primary text-xs">Save Report</button>
            <button onClick={() => setShowCreate(false)} className="btn-ghost text-xs">Cancel</button>
          </div>
        </div>
      )}

      {reports.length === 0 ? (
        <p className="text-sm text-muted py-4">No scouting reports yet.</p>
      ) : (
        <div className="space-y-3">
          {reports.map((r) => (
            <div key={r.id} className="surface-2 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${recColors[r.recommendation]}`}>{r.recommendation}</span>
                <span className="text-xs text-muted">{new Date(r.createdAt).toLocaleDateString()}</span>
              </div>
              {r.aiGeneratedDraft && (
                <div className="rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-2 mb-2">
                  <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1">AI-GENERATED DRAFT</div>
                  <pre className="text-xs text-[rgb(var(--text))] whitespace-pre-wrap max-h-40 overflow-y-auto">{r.aiGeneratedDraft.slice(0, 300)}...</pre>
                </div>
              )}
              {r.nextAction && <p className="text-xs text-muted">Next action: {r.nextAction}</p>}
              {r.status !== 'APPROVED' && (
                <button onClick={() => { approveReport(r.id, 'scout-1'); onRefresh(); }} className="btn-ghost text-xs mt-2 flex items-center gap-1">
                  <CheckCircle2 size={14} /> Approve Report
                </button>
              )}
              {r.status === 'APPROVED' && <span className="text-xs text-emerald-500 font-semibold">Approved</span>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ===== COMPARE TAB =====
function CompareTab({ projectId }: { projectId: string | null }) {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const candidates = discoverCandidates({ projectId: projectId ?? undefined });

  const toggleAthlete = (id: string) => {
    setSelectedIds((prev) => prev.includes(id) ? prev.filter((x) => x !== id) : prev.length < 4 ? [...prev, id] : prev);
  };

  const summaries = selectedIds.map((id) => getAthleteScoutingSummary(id, projectId ?? undefined));
  const targetProfile = projectId ? getActiveTargetProfile(projectId) : null;

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <SectionTitle title="Athlete Comparison" subtitle="Compare up to 4 athletes against the target profile" />
        <p className="text-xs text-muted mb-4">Select athletes from the list to compare. Comparison is against the target profile, not just between athletes.</p>

        <div className="flex flex-wrap gap-2 mb-4">
          {candidates.map((c) => (
            <button key={c.athlete.id} onClick={() => toggleAthlete(c.athlete.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                selectedIds.includes(c.athlete.id) ? 'bg-[rgb(var(--primary))] text-white' : 'surface-2 text-muted hover:text-[rgb(var(--text))]'
              }`}>
              <Avatar initials={c.athlete.initials} color={c.athlete.avatarColor} size={20} />
              {c.athlete.name}
            </button>
          ))}
        </div>
      </div>

      {summaries.length >= 2 && (
        <div className="card p-5">
          <SectionTitle title="Comparison Matrix" subtitle={targetProfile ? `Against: ${targetProfile.name}` : 'Side-by-side comparison'} />
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[rgb(var(--border))]">
                  <th className="text-left py-3 px-3 font-medium text-muted">Criterion</th>
                  {summaries.map((s) => (
                    <th key={s.athlete.id} className="text-center py-3 px-3 font-medium text-[rgb(var(--text))]">{s.athlete.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-[rgb(var(--border))]">
                  <td className="py-2 px-3 text-muted">Current Level</td>
                  {summaries.map((s) => <td key={s.athlete.id} className="text-center py-2 px-3 text-[rgb(var(--text))]">{s.currentLevel}</td>)}
                </tr>
                <tr className="border-b border-[rgb(var(--border))]">
                  <td className="py-2 px-3 text-muted">Development Trend</td>
                  {summaries.map((s) => <td key={s.athlete.id} className="text-center py-2 px-3 text-[rgb(var(--text))]">{s.developmentTrend}</td>)}
                </tr>
                <tr className="border-b border-[rgb(var(--border))]">
                  <td className="py-2 px-3 text-muted">Assessment Coverage</td>
                  {summaries.map((s) => <td key={s.athlete.id} className="text-center py-2 px-3">
                    <span className={`text-xs font-semibold ${s.assessmentCoverage === 'high' ? 'text-emerald-500' : s.assessmentCoverage === 'medium' ? 'text-amber-500' : 'text-red-500'}`}>{s.assessmentCoverage}</span>
                  </td>)}
                </tr>
                <tr className="border-b border-[rgb(var(--border))]">
                  <td className="py-2 px-3 text-muted">Scout Observations</td>
                  {summaries.map((s) => <td key={s.athlete.id} className="text-center py-2 px-3 text-[rgb(var(--text))]">{s.observationCount}</td>)}
                </tr>
                {summaries[0]?.matchResults && summaries[0].matchResults.map((m, i) => (
                  <tr key={i} className="border-b border-[rgb(var(--border))]">
                    <td className="py-2 px-3 text-muted">{m.metric}</td>
                    {summaries.map((s) => {
                      const result = s.matchResults?.[i];
                      const matchColor = result?.match === 'match' || result?.match === 'exceeds' ? 'text-emerald-500' : result?.match === 'gap' ? 'text-red-500' : 'text-muted';
                      const matchLabel = result?.match === 'match' ? '✓' : result?.match === 'exceeds' ? '✓+' : result?.match === 'gap' ? '✗' : '?';
                      return <td key={s.athlete.id} className={`text-center py-2 px-3 font-semibold ${matchColor}`}>{matchLabel}</td>;
                    })}
                  </tr>
                ))}
                {targetProfile && (
                  <tr className="border-b border-[rgb(var(--border))]">
                    <td className="py-2 px-3 text-muted font-medium">Profile Match Score</td>
                    {summaries.map((s) => (
                      <td key={s.athlete.id} className="text-center py-2 px-3">
                        {s.profileMatchScore !== undefined ? (
                          <span className={`text-sm font-bold ${s.profileMatchScore >= 70 ? 'text-emerald-500' : s.profileMatchScore >= 50 ? 'text-amber-500' : 'text-red-500'}`}>{s.profileMatchScore}%</span>
                        ) : <span className="text-muted">—</span>}
                      </td>
                    ))}
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex items-center gap-2 text-xs text-muted">
            <span className="text-emerald-500 font-semibold">✓</span> Match/Exceeds
            <span className="text-red-500 font-semibold ml-3">✗</span> Gap
            <span className="text-muted ml-3">?</span> No Data (requires further assessment)
          </div>
        </div>
      )}

      {summaries.length >= 2 && summaries[0]?.matchResults && (
        <div className="card p-5">
          <SectionTitle title="AI Comparison Summary" subtitle="AI-assisted analysis of candidates" />
          <div className="rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3">
            <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-2">AI-GENERATED ANALYSIS</div>
            <div className="space-y-2">
              {summaries.map((s) => {
                const matched = s.matchResults?.filter((m) => m.match === 'match' || m.match === 'exceeds').length ?? 0;
                const total = s.matchResults?.length ?? 0;
                const gaps = s.matchResults?.filter((m) => m.match === 'gap').length ?? 0;
                const noData = s.matchResults?.filter((m) => m.match === 'no_data').length ?? 0;
                return (
                  <div key={s.athlete.id} className="text-xs text-[rgb(var(--text))]">
                    <strong>{s.athlete.name}</strong>: {matched}/{total} criteria matched, {gaps} gaps, {noData} missing data.
                    {s.developmentTrend === 'Improving' && ' Showing positive development trajectory.'}
                    {noData > 0 && ' Additional assessment recommended for missing criteria.'}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ===== PIPELINE TAB =====
function PipelineTab({ projectId, onRefresh }: { projectId: string | null; onRefresh: () => void }) {
  if (!projectId) {
    return (
      <div className="card p-5">
        <SectionTitle title="Recruitment Pipeline" subtitle="Multi-stage recruitment tracking" />
        <p className="text-sm text-muted py-4">Select a scouting project to view its recruitment pipeline.</p>
      </div>
    );
  }

  const entries = getPipelineForProject(projectId);
  const shortlists = getShortlistsForProject(projectId);
  const watchlist = getWatchlist();
  const athletes = getAllAthletes();
  const nameMap = new Map(athletes.map((a) => [a.id, a.name]));

  const stageLabels: Record<RecruitmentStage, string> = {
    IDENTIFIED: 'Identified', OBSERVING: 'Observing', SHORTLISTED: 'Shortlisted',
    FURTHER_ASSESSMENT: 'Further Assessment', SCOUT_REVIEW: 'Scout Review',
    COACH_REVIEW: 'Coach Review', TRIAL: 'Trial', RECRUITMENT_DECISION: 'Decision', ONBOARDING: 'Onboarding',
  };

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <SectionTitle title="Pipeline Stages" subtitle="Progress athletes through recruitment stages" />
        <div className="flex items-center gap-2 mb-4 text-xs text-muted">
          <ShieldCheck size={14} className="text-emerald-500" />
          Advancing a stage requires human action. AI cannot autonomously progress athletes.
        </div>

        <div className="overflow-x-auto scrollbar-thin">
          <div className="flex gap-3 min-w-max">
            {STAGE_ORDER.map((stage) => {
              const stageEntries = entries.filter((e) => e.stage === stage);
              return (
                <div key={stage} className="w-56 shrink-0">
                  <div className="surface-2 rounded-xl p-3 mb-2">
                    <div className="text-xs font-semibold text-[rgb(var(--text))]">{stageLabels[stage]}</div>
                    <div className="text-xs text-muted">{stageEntries.length} athlete(s)</div>
                  </div>
                  <div className="space-y-2">
                    {stageEntries.map((e) => {
                      const next = getNextStage(e.stage);
                      return (
                        <div key={e.id} className="surface rounded-xl p-3">
                          <div className="text-sm font-medium text-[rgb(var(--text))]">{nameMap.get(e.athleteId) ?? 'Unknown'}</div>
                          {e.rationale && <div className="text-xs text-muted mt-1">{e.rationale}</div>}
                          {next && (
                            <button onClick={() => { advancePipeline(e.athleteId, e.projectId, next, 'Advanced by scout'); onRefresh(); }} className="btn-ghost text-xs mt-2 flex items-center gap-1">
                              <ArrowRight size={12} /> Move to {stageLabels[next]}
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <SectionTitle title="Shortlist" subtitle={`${shortlists.length} athlete(s) shortlisted`} />
          {shortlists.length === 0 ? (
            <p className="text-sm text-muted py-4">No athletes shortlisted yet.</p>
          ) : (
            <div className="space-y-2">
              {shortlists.map((s) => (
                <div key={s.id} className="surface-2 rounded-xl p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-[rgb(var(--text))]">{nameMap.get(s.athleteId) ?? 'Unknown'}</span>
                    <button onClick={() => { removeFromShortlist(s.athleteId, s.projectId); onRefresh(); }} className="text-muted hover:text-red-500"><XCircle size={14} /></button>
                  </div>
                  {s.evidenceSummary && <p className="text-xs text-muted">{s.evidenceSummary}</p>}
                  {s.nextAction && <p className="text-xs text-muted mt-1">Next: {s.nextAction}</p>}
                  {s.reviewDate && <p className="text-xs text-muted mt-1">Review: {s.reviewDate}</p>}
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card p-5">
          <SectionTitle title="Watchlist" subtitle={`${watchlist.length} athlete(s) being watched`} />
          {watchlist.length === 0 ? (
            <p className="text-sm text-muted py-4">No athletes on watchlist.</p>
          ) : (
            <div className="space-y-2">
              {watchlist.map((w) => (
                <div key={w.id} className="surface-2 rounded-xl p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-[rgb(var(--text))]">{nameMap.get(w.athleteId) ?? 'Unknown'}</span>
                    <button onClick={() => { removeFromWatchlist(w.athleteId); onRefresh(); }} className="text-muted hover:text-red-500"><XCircle size={14} /></button>
                  </div>
                  {w.reason && <p className="text-xs text-muted">{w.reason}</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ===== DASHBOARD TAB =====
function DashboardTab({ onSelectProject, onNavigate }: {
  onSelectProject: (id: string) => void;
  onNavigate: (tab: Tab) => void;
}) {
  const dashboard = getRecruitmentDashboard();

  const statCards = [
    { label: 'Active Projects', value: dashboard.activeProjects, icon: <ClipboardList size={20} />, color: 'text-emerald-500' },
    { label: 'Shortlisted', value: dashboard.shortlisted, icon: <Star size={20} />, color: 'text-blue-500' },
    { label: 'Watching', value: dashboard.watching, icon: <Eye size={20} />, color: 'text-amber-500' },
    { label: 'Pending Tasks', value: dashboard.pendingTasks, icon: <Clock size={20} />, color: 'text-orange-500' },
    { label: 'Awaiting Decision', value: dashboard.awaitingDecision, icon: <AlertCircle size={20} />, color: 'text-red-500' },
    { label: 'Incomplete Profiles', value: dashboard.incompleteProfiles, icon: <AlertTriangle size={20} />, color: 'text-purple-500' },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {statCards.map((s, i) => (
          <div key={i} className="card p-4">
            <div className="flex items-center justify-between mb-2">
              <span className={`shrink-0 ${s.color}`}>{s.icon}</span>
            </div>
            <div className="text-2xl font-bold text-[rgb(var(--text))]">{s.value}</div>
            <div className="text-xs text-muted">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card p-5">
        <SectionTitle title="Project Overview" subtitle="Active scouting projects and their progress" />
        {dashboard.projectSummaries.length === 0 ? (
          <p className="text-sm text-muted py-4">No projects yet.</p>
        ) : (
          <div className="space-y-2">
            {dashboard.projectSummaries.map((ps) => (
              <div key={ps.project.id} className="surface-2 rounded-xl p-3 cursor-pointer hover:bg-[rgb(var(--surface-2))] transition-all" onClick={() => { onSelectProject(ps.project.id); onNavigate('pipeline'); }}>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-[rgb(var(--text))]">{ps.project.name}</span>
                  <span className="text-xs text-muted">{ps.project.sport}</span>
                </div>
                <div className="flex items-center gap-4 mt-1 text-xs text-muted">
                  <span>{ps.candidates} candidates</span>
                  <span>{ps.shortlisted} shortlisted</span>
                  <span>{ps.reports} reports</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {dashboard.recentDecisions.length > 0 && (
        <div className="card p-5">
          <SectionTitle title="Recent Decisions" subtitle="Latest recruitment decisions" />
          <div className="space-y-2">
            {dashboard.recentDecisions.map((d) => {
              const athlete = getAthleteById(d.athleteId);
              return (
                <div key={d.id} className="surface-2 rounded-xl p-3 flex items-center justify-between">
                  <div>
                    <span className="text-sm font-medium text-[rgb(var(--text))]">{athlete?.name ?? 'Unknown'}</span>
                    <span className="text-xs text-muted ml-2">{d.decisionType} → {d.finalDecision ?? d.decision}</span>
                  </div>
                  <span className="text-xs text-muted">{new Date(d.createdAt).toLocaleDateString()}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ===== TASKS TAB =====
function TasksTab({ projectId, onRefresh }: { projectId: string | null; onRefresh: () => void }) {
  const tasks = projectId ? getTasksForProject(projectId) : [];
  const [showCreate, setShowCreate] = useState(false);
  const [title, setTitle] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState<ScoutTaskPriority>('medium');

  const handleCreate = () => {
    if (!title || !projectId) return;
    createTask({ title, projectId, dueDate: dueDate || undefined, priority });
    setTitle(''); setDueDate(''); setPriority('medium');
    setShowCreate(false);
    onRefresh();
  };

  const statusColors: Record<string, string> = {
    pending: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
    in_progress: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
    completed: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    cancelled: 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400',
  };

  const priorityLabels: Record<string, string> = { high: 'High', medium: 'Medium', low: 'Low' };

  return (
    <div className="card p-5">
      <SectionTitle title="Scout Tasks" subtitle="Manage scouting tasks and follow-up actions" action={
        projectId ? (
          <button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1">
            <Plus size={14} /> New Task
          </button>
        ) : undefined
      } />

      {!projectId ? (
        <p className="text-sm text-muted py-4">Select a scouting project to manage tasks.</p>
      ) : (
        <>
          {showCreate && (
            <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
              <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Task title" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
              <div className="flex gap-2">
                <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
                <select value={priority} onChange={(e) => setPriority(e.target.value as ScoutTaskPriority)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
              <div className="flex gap-2">
                <button onClick={handleCreate} className="btn-primary text-xs">Create Task</button>
                <button onClick={() => setShowCreate(false)} className="btn-ghost text-xs">Cancel</button>
              </div>
            </div>
          )}

          {tasks.length === 0 ? (
            <p className="text-sm text-muted py-4">No tasks for this project.</p>
          ) : (
            <div className="space-y-2">
              {tasks.map((t) => (
                <div key={t.id} className="surface-2 rounded-xl p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-[rgb(var(--text))]">{t.title}</span>
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${statusColors[t.status]}`}>{t.status.replace('_', ' ')}</span>
                      <span className="text-xs text-muted">{priorityLabels[t.priority]}</span>
                    </div>
                  </div>
                  {t.description && <p className="text-xs text-muted">{t.description}</p>}
                  {t.dueDate && <p className="text-xs text-muted mt-1">Due: {t.dueDate}</p>}
                  <div className="flex gap-2 mt-2">
                    {t.status === 'pending' && <button onClick={() => { updateTaskStatus(t.id, 'in_progress'); onRefresh(); }} className="btn-ghost text-xs">Start</button>}
                    {t.status === 'in_progress' && <button onClick={() => { updateTaskStatus(t.id, 'completed'); onRefresh(); }} className="btn-ghost text-xs">Complete</button>}
                    {t.status !== 'completed' && t.status !== 'cancelled' && <button onClick={() => { updateTaskStatus(t.id, 'cancelled'); onRefresh(); }} className="btn-ghost text-xs">Cancel</button>}
                    <button onClick={() => { deleteTask(t.id); onRefresh(); }} className="text-xs text-muted hover:text-red-500">Delete</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

// ===== AUDIT TAB =====
function AuditTab({ projectId }: { projectId: string | null }) {
  const entries = projectId ? getAuditForProject(projectId) : getAuditTrail();

  return (
    <div className="card p-5">
      <SectionTitle title="Audit Trail" subtitle={projectId ? 'Audit history for selected project' : 'Complete scouting audit trail'} />
      {entries.length === 0 ? (
        <p className="text-sm text-muted py-4">No audit entries yet.</p>
      ) : (
        <div className="space-y-1 max-h-[600px] overflow-y-auto scrollbar-thin">
          {entries.map((e) => (
            <div key={e.id} className="surface-2 rounded-lg p-2.5 flex items-start gap-3">
              <div className="text-xs text-muted shrink-0 mt-0.5">{new Date(e.timestamp).toLocaleString()}</div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium text-[rgb(var(--text))]">{e.action.replace(/_/g, ' ')}</div>
                <div className="text-xs text-muted">{e.user} · {e.entityType}{e.entityId ? ` · ${e.entityId.slice(0, 12)}` : ''}</div>
                {e.newState && <div className="text-xs text-muted italic mt-0.5 truncate">{e.newState}</div>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
