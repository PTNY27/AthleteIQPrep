import { useState, useRef, useCallback } from 'react';
import { parseCSV, detectColumns, validateDataset, generateTestCSVs, type ColumnMatch, type ValidationResult, type ParsedCSV } from '@/lib/dataPipeline';
import { SectionTitle } from '@/components/ui';
import { getAllAthletes } from '@/lib/extendedData';
import { Upload, FileText, CheckCircle2, AlertTriangle, XCircle, ArrowRight, ArrowLeft, Download, FileUp, Table, MapPin, ShieldCheck, FileWarning, Info } from 'lucide-react';

type Step = 'upload' | 'preview' | 'mapping' | 'validation' | 'results';

export function ImportData() {
  const [step, setStep] = useState<Step>('upload');
  const [fileName, setFileName] = useState('');
  const [parsed, setParsed] = useState<ParsedCSV | null>(null);
  const [columnMatches, setColumnMatches] = useState<ColumnMatch[]>([]);
  const [columnMap, setColumnMap] = useState<Record<string, string>>({});
  const [unitMap, setUnitMap] = useState<Record<string, string>>({});
  const [validation, setValidation] = useState<ValidationResult | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const testCSVs = generateTestCSVs();
  const athletes = getAllAthletes();

  const handleFile = useCallback((file: File) => {
    setError('');
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      try {
        const result = parseCSV(text);
        if (result.rowCount === 0) {
          setError('No data rows found in file.');
          return;
        }
        setParsed(result);
        setFileName(file.name);
        const matches = detectColumns(result.headers);
        setColumnMatches(matches);
        const initialMap: Record<string, string> = {};
        const initialUnits: Record<string, string> = {};
        matches.forEach((m) => {
          if (m.detectedMetric) initialMap[m.sourceColumn] = m.detectedMetric;
          initialUnits[m.sourceColumn] = m.unit;
        });
        setColumnMap(initialMap);
        setUnitMap(initialUnits);
        setStep('preview');
      } catch {
        setError('Failed to parse CSV file. Please check the format.');
      }
    };
    reader.readAsText(file);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file && file.name.endsWith('.csv')) handleFile(file);
    else setError('Please upload a CSV file.');
  }, [handleFile]);

  const loadTestCSV = (csv: typeof testCSVs[0]) => {
    const result = parseCSV(csv.content);
    setParsed(result);
    setFileName(csv.name);
    const matches = detectColumns(result.headers);
    setColumnMatches(matches);
    const initialMap: Record<string, string> = {};
    const initialUnits: Record<string, string> = {};
    matches.forEach((m) => {
      if (m.detectedMetric) initialMap[m.sourceColumn] = m.detectedMetric;
      initialUnits[m.sourceColumn] = m.unit;
    });
    setColumnMap(initialMap);
    setUnitMap(initialUnits);
    setStep('preview');
  };

  const runValidation = () => {
    if (!parsed) return;
    const result = validateDataset(parsed.rows, columnMap, unitMap);
    setValidation(result);
    setStep('validation');
  };

  const reset = () => {
    setStep('upload');
    setParsed(null);
    setFileName('');
    setColumnMatches([]);
    setColumnMap({});
    setUnitMap({});
    setValidation(null);
    setError('');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Import Wearable Data</h1>
        <p className="text-sm text-muted mt-1">Upload CSV exports from wearable monitoring devices</p>
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-2 flex-wrap">
        {([
          { key: 'upload', label: 'Upload', icon: <Upload size={16} /> },
          { key: 'preview', label: 'Preview', icon: <Table size={16} /> },
          { key: 'mapping', label: 'Mapping', icon: <MapPin size={16} /> },
          { key: 'validation', label: 'Validation', icon: <ShieldCheck size={16} /> },
          { key: 'results', label: 'Results', icon: <CheckCircle2 size={16} /> },
        ] as { key: Step; label: string; icon: React.ReactNode }[]).map((s, i, arr) => (
          <div key={s.key} className="flex items-center gap-2">
            <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              step === s.key ? 'bg-[rgb(var(--primary))] text-white' :
              arr.findIndex((x) => x.key === step) > i ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' :
              'surface-2 text-muted'
            }`}>
              {s.icon}
              {s.label}
            </div>
            {i < arr.length - 1 && <ArrowRight size={14} className="text-subtle" />}
          </div>
        ))}
      </div>

      {/* Step content */}
      {step === 'upload' && (
        <div className="space-y-4">
          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`card p-12 border-2 border-dashed cursor-pointer transition-all ${
              dragOver ? 'border-[rgb(var(--primary))] bg-[rgb(var(--primary-light))]' : 'border-[rgb(var(--border))] hover:border-[rgb(var(--primary))]'
            }`}
          >
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-2xl bg-[rgb(var(--primary-light))] flex items-center justify-center mb-4">
                <FileUp size={32} className="text-[rgb(var(--primary))]" />
              </div>
              <h3 className="text-lg font-bold text-[rgb(var(--text))]">Drag CSV file here</h3>
              <p className="text-sm text-muted mt-1">or click to browse</p>
              <p className="text-xs text-subtle mt-2">Supports .csv files from any wearable provider</p>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              className="hidden"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
            />
          </div>

          {error && (
            <div className="card p-4 border-l-4 border-l-red-500 bg-red-50 dark:bg-red-900/20">
              <div className="flex items-center gap-2">
                <XCircle size={18} className="text-red-500" />
                <span className="text-sm text-red-700 dark:text-red-300">{error}</span>
              </div>
            </div>
          )}

          {/* Test data */}
          <div className="card p-5">
            <SectionTitle title="Test Datasets" subtitle="Try the import workflow with realistic test data" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {testCSVs.map((csv) => (
                <button
                  key={csv.name}
                  onClick={() => loadTestCSV(csv)}
                  className="surface-2 rounded-xl p-4 text-left hover:border-[rgb(var(--primary))] transition-all"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <FileText size={16} className="text-[rgb(var(--primary))]" />
                    <span className="text-sm font-semibold text-[rgb(var(--text))]">{csv.name}</span>
                  </div>
                  <p className="text-xs text-muted">{csv.description}</p>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {step === 'preview' && parsed && (
        <div className="space-y-4">
          <div className="card p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <FileText size={20} className="text-[rgb(var(--primary))]" />
                <span className="font-semibold text-[rgb(var(--text))]">{fileName}</span>
              </div>
              <span className="text-sm text-muted">{parsed.rowCount} rows · {parsed.headers.length} columns</span>
            </div>

            {/* Column detection summary */}
            <div className="mb-4">
              <h4 className="text-xs text-muted uppercase tracking-wider mb-2">Column Detection</h4>
              <div className="flex flex-wrap gap-2">
                {columnMatches.map((m) => (
                  <span key={m.sourceColumn} className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${
                    m.confidence === 'high' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' :
                    m.confidence === 'medium' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' :
                    'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'
                  }`}>
                    {m.sourceColumn}
                    {m.detectedMetric ? ` → ${m.detectedMetric}` : ' (unmapped)'}
                  </span>
                ))}
              </div>
            </div>

            {/* Data preview table */}
            <div className="overflow-x-auto scrollbar-thin">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[rgb(var(--border))]">
                    {parsed.headers.map((h) => (
                      <th key={h} className="text-left py-2 px-3 font-medium text-muted whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {parsed.rows.slice(0, 5).map((row, i) => (
                    <tr key={i} className="border-b border-[rgb(var(--border))] last:border-0">
                      {parsed.headers.map((h) => (
                        <td key={h} className="py-2 px-3 text-muted whitespace-nowrap">{row[h]}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-subtle mt-2">Showing first 5 rows of {parsed.rowCount}</p>
          </div>

          <div className="flex items-center justify-between">
            <button onClick={reset} className="btn-ghost flex items-center gap-2">
              <ArrowLeft size={16} /> Back
            </button>
            <button onClick={() => setStep('mapping')} className="btn-primary flex items-center gap-2">
              Configure Mapping <ArrowRight size={16} />
            </button>
          </div>
        </div>
      )}

      {step === 'mapping' && parsed && (
        <div className="space-y-4">
          <div className="card p-5">
            <SectionTitle title="Column Mapping" subtitle="Map source columns to standardized AthleteIQ metrics" />
            <div className="space-y-3">
              {parsed.headers.map((header) => {
                const match = columnMatches.find((m) => m.sourceColumn === header);
                const currentTarget = columnMap[header] || '';
                const isAthleteCol = header.toLowerCase().includes('athlete') || header.toLowerCase().includes('player');
                const isDateCol = header.toLowerCase().includes('date') || header.toLowerCase().includes('time');
                const isSessionCol = header.toLowerCase().includes('session') || header.toLowerCase().includes('type');

                return (
                  <div key={header} className="flex items-center gap-3 surface-2 rounded-xl p-3">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-[rgb(var(--text))]">{header}</div>
                      {match && match.confidence !== 'none' && (
                        <div className="text-xs text-muted mt-0.5">
                          Detected: <span className="font-semibold">{match.detectedMetric || 'unmapped'}</span>
                          <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                            match.confidence === 'high' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' :
                            match.confidence === 'medium' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' :
                            'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'
                          }`}>
                            {match.confidence} confidence
                          </span>
                        </div>
                      )}
                    </div>
                    <span className="text-subtle shrink-0">→</span>
                    <select
                      value={isAthleteCol ? 'athlete_id' : isDateCol ? 'timestamp' : isSessionCol ? 'session_type' : currentTarget}
                      onChange={(e) => setColumnMap((prev) => ({ ...prev, [header]: e.target.value }))}
                      className="surface-2 rounded-lg px-3 py-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] outline-none min-w-[180px]"
                    >
                      <option value="">— Skip —</option>
                      {isAthleteCol && <option value="athlete_id">Athlete ID</option>}
                      {isDateCol && <option value="timestamp">Timestamp</option>}
                      {isSessionCol && <option value="session_type">Session Type</option>}
                      <optgroup label="AthleteIQ Metrics">
                        <option value="total_distance">Total Distance (m)</option>
                        <option value="relative_distance">Relative Distance (m/min)</option>
                        <option value="high_speed_running">High-Speed Running (m)</option>
                        <option value="sprint_distance">Sprint Distance (m)</option>
                        <option value="max_velocity">Maximum Velocity (km/h)</option>
                        <option value="accelerations">Accelerations (count)</option>
                        <option value="decelerations">Decelerations (count)</option>
                        <option value="high_intensity_efforts">High-Intensity Efforts (count)</option>
                        <option value="heart_rate_avg">Average Heart Rate (bpm)</option>
                        <option value="heart_rate_max">Max Heart Rate (bpm)</option>
                        <option value="session_rpe">Session RPE (0-10)</option>
                        <option value="duration">Session Duration (min)</option>
                        <option value="player_load">Player Load (AU)</option>
                        <option value="contact_count">Contacts (count)</option>
                        <option value="collision_load">Collision Load (AU)</option>
                        <option value="high_intensity_contacts">High-Intensity Contacts (count)</option>
                      </optgroup>
                    </select>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <button onClick={() => setStep('preview')} className="btn-ghost flex items-center gap-2">
              <ArrowLeft size={16} /> Back
            </button>
            <button onClick={runValidation} className="btn-primary flex items-center gap-2">
              Validate Data <ShieldCheck size={16} />
            </button>
          </div>
        </div>
      )}

      {step === 'validation' && validation && (
        <div className="space-y-4">
          <div className="card p-5">
            <SectionTitle title="Validation Results" subtitle="Data integrity check before import" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              <div className="surface-2 rounded-xl p-4">
                <div className="text-xs text-muted">Total Rows</div>
                <div className="text-2xl font-bold text-[rgb(var(--text))]">{validation.totalRows}</div>
              </div>
              <div className="surface-2 rounded-xl p-4">
                <div className="text-xs text-muted">Valid</div>
                <div className="text-2xl font-bold text-emerald-500">{validation.validRows}</div>
              </div>
              <div className="surface-2 rounded-xl p-4">
                <div className="text-xs text-muted">Warnings</div>
                <div className="text-2xl font-bold text-amber-500">{validation.warningRows}</div>
              </div>
              <div className="surface-2 rounded-xl p-4">
                <div className="text-xs text-muted">Rejected</div>
                <div className="text-2xl font-bold text-red-500">{validation.rejectedRows}</div>
              </div>
            </div>

            {/* Quality score */}
            <div className="surface-2 rounded-xl p-4 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-[rgb(var(--text))]">Data Quality Score</span>
                <span className={`text-lg font-bold ${
                  validation.qualityScore >= 95 ? 'text-emerald-500' :
                  validation.qualityScore >= 85 ? 'text-amber-500' :
                  validation.qualityScore >= 70 ? 'text-orange-500' : 'text-red-500'
                }`}>{validation.qualityScore}%</span>
              </div>
              <div className="h-2.5 bg-[rgb(var(--surface-3))] rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700" style={{
                  width: `${validation.qualityScore}%`,
                  backgroundColor: validation.qualityScore >= 95 ? 'rgb(var(--success))' :
                    validation.qualityScore >= 85 ? 'rgb(var(--warning))' : 'rgb(var(--error))',
                }} />
              </div>
            </div>

            {/* Issues list */}
            {validation.issues.length > 0 && (
              <div>
                <h4 className="text-xs text-muted uppercase tracking-wider mb-2">Issues Found ({validation.issues.length})</h4>
                <div className="space-y-2 max-h-64 overflow-y-auto scrollbar-thin">
                  {validation.issues.slice(0, 20).map((issue, i) => (
                    <div key={i} className={`flex items-start gap-2 rounded-lg p-3 text-sm ${
                      issue.level === 'error' ? 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300' :
                      issue.level === 'warning' ? 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300' :
                      'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
                    }`}>
                      {issue.level === 'error' ? <XCircle size={16} className="shrink-0 mt-0.5" /> :
                       issue.level === 'warning' ? <AlertTriangle size={16} className="shrink-0 mt-0.5" /> :
                       <Info size={16} className="shrink-0 mt-0.5" />}
                      <div>
                        <span className="font-semibold">Row {issue.row} · {issue.column}:</span> {issue.message}
                        {issue.value !== undefined && issue.value !== '' && <span className="ml-1 opacity-70">({issue.value})</span>}
                      </div>
                    </div>
                  ))}
                  {validation.issues.length > 20 && (
                    <p className="text-xs text-muted text-center pt-2">...and {validation.issues.length - 20} more issues</p>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between">
            <button onClick={() => setStep('mapping')} className="btn-ghost flex items-center gap-2">
              <ArrowLeft size={16} /> Back to Mapping
            </button>
            <button onClick={() => setStep('results')} className="btn-primary flex items-center gap-2">
              Confirm Import <CheckCircle2 size={16} />
            </button>
          </div>
        </div>
      )}

      {step === 'results' && validation && (
        <div className="space-y-4">
          <div className="card p-8 text-center">
            <div className="w-16 h-16 rounded-2xl bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 size={32} className="text-emerald-500" />
            </div>
            <h2 className="text-xl font-bold text-[rgb(var(--text))]">Import Complete</h2>
            <p className="text-sm text-muted mt-1">{fileName}</p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6 max-w-2xl mx-auto">
              <div className="surface-2 rounded-xl p-4">
                <div className="text-xs text-muted">Rows Processed</div>
                <div className="text-2xl font-bold text-[rgb(var(--text))]">{validation.totalRows.toLocaleString()}</div>
              </div>
              <div className="surface-2 rounded-xl p-4">
                <div className="text-xs text-muted">Valid</div>
                <div className="text-2xl font-bold text-emerald-500">{(validation.validRows + validation.warningRows).toLocaleString()}</div>
              </div>
              <div className="surface-2 rounded-xl p-4">
                <div className="text-xs text-muted">Warnings</div>
                <div className="text-2xl font-bold text-amber-500">{validation.issues.filter((i) => i.level === 'warning').length}</div>
              </div>
              <div className="surface-2 rounded-xl p-4">
                <div className="text-xs text-muted">Rejected</div>
                <div className="text-2xl font-bold text-red-500">{validation.rejectedRows}</div>
              </div>
            </div>

            <div className="surface-2 rounded-xl p-4 mt-4 max-w-2xl mx-auto">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-[rgb(var(--text))]">Data Quality</span>
                <span className={`text-lg font-bold ${
                  validation.qualityScore >= 95 ? 'text-emerald-500' :
                  validation.qualityScore >= 85 ? 'text-amber-500' : 'text-red-500'
                }`}>{validation.qualityScore}%</span>
              </div>
            </div>

            {/* Data source label */}
            <div className="mt-6 flex items-center justify-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">
                <FileUp size={14} /> Imported Data
              </span>
              <span className="text-xs text-muted">Data clearly labelled as imported — not live or demo</span>
            </div>
          </div>

          {/* Error report */}
          {validation.issues.length > 0 && (
            <div className="card p-5">
              <SectionTitle title="Error Report" subtitle="Detailed issues for review" action={
                <button className="btn-ghost text-xs flex items-center gap-1.5">
                  <Download size={14} /> Download Report
                </button>
              } />
              <div className="space-y-2 max-h-64 overflow-y-auto scrollbar-thin">
                {validation.issues.map((issue, i) => (
                  <div key={i} className="flex items-start gap-2 surface-2 rounded-lg p-3 text-sm">
                    {issue.level === 'error' ? <XCircle size={16} className="shrink-0 mt-0.5 text-red-500" /> :
                     issue.level === 'warning' ? <AlertTriangle size={16} className="shrink-0 mt-0.5 text-amber-500" /> :
                     <Info size={16} className="shrink-0 mt-0.5 text-blue-500" />}
                    <div className="text-[rgb(var(--text))]">
                      <span className="font-semibold">Row {issue.row}:</span> {issue.message}
                      {issue.value !== undefined && issue.value !== '' && <span className="ml-1 text-muted">({issue.value})</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Next steps */}
          <div className="card p-5">
            <SectionTitle title="What Happens Next" subtitle="Data pipeline processing" />
            <div className="flex flex-col lg:flex-row items-stretch gap-2 text-xs">
              {['Raw Storage', 'Validation', 'Normalization', 'Athlete Matching', 'Clean Data', 'Analytics', 'AI Engine'].map((step, i, arr) => (
                <div key={step} className="flex items-center gap-2 flex-1">
                  <div className="flex-1 surface-2 rounded-lg p-3 text-center font-medium text-[rgb(var(--text))]">{step}</div>
                  {i < arr.length - 1 && <span className="text-subtle shrink-0">→</span>}
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <button onClick={reset} className="btn-primary flex items-center gap-2">
              <Upload size={16} /> Import Another File
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
