import { useState } from 'react';
import { getAllAthletes, getAllTrainingSessions, filterSessionsByPeriod } from '@/lib/extendedData';
import { computeLoads, getLoadStatus, classifyLoad, computeMonotony, computeTrainingAverages } from '@/lib/demoData';
import { Avatar, StatusBadge, LoadClassBadge, SectionTitle, TimePeriodSelector } from '@/components/ui';
import type { TimePeriod } from '@/lib/types';
import { LineChart, BarChart, StackedBarChart } from '@/components/charts/Charts';
import { Dumbbell, HeartPulse, Zap, Gauge, Clock, Activity, Shield } from 'lucide-react';
import type { TrainingSession } from '@/lib/types';

export function TrainingLoad({ athleteId, onSelectAthlete }: { athleteId: string; onSelectAthlete: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === athleteId) || athletes[0];
  const [period, setPeriod] = useState<TimePeriod>('28d');
  const allSessions = getAllTrainingSessions(athlete.id);
  const sessions = filterSessionsByPeriod(allSessions, period);
  const { acute, chronic, acwr } = computeLoads(sessions);
  const status = getLoadStatus(acute, chronic);
  const classification = classifyLoad(acute, chronic);
  const monotony = computeMonotony(sessions);
  const avg = computeTrainingAverages(sessions);
  const [selectedSession, setSelectedSession] = useState<TrainingSession | null>(null);

  // Daily load chart
  const dailyLoad = [...sessions].reverse().map((s) => ({
    label: new Date(s.date).toLocaleDateString('en', { day: 'numeric', month: 'short' }),
    value: s.trainingLoad,
  }));

  // HR zone distribution
  const latestSession = sessions[0];
  const hrZones = latestSession ? [
    { label: 'Z1', value: latestSession.hrZonePercent.z1, color: 'rgb(34, 197, 94)' },
    { label: 'Z2', value: latestSession.hrZonePercent.z2, color: 'rgb(132, 204, 22)' },
    { label: 'Z3', value: latestSession.hrZonePercent.z3, color: 'rgb(234, 179, 8)' },
    { label: 'Z4', value: latestSession.hrZonePercent.z4, color: 'rgb(249, 115, 22)' },
    { label: 'Z5', value: latestSession.hrZonePercent.z5, color: 'rgb(220, 38, 38)' },
  ] : [];

  // Weekly stacked load
  const weeklyStacked: { label: string; values: { label: string; value: number; color: string }[] }[] = [];
  for (let w = 3; w >= 0; w--) {
    const weekStart = 27 - w * 7;
    const weekEnd = weekStart - 6;
    const weekSessions = sessions.filter((s) => {
      const day = parseInt(s.date.split('-')[2]);
      return day >= weekEnd && day <= weekStart;
    });
    const volume = weekSessions.filter((s) => ['Endurance', 'Recovery'].includes(s.type)).reduce((sum, s) => sum + s.trainingLoad, 0);
    const intensity = weekSessions.filter((s) => ['Speed', 'Physical'].includes(s.type)).reduce((sum, s) => sum + s.trainingLoad, 0);
    const other = weekSessions.filter((s) => !['Endurance', 'Recovery', 'Speed', 'Physical'].includes(s.type)).reduce((sum, s) => sum + s.trainingLoad, 0);
    weeklyStacked.push({
      label: `W-${w}`,
      values: [
        { label: 'Volume', value: volume, color: 'rgb(var(--chart-1))' },
        { label: 'Intensity', value: intensity, color: 'rgb(var(--chart-3))' },
        { label: 'Other', value: other, color: 'rgb(var(--chart-4))' },
      ],
    });
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Training Load</h1>
          <p className="text-sm text-muted mt-1">External and internal load monitoring</p>
        </div>
        <AthleteDropdown selectedId={athleteId} onSelect={onSelectAthlete} />
      </div>

      {/* Time period selector */}
      <div className="card p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <span className="text-sm font-medium text-[rgb(var(--text))]">Time Period</span>
          <TimePeriodSelector value={period} onChange={setPeriod} />
        </div>
      </div>

      {/* Status bar */}
      <div className="card p-5 flex flex-wrap items-center gap-6">
        <div className="flex items-center gap-3">
          <Avatar initials={athlete.initials} color={athlete.avatarColor} size={48} />
          <div>
            <h3 className="font-bold text-[rgb(var(--text))]">{athlete.name}</h3>
            <span className="text-sm text-muted">{athlete.position}</span>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-6">
          <div className="text-right">
            <div className="text-xs text-muted uppercase tracking-wider">Classification</div>
            <div className="mt-1"><LoadClassBadge classification={classification} /></div>
          </div>
          <div className="text-right">
            <div className="text-xs text-muted uppercase tracking-wider">Load Status</div>
            <div className="mt-1"><StatusBadge status={status} /></div>
          </div>
        </div>
      </div>

      {/* Load metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <MetricCard label="Acute Load (7d)" value={acute.toLocaleString()} unit="AU" icon={<Dumbbell size={18} />} color="rgb(var(--chart-1))" />
        <MetricCard label="Chronic Load (28d)" value={chronic.toLocaleString()} unit="AU" icon={<Activity size={18} />} color="rgb(var(--chart-2))" />
        <MetricCard label="ACWR" value={acwr.toFixed(2)} unit="" icon={<Gauge size={18} />} color={status === 'OPTIMAL' ? 'rgb(var(--success))' : 'rgb(var(--warning))'} />
        <MetricCard label="Monotony" value={monotony.toFixed(2)} unit="" icon={<Activity size={18} />} color={monotony > 1.5 ? 'rgb(var(--warning))' : 'rgb(var(--success))'} />
        <MetricCard label="Sessions" value={sessions.length.toString()} unit="" icon={<Clock size={18} />} color="rgb(var(--chart-4))" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Daily load */}
        <div className="card p-5">
          <SectionTitle title="Daily Training Load" subtitle="Session RPE × Duration" />
          <BarChart data={dailyLoad} unit="AU" height={240} />
        </div>

        {/* Weekly stacked */}
        <div className="card p-5">
          <SectionTitle title="Weekly Load Distribution" subtitle="By session type" />
          <StackedBarChart data={weeklyStacked} height={240} />
          <div className="flex items-center gap-4 mt-3 justify-center">
            <LegendItem color="rgb(var(--chart-1))" label="Volume" />
            <LegendItem color="rgb(var(--chart-3))" label="Intensity" />
            <LegendItem color="rgb(var(--chart-4))" label="Other" />
          </div>
        </div>
      </div>

      {/* External vs Internal Load */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* External load */}
        <div className="card p-5">
          <SectionTitle title="External Load" subtitle="Physical output metrics" />
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            <MetricBox label="Total Distance" value={avg?.totalDistance || 0} unit="km" icon={<Activity size={14} />} />
            <MetricBox label="HSR" value={avg?.highSpeedRunning || 0} unit="m" icon={<Zap size={14} />} />
            <MetricBox label="Sprint Distance" value={avg?.sprintDistance || 0} unit="m" icon={<Gauge size={14} />} />
            <MetricBox label="Accelerations" value={avg?.accelerations || 0} unit="" icon={<Zap size={14} />} />
            <MetricBox label="Decelerations" value={avg?.decelerations || 0} unit="" icon={<Zap size={14} />} />
            <MetricBox label="Duration" value={avg?.duration || 0} unit="min" icon={<Clock size={14} />} />
            {avg?.contacts !== undefined && (
              <MetricBox label="Contacts" value={avg.contacts} unit="" icon={<Shield size={14} />} />
            )}
            {avg?.contactLoad !== undefined && (
              <MetricBox label="Contact Load" value={avg.contactLoad} unit="AU" icon={<Shield size={14} />} />
            )}
          </div>
        </div>

        {/* Internal load */}
        <div className="card p-5">
          <SectionTitle title="Internal Load" subtitle="Physiological response" />
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
            <MetricBox label="Avg HR" value={avg?.avgHeartRate || 0} unit="bpm" icon={<HeartPulse size={14} />} />
            <MetricBox label="Max HR" value={sessions[0]?.maxHeartRate || 0} unit="bpm" icon={<HeartPulse size={14} />} />
            <MetricBox label="Session RPE" value={avg?.sessionRPE || 0} unit="/10" icon={<Gauge size={14} />} />
          </div>
          <div className="mt-4">
            <h4 className="text-xs text-muted uppercase tracking-wider mb-3">Heart Rate Zone Distribution (Latest Session)</h4>
            <div className="space-y-2">
              {hrZones.map((z) => (
                <div key={z.label} className="flex items-center gap-3">
                  <span className="text-xs text-muted w-8">{z.label}</span>
                  <div className="flex-1 h-5 bg-[rgb(var(--surface-2))] rounded-md overflow-hidden">
                    <div
                      className="h-full rounded-md transition-all duration-700"
                      style={{ width: `${z.value}%`, backgroundColor: z.color }}
                    />
                  </div>
                  <span className="text-xs font-semibold text-[rgb(var(--text))] w-10 text-right">{z.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Session table */}
      <div className="card p-5">
        <SectionTitle title="Training Sessions" subtitle={`${sessions.length} sessions in last 28 days`} />
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgb(var(--border))]">
                <th className="text-left py-2 px-3 font-medium text-muted">Date</th>
                <th className="text-left py-2 px-3 font-medium text-muted">Type</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Duration</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Distance</th>
                <th className="text-right py-2 px-3 font-medium text-muted">HSR</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Sprint</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Acc</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Avg HR</th>
                <th className="text-right py-2 px-3 font-medium text-muted">RPE</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Load</th>
              </tr>
            </thead>
            <tbody>
              {sessions.slice(0, 14).map((s) => (
                <tr
                  key={s.id}
                  onClick={() => setSelectedSession(s)}
                  className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))] cursor-pointer transition-colors"
                >
                  <td className="py-2 px-3 text-muted">{new Date(s.date).toLocaleDateString('en', { day: 'numeric', month: 'short' })}</td>
                  <td className="py-2 px-3 font-medium text-[rgb(var(--text))]">{s.type}</td>
                  <td className="py-2 px-3 text-right text-muted">{s.duration}m</td>
                  <td className="py-2 px-3 text-right text-muted">{s.totalDistance} km</td>
                  <td className="py-2 px-3 text-right text-muted">{s.highSpeedRunning}m</td>
                  <td className="py-2 px-3 text-right text-muted">{s.sprintDistance}m</td>
                  <td className="py-2 px-3 text-right text-muted">{s.accelerations}</td>
                  <td className="py-2 px-3 text-right text-muted">{s.avgHeartRate}</td>
                  <td className="py-2 px-3 text-right text-muted">{s.sessionRPE}</td>
                  <td className="py-2 px-3 text-right font-semibold text-[rgb(var(--text))]">{s.trainingLoad}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Session detail modal */}
      {selectedSession && (
        <SessionDetailModal session={selectedSession} onClose={() => setSelectedSession(null)} />
      )}
    </div>
  );
}

function SessionDetailModal({ session, onClose }: { session: TrainingSession; onClose: () => void }) {
  const classification = session.trainingLoad > 500 ? 'Very High Load' : session.trainingLoad > 350 ? 'High Load' : session.trainingLoad > 200 ? 'Moderate Load' : 'Low Load';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 animate-fade-in" onClick={onClose}>
      <div className="card rounded-2xl p-6 max-w-lg w-full animate-scale-in max-h-[90vh] overflow-y-auto scrollbar-thin" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-[rgb(var(--text))]">{session.type} Session</h3>
            <p className="text-sm text-muted">{new Date(session.date).toLocaleDateString('en', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</p>
          </div>
          <button onClick={onClose} className="text-muted hover:text-[rgb(var(--text))] text-xl">✕</button>
        </div>

        <div className="mb-4">
          <LoadClassBadge classification={classification as 'Low Load' | 'Moderate Load' | 'High Load' | 'Very High Load'} />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <DetailItem label="Duration" value={`${session.duration} min`} />
          <DetailItem label="Training Load" value={`${session.trainingLoad} AU`} />
          <DetailItem label="Total Distance" value={`${session.totalDistance} km`} />
          <DetailItem label="Distance/min" value={`${session.relativeDistance} m/min`} />
          <DetailItem label="High-Speed Running" value={`${session.highSpeedRunning} m`} />
          <DetailItem label="Sprint Distance" value={`${session.sprintDistance} m`} />
          <DetailItem label="Accelerations" value={session.accelerations.toString()} />
          <DetailItem label="Decelerations" value={session.decelerations.toString()} />
          <DetailItem label="High-Intensity Efforts" value={session.highIntensityEfforts.toString()} />
          <DetailItem label="Player Load" value={session.playerLoad.toString()} />
          <DetailItem label="Avg Heart Rate" value={`${session.avgHeartRate} bpm`} />
          <DetailItem label="Max Heart Rate" value={`${session.maxHeartRate} bpm`} />
          <DetailItem label="Session RPE" value={`${session.sessionRPE}/10`} />
          {session.contacts !== undefined && <DetailItem label="Contacts" value={session.contacts.toString()} />}
          {session.contactLoad !== undefined && <DetailItem label="Contact Load" value={`${session.contactLoad} AU`} />}
        </div>

        <div className="mt-4 pt-4 border-t border-[rgb(var(--border))]">
          <h4 className="text-xs text-muted uppercase tracking-wider mb-2">HR Zone Distribution</h4>
          <div className="space-y-1.5">
            {[
              { label: 'Z1 (Recovery)', value: session.hrZonePercent.z1, color: 'rgb(34, 197, 94)' },
              { label: 'Z2 (Aerobic)', value: session.hrZonePercent.z2, color: 'rgb(132, 204, 22)' },
              { label: 'Z3 (Tempo)', value: session.hrZonePercent.z3, color: 'rgb(234, 179, 8)' },
              { label: 'Z4 (Threshold)', value: session.hrZonePercent.z4, color: 'rgb(249, 115, 22)' },
              { label: 'Z5 (Max)', value: session.hrZonePercent.z5, color: 'rgb(220, 38, 38)' },
            ].map((z) => (
              <div key={z.label} className="flex items-center gap-3">
                <span className="text-xs text-muted w-28">{z.label}</span>
                <div className="flex-1 h-4 bg-[rgb(var(--surface-2))] rounded-md overflow-hidden">
                  <div className="h-full rounded-md" style={{ width: `${z.value}%`, backgroundColor: z.color }} />
                </div>
                <span className="text-xs font-semibold text-[rgb(var(--text))] w-10 text-right">{z.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function DetailItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="surface-2 rounded-lg p-3">
      <div className="text-xs text-muted">{label}</div>
      <div className="text-sm font-semibold text-[rgb(var(--text))] mt-0.5">{value}</div>
    </div>
  );
}

function MetricCard({ label, value, unit, icon, color }: { label: string; value: string; unit: string; icon: React.ReactNode; color: string }) {
  return (
    <div className="card p-4">
      <div className="flex items-center gap-2 mb-2">
        <span style={{ color }}>{icon}</span>
        <span className="text-xs text-muted uppercase tracking-wider">{label}</span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="text-2xl font-bold text-[rgb(var(--text))]">{value}</span>
        {unit && <span className="text-xs text-muted">{unit}</span>}
      </div>
    </div>
  );
}

function MetricBox({ label, value, unit, icon }: { label: string; value: number; unit: string; icon: React.ReactNode }) {
  return (
    <div className="surface-2 rounded-xl p-3">
      <div className="flex items-center gap-1.5 mb-1">
        <span className="text-subtle">{icon}</span>
        <span className="text-xs text-muted">{label}</span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="text-lg font-bold text-[rgb(var(--text))]">{value.toFixed(value < 10 ? 1 : 0)}</span>
        {unit && <span className="text-xs text-muted">{unit}</span>}
      </div>
    </div>
  );
}

function LegendItem({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="w-3 h-3 rounded" style={{ backgroundColor: color }} />
      <span className="text-xs text-muted">{label}</span>
    </div>
  );
}

function AthleteDropdown({ selectedId, onSelect }: { selectedId: string; onSelect: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === selectedId) || athletes[0];
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 surface rounded-xl px-3 py-2 hover:border-[rgb(var(--primary))] transition-colors"
      >
        <Avatar initials={athlete.initials} color={athlete.avatarColor} size={32} />
        <span className="text-sm font-medium text-[rgb(var(--text))]">{athlete.name}</span>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-2 z-20 w-64 card rounded-xl shadow-lg overflow-hidden animate-scale-in">
            {athletes.map((a) => (
              <button
                key={a.id}
                onClick={() => { onSelect(a.id); setOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-[rgb(var(--surface-2))] transition-colors text-left ${a.id === selectedId ? 'bg-[rgb(var(--surface-2))]' : ''}`}
              >
                <Avatar initials={a.initials} color={a.avatarColor} size={36} />
                <div>
                  <div className="text-sm font-medium text-[rgb(var(--text))]">{a.name}</div>
                  <div className="text-xs text-muted">{a.position}</div>
                </div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
