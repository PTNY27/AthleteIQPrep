import { useState } from 'react';
import { performanceDemands, footballPositions, rugbyPositions } from '@/lib/demoData';
import { SectionTitle } from '@/components/ui';
import { Target, Dumbbell, Zap, Activity, HeartPulse, Shield } from 'lucide-react';
import type { Sport, Position, PerformanceDemand } from '@/lib/types';

const categoryIcons: Record<string, React.ReactNode> = {
  volume: <Activity size={16} />,
  intensity: <Zap size={16} />,
  frequency: <Target size={16} />,
  physiological: <HeartPulse size={16} />,
  contact: <Shield size={16} />,
};

const categoryColors: Record<string, string> = {
  volume: 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-300',
  intensity: 'bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-300',
  frequency: 'bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-300',
  physiological: 'bg-teal-100 dark:bg-teal-900/30 text-teal-600 dark:text-teal-300',
  contact: 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-300',
};

export function PerformanceDemands() {
  const [sport, setSport] = useState<Sport | null>(null);
  const [position, setPosition] = useState<Position | null>(null);

  const positions = sport === 'football' ? footballPositions : sport === 'rugby' ? rugbyPositions : [];
  const demands: PerformanceDemand[] = position ? performanceDemands[position] || [] : [];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Performance Demands</h1>
        <p className="text-sm text-muted mt-1">What does the sport and position require? Start with demands, not technology.</p>
      </div>

      {/* Step 1: Sport selection */}
      <div className="card p-5">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-7 h-7 rounded-full bg-[rgb(var(--primary))] text-white flex items-center justify-center text-sm font-bold">1</div>
          <h2 className="font-semibold text-[rgb(var(--text))]">Select Sport</h2>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <SportButton
            label="Football"
            description="Association football — outfield and goalkeeper positions"
            active={sport === 'football'}
            onClick={() => { setSport('football'); setPosition(null); }}
            icon={<Dumbbell size={24} />}
          />
          <SportButton
            label="Rugby"
            description="Rugby union — forwards and backs positions"
            active={sport === 'rugby'}
            onClick={() => { setSport('rugby'); setPosition(null); }}
            icon={<Shield size={24} />}
          />
        </div>
      </div>

      {/* Step 2: Position selection */}
      {sport && (
        <div className="card p-5 animate-slide-up">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-full bg-[rgb(var(--primary))] text-white flex items-center justify-center text-sm font-bold">2</div>
            <h2 className="font-semibold text-[rgb(var(--text))]">Select Position</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {positions.map((pos) => (
              <button
                key={pos}
                onClick={() => setPosition(pos)}
                className={`px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                  position === pos
                    ? 'bg-[rgb(var(--primary))] text-white shadow-sm'
                    : 'surface-2 text-muted hover:text-[rgb(var(--text))]'
                }`}
              >
                {pos}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Step 3: Performance demands */}
      {position && demands.length > 0 && (
        <div className="card p-5 animate-slide-up">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-7 h-7 rounded-full bg-[rgb(var(--primary))] text-white flex items-center justify-center text-sm font-bold">3</div>
            <h2 className="font-semibold text-[rgb(var(--text))]">Performance Demands — {position}</h2>
          </div>

          <p className="text-sm text-muted mb-4">
            These demands define what should be measured. The performance-demand model determines the monitoring approach.
          </p>

          {/* Category groups */}
          {['volume', 'intensity', 'frequency', 'physiological', 'contact'].map((cat) => {
            const catDemands = demands.filter((d) => d.category === cat);
            if (catDemands.length === 0) return null;
            return (
              <div key={cat} className="mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <span className={`w-8 h-8 rounded-lg flex items-center justify-center ${categoryColors[cat]}`}>
                    {categoryIcons[cat]}
                  </span>
                  <h3 className="text-sm font-semibold text-[rgb(var(--text))] capitalize">{cat} Demands</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {catDemands.map((d) => (
                    <div key={d.label} className="surface-2 rounded-xl p-4">
                      <div className="flex items-start justify-between mb-2">
                        <span className="text-sm font-medium text-[rgb(var(--text))]">{d.label}</span>
                        <span className="text-sm font-bold text-[rgb(var(--primary))] whitespace-nowrap ml-2">
                          {d.value}{d.unit && ` ${d.unit}`}
                        </span>
                      </div>
                      <p className="text-xs text-muted">{d.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {/* What should be measured */}
          <div className="mt-6 pt-6 border-t border-[rgb(var(--border))]">
            <div className="flex items-center gap-2 mb-3">
              <Target size={18} className="text-[rgb(var(--primary))]" />
              <h3 className="text-sm font-semibold text-[rgb(var(--text))]">What Should Be Measured</h3>
            </div>
            <p className="text-sm text-muted mb-4">
              Based on the performance demands above, the following metrics should be monitored:
            </p>
            <div className="flex flex-wrap gap-2">
              {demands.map((d) => (
                <span key={d.label} className="px-3 py-1.5 rounded-full text-xs font-medium bg-[rgb(var(--primary-light))] text-[rgb(var(--primary))]">
                  {d.label}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {!sport && (
        <div className="card p-12 text-center">
          <Target size={48} className="mx-auto text-subtle mb-4" />
          <p className="text-muted">Select a sport above to begin the performance-demand analysis.</p>
          <p className="text-xs text-subtle mt-2">Sport → Position → Performance Demands → What to Measure</p>
        </div>
      )}
    </div>
  );
}

function SportButton({ label, description, active, onClick, icon }: { label: string; description: string; active: boolean; onClick: () => void; icon: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`p-5 rounded-2xl text-left transition-all border-2 ${
        active
          ? 'border-[rgb(var(--primary))] bg-[rgb(var(--primary-light))]'
          : 'border-[rgb(var(--border))] surface hover:border-[rgb(var(--primary))]/50'
      }`}
    >
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
        active ? 'bg-[rgb(var(--primary))] text-white' : 'surface-2 text-muted'
      }`}>
        {icon}
      </div>
      <h3 className="font-bold text-[rgb(var(--text))] text-lg">{label}</h3>
      <p className="text-xs text-muted mt-1">{description}</p>
    </button>
  );
}
