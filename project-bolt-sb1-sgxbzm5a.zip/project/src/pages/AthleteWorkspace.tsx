import { useState } from 'react';
import {
  getDevelopmentPriorities, getAthleteDevelopmentPlans, createDevelopmentPlan,
  activatePlan, pausePlan, completePlan, getGoalsForAthlete, createGoal, updateGoal,
  getSessionsForAthlete, createSession, completeSession, cancelSession, updateSession, suggestSessionStructure,
  getNotesForAthlete, createNote, deleteNote,
  getDecisionsForAthlete, recordCoachDecision,
  getDevelopmentProgress, getPlanVsActual,
  getReviewsForAthlete, createDevelopmentReview, generateReviewSummary,
  getObjectivesForPlan, createObjective, updateObjective,
  draftDevelopmentReport, getAuditTrail,
  type DevelopmentPrioritySuggestion,
} from '@/lib/coachEngine';
import { getAllAthletes, getAllTrainingSessions, getAllMatchRecords, getAllCapacityTests, computeReadiness, computeDataQuality, computeSimilarity } from '@/lib/extendedData';
import { computeLoads, getLoadStatus, computeTrainingAverages, computeMatchAverages } from '@/lib/demoData';
import { generateAthleteProfile } from '@/lib/intelligenceEngine';
import { Avatar, SportBadge, StatusBadge, SectionTitle, ReadinessBadge, DataQualityBadge } from '@/components/ui';
import { RadarChart } from '@/components/charts/Charts';
import {
  Target, Flag, ClipboardList, FileText, Calendar, Plus, Check, X, Edit3, Clock,
  TrendingUp, TrendingDown, AlertTriangle, ShieldCheck, Sparkles, FileCheck,
  ChevronRight, Activity, StickyNote, MessageSquare, RefreshCw, Download,
} from 'lucide-react';
import type { PageKey } from '@/components/Sidebar';
import type {
  PlanStatus, ObjectivePriority, NoteCategory, NoteVisibility,
  CoachDecisionType, ReviewDecision, SessionBlock,
} from '@/lib/types';

interface AthleteWorkspaceProps {
  athleteId: string;
  onNavigate: (page: PageKey) => void;
}

type Tab = 'overview' | 'insights' | 'priorities' | 'plan' | 'goals' | 'sessions' | 'notes' | 'progress' | 'review' | 'report';

export function AthleteWorkspace({ athleteId, onNavigate }: AthleteWorkspaceProps) {
  const [tab, setTab] = useState<Tab>('overview');
  const [refreshKey, setRefreshKey] = useState(0);
  const refresh = () => setRefreshKey((k) => k + 1);

  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === athleteId) ?? athletes[0];
  const sessions = getAllTrainingSessions(athlete.id);
  const matches = getAllMatchRecords(athlete.id);
  const tests = getAllCapacityTests(athlete.id);
  const { acute, chronic, acwr } = computeLoads(sessions);
  const status = getLoadStatus(acute, chronic);
  const readiness = computeReadiness(athlete.id);
  const dataQuality = computeDataQuality(athlete.id);
  const profile = generateAthleteProfile({ athlete, sessions, matches, tests, interventions: [] });

  const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
    { key: 'overview', label: 'Overview', icon: <Activity size={16} /> },
    { key: 'insights', label: 'Insights', icon: <Sparkles size={16} /> },
    { key: 'priorities', label: 'Priorities', icon: <Flag size={16} /> },
    { key: 'plan', label: 'Development Plan', icon: <FileText size={16} /> },
    { key: 'goals', label: 'Goals', icon: <Target size={16} /> },
    { key: 'sessions', label: 'Sessions', icon: <Calendar size={16} /> },
    { key: 'notes', label: 'Notes', icon: <StickyNote size={16} /> },
    { key: 'progress', label: 'Progress', icon: <TrendingUp size={16} /> },
    { key: 'review', label: 'Review', icon: <FileCheck size={16} /> },
    { key: 'report', label: 'Report', icon: <Download size={16} /> },
  ];

  return (
    <div className="space-y-6 animate-fade-in" key={refreshKey}>
      {/* Header */}
      <div className="card p-6">
        <div className="flex flex-col lg:flex-row lg:items-center gap-4">
          <Avatar initials={athlete.initials} color={athlete.avatarColor} size={64} />
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-[rgb(var(--text))]">{athlete.name}</h1>
            <div className="flex flex-wrap items-center gap-2 mt-2">
              <SportBadge sport={athlete.sport} />
              <span className="text-sm text-muted">{athlete.position}</span>
              <span className="text-sm text-subtle">·</span>
              <span className="text-sm text-muted">{athlete.age} years</span>
              <span className="text-sm text-subtle">·</span>
              <span className="text-sm text-muted">Level: {profile.overallLevel}</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="text-xs text-muted uppercase tracking-wider">Load</div>
              <div className="mt-1"><StatusBadge status={status} /></div>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted uppercase tracking-wider">Readiness</div>
              <div className="mt-1"><ReadinessBadge status={readiness.status} /></div>
            </div>
            <div className="text-right">
              <div className="text-xs text-muted uppercase tracking-wider">Data</div>
              <div className="mt-1"><DataQualityBadge status={dataQuality.status} /></div>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Bar */}
      <div className="flex flex-wrap gap-1 surface rounded-xl p-1.5 sticky top-2 z-20">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === t.key
                ? 'bg-[rgb(var(--primary))] text-white shadow-sm'
                : 'text-muted hover:bg-[rgb(var(--surface-2))] hover:text-[rgb(var(--text))]'
            }`}
          >
            {t.icon}
            <span className="hidden sm:inline">{t.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {tab === 'overview' && <OverviewTab athleteId={athlete.id} profile={profile} tests={tests} />}
      {tab === 'insights' && <InsightsTab athleteId={athlete.id} />}
      {tab === 'priorities' && <PrioritiesTab athleteId={athlete.id} onRefresh={refresh} />}
      {tab === 'plan' && <PlanTab athleteId={athlete.id} onRefresh={refresh} />}
      {tab === 'goals' && <GoalsTab athleteId={athlete.id} onRefresh={refresh} />}
      {tab === 'sessions' && <SessionsTab athleteId={athlete.id} onRefresh={refresh} />}
      {tab === 'notes' && <NotesTab athleteId={athlete.id} onRefresh={refresh} />}
      {tab === 'progress' && <ProgressTab athleteId={athlete.id} />}
      {tab === 'review' && <ReviewTab athleteId={athlete.id} onRefresh={refresh} />}
      {tab === 'report' && <ReportTab athleteId={athlete.id} />}
    </div>
  );
}

// ===== OVERVIEW TAB =====
function OverviewTab({ athleteId, profile, tests }: { athleteId: string; profile: ReturnType<typeof generateAthleteProfile>; tests: ReturnType<typeof getAllCapacityTests> }) {
  const radarData = tests.slice(0, 6).map((t) => ({
    label: t.name.length > 12 ? t.name.split(' ')[0] : t.name,
    value: t.higherIsBetter ? (t.latest / t.benchmark) * 100 : (t.benchmark / t.latest) * 100,
    max: 100,
  }));

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <SectionTitle title="Capacity Profile" subtitle="Performance vs positional benchmark" />
          <RadarChart data={radarData} size={280} />
          <p className="text-xs text-muted text-center mt-2">% of positional benchmark achieved</p>
        </div>
        <div className="card p-5">
          <SectionTitle title="Strengths & Development Areas" subtitle="From Stage 6 interpretation" />
          <div className="space-y-3">
            {profile.strengths.length > 0 && (
              <div>
                <div className="text-xs font-semibold text-emerald-500 uppercase mb-2">Strengths</div>
                {profile.strengths.slice(0, 4).map((s, i) => (
                  <div key={i} className="flex items-center justify-between surface-2 rounded-lg p-2.5 mb-1.5">
                    <span className="text-sm text-[rgb(var(--text))]">{s.metric}</span>
                    <span className="text-xs font-semibold text-emerald-500">{s.level}</span>
                  </div>
                ))}
              </div>
            )}
            {profile.developmentAreas.length > 0 && (
              <div>
                <div className="text-xs font-semibold text-amber-500 uppercase mb-2 mt-3">Development Areas</div>
                {profile.developmentAreas.slice(0, 4).map((d, i) => (
                  <div key={i} className="flex items-center justify-between surface-2 rounded-lg p-2.5 mb-1.5">
                    <span className="text-sm text-[rgb(var(--text))]">{d.metric}</span>
                    <span className="text-xs font-semibold text-amber-500">{d.level}</span>
                  </div>
                ))}
              </div>
            )}
            {profile.criticalWeaknesses.length > 0 && (
              <div>
                <div className="text-xs font-semibold text-red-500 uppercase mb-2 mt-3">Critical Weaknesses</div>
                {profile.criticalWeaknesses.slice(0, 4).map((c, i) => (
                  <div key={i} className="flex items-center justify-between surface-2 rounded-lg p-2.5 mb-1.5">
                    <span className="text-sm text-[rgb(var(--text))]">{c.metric}</span>
                    <span className="text-xs font-semibold text-red-500">{c.level}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      <div className="card p-5">
        <SectionTitle title="Data Sufficiency" subtitle="Evidence quality for this athlete" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <MetricBox label="Sessions" value={profile.dataSufficiency.sessions.toString()} />
          <MetricBox label="Matches" value={profile.dataSufficiency.matches.toString()} />
          <MetricBox label="Capacity Tests" value={profile.dataSufficiency.capacityTests.toString()} />
          <MetricBox label="Data Level" value={profile.dataSufficiency.level} />
        </div>
        <p className="text-xs text-muted mt-3">{profile.dataSufficiency.reason}</p>
      </div>
    </div>
  );
}

// ===== INSIGHTS TAB =====
function InsightsTab({ athleteId }: { athleteId: string }) {
  const athlete = getAllAthletes().find((a) => a.id === athleteId)!;
  const sessions = getAllTrainingSessions(athleteId);
  const matches = getAllMatchRecords(athleteId);
  const tests = getAllCapacityTests(athleteId);
  const profile = generateAthleteProfile({ athlete, sessions, matches, tests, interventions: [] });

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <SectionTitle title="Trends" subtitle="Stage 6 trend analysis for each capacity metric" />
        <div className="space-y-2">
          {profile.trends.map((t, i) => (
            <div key={i} className="surface-2 rounded-xl p-3">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium text-[rgb(var(--text))]">{t.metric}</span>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                  t.trend === 'IMPROVING' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' :
                  t.trend === 'DECLINING' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' :
                  'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300'
                }`}>{t.trend}</span>
              </div>
              <p className="text-xs text-muted">{t.evidence}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="card p-5">
        <SectionTitle title="Gap Analysis" subtitle="Training vs match demand gaps" />
        <div className="space-y-2">
          {profile.gaps.map((g, i) => (
            <div key={i} className="surface-2 rounded-xl p-3">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium text-[rgb(var(--text))]">{g.metric}</span>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                  g.gapStatus === 'UNDEREXPOSURE' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' :
                  g.gapStatus === 'EXCESSIVE' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' :
                  'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300'
                }`}>{g.gapStatus}</span>
              </div>
              <p className="text-xs text-muted">{g.evidence}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ===== PRIORITIES TAB (Coach Decision Gate) =====
function PrioritiesTab({ athleteId, onRefresh }: { athleteId: string; onRefresh: () => void }) {
  const priorities = getDevelopmentPriorities(athleteId);
  const decisions = getDecisionsForAthlete(athleteId);
  const [rationaleMap, setRationaleMap] = useState<Record<string, string>>({});
  const [editMap, setEditMap] = useState<Record<string, string>>({});
  const [decidedSet, setDecidedSet] = useState<Set<string>>(new Set());

  const handleDecision = (priority: DevelopmentPrioritySuggestion, decision: CoachDecisionType) => {
    const rationale = rationaleMap[priority.metric];
    const finalDecision = decision === 'edited' ? editMap[priority.metric] : undefined;
    recordCoachDecision({
      athleteId,
      recommendationType: 'priority',
      decision,
      originalSuggestion: priority.recommendation,
      finalDecision,
      rationale,
    });
    setDecidedSet((prev) => new Set(prev).add(priority.metric));
    onRefresh();
  };

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <SectionTitle title="Development Priorities" subtitle="Stage 6 analysis — review and decide on each priority" />
        <div className="flex items-center gap-2 mb-4 text-xs text-muted">
          <Sparkles size={14} className="text-amber-500" />
          AI SUGGESTION — These priorities were generated from validated Stage 5A data and Stage 6 analysis.
        </div>
        {priorities.length === 0 ? (
          <p className="text-sm text-muted py-4">No development priorities identified. Insufficient data or all metrics at target.</p>
        ) : (
          <div className="space-y-4">
            {priorities.map((p, i) => {
              const decided = decidedSet.has(p.metric);
              return (
                <div key={i} className="surface-2 rounded-xl p-4 border-l-4 border-l-amber-500">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-[rgb(var(--text))]">{p.metric}</span>
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${p.priority === 'HIGH' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300'}`}>
                      {p.priority}
                    </span>
                  </div>
                  <div className="text-xs text-muted mb-2">
                    <span className="font-semibold">Evidence:</span> {p.evidence}
                  </div>
                  <div className="text-xs text-muted mb-2">
                    <span className="font-semibold">Data Confidence:</span> {p.confidence}
                  </div>
                  <div className="rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3 mb-3">
                    <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1">AI SUGGESTION</div>
                    <p className="text-sm text-[rgb(var(--text))]">{p.recommendation}</p>
                    {p.targetValue !== undefined && (
                      <p className="text-xs text-muted mt-1">Suggested target: {p.targetValue} {p.targetUnit}</p>
                    )}
                  </div>
                  {decided ? (
                    <div className="flex items-center gap-2 text-sm text-emerald-500 font-semibold">
                      <Check size={16} /> Decision recorded
                    </div>
                  ) : (
                    <>
                      <textarea
                        placeholder="Optional rationale for override/reject..."
                        value={rationaleMap[p.metric] ?? ''}
                        onChange={(e) => setRationaleMap((prev) => ({ ...prev, [p.metric]: e.target.value }))}
                        className="w-full surface-2 rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none mb-2 min-h-[40px]"
                      />
                      <div className="flex flex-wrap gap-2">
                        <button onClick={() => handleDecision(p, 'accepted')} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-100 text-emerald-700 hover:bg-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-300 transition-colors">
                          <Check size={14} /> Accept
                        </button>
                        <button onClick={() => handleDecision(p, 'edited')} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-100 text-blue-700 hover:bg-blue-200 dark:bg-blue-900/30 dark:text-blue-300 transition-colors">
                          <Edit3 size={14} /> Edit & Apply
                        </button>
                        <button onClick={() => handleDecision(p, 'rejected')} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-300 transition-colors">
                          <X size={14} /> Reject
                        </button>
                        <button onClick={() => handleDecision(p, 'deferred')} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-300 transition-colors">
                          <Clock size={14} /> Defer
                        </button>
                      </div>
                      {editMap[p.metric] === undefined && (
                        <textarea
                          placeholder="Edit the suggestion before applying..."
                          value={editMap[p.metric] ?? ''}
                          onChange={(e) => setEditMap((prev) => ({ ...prev, [p.metric]: e.target.value }))}
                          className="w-full surface-2 rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none mt-2 min-h-[40px]"
                        />
                      )}
                    </>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Decision History */}
      {decisions.length > 0 && (
        <div className="card p-5">
          <SectionTitle title="Decision History" subtitle="Coach decisions on AI recommendations" />
          <div className="space-y-2">
            {decisions.slice(0, 10).map((d, i) => (
              <div key={i} className="surface-2 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${d.decision === 'accepted' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : d.decision === 'rejected' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' : d.decision === 'edited' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300' : 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300'}`}>
                    {d.decision}
                  </span>
                  <span className="text-xs text-muted">{new Date(d.createdAt).toLocaleDateString()}</span>
                </div>
                <p className="text-xs text-muted">Original: {d.originalSuggestion}</p>
                {d.finalDecision && <p className="text-xs text-[rgb(var(--text))] mt-1">Final: {d.finalDecision}</p>}
                {d.rationale && <p className="text-xs text-muted italic mt-1">Rationale: {d.rationale}</p>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ===== PLAN TAB =====
function PlanTab({ athleteId, onRefresh }: { athleteId: string; onRefresh: () => void }) {
  const plans = getAthleteDevelopmentPlans(athleteId);
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reviewDate, setReviewDate] = useState('');
  const [reassessmentDate, setReassessmentDate] = useState('');
  const [coachNotes, setCoachNotes] = useState('');

  const handleCreate = () => {
    if (!name || !startDate || !endDate) return;
    createDevelopmentPlan({ athleteId, name, startDate, endDate, reviewDate: reviewDate || undefined, reassessmentDate: reassessmentDate || undefined, coachNotes: coachNotes || undefined });
    setName(''); setStartDate(''); setEndDate(''); setReviewDate(''); setReassessmentDate(''); setCoachNotes('');
    setShowCreate(false);
    onRefresh();
  };

  const statusColors: Record<PlanStatus, string> = {
    DRAFT: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
    ACTIVE: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    PAUSED: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
    COMPLETED: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
    ARCHIVED: 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400',
  };

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <SectionTitle title="Individual Development Plans" subtitle="Coach-controlled development plans" action={
          <button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1">
            <Plus size={14} /> New Plan
          </button>
        } />

        {showCreate && (
          <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Plan name" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted block mb-1">Start Date</label>
                <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
              </div>
              <div>
                <label className="text-xs text-muted block mb-1">End Date</label>
                <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-muted block mb-1">Review Date (optional)</label>
                <input type="date" value={reviewDate} onChange={(e) => setReviewDate(e.target.value)} className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
              </div>
              <div>
                <label className="text-xs text-muted block mb-1">Reassessment Date (optional)</label>
                <input type="date" value={reassessmentDate} onChange={(e) => setReassessmentDate(e.target.value)} className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
              </div>
            </div>
            <textarea value={coachNotes} onChange={(e) => setCoachNotes(e.target.value)} placeholder="Coach notes (optional)" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none min-h-[60px]" />
            <div className="flex gap-2">
              <button onClick={handleCreate} className="btn-primary text-xs">Create as Draft</button>
              <button onClick={() => setShowCreate(false)} className="btn-ghost text-xs">Cancel</button>
            </div>
          </div>
        )}

        {plans.length === 0 ? (
          <p className="text-sm text-muted py-4">No development plans yet. Create one to get started.</p>
        ) : (
          <div className="space-y-3">
            {plans.map((plan) => {
              const objectives = getObjectivesForPlan(plan.id);
              return (
                <div key={plan.id} className="surface-2 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-[rgb(var(--text))]">{plan.name}</span>
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${statusColors[plan.status]}`}>{plan.status}</span>
                  </div>
                  <div className="text-xs text-muted mb-2">
                    {plan.startDate} → {plan.endDate}
                    {plan.reviewDate && <span className="ml-2">· Review: {plan.reviewDate}</span>}
                    {plan.reassessmentDate && <span className="ml-2">· Reassess: {plan.reassessmentDate}</span>}
                  </div>
                  {plan.coachNotes && <p className="text-xs text-muted italic mb-2">{plan.coachNotes}</p>}
                  {objectives.length > 0 && (
                    <div className="mt-2 space-y-1.5">
                      <div className="text-xs font-semibold text-muted uppercase">Objectives</div>
                      {objectives.map((obj) => (
                        <div key={obj.id} className="flex items-center justify-between surface rounded-lg p-2">
                          <div>
                            <span className="text-sm text-[rgb(var(--text))]">{obj.title}</span>
                            {obj.aiGenerated && <span className="ml-2 text-xs text-amber-500">AI</span>}
                          </div>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${obj.priority === 'HIGH' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' : obj.priority === 'MEDIUM' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' : 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300'}`}>{obj.priority}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="flex flex-wrap gap-2 mt-3">
                    {plan.status === 'DRAFT' && <button onClick={() => { activatePlan(plan.id); onRefresh(); }} className="btn-primary text-xs">Activate</button>}
                    {plan.status === 'ACTIVE' && <button onClick={() => { pausePlan(plan.id); onRefresh(); }} className="btn-ghost text-xs">Pause</button>}
                    {plan.status === 'ACTIVE' && <button onClick={() => { completePlan(plan.id); onRefresh(); }} className="btn-ghost text-xs">Complete</button>}
                    {plan.status === 'PAUSED' && <button onClick={() => { activatePlan(plan.id); onRefresh(); }} className="btn-primary text-xs">Resume</button>}
                    {plan.status !== 'ARCHIVED' && <button onClick={() => { completePlan(plan.id); onRefresh(); }} className="btn-ghost text-xs">Archive</button>}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ===== GOALS TAB =====
function GoalsTab({ athleteId, onRefresh }: { athleteId: string; onRefresh: () => void }) {
  const goals = getGoalsForAthlete(athleteId);
  const [showCreate, setShowCreate] = useState(false);
  const [metric, setMetric] = useState('');
  const [baseline, setBaseline] = useState('');
  const [target, setTarget] = useState('');
  const [unit, setUnit] = useState('');
  const [targetDate, setTargetDate] = useState('');
  const [priority, setPriority] = useState<ObjectivePriority>('MEDIUM');

  const handleCreate = () => {
    if (!metric || !targetDate) return;
    createGoal({
      athleteId,
      metric,
      baseline: baseline ? parseFloat(baseline) : undefined,
      target: target ? parseFloat(target) : undefined,
      unit: unit || undefined,
      targetDate,
      priority,
    });
    setMetric(''); setBaseline(''); setTarget(''); setUnit(''); setTargetDate(''); setPriority('MEDIUM');
    setShowCreate(false);
    onRefresh();
  };

  const statusColors: Record<string, string> = {
    NOT_STARTED: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
    IN_PROGRESS: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
    ON_TRACK: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    AT_RISK: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300',
    ACHIEVED: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    CLOSED: 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400',
  };

  return (
    <div className="card p-5">
        <SectionTitle title="Goals" subtitle="Measurable development goals" action={
          <button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1">
            <Plus size={14} /> New Goal
          </button>
        } />

        {showCreate && (
          <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
            <input value={metric} onChange={(e) => setMetric(e.target.value)} placeholder="Metric (e.g. 30m Sprint)" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            <div className="grid grid-cols-3 gap-3">
              <input value={baseline} onChange={(e) => setBaseline(e.target.value)} placeholder="Baseline" type="number" className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
              <input value={target} onChange={(e) => setTarget(e.target.value)} placeholder="Target" type="number" className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
              <input value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="Unit" className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <input type="date" value={targetDate} onChange={(e) => setTargetDate(e.target.value)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
              <select value={priority} onChange={(e) => setPriority(e.target.value as ObjectivePriority)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none">
                <option value="HIGH">High Priority</option>
                <option value="MEDIUM">Medium Priority</option>
                <option value="LOW">Low Priority</option>
              </select>
            </div>
            <div className="flex gap-2">
              <button onClick={handleCreate} className="btn-primary text-xs">Create Goal</button>
              <button onClick={() => setShowCreate(false)} className="btn-ghost text-xs">Cancel</button>
            </div>
          </div>
        )}

        {goals.length === 0 ? (
          <p className="text-sm text-muted py-4">No goals yet. Create one to track progress.</p>
        ) : (
          <div className="space-y-3">
            {goals.map((g) => (
              <div key={g.id} className="surface-2 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <span className="text-sm font-bold text-[rgb(var(--text))]">{g.metric}</span>
                    {g.aiGenerated && <span className="ml-2 text-xs text-amber-500">AI suggested</span>}
                  </div>
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${statusColors[g.status]}`}>{g.status}</span>
                </div>
                <div className="text-xs text-muted mb-2">
                  {g.baseline ?? '?'} → {g.target ?? '?'} {g.unit ?? ''} by {g.targetDate}
                </div>
                <div className="flex flex-wrap gap-2">
                  <button onClick={() => { updateGoal(g.id, { status: 'IN_PROGRESS' }); onRefresh(); }} className="btn-ghost text-xs">In Progress</button>
                  <button onClick={() => { updateGoal(g.id, { status: 'ON_TRACK' }); onRefresh(); }} className="btn-ghost text-xs">On Track</button>
                  <button onClick={() => { updateGoal(g.id, { status: 'AT_RISK' }); onRefresh(); }} className="btn-ghost text-xs">At Risk</button>
                  <button onClick={() => { updateGoal(g.id, { status: 'ACHIEVED' }); onRefresh(); }} className="btn-ghost text-xs">Achieved</button>
                  <button onClick={() => { updateGoal(g.id, { status: 'CLOSED' }); onRefresh(); }} className="btn-ghost text-xs">Close</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
  );
}

// ===== SESSIONS TAB =====
function SessionsTab({ athleteId, onRefresh }: { athleteId: string; onRefresh: () => void }) {
  const athleteSessions = getSessionsForAthlete(athleteId);
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [duration, setDuration] = useState('90');
  const [objective, setObjective] = useState('');
  const [location, setLocation] = useState('');
  const [aiStructure, setAiStructure] = useState<SessionBlock[] | null>(null);

  const handleCreate = () => {
    if (!name || !date) return;
    createSession({
      athleteId,
      date,
      duration: parseInt(duration) || 90,
      name,
      objective: objective || undefined,
      location: location || undefined,
      structure: aiStructure ?? undefined,
      aiGenerated: aiStructure !== null,
    });
    setName(''); setDate(''); setDuration('90'); setObjective(''); setLocation(''); setAiStructure(null);
    setShowCreate(false);
    onRefresh();
  };

  const handleAISuggest = () => {
    const result = suggestSessionStructure(athleteId, objective || 'general development');
    setAiStructure(result.blocks);
  };

  const statusColors: Record<string, string> = {
    PLANNED: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
    IN_PROGRESS: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
    COMPLETED: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    CANCELLED: 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400',
    MISSED: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300',
  };

  return (
    <div className="card p-5">
        <SectionTitle title="Coaching Sessions" subtitle="Plan and track training sessions" action={
          <button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1">
            <Plus size={14} /> New Session
          </button>
        } />

        {showCreate && (
          <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Session name" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            <div className="grid grid-cols-3 gap-3">
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
              <input type="number" value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="Duration (min)" className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
              <input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Location" className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            </div>
            <input value={objective} onChange={(e) => setObjective(e.target.value)} placeholder="Session objective" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            <div className="flex items-center gap-2">
              <button onClick={handleAISuggest} className="btn-ghost text-xs flex items-center gap-1">
                <Sparkles size={14} className="text-amber-500" /> AI Suggest Structure
              </button>
              {aiStructure && (
                <span className="text-xs text-amber-500">AI structure loaded — coach can edit before saving</span>
              )}
            </div>
            {aiStructure && (
              <div className="surface rounded-lg p-3 space-y-2">
                {aiStructure.map((block, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-muted w-6">{i + 1}.</span>
                    <span className="text-sm text-[rgb(var(--text))] flex-1">{block.name}</span>
                    <span className="text-xs text-muted">{block.duration} min</span>
                  </div>
                ))}
              </div>
            )}
            <div className="flex gap-2">
              <button onClick={handleCreate} className="btn-primary text-xs">Create Session</button>
              <button onClick={() => setShowCreate(false)} className="btn-ghost text-xs">Cancel</button>
            </div>
          </div>
        )}

        {athleteSessions.length === 0 ? (
          <p className="text-sm text-muted py-4">No sessions planned yet.</p>
        ) : (
          <div className="space-y-3">
            {athleteSessions.sort((a, b) => b.date.localeCompare(a.date)).map((s) => (
              <div key={s.id} className="surface-2 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <span className="text-sm font-bold text-[rgb(var(--text))]">{s.name}</span>
                    {s.aiGenerated && <span className="ml-2 text-xs text-amber-500">AI assisted</span>}
                  </div>
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${statusColors[s.status]}`}>{s.status}</span>
                </div>
                <div className="text-xs text-muted mb-2">
                  {s.date} · {s.duration} min {s.location && `· ${s.location}`}
                </div>
                {s.objective && <div className="text-xs text-muted mb-2">Objective: {s.objective}</div>}
                {s.structure.length > 0 && (
                  <div className="surface rounded-lg p-2 mb-2">
                    {s.structure.map((block, i) => (
                      <div key={i} className="flex items-center gap-2 text-xs">
                        <span className="text-muted w-6">{i + 1}.</span>
                        <span className="text-[rgb(var(--text))] flex-1">{block.name}</span>
                        <span className="text-muted">{block.duration} min</span>
                      </div>
                    ))}
                  </div>
                )}
                <div className="flex flex-wrap gap-2">
                  {s.status === 'PLANNED' && <button onClick={() => { completeSession(s.id); onRefresh(); }} className="btn-ghost text-xs">Mark Complete</button>}
                  {s.status === 'PLANNED' && <button onClick={() => { cancelSession(s.id); onRefresh(); }} className="btn-ghost text-xs">Cancel</button>}
                  {s.status === 'PLANNED' && <button onClick={() => { updateSession(s.id, { status: 'MISSED' }); onRefresh(); }} className="btn-ghost text-xs">Mark Missed</button>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
  );
}

// ===== NOTES TAB =====
function NotesTab({ athleteId, onRefresh }: { athleteId: string; onRefresh: () => void }) {
  const notes = getNotesForAthlete(athleteId);
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<NoteCategory>('observation');
  const [visibility, setVisibility] = useState<NoteVisibility>('private');

  const handleAdd = () => {
    if (!content) return;
    createNote({ athleteId, category, visibility, content });
    setContent('');
    onRefresh();
  };

  const categoryLabels: Record<NoteCategory, string> = {
    observation: 'Observation', session: 'Session', behaviour: 'Behaviour', tactical: 'Tactical',
    technical: 'Technical', training_response: 'Training Response', development: 'Development', review: 'Review',
  };

  return (
    <div className="card p-5">
        <SectionTitle title="Coach Notes" subtitle="Timestamped observations and comments" />

        <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
          <div className="flex flex-wrap gap-2">
            <select value={category} onChange={(e) => setCategory(e.target.value as NoteCategory)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none">
              {(Object.keys(categoryLabels) as NoteCategory[]).map((c) => <option key={c} value={c}>{categoryLabels[c]}</option>)}
            </select>
            <select value={visibility} onChange={(e) => setVisibility(e.target.value as NoteVisibility)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none">
              <option value="private">Private</option>
              <option value="shared">Shared with athlete</option>
              <option value="staff">Staff only</option>
            </select>
          </div>
          <textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Write a note..." className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none min-h-[60px]" />
          <button onClick={handleAdd} className="btn-primary text-xs flex items-center gap-1"><Plus size={14} /> Add Note</button>
        </div>

        {notes.length === 0 ? (
          <p className="text-sm text-muted py-4">No notes recorded yet.</p>
        ) : (
          <div className="space-y-2">
            {notes.map((n) => (
              <div key={n.id} className="surface-2 rounded-xl p-3">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-muted">{categoryLabels[n.category]}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${n.visibility === 'private' ? 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400' : n.visibility === 'shared' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300'}`}>{n.visibility}</span>
                  </div>
                  <button onClick={() => { deleteNote(n.id); onRefresh(); }} className="text-muted hover:text-red-500 transition-colors"><X size={14} /></button>
                </div>
                <p className="text-sm text-[rgb(var(--text))]">{n.content}</p>
                <div className="text-xs text-muted mt-1">{new Date(n.createdAt).toLocaleString()}</div>
              </div>
            ))}
          </div>
        )}
      </div>
  );
}

// ===== PROGRESS TAB =====
function ProgressTab({ athleteId }: { athleteId: string }) {
  const progress = getDevelopmentProgress(athleteId);
  const planVsActual = getPlanVsActual(athleteId);

  const statusColors: Record<string, string> = {
    ON_TRACK: 'text-emerald-500', IMPROVING: 'text-emerald-500', STABLE: 'text-blue-500',
    BEHIND: 'text-amber-500', AT_RISK: 'text-red-500', ACHIEVED: 'text-emerald-500', NO_DATA: 'text-muted',
  };

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <SectionTitle title="Plan vs Actual" subtitle="Training session completion" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <MetricBox label="Planned" value={planVsActual.planned.toString()} />
          <MetricBox label="Completed" value={planVsActual.completed.toString()} />
          <MetricBox label="Missed" value={planVsActual.missed.toString()} />
          <MetricBox label="Completion Rate" value={`${planVsActual.completionRate}%`} />
        </div>
      </div>
      <div className="card p-5">
        <SectionTitle title="Progress Monitoring" subtitle="Target vs current for each goal" />
        {progress.length === 0 ? (
          <p className="text-sm text-muted py-4">No progress data. Create goals to track progress.</p>
        ) : (
          <div className="space-y-3">
            {progress.map((p, i) => (
              <div key={i} className="surface-2 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-[rgb(var(--text))]">{p.metric}</span>
                  <span className={`text-xs font-semibold ${statusColors[p.status]}`}>{p.status}</span>
                </div>
                <div className="text-xs text-muted mb-2">
                  {p.baseline ?? '?'} → {p.current ?? '?'} / {p.target ?? '?'} {p.unit ?? ''}
                </div>
                <div className="w-full h-2 bg-[rgb(var(--surface-2))] rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-700" style={{
                    width: `${Math.min(100, p.progress)}%`,
                    backgroundColor: p.status === 'AT_RISK' ? 'rgb(var(--error))' : p.status === 'ACHIEVED' || p.status === 'ON_TRACK' ? 'rgb(var(--success))' : 'rgb(var(--warning))',
                  }} />
                </div>
                <div className="text-xs text-muted mt-1">{Math.round(p.progress)}% progress</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ===== REVIEW TAB =====
function ReviewTab({ athleteId, onRefresh }: { athleteId: string; onRefresh: () => void }) {
  const reviews = getReviewsForAthlete(athleteId);
  const [showCreate, setShowCreate] = useState(false);
  const [reviewDate, setReviewDate] = useState('');
  const [coachObservations, setCoachObservations] = useState('');
  const [decision, setDecision] = useState<ReviewDecision>('continue');
  const [aiSummary, setAiSummary] = useState('');
  const [showAISummary, setShowAISummary] = useState(false);

  const handleGenerateAI = () => {
    const result = generateReviewSummary(athleteId);
    setAiSummary(result.summary);
    setShowAISummary(true);
  };

  const handleCreate = () => {
    if (!reviewDate) return;
    createDevelopmentReview({
      athleteId,
      reviewDate,
      coachObservations: coachObservations || undefined,
      coachDecision: decision,
      aiGeneratedSummary: aiSummary || undefined,
      aiGenerated: aiSummary !== '',
    });
    setReviewDate(''); setCoachObservations(''); setAiSummary(''); setShowAISummary(false);
    setShowCreate(false);
    onRefresh();
  };

  const decisionLabels: Record<ReviewDecision, string> = {
    continue: 'Continue', modify: 'Modify', increase_difficulty: 'Increase Difficulty',
    reduce_difficulty: 'Reduce Difficulty', change_priority: 'Change Priority',
    close_objective: 'Close Objective', create_new_objective: 'Create New Objective',
    reassess_later: 'Reassess Later',
  };

  return (
    <div className="card p-5">
        <SectionTitle title="Development Reviews" subtitle="Formal coach review workflow" action={
          <button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1">
            <Plus size={14} /> New Review
          </button>
        } />

        {showCreate && (
          <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
            <div className="flex items-center gap-2">
              <button onClick={handleGenerateAI} className="btn-ghost text-xs flex items-center gap-1">
                <Sparkles size={14} className="text-amber-500" /> Generate AI Review Summary
              </button>
            </div>
            {showAISummary && aiSummary && (
              <div className="rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3">
                <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1">AI-GENERATED DRAFT — Review before saving</div>
                <pre className="text-xs text-[rgb(var(--text))] whitespace-pre-wrap">{aiSummary}</pre>
              </div>
            )}
            <div>
              <label className="text-xs text-muted block mb-1">Review Date</label>
              <input type="date" value={reviewDate} onChange={(e) => setReviewDate(e.target.value)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
            </div>
            <textarea value={coachObservations} onChange={(e) => setCoachObservations(e.target.value)} placeholder="Coach observations" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none min-h-[80px]" />
            <select value={decision} onChange={(e) => setDecision(e.target.value as ReviewDecision)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none">
              {(Object.keys(decisionLabels) as ReviewDecision[]).map((d) => <option key={d} value={d}>{decisionLabels[d]}</option>)}
            </select>
            <div className="flex gap-2">
              <button onClick={handleCreate} className="btn-primary text-xs">Save Review</button>
              <button onClick={() => setShowCreate(false)} className="btn-ghost text-xs">Cancel</button>
            </div>
          </div>
        )}

        {reviews.length === 0 ? (
          <p className="text-sm text-muted py-4">No reviews recorded yet.</p>
        ) : (
          <div className="space-y-3">
            {reviews.map((r) => (
              <div key={r.id} className="surface-2 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-bold text-[rgb(var(--text))]">{r.reviewDate}</span>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">{decisionLabels[r.coachDecision]}</span>
                </div>
                {r.aiGeneratedSummary && (
                  <div className="rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-2 mb-2">
                    <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1">AI-GENERATED SUMMARY</div>
                    <pre className="text-xs text-[rgb(var(--text))] whitespace-pre-wrap">{r.aiGeneratedSummary.slice(0, 200)}...</pre>
                  </div>
                )}
                {r.coachObservations && <p className="text-sm text-[rgb(var(--text))]">{r.coachObservations}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
  );
}

// ===== REPORT TAB =====
function ReportTab({ athleteId }: { athleteId: string }) {
  const [report, setReport] = useState('');
  const [generated, setGenerated] = useState(false);

  const handleGenerate = () => {
    const result = draftDevelopmentReport(athleteId);
    setReport(result.report);
    setGenerated(true);
  };

  const handleCopy = () => {
    navigator.clipboard?.writeText(report);
  };

  return (
    <div className="card p-5">
        <SectionTitle title="Development Report" subtitle="AI-drafted, coach-approved athlete report" />

        {!generated ? (
          <div className="text-center py-8">
            <FileText size={48} className="text-muted mx-auto mb-4" />
            <p className="text-sm text-muted mb-4">Generate an AI-drafted report from validated Stage 5A data and Stage 6 analysis.</p>
            <button onClick={handleGenerate} className="btn-primary text-sm flex items-center gap-2 mx-auto">
              <Sparkles size={16} className="text-amber-300" /> Generate AI Draft Report
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3">
              <div className="text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1">AI-GENERATED DRAFT — Coach must review and approve before use</div>
            </div>
            <textarea value={report} onChange={(e) => setReport(e.target.value)} className="w-full surface-2 rounded-xl p-4 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none min-h-[400px] font-mono" />
            <div className="flex flex-wrap gap-2">
              <button onClick={handleCopy} className="btn-primary text-xs flex items-center gap-1"><Download size={14} /> Copy Report</button>
              <button onClick={handleGenerate} className="btn-ghost text-xs flex items-center gap-1"><RefreshCw size={14} /> Regenerate</button>
            </div>
          </div>
        )}
      </div>
  );
}

// ===== SHARED =====
function MetricBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="surface-2 rounded-xl p-3">
      <div className="text-xs text-muted">{label}</div>
      <div className="text-lg font-bold text-[rgb(var(--text))] mt-1">{value}</div>
    </div>
  );
}
