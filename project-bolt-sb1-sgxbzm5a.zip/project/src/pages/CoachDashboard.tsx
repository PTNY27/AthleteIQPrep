import { useState } from 'react';
import {
  getCoachAthleteSummaries, getAttentionRequired, getRecentActivity, getUpcoming,
  getDevelopmentPriorities, type CoachAthleteSummary, type AttentionItem,
} from '@/lib/coachEngine';
import { getAllAthletes, getAllTrainingSessions, getAllMatchRecords, getAllInsightsList, computeSquadOverview, computeReadiness, computeDataQuality } from '@/lib/extendedData';
import { computeLoads, getLoadStatus } from '@/lib/demoData';
import { KpiCard, StatusBadge, Avatar, SportBadge, SectionTitle, ReadinessBadge, DataQualityBadge } from '@/components/ui';
import { Users, AlertTriangle, Target, Activity, Calendar, Clock, ChevronRight, ClipboardList, TrendingUp, CheckCircle2, Flag, Bell } from 'lucide-react';
import type { PageKey } from '@/components/Sidebar';

interface CoachDashboardProps {
  selectedAthleteId: string;
  onNavigate: (page: PageKey) => void;
  onSelectAthlete: (id: string) => void;
}

export function CoachDashboard({ onNavigate, onSelectAthlete }: CoachDashboardProps) {
  const summaries = getCoachAthleteSummaries();
  const attentionItems = getAttentionRequired();
  const recentActivity = getRecentActivity(8);
  const upcoming = getUpcoming(6);

  const totalAthletes = summaries.length;
  const attentionCount = attentionItems.length;
  const activePlans = summaries.filter((s) => s.activePlanCount > 0).length;
  const activeGoals = summaries.reduce((sum, s) => sum + s.activeGoalCount, 0);

  const topPriorities = summaries.slice(0, 4).flatMap((s) => {
    const priorities = getDevelopmentPriorities(s.athlete.id).slice(0, 1);
    return priorities.map((p) => ({ ...p, athleteName: s.athlete.name, athleteId: s.athlete.id }));
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Coach Dashboard</h1>
        <p className="text-sm text-muted mt-1">Your athletes, priorities and actions at a glance</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="My Athletes" value={totalAthletes.toString()} unit="" sublabel={`${activePlans} with active plans`} icon={<Users size={20} />} color="rgb(var(--chart-1))" />
        <KpiCard label="Attention Required" value={attentionCount.toString()} unit="" sublabel={attentionCount > 0 ? 'Review needed' : 'All clear'} icon={<AlertTriangle size={20} />} color="rgb(var(--error))" />
        <KpiCard label="Active Goals" value={activeGoals.toString()} unit="" sublabel="In progress" icon={<Target size={20} />} color="rgb(var(--chart-2))" />
        <KpiCard label="Upcoming" value={upcoming.length.toString()} unit="" sublabel="Next 7 days" icon={<Calendar size={20} />} color="rgb(var(--chart-3))" />
      </div>

      {/* Attention Required */}
      <div className="card p-5">
        <SectionTitle title="Attention Required" subtitle="Athletes needing coach review" action={
          <button onClick={() => onNavigate('athletes')} className="btn-ghost text-xs">All Athletes →</button>
        } />
        {attentionItems.length === 0 ? (
          <div className="flex items-center gap-2 text-sm text-muted py-4">
            <CheckCircle2 size={18} className="text-emerald-500" />
            No items require immediate attention.
          </div>
        ) : (
          <div className="space-y-2">
            {attentionItems.slice(0, 6).map((item, i) => (
              <AttentionRow key={i} item={item} onSelect={onSelectAthlete} />
            ))}
          </div>
        )}
      </div>

      {/* My Athletes */}
      <div className="card p-5">
        <SectionTitle title="My Athletes" subtitle="Quick access to athletes under your responsibility" action={
          <button onClick={() => onNavigate('athletes')} className="btn-ghost text-xs">All Athletes →</button>
        } />
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgb(var(--border))]">
                <th className="text-left py-3 px-3 font-medium text-muted">Athlete</th>
                <th className="text-center py-3 px-3 font-medium text-muted hidden sm:table-cell">Load</th>
                <th className="text-center py-3 px-3 font-medium text-muted">Readiness</th>
                <th className="text-center py-3 px-3 font-medium text-muted hidden md:table-cell">Plans</th>
                <th className="text-center py-3 px-3 font-medium text-muted hidden md:table-cell">Goals</th>
                <th className="text-center py-3 px-3 font-medium text-muted hidden lg:table-cell">Flags</th>
              </tr>
            </thead>
            <tbody>
              {summaries.map((s) => (
                <tr key={s.athlete.id} className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))] transition-colors cursor-pointer" onClick={() => onSelectAthlete(s.athlete.id)}>
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2">
                      <Avatar initials={s.athlete.initials} color={s.athlete.avatarColor} size={32} />
                      <div>
                        <div className="font-medium text-[rgb(var(--text))]">{s.athlete.name}</div>
                        <div className="text-xs text-muted sm:hidden">{s.athlete.position}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-center hidden sm:table-cell"><StatusBadge status={s.loadStatus} /></td>
                  <td className="py-3 px-3 text-center"><ReadinessBadge status={s.readiness.status} /></td>
                  <td className="py-3 px-3 text-center hidden md:table-cell text-[rgb(var(--text))]">{s.activePlanCount}</td>
                  <td className="py-3 px-3 text-center hidden md:table-cell text-[rgb(var(--text))]">{s.activeGoalCount}</td>
                  <td className="py-3 px-3 text-center hidden lg:table-cell">
                    {s.attentionFlags.length > 0 ? (
                      <span className="inline-flex items-center gap-1 text-xs text-amber-500 font-semibold">
                        <Flag size={12} /> {s.attentionFlags.length}
                      </span>
                    ) : (
                      <span className="text-xs text-muted">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Development Priorities + Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <SectionTitle title="Development Priorities" subtitle="Top athlete priorities from Stage 6 analysis" />
          {topPriorities.length === 0 ? (
            <p className="text-sm text-muted py-4">No priorities identified yet.</p>
          ) : (
            <div className="space-y-3">
              {topPriorities.map((p, i) => (
                <div key={i} className="surface-2 rounded-xl p-3 cursor-pointer hover:border-[rgb(var(--primary))] transition-all" onClick={() => onSelectAthlete(p.athleteId)}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-semibold text-[rgb(var(--text))]">{p.athleteName}</span>
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${p.priority === 'HIGH' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' : p.priority === 'MEDIUM' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' : 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300'}`}>
                      {p.priority}
                    </span>
                  </div>
                  <div className="text-sm text-[rgb(var(--text))]">{p.metric}</div>
                  <div className="text-xs text-muted mt-1">{p.evidence}</div>
                  <div className="text-xs text-muted mt-1 italic">AI SUGGESTION: {p.recommendation}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card p-5">
          <SectionTitle title="Recent Activity" subtitle="Latest coaching actions and updates" />
          {recentActivity.length === 0 ? (
            <p className="text-sm text-muted py-4">No recent activity.</p>
          ) : (
            <div className="space-y-2">
              {recentActivity.map((a, i) => (
                <div key={i} className="flex items-start gap-3 surface-2 rounded-lg p-2.5">
                  <ActivityIcon type={a.type} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-[rgb(var(--text))] truncate">{a.description}</div>
                    <div className="text-xs text-muted">{a.athleteName} · {new Date(a.timestamp).toLocaleDateString()}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Upcoming */}
      <div className="card p-5">
        <SectionTitle title="Upcoming" subtitle="Scheduled sessions, reviews and deadlines" />
        {upcoming.length === 0 ? (
          <p className="text-sm text-muted py-4">Nothing upcoming.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {upcoming.map((u, i) => (
              <div key={i} className="surface-2 rounded-xl p-3 cursor-pointer hover:border-[rgb(var(--primary))] transition-all" onClick={() => onSelectAthlete(u.athleteId)}>
                <div className="flex items-center gap-2 mb-1">
                  <Clock size={14} className="text-subtle" />
                  <span className="text-xs text-muted">{new Date(u.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</span>
                </div>
                <div className="text-sm font-medium text-[rgb(var(--text))]">{u.description}</div>
                <div className="text-xs text-muted mt-0.5">{u.athleteName}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function AttentionRow({ item, onSelect }: { item: AttentionItem; onSelect: (id: string) => void }) {
  const sevColor = item.severity === 'high' ? 'border-l-red-500' : item.severity === 'medium' ? 'border-l-amber-500' : 'border-l-blue-500';
  return (
    <div className={`surface-2 rounded-xl p-3 border-l-4 ${sevColor} cursor-pointer hover:border-[rgb(var(--primary))] transition-all`} onClick={() => onSelect(item.athleteId)}>
      <div className="flex items-center justify-between">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-[rgb(var(--text))]">{item.athleteName}</span>
            <span className={`text-xs px-2 py-0.5 rounded-full ${item.severity === 'high' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' : item.severity === 'medium' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' : 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300'}`}>
              {item.severity}
            </span>
          </div>
          <p className="text-xs text-muted mt-1">{item.message}</p>
        </div>
        <ChevronRight size={16} className="text-subtle shrink-0" />
      </div>
    </div>
  );
}

function ActivityIcon({ type }: { type: string }) {
  const icons: Record<string, React.ReactNode> = {
    note: <ClipboardList size={16} className="text-blue-500" />,
    training: <Activity size={16} className="text-emerald-500" />,
    decision: <CheckCircle2 size={16} className="text-amber-500" />,
    goal_progress: <Target size={16} className="text-purple-500" />,
    feedback: <TrendingUp size={16} className="text-teal-500" />,
    reassessment: <Bell size={16} className="text-orange-500" />,
    assessment: <ClipboardList size={16} className="text-blue-500" />,
    plan_update: <ClipboardList size={16} className="text-blue-500" />,
  };
  return <span className="mt-0.5 shrink-0">{icons[type] ?? <Activity size={16} className="text-muted" />}</span>;
}
