import { useState } from 'react';
import {
  getCurrentUser, updateCurrentUser, getUserPreferences, updateUserPreferences,
  getAppearance, updateAppearance, getAccessibility, updateAccessibility,
  getOrganisation, updateOrganisation,
  getProgrammes, createProgramme, updateProgramme, deleteProgramme,
  getTeams, createTeam, updateTeam, deleteTeam,
  getAgeGroups, createAgeGroup, updateAgeGroup, deleteAgeGroup,
  getRoles, hasPermission, getRoleLabel,
  getNotificationPreferences, updateNotificationPreference,
  getNotificationRules, updateNotificationRule,
  getBenchmarks, createBenchmark, updateBenchmark, archiveBenchmark,
  getKPIs, createKPI, updateKPI, deleteKPI,
  getAIConfig, updateAIConfig,
  getPrivacyConfig, updatePrivacyConfig,
  getReportConfig, updateReportConfig,
  getDataRetention, updateDataRetention,
  getDataQualityThresholds, updateDataQualityThresholds,
  getFeatureFlags, updateFeatureFlag,
  getSeasons, createSeason, updateSeason,
  getCompetitions, createCompetition,
  getTaskConfig, updateTaskConfig,
  getScoutingSettings, updateScoutingSettings,
  getDevelopmentSettings, updateDevelopmentSettings,
  getPerformanceSettings, updatePerformanceSettings,
  getIntegrations, updateIntegration,
  getSystemStatus,
  getConfigVersions, createConfigVersion,
  getSettingsAuditLog,
  getConfigurationHealth,
  getUsers, updateUserRole, toggleUserActive,
} from '@/lib/settingsEngine';
import { SPORT_LIST } from '@/lib/sportConfig';
import { Avatar, SectionTitle } from '@/components/ui';
import { DataSources } from '@/pages/DataSources';
import { ImportData } from '@/pages/ImportData';
import { DataQualityCentre } from '@/pages/DataQualityCentre';
import { ImportHistory } from '@/pages/ImportHistory';
import {
  User, Building2, Users, Shield, Activity, TrendingUp, Search, Bell,
  Sparkles, Database, Eye, FileText, Settings as SettingsIcon, Plus, Trash2,
  CheckCircle2, XCircle, AlertTriangle, ChevronRight, Lock, Globe,
  Palette, Accessibility as AccessibilityIcon, Calendar, Flag,
  History, Server, Zap, Save, RotateCcw, Upload, ShieldCheck,
} from 'lucide-react';
import type {
  UserRole, AppearanceMode, InterfaceDensity, MeasurementSystem,
  DateFormat, TimeFormat, NotificationChannel, EvidenceConfidence,
} from '@/lib/types';

type SettingsSection =
  | 'overview' | 'account' | 'preferences' | 'appearance' | 'accessibility'
  | 'language' | 'organisation' | 'programmes' | 'teams' | 'sports'
  | 'age-groups' | 'users' | 'roles' | 'permissions'
  | 'performance' | 'development' | 'scouting'
  | 'ai' | 'notifications' | 'data' | 'privacy' | 'reports'
  | 'seasons' | 'feature-flags' | 'integrations' | 'system' | 'audit' | 'versions'
  | 'data-sources' | 'import' | 'data-quality' | 'import-history';

const SECTIONS: { group: string; items: { key: SettingsSection; label: string; icon: React.ReactNode }[] }[] = [
  {
    group: 'Account',
    items: [
      { key: 'account', label: 'Profile', icon: <User size={16} /> },
      { key: 'preferences', label: 'Preferences', icon: <SettingsIcon size={16} /> },
      { key: 'appearance', label: 'Appearance', icon: <Palette size={16} /> },
      { key: 'accessibility', label: 'Accessibility', icon: <AccessibilityIcon size={16} /> },
      { key: 'language', label: 'Language & Region', icon: <Globe size={16} /> },
    ],
  },
  {
    group: 'Organisation',
    items: [
      { key: 'organisation', label: 'Organisation Profile', icon: <Building2 size={16} /> },
      { key: 'programmes', label: 'Programmes', icon: <Flag size={16} /> },
      { key: 'teams', label: 'Teams', icon: <Users size={16} /> },
      { key: 'sports', label: 'Sports', icon: <Activity size={16} /> },
      { key: 'age-groups', label: 'Age Groups', icon: <Calendar size={16} /> },
    ],
  },
  {
    group: 'Users & Access',
    items: [
      { key: 'users', label: 'Users', icon: <Users size={16} /> },
      { key: 'roles', label: 'Roles', icon: <Shield size={16} /> },
      { key: 'permissions', label: 'Permissions', icon: <Lock size={16} /> },
    ],
  },
  {
    group: 'Configuration',
    items: [
      { key: 'performance', label: 'Performance', icon: <TrendingUp size={16} /> },
      { key: 'development', label: 'Development', icon: <TrendingUp size={16} /> },
      { key: 'scouting', label: 'Scouting & Recruitment', icon: <Search size={16} /> },
      { key: 'seasons', label: 'Seasons & Competitions', icon: <Calendar size={16} /> },
    ],
  },
  {
    group: 'Data Pipeline',
    items: [
      { key: 'data-sources', label: 'Data Sources', icon: <Database size={16} /> },
      { key: 'import', label: 'Import Data', icon: <Upload size={16} /> },
      { key: 'data-quality', label: 'Data Quality', icon: <ShieldCheck size={16} /> },
      { key: 'import-history', label: 'Import History', icon: <History size={16} /> },
    ],
  },
  {
    group: 'Platform',
    items: [
      { key: 'ai', label: 'AI Settings', icon: <Sparkles size={16} /> },
      { key: 'notifications', label: 'Notifications', icon: <Bell size={16} /> },
      { key: 'data', label: 'Data Management', icon: <Database size={16} /> },
      { key: 'privacy', label: 'Privacy & Security', icon: <Eye size={16} /> },
      { key: 'reports', label: 'Reports', icon: <FileText size={16} /> },
      { key: 'feature-flags', label: 'Feature Flags', icon: <Zap size={16} /> },
      { key: 'integrations', label: 'Integrations', icon: <Server size={16} /> },
      { key: 'system', label: 'System Status', icon: <Server size={16} /> },
    ],
  },
  {
    group: 'Governance',
    items: [
      { key: 'audit', label: 'Settings Audit Log', icon: <History size={16} /> },
      { key: 'versions', label: 'Configuration Versions', icon: <RotateCcw size={16} /> },
    ],
  },
];

export function SettingsPage() {
  const [section, setSection] = useState<SettingsSection>('overview');
  const [refreshKey, setRefreshKey] = useState(0);
  const refresh = () => setRefreshKey((k) => k + 1);
  const user = getCurrentUser();

  return (
    <div className="flex flex-col lg:flex-row gap-6 animate-fade-in" key={refreshKey}>
      <div className="lg:w-64 shrink-0">
        <div className="card p-4 lg:sticky lg:top-8">
          <h1 className="text-lg font-bold text-[rgb(var(--text))] mb-1">Settings</h1>
          <p className="text-xs text-muted mb-4">Platform configuration & governance</p>
          <div className="space-y-4 max-h-[70vh] overflow-y-auto scrollbar-thin">
            {SECTIONS.map((sg) => (
              <div key={sg.group}>
                <div className="text-xs font-semibold text-subtle uppercase tracking-wider px-2 mb-1">{sg.group}</div>
                <div className="space-y-0.5">
                  {sg.items.map((item) => (
                    <button key={item.key} onClick={() => setSection(item.key)}
                      className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm font-medium transition-all ${
                        section === item.key ? 'bg-[rgb(var(--primary))] text-white' : 'text-muted hover:bg-[rgb(var(--surface-2))] hover:text-[rgb(var(--text))]'
                      }`}>
                      {item.icon}{item.label}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1 min-w-0">
        {section === 'overview' && <OverviewSection onNavigate={setSection} />}
        {section === 'account' && <AccountSection onRefresh={refresh} />}
        {section === 'preferences' && <PreferencesSection onRefresh={refresh} />}
        {section === 'appearance' && <AppearanceSection onRefresh={refresh} />}
        {section === 'accessibility' && <AccessibilitySection onRefresh={refresh} />}
        {section === 'language' && <LanguageSection onRefresh={refresh} />}
        {section === 'organisation' && <OrganisationSection onRefresh={refresh} />}
        {section === 'programmes' && <ProgrammesSection onRefresh={refresh} />}
        {section === 'teams' && <TeamsSection onRefresh={refresh} />}
        {section === 'sports' && <SportsSection />}
        {section === 'age-groups' && <AgeGroupsSection onRefresh={refresh} />}
        {section === 'users' && <UsersSection onRefresh={refresh} />}
        {section === 'roles' && <RolesSection />}
        {section === 'permissions' && <PermissionsSection />}
        {section === 'performance' && <PerformanceSection onRefresh={refresh} />}
        {section === 'development' && <DevelopmentSection onRefresh={refresh} />}
        {section === 'scouting' && <ScoutingSection onRefresh={refresh} />}
        {section === 'ai' && <AISection onRefresh={refresh} />}
        {section === 'notifications' && <NotificationsSection onRefresh={refresh} />}
        {section === 'data' && <DataSection onRefresh={refresh} />}
        {section === 'privacy' && <PrivacySection onRefresh={refresh} />}
        {section === 'reports' && <ReportsSection onRefresh={refresh} />}
        {section === 'seasons' && <SeasonsSection onRefresh={refresh} />}
        {section === 'feature-flags' && <FeatureFlagsSection onRefresh={refresh} />}
        {section === 'integrations' && <IntegrationsSection onRefresh={refresh} />}
        {section === 'system' && <SystemSection />}
        {section === 'audit' && <AuditSection />}
        {section === 'versions' && <VersionsSection onRefresh={refresh} />}
        {section === 'data-sources' && <DataSources />}
        {section === 'import' && <ImportData />}
        {section === 'data-quality' && <DataQualityCentre />}
        {section === 'import-history' && <ImportHistory />}
      </div>
    </div>
  );
}

// ===== OVERVIEW =====
function OverviewSection({ onNavigate }: { onNavigate: (s: SettingsSection) => void }) {
  const health = getConfigurationHealth();
  const user = getCurrentUser();
  const org = getOrganisation();
  const users = getUsers();
  const programmes = getProgrammes();
  const teams = getTeams();

  const healthIcon = (status: string) => status === 'healthy' ? <CheckCircle2 size={16} className="text-emerald-500" /> : status === 'attention_required' ? <AlertTriangle size={16} className="text-amber-500" /> : <XCircle size={16} className="text-red-500" />;

  return (
    <div className="space-y-4">
      <div className="card p-6">
        <div className="flex items-center gap-4 mb-4">
          <Avatar initials={user.initials} color={user.avatarColor} size={56} />
          <div>
            <h2 className="text-xl font-bold text-[rgb(var(--text))]">{user.name}</h2>
            <p className="text-sm text-muted">{user.jobTitle} · {getRoleLabel(user.role)}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="surface-2 rounded-xl p-3 text-center"><div className="text-2xl font-bold text-[rgb(var(--text))]">{org.name.slice(0, 12)}</div><div className="text-xs text-muted">Organisation</div></div>
          <div className="surface-2 rounded-xl p-3 text-center"><div className="text-2xl font-bold text-[rgb(var(--text))]">{users.length}</div><div className="text-xs text-muted">Users</div></div>
          <div className="surface-2 rounded-xl p-3 text-center"><div className="text-2xl font-bold text-[rgb(var(--text))]">{programmes.length}</div><div className="text-xs text-muted">Programmes</div></div>
          <div className="surface-2 rounded-xl p-3 text-center"><div className="text-2xl font-bold text-[rgb(var(--text))]">{teams.length}</div><div className="text-xs text-muted">Teams</div></div>
        </div>
      </div>

      <div className="card p-5">
        <SectionTitle title="Configuration Health" subtitle="Status of platform configuration areas" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {health.map((h, i) => (
            <div key={i} className="surface-2 rounded-xl p-3 flex items-center gap-3">
              {healthIcon(h.status)}
              <div className="flex-1">
                <div className="text-sm font-medium text-[rgb(var(--text))]">{h.category}</div>
                <div className="text-xs text-muted">{h.detail}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="card p-5">
        <SectionTitle title="Quick Links" subtitle="Jump to common settings" />
        <div className="flex flex-wrap gap-2">
          <button onClick={() => onNavigate('account')} className="btn-ghost text-xs flex items-center gap-1"><User size={14} /> Profile</button>
          <button onClick={() => onNavigate('organisation')} className="btn-ghost text-xs flex items-center gap-1"><Building2 size={14} /> Organisation</button>
          <button onClick={() => onNavigate('ai')} className="btn-ghost text-xs flex items-center gap-1"><Sparkles size={14} /> AI Settings</button>
          <button onClick={() => onNavigate('privacy')} className="btn-ghost text-xs flex items-center gap-1"><Eye size={14} /> Privacy</button>
          <button onClick={() => onNavigate('audit')} className="btn-ghost text-xs flex items-center gap-1"><History size={14} /> Audit Log</button>
        </div>
      </div>
    </div>
  );
}

// ===== ACCOUNT =====
function AccountSection({ onRefresh }: { onRefresh: () => void }) {
  const user = getCurrentUser();
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [jobTitle, setJobTitle] = useState(user.jobTitle);

  const save = () => {
    updateCurrentUser({ name, email, jobTitle });
    onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Account Profile" subtitle="Manage your personal account information" />
      <div className="flex items-center gap-4 mb-6">
        <Avatar initials={user.initials} color={user.avatarColor} size={64} />
        <div>
          <div className="text-sm font-bold text-[rgb(var(--text))]">{user.name}</div>
          <div className="text-xs text-muted">{getRoleLabel(user.role)}</div>
        </div>
      </div>
      <div className="space-y-3">
        <div>
          <label className="text-xs text-muted block mb-1">Display Name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
        </div>
        <div>
          <label className="text-xs text-muted block mb-1">Email</label>
          <input value={email} onChange={(e) => setEmail(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
        </div>
        <div>
          <label className="text-xs text-muted block mb-1">Job Title</label>
          <input value={jobTitle} onChange={(e) => setJobTitle(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] focus:outline-none" />
        </div>
        <button onClick={save} className="btn-primary text-xs flex items-center gap-1"><Save size={14} /> Save Changes</button>
      </div>
    </div>
  );
}

// ===== PREFERENCES =====
function PreferencesSection({ onRefresh }: { onRefresh: () => void }) {
  const prefs = getUserPreferences();
  const [landing, setLanding] = useState(prefs.defaultLandingPage);
  const [dateRange, setDateRange] = useState(prefs.defaultDateRange);
  const [density, setDensity] = useState<InterfaceDensity>(prefs.tableDensity);

  const save = () => {
    updateUserPreferences({ defaultLandingPage: landing, defaultDateRange: dateRange, tableDensity: density });
    onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Personal Preferences" subtitle="Customise your default experience" />
      <div className="space-y-3">
        <div>
          <label className="text-xs text-muted block mb-1">Default Landing Page</label>
          <select value={landing} onChange={(e) => setLanding(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            <option value="coach-dashboard">Coach Dashboard</option>
            <option value="dashboard">Performance Dashboard</option>
            <option value="athletes">My Athletes</option>
            <option value="scouting">Scouting Workspace</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-muted block mb-1">Default Date Range</label>
          <select value={dateRange} onChange={(e) => setDateRange(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            <option value="7d">7 Days</option><option value="14d">14 Days</option><option value="28d">28 Days</option><option value="6w">6 Weeks</option><option value="season">Season</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-muted block mb-1">Table Density</label>
          <select value={density} onChange={(e) => setDensity(e.target.value as InterfaceDensity)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            <option value="comfortable">Comfortable</option><option value="compact">Compact</option>
          </select>
        </div>
        <button onClick={save} className="btn-primary text-xs flex items-center gap-1"><Save size={14} /> Save Preferences</button>
      </div>
    </div>
  );
}

// ===== APPEARANCE =====
function AppearanceSection({ onRefresh }: { onRefresh: () => void }) {
  const app = getAppearance();
  const [mode, setMode] = useState<AppearanceMode>(app.mode);
  const [density, setDensity] = useState<InterfaceDensity>(app.density);
  const [textSize, setTextSize] = useState(app.textSize);
  const [reducedMotion, setReducedMotion] = useState(app.reducedMotion);

  const save = () => {
    updateAppearance({ mode, density, textSize, reducedMotion });
    onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Appearance" subtitle="Customise the visual interface" />
      <div className="space-y-3">
        <div>
          <label className="text-xs text-muted block mb-1">Theme Mode</label>
          <select value={mode} onChange={(e) => setMode(e.target.value as AppearanceMode)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            <option value="light">Light</option><option value="dark">Dark</option><option value="system">System</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-muted block mb-1">Interface Density</label>
          <select value={density} onChange={(e) => setDensity(e.target.value as InterfaceDensity)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            <option value="comfortable">Comfortable</option><option value="compact">Compact</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-muted block mb-1">Text Size</label>
          <select value={textSize} onChange={(e) => setTextSize(e.target.value as 'small' | 'medium' | 'large')} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            <option value="small">Small</option><option value="medium">Medium</option><option value="large">Large</option>
          </select>
        </div>
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]">
          <input type="checkbox" checked={reducedMotion} onChange={(e) => setReducedMotion(e.target.checked)} className="accent-[rgb(var(--primary))]" />
          Reduced Motion
        </label>
        <button onClick={save} className="btn-primary text-xs flex items-center gap-1"><Save size={14} /> Save Appearance</button>
      </div>
    </div>
  );
}

// ===== ACCESSIBILITY =====
function AccessibilitySection({ onRefresh }: { onRefresh: () => void }) {
  const acc = getAccessibility();
  const [textScaling, setTextScaling] = useState(acc.textScaling);
  const [reducedMotion, setReducedMotion] = useState(acc.reducedMotion);
  const [keyboardNav, setKeyboardNav] = useState(acc.keyboardNavigation);
  const [highContrast, setHighContrast] = useState(acc.highContrast);
  const [focusIndicators, setFocusIndicators] = useState(acc.focusIndicators);
  const [chartAcc, setChartAcc] = useState(acc.chartAccessibility);

  const save = () => {
    updateAccessibility({ textScaling, reducedMotion, keyboardNavigation: keyboardNav, highContrast, focusIndicators, chartAccessibility: chartAcc });
    onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Accessibility" subtitle="Configure accessibility options" />
      <div className="space-y-3">
        <div>
          <label className="text-xs text-muted block mb-1">Text Scaling ({textScaling.toFixed(2)}x)</label>
          <input type="range" min="0.75" max="1.5" step="0.05" value={textScaling} onChange={(e) => setTextScaling(parseFloat(e.target.value))} className="w-full accent-[rgb(var(--primary))]" />
        </div>
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={reducedMotion} onChange={(e) => setReducedMotion(e.target.checked)} className="accent-[rgb(var(--primary))]" /> Reduced Motion</label>
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={keyboardNav} onChange={(e) => setKeyboardNav(e.target.checked)} className="accent-[rgb(var(--primary))]" /> Enhanced Keyboard Navigation</label>
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={highContrast} onChange={(e) => setHighContrast(e.target.checked)} className="accent-[rgb(var(--primary))]" /> High Contrast Mode</label>
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={focusIndicators} onChange={(e) => setFocusIndicators(e.target.checked)} className="accent-[rgb(var(--primary))]" /> Visible Focus Indicators</label>
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={chartAcc} onChange={(e) => setChartAcc(e.target.checked)} className="accent-[rgb(var(--primary))]" /> Chart Accessibility (text descriptions)</label>
        <button onClick={save} className="btn-primary text-xs flex items-center gap-1"><Save size={14} /> Save Accessibility</button>
      </div>
      <div className="mt-4 rounded-lg bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 p-3">
        <p className="text-xs text-[rgb(var(--text))]">Status is never communicated through colour alone. Trend indicators include arrows and text labels alongside colour.</p>
      </div>
    </div>
  );
}

// ===== LANGUAGE & REGION =====
function LanguageSection({ onRefresh }: { onRefresh: () => void }) {
  const user = getCurrentUser();
  const [timezone, setTimezone] = useState(user.timezone);
  const [language, setLanguage] = useState(user.language);
  const [dateFormat, setDateFormat] = useState<DateFormat>(user.dateFormat);
  const [timeFormat, setTimeFormat] = useState<TimeFormat>(user.timeFormat);
  const [measurement, setMeasurement] = useState<MeasurementSystem>(user.measurementSystem);
  const [firstDay, setFirstDay] = useState(user.firstDayOfWeek);

  const save = () => {
    updateCurrentUser({ timezone, language, dateFormat, timeFormat, measurementSystem: measurement, firstDayOfWeek: firstDay });
    onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Language & Region" subtitle="Configure regional and measurement preferences" />
      <div className="space-y-3">
        <div>
          <label className="text-xs text-muted block mb-1">Timezone</label>
          <select value={timezone} onChange={(e) => setTimezone(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            <option value="Europe/London">Europe/London (GMT)</option><option value="Europe/Paris">Europe/Paris (CET)</option><option value="America/New_York">America/New_York (EST)</option><option value="Australia/Sydney">Australia/Sydney (AEDT)</option><option value="UTC">UTC</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-muted block mb-1">Language</label>
          <select value={language} onChange={(e) => setLanguage(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            <option value="en-GB">English (UK)</option><option value="en-US">English (US)</option><option value="fr-FR">French</option><option value="es-ES">Spanish</option>
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-muted block mb-1">Date Format</label>
            <select value={dateFormat} onChange={(e) => setDateFormat(e.target.value as DateFormat)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
              <option value="DD/MM/YYYY">DD/MM/YYYY</option><option value="MM/DD/YYYY">MM/DD/YYYY</option><option value="YYYY-MM-DD">YYYY-MM-DD</option>
            </select>
          </div>
          <div>
            <label className="text-xs text-muted block mb-1">Time Format</label>
            <select value={timeFormat} onChange={(e) => setTimeFormat(e.target.value as TimeFormat)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
              <option value="24h">24-hour</option><option value="12h">12-hour</option>
            </select>
          </div>
        </div>
        <div>
          <label className="text-xs text-muted block mb-1">Measurement System</label>
          <select value={measurement} onChange={(e) => setMeasurement(e.target.value as MeasurementSystem)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            <option value="metric">Metric (m, kg, km)</option><option value="imperial">Imperial (ft, lb, mi)</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-muted block mb-1">First Day of Week</label>
          <select value={firstDay} onChange={(e) => setFirstDay(parseInt(e.target.value))} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
            <option value={0}>Sunday</option><option value={1}>Monday</option><option value={6}>Saturday</option>
          </select>
        </div>
        <button onClick={save} className="btn-primary text-xs flex items-center gap-1"><Save size={14} /> Save Regional Settings</button>
      </div>
    </div>
  );
}

// ===== ORGANISATION =====
function OrganisationSection({ onRefresh }: { onRefresh: () => void }) {
  const org = getOrganisation();
  const [name, setName] = useState(org.name);
  const [type, setType] = useState(org.type);
  const [country, setCountry] = useState(org.country);
  const [timezone, setTimezone] = useState(org.timezone);
  const [measurement, setMeasurement] = useState<MeasurementSystem>(org.measurementSystem);
  const [defaultSport, setDefaultSport] = useState(org.defaultSport);
  const [description, setDescription] = useState(org.description);
  const [contactEmail, setContactEmail] = useState(org.contactEmail);

  const save = () => {
    updateOrganisation({ name, type, country, timezone, measurementSystem: measurement, defaultSport, description, contactEmail });
    onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Organisation Profile" subtitle="Configure your organisation details" />
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div><label className="text-xs text-muted block mb-1">Organisation Name</label><input value={name} onChange={(e) => setName(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
          <div><label className="text-xs text-muted block mb-1">Type</label><input value={type} onChange={(e) => setType(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="text-xs text-muted block mb-1">Country</label><input value={country} onChange={(e) => setCountry(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
          <div><label className="text-xs text-muted block mb-1">Timezone</label><select value={timezone} onChange={(e) => setTimezone(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none"><option value="Europe/London">Europe/London</option><option value="UTC">UTC</option></select></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="text-xs text-muted block mb-1">Measurement System</label><select value={measurement} onChange={(e) => setMeasurement(e.target.value as MeasurementSystem)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none"><option value="metric">Metric</option><option value="imperial">Imperial</option></select></div>
          <div><label className="text-xs text-muted block mb-1">Default Sport</label><select value={defaultSport} onChange={(e) => setDefaultSport(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">{SPORT_LIST.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}</select></div>
        </div>
        <div><label className="text-xs text-muted block mb-1">Contact Email</label><input value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
        <div><label className="text-xs text-muted block mb-1">Description</label><textarea value={description} onChange={(e) => setDescription(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none min-h-[60px]" /></div>
        <button onClick={save} className="btn-primary text-xs flex items-center gap-1"><Save size={14} /> Save Organisation</button>
      </div>
    </div>
  );
}

// ===== PROGRAMMES =====
function ProgrammesSection({ onRefresh }: { onRefresh: () => void }) {
  const programmes = getProgrammes();
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [sport, setSport] = useState('football');
  const [ageMin, setAgeMin] = useState('');
  const [ageMax, setAgeMax] = useState('');

  const handleCreate = () => {
    if (!name) return;
    createProgramme({ name, type: 'Development', sport, ageMin: parseInt(ageMin) || 0, ageMax: parseInt(ageMax) || 99, objectives: '', reportingCycle: 'Monthly', developmentCycle: '12 weeks', active: true });
    setName(''); setAgeMin(''); setAgeMax(''); setShowCreate(false); onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Programmes" subtitle="Manage development programmes" action={<button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1"><Plus size={14} /> New Programme</button>} />
      {showCreate && (
        <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Programme name" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
          <select value={sport} onChange={(e) => setSport(e.target.value)} className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">{SPORT_LIST.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}</select>
          <div className="grid grid-cols-2 gap-2"><input value={ageMin} onChange={(e) => setAgeMin(e.target.value)} placeholder="Min age" type="number" className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /><input value={ageMax} onChange={(e) => setAgeMax(e.target.value)} placeholder="Max age" type="number" className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
          <button onClick={handleCreate} className="btn-primary text-xs">Create</button>
        </div>
      )}
      <div className="space-y-2">
        {programmes.map((p) => (
          <div key={p.id} className="surface-2 rounded-xl p-3 flex items-center justify-between">
            <div><div className="text-sm font-medium text-[rgb(var(--text))]">{p.name}</div><div className="text-xs text-muted">{p.sport} · Ages {p.ageMin}–{p.ageMax} · {p.reportingCycle}</div></div>
            <div className="flex items-center gap-2"><span className={`text-xs px-2 py-0.5 rounded-full ${p.active ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'}`}>{p.active ? 'Active' : 'Inactive'}</span><button onClick={() => { deleteProgramme(p.id); onRefresh(); }} className="text-muted hover:text-red-500"><Trash2 size={14} /></button></div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== TEAMS =====
function TeamsSection({ onRefresh }: { onRefresh: () => void }) {
  const teams = getTeams();
  const programmes = getProgrammes();
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [sport, setSport] = useState('football');
  const [programmeId, setProgrammeId] = useState(programmes[0]?.id ?? '');
  const [ageGroup, setAgeGroup] = useState('U16');

  const handleCreate = () => {
    if (!name) return;
    createTeam({ name, sport, programmeId, ageGroup, competition: '', coachId: 'user-1', active: true });
    setName(''); setShowCreate(false); onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Teams" subtitle="Manage teams within programmes" action={<button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1"><Plus size={14} /> New Team</button>} />
      {showCreate && (
        <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Team name" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
          <select value={sport} onChange={(e) => setSport(e.target.value)} className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">{SPORT_LIST.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}</select>
          <select value={programmeId} onChange={(e) => setProgrammeId(e.target.value)} className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">{programmes.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
          <button onClick={handleCreate} className="btn-primary text-xs">Create</button>
        </div>
      )}
      <div className="space-y-2">
        {teams.map((t) => (
          <div key={t.id} className="surface-2 rounded-xl p-3 flex items-center justify-between">
            <div><div className="text-sm font-medium text-[rgb(var(--text))]">{t.name}</div><div className="text-xs text-muted">{t.sport} · {t.ageGroup} · {t.competition || 'No competition'}</div></div>
            <button onClick={() => { deleteTeam(t.id); onRefresh(); }} className="text-muted hover:text-red-500"><Trash2 size={14} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== SPORTS =====
function SportsSection() {
  return (
    <div className="card p-5">
      <SectionTitle title="Sport Registry" subtitle="8 sports configured in the central registry" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {SPORT_LIST.map((s) => (
          <div key={s.key} className="surface-2 rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-bold text-[rgb(var(--text))]">{s.label}</span>
              <span className="text-xs text-emerald-500 font-semibold">Active</span>
            </div>
            <div className="text-xs text-muted space-y-0.5">
              <div>Positions: {s.positions.length || (s.isEventBased ? 'Event-based' : 'None')}</div>
              <div>Technical attributes: {s.technicalAttributes.length}</div>
              <div>Tactical attributes: {s.tacticalAttributes.length}</div>
              <div>Physical attributes: {s.physicalAttributes.length}</div>
              <div>Performance metrics: {s.performanceMetrics.length}</div>
              {s.isEventBased && <div>Strokes: {s.strokes?.length ?? 0} · Events: {s.events?.length ?? 0}</div>}
              {s.formats && <div>Formats: {s.formats.join(', ')}</div>}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3">
        <p className="text-xs text-[rgb(var(--text))]">Sports are managed through the central sport registry. All modules reference this registry — no module creates its own sport definitions. Additional sports can be added in future stages without rebuilding the core platform.</p>
      </div>
    </div>
  );
}

// ===== AGE GROUPS =====
function AgeGroupsSection({ onRefresh }: { onRefresh: () => void }) {
  const ageGroups = getAgeGroups();
  const [showCreate, setShowCreate] = useState(false);
  const [label, setLabel] = useState('');
  const [minAge, setMinAge] = useState('');
  const [maxAge, setMaxAge] = useState('');

  const handleCreate = () => {
    if (!label) return;
    createAgeGroup({ label, minAge: parseInt(minAge) || 0, maxAge: parseInt(maxAge) || 99, custom: true, active: true });
    setLabel(''); setMinAge(''); setMaxAge(''); setShowCreate(false); onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Age Groups" subtitle="Configure age group definitions" action={<button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1"><Plus size={14} /> Custom Group</button>} />
      {showCreate && (
        <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
          <input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Age group label" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
          <div className="grid grid-cols-2 gap-2"><input value={minAge} onChange={(e) => setMinAge(e.target.value)} placeholder="Min age" type="number" className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /><input value={maxAge} onChange={(e) => setMaxAge(e.target.value)} placeholder="Max age" type="number" className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
          <button onClick={handleCreate} className="btn-primary text-xs">Create</button>
        </div>
      )}
      <div className="space-y-2">
        {ageGroups.map((a) => (
          <div key={a.key} className="surface-2 rounded-xl p-3 flex items-center justify-between">
            <div><div className="text-sm font-medium text-[rgb(var(--text))]">{a.label}</div><div className="text-xs text-muted">Ages {a.minAge}–{a.maxAge} {a.custom && '· Custom'}</div></div>
            <div className="flex items-center gap-2">
              <span className={`text-xs px-2 py-0.5 rounded-full ${a.active ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'}`}>{a.active ? 'Active' : 'Inactive'}</span>
              {a.custom && <button onClick={() => { deleteAgeGroup(a.key); onRefresh(); }} className="text-muted hover:text-red-500"><Trash2 size={14} /></button>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== USERS =====
function UsersSection({ onRefresh }: { onRefresh: () => void }) {
  const users = getUsers();
  const roles: UserRole[] = ['ADMIN', 'HEAD_COACH', 'COACH', 'SCOUT', 'PERFORMANCE_ANALYST', 'ACADEMY_DIRECTOR', 'READ_ONLY'];

  return (
    <div className="card p-5">
      <SectionTitle title="User Management" subtitle="Manage user accounts and roles" />
      <div className="space-y-2">
        {users.map((u) => (
          <div key={u.id} className="surface-2 rounded-xl p-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar initials={u.initials} color={u.avatarColor} size={36} />
              <div><div className="text-sm font-medium text-[rgb(var(--text))]">{u.name}</div><div className="text-xs text-muted">{u.email}</div></div>
            </div>
            <div className="flex items-center gap-2">
              <select value={u.role} onChange={(e) => { updateUserRole(u.id, e.target.value as UserRole); onRefresh(); }} className="surface rounded-lg p-1.5 text-xs text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">
                {roles.map((r) => <option key={r} value={r}>{getRoleLabel(r)}</option>)}
              </select>
              <span className={`text-xs px-2 py-0.5 rounded-full ${u.active ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'}`}>{u.active ? 'Active' : 'Inactive'}</span>
              <button onClick={() => { toggleUserActive(u.id); onRefresh(); }} className="text-xs text-muted hover:text-[rgb(var(--text))]">{u.active ? 'Deactivate' : 'Activate'}</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== ROLES =====
function RolesSection() {
  const roles = getRoles();
  return (
    <div className="card p-5">
      <SectionTitle title="Role Registry" subtitle="Central role definitions and their permissions" />
      <div className="space-y-2">
        {roles.map((r) => (
          <div key={r.key} className="surface-2 rounded-xl p-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-bold text-[rgb(var(--text))]">{r.label}</span>
              <span className="text-xs text-muted">{r.scopeLevel}</span>
            </div>
            <p className="text-xs text-muted mb-2">{r.description}</p>
            <div className="flex flex-wrap gap-1">
              {r.permissions.map((p) => <span key={p} className="text-xs surface rounded-full px-2 py-0.5 text-muted">{p}</span>)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== PERMISSIONS =====
function PermissionsSection() {
  const user = getCurrentUser();
  const roles = getRoles();
  const userRole = roles.find((r) => r.key === user.role);
  const allPermissions = ['view', 'assess', 'compare', 'decide', 'report', 'scout', 'observe', 'shortlist', 'analyse', 'validate', 'review', 'configure', 'manage_users', 'manage_benchmarks', 'manage_ai', 'export', 'all'];

  return (
    <div className="card p-5">
      <SectionTitle title="Permission Matrix" subtitle="Role-based permission overview" />
      <div className="overflow-x-auto scrollbar-thin">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-[rgb(var(--border))]"><th className="text-left py-2 px-2 font-medium text-muted">Permission</th>{roles.map((r) => <th key={r.key} className="text-center py-2 px-2 font-medium text-muted">{r.label}</th>)}</tr></thead>
          <tbody>
            {allPermissions.map((perm) => (
              <tr key={perm} className="border-b border-[rgb(var(--border))] last:border-0">
                <td className="py-2 px-2 text-[rgb(var(--text))]">{perm.replace(/_/g, ' ')}</td>
                {roles.map((r) => <td key={r.key} className="text-center py-2 px-2">{r.permissions.includes(perm) || r.permissions.includes('all') ? <CheckCircle2 size={14} className="text-emerald-500 inline" /> : <XCircle size={14} className="text-muted inline" />}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-4 rounded-lg bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 p-3">
        <p className="text-xs text-[rgb(var(--text))]">Your current role: <strong>{getRoleLabel(user.role)}</strong>. Security controls are always enforced and cannot be weakened by lower-level settings.</p>
      </div>
    </div>
  );
}

// ===== PERFORMANCE =====
function PerformanceSection({ onRefresh }: { onRefresh: () => void }) {
  const settings = getPerformanceSettings();
  return (
    <div className="card p-5">
      <SectionTitle title="Performance Settings" subtitle="Configure metrics, units, and testing protocols" />
      <div className="space-y-3">
        <div><label className="text-xs text-muted block mb-1">Metric Categories</label><div className="flex flex-wrap gap-1">{settings.metricCategories.map((c) => <span key={c} className="text-xs surface rounded-full px-2 py-0.5 text-muted">{c}</span>)}</div></div>
        <div><label className="text-xs text-muted block mb-1">Default Units</label><div className="grid grid-cols-2 gap-2">{Object.entries(settings.defaultUnits).map(([k, v]) => <div key={k} className="surface-2 rounded-lg p-2 text-xs"><span className="text-muted">{k}:</span> <span className="text-[rgb(var(--text))]">{v}</span></div>)}</div></div>
        <div><label className="text-xs text-muted block mb-1">Testing Frequency Options</label><div className="flex flex-wrap gap-1">{settings.testingFrequency.map((f) => <span key={f.label} className="text-xs surface rounded-full px-2 py-0.5 text-muted">{f.label}</span>)}</div></div>
      </div>
      <div className="mt-4 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3"><p className="text-xs text-[rgb(var(--text))]">Stage 5A validated algorithms are locked and cannot be modified through these settings. These settings affect presentation and organisational preferences only.</p></div>
    </div>
  );
}

// ===== DEVELOPMENT =====
function DevelopmentSection({ onRefresh }: { onRefresh: () => void }) {
  const settings = getDevelopmentSettings();
  return (
    <div className="card p-5">
      <SectionTitle title="Development Settings" subtitle="Configure development categories and review cycles" />
      <div className="space-y-3">
        <div><label className="text-xs text-muted block mb-1">Objective Categories</label><div className="flex flex-wrap gap-1">{settings.objectiveCategories.map((c) => <span key={c} className="text-xs surface rounded-full px-2 py-0.5 text-muted">{c}</span>)}</div></div>
        <div><label className="text-xs text-muted block mb-1">Intervention Types</label><div className="flex flex-wrap gap-1">{settings.interventionTypes.map((t) => <span key={t} className="text-xs surface rounded-full px-2 py-0.5 text-muted">{t}</span>)}</div></div>
        <div><label className="text-xs text-muted block mb-1">Review Cycles</label><div className="flex flex-wrap gap-1">{settings.reviewCycles.map((c) => <span key={c.label} className="text-xs surface rounded-full px-2 py-0.5 text-muted">{c.label} ({c.days}d)</span>)}</div></div>
        <div><label className="text-xs text-muted block mb-1">Reassessment Interval: {settings.reassessmentIntervalDays} days</label></div>
      </div>
      <div className="mt-4 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3"><p className="text-xs text-[rgb(var(--text))]">Settings cannot automatically modify an athlete's development plan. Stage 7 human development controls remain in place.</p></div>
    </div>
  );
}

// ===== SCOUTING =====
function ScoutingSection({ onRefresh }: { onRefresh: () => void }) {
  const settings = getScoutingSettings();
  return (
    <div className="card p-5">
      <SectionTitle title="Scouting & Recruitment Settings" subtitle="Configure scouting attributes and pipeline" />
      <div className="space-y-3">
        <div><label className="text-xs text-muted block mb-1">Default Evidence Confidence</label><div className="text-sm text-[rgb(var(--text))] capitalize">{settings.defaultEvidenceConfidence}</div></div>
        <div><label className="text-xs text-muted block mb-1">Pipeline Stages</label><div className="flex flex-wrap gap-1">{settings.pipelineStages.map((s) => <span key={s} className="text-xs surface rounded-full px-2 py-0.5 text-muted">{s.replace(/_/g, ' ')}</span>)}</div></div>
        <div><label className="text-xs text-muted block mb-1">Project Statuses</label><div className="flex flex-wrap gap-1">{settings.projectStatuses.map((s) => <span key={s} className="text-xs surface rounded-full px-2 py-0.5 text-muted">{s}</span>)}</div></div>
        <div><label className="text-xs text-muted block mb-1">Weighting Validation</label><span className={`text-xs font-semibold ${settings.weightingValidation ? 'text-emerald-500' : 'text-red-500'}`}>{settings.weightingValidation ? 'Enabled' : 'Disabled'}</span></div>
      </div>
      <div className="mt-4 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3"><p className="text-xs text-[rgb(var(--text))]">Global settings cannot silently modify historical scouting decisions. Stage 8 recruitment controls remain in place.</p></div>
    </div>
  );
}

// ===== AI =====
function AISection({ onRefresh }: { onRefresh: () => void }) {
  const config = getAIConfig();
  const [enabled, setEnabled] = useState(config.aiEnabled);
  const [explanationReq, setExplanationReq] = useState(config.explanationRequired);
  const [explanationDepth, setExplanationDepth] = useState(config.explanationDepth);
  const [reviewReq, setReviewReq] = useState(config.reviewRequired);
  const [logging, setLogging] = useState(config.loggingEnabled);
  const [confidenceDisplay, setConfidenceDisplay] = useState(config.confidenceDisplay);

  const save = () => {
    updateAIConfig({ aiEnabled: enabled, explanationRequired: explanationReq, explanationDepth, reviewRequired: reviewReq, loggingEnabled: logging, confidenceDisplay });
    onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="AI Settings" subtitle="Configure AI behaviour and safety controls" />
      <div className="space-y-3">
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} className="accent-[rgb(var(--primary))]" /> AI Enabled</label>
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={explanationReq} onChange={(e) => setExplanationReq(e.target.checked)} className="accent-[rgb(var(--primary))]" /> Require Explanations (locked on)</label>
        <div><label className="text-xs text-muted block mb-1">Explanation Depth</label><select value={explanationDepth} onChange={(e) => setExplanationDepth(e.target.value as 'brief' | 'standard' | 'detailed')} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none"><option value="brief">Brief</option><option value="standard">Standard</option><option value="detailed">Detailed</option></select></div>
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={reviewReq} onChange={(e) => setReviewReq(e.target.checked)} className="accent-[rgb(var(--primary))]" /> Human Review Required (locked on)</label>
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={logging} onChange={(e) => setLogging(e.target.checked)} className="accent-[rgb(var(--primary))]" /> AI Logging Enabled</label>
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={confidenceDisplay} onChange={(e) => setConfidenceDisplay(e.target.checked)} className="accent-[rgb(var(--primary))]" /> Display Confidence Levels</label>
        <button onClick={save} className="btn-primary text-xs flex items-center gap-1"><Save size={14} /> Save AI Settings</button>
      </div>
      <div className="mt-4 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 p-3">
        <div className="flex items-center gap-2 mb-1"><Lock size={14} className="text-red-500" /><span className="text-xs font-semibold text-red-600 dark:text-red-400">SAFETY CONTROLS — CANNOT BE DISABLED</span></div>
        <p className="text-xs text-[rgb(var(--text))]">Evidence requirements, human decision controls, and audit requirements are permanently enforced. AI must remain assistive, evidence-grounded, transparent, and non-autonomous.</p>
      </div>
    </div>
  );
}

// ===== NOTIFICATIONS =====
function NotificationsSection({ onRefresh }: { onRefresh: () => void }) {
  const prefs = getNotificationPreferences();
  const rules = getNotificationRules();

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <SectionTitle title="Notification Preferences" subtitle="Configure your notification channels" />
        <div className="space-y-2">
          {prefs.map((p) => (
            <div key={p.channel} className="surface-2 rounded-xl p-3 flex items-center justify-between">
              <div><div className="text-sm font-medium text-[rgb(var(--text))] capitalize">{p.channel.replace('_', ' ')}</div><div className="text-xs text-muted">{p.enabled ? 'Enabled' : 'Disabled'}</div></div>
              <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={p.enabled} onChange={(e) => { updateNotificationPreference(p.channel, { enabled: e.target.checked }); onRefresh(); }} className="accent-[rgb(var(--primary))]" /> {p.enabled ? 'On' : 'Off'}</label>
            </div>
          ))}
        </div>
      </div>
      <div className="card p-5">
        <SectionTitle title="Notification Rules" subtitle="System notification rules and priorities" />
        <div className="space-y-2">
          {rules.map((r) => (
            <div key={r.id} className="surface-2 rounded-xl p-3 flex items-center justify-between">
              <div><div className="text-sm font-medium text-[rgb(var(--text))]">{r.label}</div><div className="text-xs text-muted">Priority: {r.priority} · Channels: {r.channels.join(', ')}</div></div>
              <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={r.active} onChange={(e) => { updateNotificationRule(r.id, { active: e.target.checked }); onRefresh(); }} className="accent-[rgb(var(--primary))]" /> {r.active ? 'Active' : 'Inactive'}</label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ===== DATA =====
function DataSection({ onRefresh }: { onRefresh: () => void }) {
  const retention = getDataRetention();
  const thresholds = getDataQualityThresholds();
  const [activeDays, setActiveDays] = useState(retention.activeRetentionDays);
  const [archiveDays, setArchiveDays] = useState(retention.autoArchiveDays);
  const [staleDays, setStaleDays] = useState(thresholds.staleDataDays);
  const [minSample, setMinSample] = useState(thresholds.minSampleSize);

  const saveRetention = () => { updateDataRetention({ activeRetentionDays: activeDays, autoArchiveDays: archiveDays }); onRefresh(); };
  const saveThresholds = () => { updateDataQualityThresholds({ staleDataDays: staleDays, minSampleSize: minSample }); onRefresh(); };

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <SectionTitle title="Data Retention" subtitle="Configure data retention and archiving policies" />
        <div className="space-y-3">
          <div><label className="text-xs text-muted block mb-1">Active Retention (days): {activeDays}</label><input type="number" value={activeDays} onChange={(e) => setActiveDays(parseInt(e.target.value) || 0)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
          <div><label className="text-xs text-muted block mb-1">Auto-Archive After (days): {archiveDays}</label><input type="number" value={archiveDays} onChange={(e) => setArchiveDays(parseInt(e.target.value) || 0)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
          <div><label className="text-xs text-muted block mb-1">Deletion Policy</label><select value={retention.deletionPolicy} onChange={(e) => updateDataRetention({ deletionPolicy: e.target.value as 'soft' | 'hard' | 'legal_hold' })} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none"><option value="soft">Soft Delete</option><option value="hard">Hard Delete</option><option value="legal_hold">Legal Hold</option></select></div>
          <button onClick={saveRetention} className="btn-primary text-xs flex items-center gap-1"><Save size={14} /> Save Retention</button>
        </div>
      </div>
      <div className="card p-5">
        <SectionTitle title="Data Quality Thresholds" subtitle="Configure data quality validation rules" />
        <div className="space-y-3">
          <div><label className="text-xs text-muted block mb-1">Stale Data Threshold (days): {staleDays}</label><input type="number" value={staleDays} onChange={(e) => setStaleDays(parseInt(e.target.value) || 0)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
          <div><label className="text-xs text-muted block mb-1">Minimum Sample Size: {minSample}</label><input type="number" value={minSample} onChange={(e) => setMinSample(parseInt(e.target.value) || 0)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
          <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={thresholds.duplicateDetection} onChange={(e) => updateDataQualityThresholds({ duplicateDetection: e.target.checked })} className="accent-[rgb(var(--primary))]" /> Duplicate Detection</label>
          <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={thresholds.contradictoryAlerts} onChange={(e) => updateDataQualityThresholds({ contradictoryAlerts: e.target.checked })} className="accent-[rgb(var(--primary))]" /> Contradictory Data Alerts</label>
          <button onClick={saveThresholds} className="btn-primary text-xs flex items-center gap-1"><Save size={14} /> Save Thresholds</button>
        </div>
      </div>
    </div>
  );
}

// ===== PRIVACY =====
function PrivacySection({ onRefresh }: { onRefresh: () => void }) {
  const config = getPrivacyConfig();
  const [athleteVis, setAthleteVis] = useState(config.athleteVisibility);
  const [scoutingVis, setScoutingVis] = useState(config.scoutingVisibility);
  const [exportAllowed, setExportAllowed] = useState(config.exportAllowed);

  const save = () => {
    updatePrivacyConfig({ athleteVisibility: athleteVis, scoutingVisibility: scoutingVis, exportAllowed });
    onRefresh();
  };

  return (
    <div className="card p-5">
      <SectionTitle title="Privacy & Security" subtitle="Configure data visibility and privacy controls" />
      <div className="space-y-3">
        <div><label className="text-xs text-muted block mb-1">Athlete Visibility</label><select value={athleteVis} onChange={(e) => setAthleteVis(e.target.value as typeof athleteVis)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none"><option value="organisation">Organisation-wide</option><option value="programme">Programme-only</option><option value="team">Team-only</option><option value="restricted">Restricted</option></select></div>
        <div><label className="text-xs text-muted block mb-1">Scouting Visibility</label><select value={scoutingVis} onChange={(e) => setScoutingVis(e.target.value as typeof scoutingVis)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none"><option value="organisation">Organisation-wide</option><option value="programme">Programme-only</option><option value="team">Team-only</option><option value="restricted">Restricted</option></select></div>
        <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={exportAllowed} onChange={(e) => setExportAllowed(e.target.checked)} className="accent-[rgb(var(--primary))]" /> Data Export Allowed</label>
        <button onClick={save} className="btn-primary text-xs flex items-center gap-1"><Save size={14} /> Save Privacy</button>
      </div>
      <div className="mt-4 rounded-lg bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 p-3">
        <div className="flex items-center gap-2 mb-1"><Lock size={14} className="text-red-500" /><span className="text-xs font-semibold text-red-600 dark:text-red-400">YOUTH SAFEGUARDS — LOCKED ON</span></div>
        <p className="text-xs text-[rgb(var(--text))]">Youth athlete restrictions and public ranking prohibitions cannot be disabled. Sensitive information for minors remains protected.</p>
      </div>
    </div>
  );
}

// ===== REPORTS =====
function ReportsSection({ onRefresh }: { onRefresh: () => void }) {
  const config = getReportConfig();
  const [orgName, setOrgName] = useState(config.orgName);
  const [header, setHeader] = useState(config.header);
  const [footer, setFooter] = useState(config.footer);
  const [format, setFormat] = useState(config.defaultFormat);

  const save = () => { updateReportConfig({ orgName, header, footer, defaultFormat: format }); onRefresh(); };

  return (
    <div className="card p-5">
      <SectionTitle title="Report Configuration" subtitle="Configure report branding and defaults" />
      <div className="space-y-3">
        <div><label className="text-xs text-muted block mb-1">Organisation Name (on reports)</label><input value={orgName} onChange={(e) => setOrgName(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
        <div><label className="text-xs text-muted block mb-1">Report Header</label><input value={header} onChange={(e) => setHeader(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
        <div><label className="text-xs text-muted block mb-1">Report Footer</label><input value={footer} onChange={(e) => setFooter(e.target.value)} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
        <div><label className="text-xs text-muted block mb-1">Default Export Format</label><select value={format} onChange={(e) => setFormat(e.target.value as 'pdf' | 'csv' | 'excel')} className="w-full surface rounded-lg p-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none"><option value="pdf">PDF</option><option value="csv">CSV</option><option value="excel">Excel</option></select></div>
        <button onClick={save} className="btn-primary text-xs flex items-center gap-1"><Save size={14} /> Save Report Settings</button>
      </div>
    </div>
  );
}

// ===== SEASONS =====
function SeasonsSection({ onRefresh }: { onRefresh: () => void }) {
  const seasons = getSeasons();
  const competitions = getCompetitions();
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [sport, setSport] = useState('football');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const handleCreate = () => {
    if (!name) return;
    createSeason({ name, sport, startDate, endDate, active: true });
    setName(''); setStartDate(''); setEndDate(''); setShowCreate(false); onRefresh();
  };

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <SectionTitle title="Seasons" subtitle="Manage competition seasons" action={<button onClick={() => setShowCreate(!showCreate)} className="btn-primary text-xs flex items-center gap-1"><Plus size={14} /> New Season</button>} />
        {showCreate && (
          <div className="surface-2 rounded-xl p-4 mb-4 space-y-3">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Season name" className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" />
            <select value={sport} onChange={(e) => setSport(e.target.value)} className="w-full surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none">{SPORT_LIST.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}</select>
            <div className="grid grid-cols-2 gap-2"><input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /><input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="surface rounded-lg p-2 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:outline-none" /></div>
            <button onClick={handleCreate} className="btn-primary text-xs">Create</button>
          </div>
        )}
        <div className="space-y-2">
          {seasons.map((s) => (
            <div key={s.id} className="surface-2 rounded-xl p-3 flex items-center justify-between">
              <div><div className="text-sm font-medium text-[rgb(var(--text))]">{s.name}</div><div className="text-xs text-muted">{s.sport} · {s.startDate} to {s.endDate}</div></div>
              <span className={`text-xs px-2 py-0.5 rounded-full ${s.active ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'}`}>{s.active ? 'Active' : 'Inactive'}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="card p-5">
        <SectionTitle title="Competitions" subtitle="Registered competitions" />
        <div className="space-y-2">
          {competitions.map((c) => (
            <div key={c.id} className="surface-2 rounded-xl p-3 flex items-center justify-between">
              <div><div className="text-sm font-medium text-[rgb(var(--text))]">{c.name}</div><div className="text-xs text-muted">{c.sport} · {c.level} · {c.format}</div></div>
              <span className={`text-xs px-2 py-0.5 rounded-full ${c.active ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'}`}>{c.active ? 'Active' : 'Inactive'}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ===== FEATURE FLAGS =====
function FeatureFlagsSection({ onRefresh }: { onRefresh: () => void }) {
  const flags = getFeatureFlags();
  return (
    <div className="card p-5">
      <SectionTitle title="Feature Flags" subtitle="Enable or disable platform features" />
      <div className="space-y-2">
        {flags.map((f) => (
          <div key={f.key} className="surface-2 rounded-xl p-3 flex items-center justify-between">
            <div><div className="text-sm font-medium text-[rgb(var(--text))]">{f.label}</div><div className="text-xs text-muted">{f.description} · Module: {f.module}</div></div>
            <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={f.enabled} onChange={(e) => { updateFeatureFlag(f.key, e.target.checked); onRefresh(); }} className="accent-[rgb(var(--primary))]" /> {f.enabled ? 'On' : 'Off'}</label>
          </div>
        ))}
      </div>
      <div className="mt-4 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 p-3"><p className="text-xs text-[rgb(var(--text))]">Feature flags cannot bypass safety controls. Disabling a feature flag does not alter historical data or decisions.</p></div>
    </div>
  );
}

// ===== INTEGRATIONS =====
function IntegrationsSection({ onRefresh }: { onRefresh: () => void }) {
  const config = getIntegrations();
  return (
    <div className="card p-5">
      <SectionTitle title="Integrations" subtitle="Manage external system integrations" />
      <div className="space-y-2">
        {config.integrations.map((i) => (
          <div key={i.key} className="surface-2 rounded-xl p-3 flex items-center justify-between">
            <div><div className="text-sm font-medium text-[rgb(var(--text))]">{i.label}</div><div className="text-xs text-muted">Type: {i.type} · {i.connected ? 'Connected' : 'Not connected'}</div></div>
            <label className="flex items-center gap-2 text-sm text-[rgb(var(--text))]"><input type="checkbox" checked={i.enabled} onChange={(e) => { updateIntegration(i.key, e.target.checked); onRefresh(); }} className="accent-[rgb(var(--primary))]" /> {i.enabled ? 'Enabled' : 'Disabled'}</label>
          </div>
        ))}
      </div>
      <div className="mt-4 rounded-lg bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 p-3"><p className="text-xs text-[rgb(var(--text))]">Only integrations that are actually implemented are shown. No fake or placeholder integrations are displayed.</p></div>
    </div>
  );
}

// ===== SYSTEM STATUS =====
function SystemSection() {
  const status = getSystemStatus();
  const services: { key: string; label: string; status: typeof status.application }[] = [
    { key: 'application', label: 'Application', status: status.application },
    { key: 'database', label: 'Database', status: status.database },
    { key: 'analytics', label: 'Analytics Engine', status: status.analytics },
    { key: 'ai', label: 'AI Service', status: status.ai },
    { key: 'notifications', label: 'Notification Service', status: status.notifications },
  ];
  const statusColor = (s: string) => s === 'operational' ? 'text-emerald-500' : s === 'degraded' ? 'text-amber-500' : 'text-red-500';
  const statusIcon = (s: string) => s === 'operational' ? <CheckCircle2 size={16} /> : s === 'degraded' ? <AlertTriangle size={16} /> : <XCircle size={16} />;

  return (
    <div className="card p-5">
      <SectionTitle title="System Status" subtitle="Platform service health" />
      <div className="space-y-2">
        {services.map((s) => (
          <div key={s.key} className="surface-2 rounded-xl p-3 flex items-center gap-3">
            <span className={statusColor(s.status)}>{statusIcon(s.status)}</span>
            <span className="text-sm font-medium text-[rgb(var(--text))]">{s.label}</span>
            <span className={`text-xs font-semibold ml-auto capitalize ${statusColor(s.status)}`}>{s.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== AUDIT =====
function AuditSection() {
  const log = getSettingsAuditLog();
  return (
    <div className="card p-5">
      <SectionTitle title="Settings Audit Log" subtitle="All configuration changes are recorded" />
      {log.length === 0 ? (
        <p className="text-sm text-muted py-4">No settings changes recorded yet.</p>
      ) : (
        <div className="space-y-1 max-h-[600px] overflow-y-auto scrollbar-thin">
          {log.map((e) => (
            <div key={e.id} className="surface-2 rounded-lg p-2.5 flex items-start gap-3">
              <div className="text-xs text-muted shrink-0 mt-0.5">{new Date(e.timestamp).toLocaleString()}</div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium text-[rgb(var(--text))]">{e.action} — {e.settingType}</div>
                <div className="text-xs text-muted">{e.user}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ===== VERSIONS =====
function VersionsSection({ onRefresh }: { onRefresh: () => void }) {
  const versions = getConfigVersions();
  return (
    <div className="card p-5">
      <SectionTitle title="Configuration Versions" subtitle="Track configuration version history" action={<button onClick={() => { createConfigVersion('organisation', 'Manual version snapshot'); onRefresh(); }} className="btn-ghost text-xs flex items-center gap-1"><Plus size={14} /> New Version</button>} />
      <div className="space-y-2">
        {versions.map((v) => (
          <div key={v.id} className="surface-2 rounded-xl p-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-bold text-[rgb(var(--text))]">{v.version}</span>
              <span className={`text-xs px-2 py-0.5 rounded-full ${v.status === 'active' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'}`}>{v.status}</span>
            </div>
            <div className="text-xs text-muted">{v.configurationType} · {new Date(v.effectiveFrom).toLocaleDateString()}</div>
            <div className="text-xs text-muted italic mt-1">{v.reason}</div>
          </div>
        ))}
      </div>
      <div className="mt-4 rounded-lg bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 p-3"><p className="text-xs text-[rgb(var(--text))]">Historical records retain their original configuration version. Changing configuration does not silently alter historical meaning.</p></div>
    </div>
  );
}
