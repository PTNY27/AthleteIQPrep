import { demoImportHistory, demoSessionsNeedingReview, demoOutliers } from '@/lib/dataPipelineData';
import { getAllAthletes, getAllTrainingSessions, computeDataQuality } from '@/lib/extendedData';
import { SectionTitle, KpiCard, DataQualityBadge, Avatar } from '@/components/ui';
import { CheckCircle2, AlertTriangle, XCircle, FileWarning, Database, ShieldCheck, Activity, Eye, Download, RefreshCw, Search, X } from 'lucide-react';
import { useState } from 'react';
import type { ImportRecord, ValidationIssue } from '@/lib/dataPipeline';

export function DataQualityCentre() {
  const athletes = getAllAthletes();
  const allSessions = athletes.flatMap((a) => getAllTrainingSessions(a.id).map((s) => ({ ...s, athlete: a })));

  const totalSessions = allSessions.length;
  const sessionsWithGoodQuality = allSessions.filter((s) => (s.gpsCompleteness || 95) >= 90 && (s.hrCompleteness || 90) >= 85).length;
  const sessionsNeedingReview = allSessions.filter((s) => (s.gpsCompleteness || 95) < 85 || (s.hrCompleteness || 90) < 80).length;
  const avgGpsCompleteness = Math.round(allSessions.reduce((sum, s) => sum + (s.gpsCompleteness || 95), 0) / totalSessions);
  const avgHrCompleteness = Math.round(allSessions.reduce((sum, s) => sum + (s.hrCompleteness || 90), 0) / totalSessions);

  const [selectedImport, setSelectedImport] = useState<ImportRecord | null>(null);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Data Quality Centre</h1>
        <p className="text-sm text-muted mt-1">Completeness, validation, and outlier monitoring</p>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Sessions Monitored" value={totalSessions.toString()} unit="" sublabel={`${athletes.length} athletes`} icon={<Database size={20} />} color="rgb(var(--chart-1))" />
        <KpiCard label="GPS Completeness" value={avgGpsCompleteness.toString()} unit="%" sublabel={`${sessionsWithGoodQuality} sessions good`} icon={<Activity size={20} />} color="rgb(var(--chart-2))" />
        <KpiCard label="HR Completeness" value={avgHrCompleteness.toString()} unit="%" sublabel="Across all sessions" icon={<ShieldCheck size={20} />} color="rgb(var(--chart-3))" />
        <KpiCard label="Require Review" value={sessionsNeedingReview.toString()} unit="" sublabel="Sessions needing attention" icon={<FileWarning size={20} />} color="rgb(var(--error))" />
      </div>

      {/* Quality breakdown */}
      <div className="card p-5">
        <SectionTitle title="Data Quality Breakdown" subtitle="Squad-level quality assessment" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {athletes.map((athlete) => {
            const dq = computeDataQuality(athlete.id);
            return (
              <div key={athlete.id} className="surface-2 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Avatar initials={athlete.initials} color={athlete.avatarColor} size={32} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-[rgb(var(--text))] truncate">{athlete.name}</div>
                    <div className="text-xs text-muted">{athlete.position}</div>
                  </div>
                  <DataQualityBadge status={dq.status} gps={dq.gps} hr={dq.hr} />
                </div>
                <div className="space-y-2">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-muted">GPS</span>
                      <span className="text-xs font-semibold text-[rgb(var(--text))]">{dq.gps}%</span>
                    </div>
                    <div className="h-1.5 bg-[rgb(var(--surface-3))] rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-700" style={{
                        width: `${dq.gps}%`,
                        backgroundColor: dq.gps >= 90 ? 'rgb(var(--success))' : dq.gps >= 75 ? 'rgb(var(--warning))' : 'rgb(var(--error))',
                      }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-muted">HR</span>
                      <span className="text-xs font-semibold text-[rgb(var(--text))]">{dq.hr}%</span>
                    </div>
                    <div className="h-1.5 bg-[rgb(var(--surface-3))] rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-700" style={{
                        width: `${dq.hr}%`,
                        backgroundColor: dq.hr >= 90 ? 'rgb(var(--success))' : dq.hr >= 75 ? 'rgb(var(--warning))' : 'rgb(var(--error))',
                      }} />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Outlier detection */}
      <div className="card p-5">
        <SectionTitle title="Outlier Detection" subtitle="Statistical and individual baseline anomalies" />
        <div className="space-y-3">
          {demoOutliers.map((outlier, i) => {
            const athlete = athletes.find((a) => a.id === outlier.athleteId);
            return (
              <div key={i} className={`surface-2 rounded-xl p-4 border-l-4 ${
                outlier.level === 'level2' ? 'border-l-red-500' : 'border-l-amber-500'
              }`}>
                <div className="flex items-start gap-3">
                  {athlete && <Avatar initials={athlete.initials} color={athlete.avatarColor} size={36} />}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-[rgb(var(--text))]">{athlete?.name || outlier.athleteId}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        outlier.level === 'level2' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' :
                        'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300'
                      }`}>
                        {outlier.level === 'level2' ? 'Individual Anomaly' : 'Statistical Outlier'}
                      </span>
                    </div>
                    <p className="text-sm text-muted mt-1">{outlier.message}</p>
                    <div className="text-xs text-subtle mt-1">
                      Baseline mean: {Math.round(outlier.baseline.mean)} · Std: {outlier.baseline.std.toFixed(1)} · Z-score: {outlier.zScore.toFixed(1)}
                    </div>
                  </div>
                  <button className="btn-ghost text-xs flex items-center gap-1 shrink-0">
                    <Eye size={14} /> Review
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sessions requiring review */}
      <div className="card p-5">
        <SectionTitle title="Sessions Requiring Review" subtitle="Data quality issues detected" />
        <div className="space-y-3">
          {demoSessionsNeedingReview.map((session, i) => {
            const athlete = athletes.find((a) => a.id === session.athleteId);
            return (
              <div key={i} className="surface-2 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  {athlete && <Avatar initials={athlete.initials} color={athlete.avatarColor} size={36} />}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="text-sm font-semibold text-[rgb(var(--text))]">{athlete?.name || session.athleteId}</span>
                      <span className="text-xs text-muted">{session.date}</span>
                      <span className="text-xs text-muted">· {session.type}</span>
                      <span className="text-xs text-muted">· {session.source}</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {session.issues.map((issue, j) => (
                        <span key={j} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300">
                          <AlertTriangle size={12} /> {issue}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xs text-muted">Quality</div>
                    <div className={`text-lg font-bold ${session.quality < 70 ? 'text-red-500' : 'text-amber-500'}`}>{session.quality}%</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Import quality summary */}
      <div className="card p-5">
        <SectionTitle title="Import Quality Summary" subtitle="Recent data imports and their quality" action={
          <button className="btn-ghost text-xs">View Import History →</button>
        } />
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgb(var(--border))]">
                <th className="text-left py-2 px-3 font-medium text-muted">Date</th>
                <th className="text-left py-2 px-3 font-medium text-muted">Source</th>
                <th className="text-left py-2 px-3 font-medium text-muted hidden md:table-cell">File</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Records</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Quality</th>
                <th className="text-center py-2 px-3 font-medium text-muted">Status</th>
                <th className="text-center py-2 px-3 font-medium text-muted"></th>
              </tr>
            </thead>
            <tbody>
              {demoImportHistory.map((imp) => (
                <tr key={imp.id} className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))] transition-colors">
                  <td className="py-2 px-3 text-muted whitespace-nowrap">{imp.date}</td>
                  <td className="py-2 px-3 text-[rgb(var(--text))]">{imp.source}</td>
                  <td className="py-2 px-3 text-muted hidden md:table-cell">{imp.fileName}</td>
                  <td className="py-2 px-3 text-right text-muted">{imp.records}</td>
                  <td className="py-2 px-3 text-right font-semibold text-[rgb(var(--text))]">{imp.quality}%</td>
                  <td className="py-2 px-3 text-center">
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
                      imp.status === 'complete' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' :
                      imp.status === 'partial' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' :
                      imp.status === 'requires-review' ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300' :
                      'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
                    }`}>
                      {imp.status === 'complete' && <CheckCircle2 size={12} />}
                      {imp.status === 'partial' && <AlertTriangle size={12} />}
                      {imp.status === 'requires-review' && <FileWarning size={12} />}
                      {imp.status === 'failed' && <XCircle size={12} />}
                      {imp.status}
                    </span>
                  </td>
                  <td className="py-2 px-3 text-center">
                    {imp.errorReport && (
                      <button onClick={() => setSelectedImport(imp)} className="text-muted hover:text-[rgb(var(--text))] transition-colors">
                        <Eye size={16} />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Error report modal */}
      {selectedImport && (
        <ErrorReportModal importRecord={selectedImport} onClose={() => setSelectedImport(null)} />
      )}
    </div>
  );
}

function ErrorReportModal({ importRecord, onClose }: { importRecord: ImportRecord; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 animate-fade-in" onClick={onClose}>
      <div className="card rounded-2xl p-6 max-w-2xl w-full animate-scale-in max-h-[85vh] overflow-y-auto scrollbar-thin" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-[rgb(var(--text))]">Import Error Report</h3>
            <p className="text-sm text-muted">{importRecord.fileName}</p>
          </div>
          <button onClick={onClose} className="text-muted hover:text-[rgb(var(--text))] text-xl">✕</button>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className="surface-2 rounded-lg p-3 text-center">
            <div className="text-xs text-muted">Accepted</div>
            <div className="text-xl font-bold text-emerald-500">{importRecord.valid}</div>
          </div>
          <div className="surface-2 rounded-lg p-3 text-center">
            <div className="text-xs text-muted">Warnings</div>
            <div className="text-xl font-bold text-amber-500">{importRecord.warnings}</div>
          </div>
          <div className="surface-2 rounded-lg p-3 text-center">
            <div className="text-xs text-muted">Rejected</div>
            <div className="text-xl font-bold text-red-500">{importRecord.rejected}</div>
          </div>
        </div>

        {importRecord.errorReport && (
          <div className="space-y-2">
            <h4 className="text-xs text-muted uppercase tracking-wider">Detailed Issues</h4>
            {importRecord.errorReport.map((issue: ValidationIssue, i) => (
              <div key={i} className={`flex items-start gap-2 rounded-lg p-3 text-sm ${
                issue.level === 'error' ? 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300' :
                issue.level === 'warning' ? 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300' :
                'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
              }`}>
                {issue.level === 'error' ? <XCircle size={16} className="shrink-0 mt-0.5" /> :
                 issue.level === 'warning' ? <AlertTriangle size={16} className="shrink-0 mt-0.5" /> :
                 <Activity size={16} className="shrink-0 mt-0.5" />}
                <div>
                  <span className="font-semibold">Row {issue.row} · {issue.column}:</span> {issue.message}
                  {issue.value !== undefined && issue.value !== '' && <span className="ml-1 opacity-70">({issue.value})</span>}
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-4 flex justify-end gap-2">
          <button className="btn-ghost text-xs flex items-center gap-1.5">
            <Download size={14} /> Download Report
          </button>
          <button onClick={onClose} className="btn-primary text-xs">Close</button>
        </div>
      </div>
    </div>
  );
}
