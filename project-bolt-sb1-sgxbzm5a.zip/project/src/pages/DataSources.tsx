import { useState } from 'react';
import { demoDataSources, demoPipelineStages, demoAuditLog } from '@/lib/dataPipelineData';
import { SectionTitle, KpiCard } from '@/components/ui';
import { Satellite, HeartPulse, Radar, Cpu, Wifi, Database, CheckCircle2, AlertTriangle, Clock, RefreshCw, Settings, Link2, Unlink, Activity, Shield, FileWarning } from 'lucide-react';
import type { DataSourceConfig } from '@/lib/dataPipeline';

export function DataSources() {
  const [sources] = useState<DataSourceConfig[]>(demoDataSources);
  const [stages] = useState(demoPipelineStages);
  const [auditLog] = useState(demoAuditLog);

  const connectedCount = sources.filter((s) => s.status === 'connected').length;
  const totalAthletes = Math.max(...sources.map((s) => s.athletes));
  const totalSessions = sources.reduce((sum, s) => sum + s.sessions, 0);
  const avgQuality = Math.round(sources.filter((s) => s.dataQuality > 0).reduce((sum, s) => sum + s.dataQuality, 0) / sources.filter((s) => s.dataQuality > 0).length);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Data Sources</h1>
        <p className="text-sm text-muted mt-1">Wearable integration and data pipeline status</p>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Connected Sources" value={connectedCount.toString()} unit="" sublabel={`${sources.length} total`} icon={<Wifi size={20} />} color="rgb(var(--success))" />
        <KpiCard label="Athletes Monitored" value={totalAthletes.toString()} unit="" sublabel="Across all sources" icon={<Database size={20} />} color="rgb(var(--chart-1))" />
        <KpiCard label="Total Sessions" value={totalSessions.toLocaleString()} unit="" sublabel="Last 28 days" icon={<Activity size={20} />} color="rgb(var(--chart-2))" />
        <KpiCard label="Avg Data Quality" value={avgQuality.toString()} unit="%" sublabel="Across connected sources" icon={<CheckCircle2 size={20} />} color="rgb(var(--chart-3))" />
      </div>

      {/* Pipeline status */}
      <div className="card p-5">
        <SectionTitle title="Data Pipeline Status" subtitle="Real-time pipeline health" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {stages.map((stage) => (
            <div key={stage.name} className="surface-2 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold text-[rgb(var(--text))]">{stage.name}</span>
                {stage.status === 'operational' ? (
                  <CheckCircle2 size={16} className="text-emerald-500" />
                ) : stage.status === 'degraded' ? (
                  <AlertTriangle size={16} className="text-amber-500" />
                ) : (
                  <AlertTriangle size={16} className="text-red-500" />
                )}
              </div>
              <div className="text-xs text-muted capitalize">{stage.status}</div>
              <div className="text-xs text-subtle mt-1">{stage.recordsProcessed.toLocaleString()} records</div>
              <div className="text-xs text-subtle mt-0.5">Last: {stage.lastRun}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Data source cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sources.map((source) => (
          <DataSourceCard key={source.id} source={source} />
        ))}
      </div>

      {/* Architecture diagram */}
      <div className="card p-5">
        <SectionTitle title="Integration Architecture" subtitle="Device-independent adapter pattern" />
        <div className="flex flex-col lg:flex-row items-stretch gap-2 text-xs">
          {['External Provider', 'Provider Adapter', 'Ingestion Layer', 'Validation', 'Normalization', 'AthleteIQ Data Model', 'Analytics Engine', 'AI Engine', 'Coach'].map((step, i, arr) => (
            <div key={step} className="flex items-center gap-2 flex-1">
              <div className="flex-1 surface-2 rounded-lg p-3 text-center font-medium text-[rgb(var(--text))]">
                {step}
              </div>
              {i < arr.length - 1 && <span className="text-subtle shrink-0">→</span>}
            </div>
          ))}
        </div>
        <p className="text-xs text-muted mt-4">
          The analytics engine does not depend directly on any single wearable provider. New connectors can be added without redesigning the system.
        </p>
      </div>

      {/* Audit log */}
      <div className="card p-5">
        <SectionTitle title="Audit Log" subtitle="Recent system actions" />
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgb(var(--border))]">
                <th className="text-left py-2 px-3 font-medium text-muted">Timestamp</th>
                <th className="text-left py-2 px-3 font-medium text-muted">User</th>
                <th className="text-left py-2 px-3 font-medium text-muted">Action</th>
                <th className="text-left py-2 px-3 font-medium text-muted">Object</th>
                <th className="text-left py-2 px-3 font-medium text-muted hidden md:table-cell">Details</th>
              </tr>
            </thead>
            <tbody>
              {auditLog.map((entry) => (
                <tr key={entry.id} className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))] transition-colors">
                  <td className="py-2 px-3 text-muted whitespace-nowrap">{entry.timestamp}</td>
                  <td className="py-2 px-3 text-muted">{entry.user}</td>
                  <td className="py-2 px-3 font-medium text-[rgb(var(--text))]">{entry.action}</td>
                  <td className="py-2 px-3 text-muted">{entry.object}</td>
                  <td className="py-2 px-3 text-subtle hidden md:table-cell">{entry.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function DataSourceCard({ source }: { source: DataSourceConfig }) {
  const typeIcons: Record<string, React.ReactNode> = {
    gps: <Satellite size={20} />,
    hr: <HeartPulse size={20} />,
    tracking: <Radar size={20} />,
    sensor: <Cpu size={20} />,
    platform: <Database size={20} />,
  };

  const statusConfig = {
    connected: { color: 'text-emerald-500', bg: 'bg-emerald-50 dark:bg-emerald-900/20', border: 'border-emerald-200 dark:border-emerald-800', label: 'Connected', icon: <Link2 size={14} /> },
    'integration-ready': { color: 'text-blue-500', bg: 'bg-blue-50 dark:bg-blue-900/20', border: 'border-blue-200 dark:border-blue-800', label: 'Integration Ready', icon: <Settings size={14} /> },
    demo: { color: 'text-amber-500', bg: 'bg-amber-50 dark:bg-amber-900/20', border: 'border-amber-200 dark:border-amber-800', label: 'Demo Data', icon: <FileWarning size={14} /> },
    error: { color: 'text-red-500', bg: 'bg-red-50 dark:bg-red-900/20', border: 'border-red-200 dark:border-red-800', label: 'Error', icon: <Unlink size={14} /> },
  };

  const s = statusConfig[source.status];

  return (
    <div className={`card p-5 border ${s.border}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-[rgb(var(--primary-light))] flex items-center justify-center text-[rgb(var(--primary))]">
            {typeIcons[source.type]}
          </div>
          <div>
            <h3 className="font-bold text-[rgb(var(--text))]">{source.name}</h3>
            <p className="text-xs text-muted">{source.provider}</p>
          </div>
        </div>
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${s.bg} ${s.color}`}>
          {s.icon}
          {s.label}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div>
          <div className="text-xs text-muted">Last Sync</div>
          <div className="text-sm font-medium text-[rgb(var(--text))]">{source.lastSync || 'Never'}</div>
        </div>
        <div>
          <div className="text-xs text-muted">Sync Frequency</div>
          <div className="text-sm font-medium text-[rgb(var(--text))] capitalize">{source.syncFrequency}</div>
        </div>
        <div>
          <div className="text-xs text-muted">Athletes</div>
          <div className="text-sm font-medium text-[rgb(var(--text))]">{source.athletes}</div>
        </div>
        <div>
          <div className="text-xs text-muted">Sessions</div>
          <div className="text-sm font-medium text-[rgb(var(--text))]">{source.sessions}</div>
        </div>
      </div>

      {source.dataQuality > 0 && (
        <div className="mb-4">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-muted">Data Quality</span>
            <span className="text-xs font-semibold text-[rgb(var(--text))]">{source.dataQuality}%</span>
          </div>
          <div className="h-2 bg-[rgb(var(--surface-2))] rounded-full overflow-hidden">
            <div className="h-full rounded-full transition-all duration-700" style={{
              width: `${source.dataQuality}%`,
              backgroundColor: source.dataQuality >= 90 ? 'rgb(var(--success))' : source.dataQuality >= 75 ? 'rgb(var(--warning))' : 'rgb(var(--error))',
            }} />
          </div>
        </div>
      )}

      <div className="flex items-center gap-2">
        {source.status === 'connected' && (
          <>
            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium surface-2 hover:bg-[rgb(var(--surface-3))] transition-colors text-[rgb(var(--text))]">
              <RefreshCw size={14} /> Sync Now
            </button>
            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium surface-2 hover:bg-[rgb(var(--surface-3))] transition-colors text-[rgb(var(--text))]">
              <Settings size={14} /> Configure
            </button>
            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium surface-2 hover:bg-[rgb(var(--surface-3))] transition-colors text-[rgb(var(--text))]">
              <Activity size={14} /> View Data
            </button>
          </>
        )}
        {source.status === 'integration-ready' && (
          <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[rgb(var(--primary))] text-white hover:opacity-90 transition-opacity">
            <Link2 size={14} /> Connect
          </button>
        )}
        {source.status === 'demo' && (
          <span className="text-xs text-muted flex items-center gap-1.5">
            <Shield size={14} /> Synthetic data for demonstration
          </span>
        )}
      </div>
    </div>
  );
}
