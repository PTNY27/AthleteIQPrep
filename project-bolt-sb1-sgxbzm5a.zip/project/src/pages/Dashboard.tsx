import { useState } from 'react';
import { getAllAthletes, getAllTrainingSessions, getAllMatchRecords, getAllInsightsList, computeSimilarity, computeReadiness, computeWhatChanged, computeDataQuality, computeSquadOverview } from '@/lib/extendedData';
import { computeLoads, getLoadStatus, computeTrainingAverages, computeMatchAverages } from '@/lib/demoData';
import { KpiCard, StatusBadge, Avatar, SportBadge, SectionTitle, ReadinessBadge, DataQualityBadge } from '@/components/ui';
import { BarChart, DonutGauge } from '@/components/charts/Charts';
import { Dumbbell, Trophy, Zap, TrendingUp, AlertTriangle, Sparkles, Gauge, Users, ShieldCheck, Eye, Activity, ArrowUp, ArrowDown, Minus, CheckCircle2, XCircle, Edit3 } from 'lucide-react';
import type { PageKey } from '@/components/Sidebar';
import type { AIInsight } from '@/lib/types';

interface DashboardProps {
  selectedAthleteId: string;
  onNavigate: (page: PageKey) => void;
  onSelectAthlete: (id: string) => void;
}

export function Dashboard({ onNavigate, onSelectAthlete }: DashboardProps) {
  const squad = computeSquadOverview();
  const allInsights = getAllInsightsList();
  const [feedback, setFeedback] = useState<Record<string, 'accepted' | 'modified' | 'rejected'>>({});

  const reviewCount = squad.filter((s) => s.readiness.status === 'REVIEW').length;
  const monitorCount = squad.filter((s) => s.readiness.status === 'MONITOR').length;
  const onTrackCount = squad.filter((s) => s.readiness.status === 'READY').length;
  const avgSimilarity = Math.round(squad.reduce((sum, s) => sum + s.similarity.overall, 0) / squad.length);
  const totalLoad = squad.reduce((sum, s) => sum + s.acute, 0);
  const totalMatches = squad.reduce((sum, s) => sum + s.matches.length, 0);

  const topInsights = allInsights
    .filter((i) => i.severity === 'critical' || i.severity === 'warning')
    .slice(0, 5);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Performance Dashboard</h1>
        <p className="text-sm text-muted mt-1">Measure → Understand → Compare → Optimize → Develop</p>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Athletes Monitored" value={squad.length.toString()} unit="" sublabel={`${onTrackCount} on track`} icon={<Users size={20} />} color="rgb(var(--chart-1))" />
        <KpiCard label="Require Review" value={reviewCount.toString()} unit="" sublabel={`${monitorCount} to monitor`} icon={<AlertTriangle size={20} />} color="rgb(var(--error))" />
        <KpiCard label="Squad Similarity" value={avgSimilarity.toString()} unit="%" sublabel="Training → Match" icon={<Gauge size={20} />} color="rgb(var(--chart-2))" />
        <KpiCard label="Squad Load (7d)" value={totalLoad.toLocaleString()} unit="AU" sublabel={`${totalMatches} matches played`} icon={<Dumbbell size={20} />} color="rgb(var(--chart-3))" />
      </div>

      {/* Coach Action Centre */}
      <div className="card p-5">
        <SectionTitle title="Today's Performance Actions" subtitle="Squad-level coaching priorities" action={
          <button onClick={() => onNavigate('ai')} className="btn-ghost text-xs">All Insights →</button>
        } />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
          <ActionSummaryCard count={reviewCount} label="REVIEW" icon={<AlertTriangle size={18} />} color="text-red-500" bg="bg-red-50 dark:bg-red-900/20" />
          <ActionSummaryCard count={monitorCount} label="MONITOR" icon={<Eye size={18} />} color="text-amber-500" bg="bg-amber-50 dark:bg-amber-900/20" />
          <ActionSummaryCard count={onTrackCount} label="ON TRACK" icon={<ShieldCheck size={18} />} color="text-emerald-500" bg="bg-emerald-50 dark:bg-emerald-900/20" />
        </div>

        {/* Individual athlete actions */}
        <div className="space-y-3">
          {squad.filter((s) => s.readiness.status !== 'READY' || s.flags > 0).slice(0, 4).map((s) => (
            <AthleteActionRow key={s.athlete.id} s={s} onSelect={onSelectAthlete} />
          ))}
        </div>
      </div>

      {/* Squad View */}
      <div className="card p-5">
        <SectionTitle title="Squad Overview" subtitle="Training vs Match similarity and load status across all athletes" />
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgb(var(--border))]">
                <th className="text-left py-3 px-3 font-medium text-muted">Athlete</th>
                <th className="text-left py-3 px-3 font-medium text-muted hidden sm:table-cell">Position</th>
                <th className="text-center py-3 px-3 font-medium text-muted">Load</th>
                <th className="text-center py-3 px-3 font-medium text-muted hidden md:table-cell">ACWR</th>
                <th className="text-center py-3 px-3 font-medium text-muted">Similarity</th>
                <th className="text-center py-3 px-3 font-medium text-muted hidden lg:table-cell">Data</th>
                <th className="text-center py-3 px-3 font-medium text-muted">Readiness</th>
              </tr>
            </thead>
            <tbody>
              {squad.map((s) => (
                <tr key={s.athlete.id} className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))] transition-colors cursor-pointer" onClick={() => onSelectAthlete(s.athlete.id)}>
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-2">
                      <Avatar initials={s.athlete.initials} color={s.athlete.avatarColor} size={32} />
                      <div>
                        <div className="font-medium text-[rgb(var(--text))]">{s.athlete.name}</div>
                        <div className="text-xs text-muted sm:hidden">{s.athlete.position}</div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-muted hidden sm:table-cell">{s.athlete.position}</td>
                  <td className="py-3 px-3 text-center"><StatusBadge status={s.status} /></td>
                  <td className="py-3 px-3 text-center font-semibold text-[rgb(var(--text))] hidden md:table-cell">{s.acwr.toFixed(2)}</td>
                  <td className="py-3 px-3 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-16 h-2 bg-[rgb(var(--surface-2))] rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all" style={{ width: `${s.similarity.overall}%`, backgroundColor: s.similarity.overall >= 75 ? 'rgb(var(--success))' : s.similarity.overall >= 50 ? 'rgb(var(--warning))' : 'rgb(var(--error))' }} />
                      </div>
                      <span className="text-xs font-semibold text-[rgb(var(--text))]">{s.similarity.overall}%</span>
                    </div>
                  </td>
                  <td className="py-3 px-3 text-center hidden lg:table-cell">
                    <DataQualityBadge status={computeDataQuality(s.athlete.id).status} />
                  </td>
                  <td className="py-3 px-3 text-center"><ReadinessBadge status={s.readiness.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Training vs Match + Performance Development */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card p-5">
          <SectionTitle title="Training vs Match Similarity" subtitle="Squad-wide breakdown" action={
            <button onClick={() => onNavigate('comparison')} className="btn-ghost text-xs">Full Comparison →</button>
          } />
          <div className="space-y-3">
            {squad.slice(0, 6).map((s) => (
              <div key={s.athlete.id} className="flex items-center gap-3">
                <Avatar initials={s.athlete.initials} color={s.athlete.avatarColor} size={28} />
                <span className="text-sm text-[rgb(var(--text))] w-24 truncate">{s.athlete.name}</span>
                <div className="flex-1 h-2 bg-[rgb(var(--surface-2))] rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-700" style={{ width: `${s.similarity.overall}%`, backgroundColor: s.similarity.overall >= 75 ? 'rgb(var(--success))' : s.similarity.overall >= 50 ? 'rgb(var(--warning))' : 'rgb(var(--error))' }} />
                </div>
                <span className="text-xs font-semibold text-[rgb(var(--text))] w-10 text-right">{s.similarity.overall}%</span>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <SectionTitle title="Performance Development" subtitle="Capacity trends across squad" />
          <div className="space-y-3">
            {squad.slice(0, 5).map((s) => {
              const tests = s.athlete.id;
              const trend = getTrendForAthlete(tests);
              return (
                <div key={s.athlete.id} className="flex items-center gap-3 surface-2 rounded-xl p-3">
                  <Avatar initials={s.athlete.initials} color={s.athlete.avatarColor} size={32} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold text-[rgb(var(--text))] truncate">{s.athlete.name}</div>
                    <div className="text-xs text-muted">{trend.label}</div>
                  </div>
                  <span className={`text-sm font-bold ${trend.positive ? 'text-emerald-500' : 'text-amber-500'}`}>{trend.change}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* AI Insights with Coach Feedback Loop */}
      <div className="card p-5">
        <SectionTitle title="AI Insights" subtitle="Explainable findings with coach feedback" action={
          <button onClick={() => onNavigate('ai')} className="btn-ghost text-xs">All Insights →</button>
        } />
        <div className="space-y-3">
          {topInsights.map((insight) => (
            <InsightWithFeedback
              key={insight.id}
              insight={insight}
              feedback={feedback[insight.id]}
              onFeedback={(action) => setFeedback((prev) => ({ ...prev, [insight.id]: action }))}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function ActionSummaryCard({ count, label, icon, color, bg }: { count: number; label: string; icon: React.ReactNode; color: string; bg: string }) {
  return (
    <div className={`rounded-xl p-4 ${bg} flex items-center gap-3`}>
      <span className={color}>{icon}</span>
      <div>
        <div className={`text-2xl font-bold ${color}`}>{count}</div>
        <div className="text-xs text-muted">{label}</div>
      </div>
    </div>
  );
}

function AthleteActionRow({ s, onSelect }: { s: ReturnType<typeof computeSquadOverview>[0]; onSelect: (id: string) => void }) {
  const athlete = s.athlete;
  const insight = s.insights.find((i) => i.severity === 'critical' || i.severity === 'warning');
  if (!insight) return null;

  const severityColor = insight.severity === 'critical' ? 'border-l-red-500' : insight.severity === 'warning' ? 'border-l-amber-500' : 'border-l-blue-500';

  return (
    <div className={`surface-2 rounded-xl p-4 border-l-4 ${severityColor}`}>
      <div className="flex items-start gap-3">
        <Avatar initials={athlete.initials} color={athlete.avatarColor} size={36} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-sm text-[rgb(var(--text))]">{athlete.name}</span>
            <SportBadge sport={athlete.sport} />
            <span className="text-xs text-muted">{athlete.position}</span>
            <ReadinessBadge status={s.readiness.status} />
          </div>
          <p className="text-sm text-[rgb(var(--text))] mt-1.5">{insight.finding}</p>
          <p className="text-xs text-muted mt-1">{insight.evidence}</p>
          <div className="mt-2 flex items-start gap-1.5">
            <span className="text-xs font-semibold text-[rgb(var(--text))] shrink-0">Action: </span>
            <span className="text-xs text-muted">{insight.action}</span>
          </div>
          <div className="mt-2 flex items-center gap-3 flex-wrap">
            <span className="text-xs text-muted">Confidence: <span className="font-semibold text-[rgb(var(--text))]">{insight.confidence}</span></span>
            <DataQualityBadge status={insight.dataQuality} />
          </div>
        </div>
        <button onClick={() => onSelect(athlete.id)} className="btn-ghost text-xs shrink-0">View →</button>
      </div>
    </div>
  );
}

function InsightWithFeedback({ insight, feedback, onFeedback }: { insight: AIInsight; feedback?: 'accepted' | 'modified' | 'rejected'; onFeedback: (a: 'accepted' | 'modified' | 'rejected') => void }) {
  const severityStyles = {
    info: { bg: 'bg-blue-50 dark:bg-blue-900/20', border: 'border-blue-200 dark:border-blue-800', icon: <Sparkles size={16} className="text-blue-500" /> },
    warning: { bg: 'bg-amber-50 dark:bg-amber-900/20', border: 'border-amber-200 dark:border-amber-800', icon: <AlertTriangle size={16} className="text-amber-500" /> },
    critical: { bg: 'bg-red-50 dark:bg-red-900/20', border: 'border-red-200 dark:border-red-800', icon: <AlertTriangle size={16} className="text-red-500" /> },
    positive: { bg: 'bg-emerald-50 dark:bg-emerald-900/20', border: 'border-emerald-200 dark:border-emerald-800', icon: <TrendingUp size={16} className="text-emerald-500" /> },
  };
  const s = severityStyles[insight.severity];
  const athlete = getAllAthletes().find((a) => a.id === insight.athleteId);

  return (
    <div className={`rounded-xl p-4 border ${s.bg} ${s.border}`}>
      <div className="flex items-start gap-2">
        <span className="mt-0.5 shrink-0">{s.icon}</span>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            {athlete && <span className="text-xs font-semibold text-[rgb(var(--text))]">{athlete.name}</span>}
            <span className="text-xs text-muted">· {insight.metric}</span>
          </div>
          <p className="text-sm font-semibold text-[rgb(var(--text))]">{insight.finding}</p>
          <p className="text-xs text-muted mt-1">{insight.evidence}</p>
          <p className="text-xs text-muted mt-1">{insight.interpretation}</p>
          <div className="mt-2 pt-2 border-t border-[rgb(var(--border))]">
            <span className="text-xs font-semibold text-[rgb(var(--text))]">Suggested: </span>
            <span className="text-xs text-muted">{insight.action}</span>
          </div>
          <div className="mt-2 flex items-center gap-3 flex-wrap">
            <span className="text-xs text-muted">Confidence: <span className="font-semibold text-[rgb(var(--text))]">{insight.confidence}</span></span>
            <DataQualityBadge status={insight.dataQuality} />
          </div>
          {/* Feedback buttons */}
          <div className="mt-3 flex items-center gap-2">
            {feedback ? (
              <span className="text-xs font-semibold text-emerald-500 flex items-center gap-1">
                <CheckCircle2 size={14} /> Feedback recorded: {feedback}
              </span>
            ) : (
              <>
                <button onClick={() => onFeedback('accepted')} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-emerald-100 text-emerald-700 hover:bg-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-300 transition-colors">
                  <CheckCircle2 size={14} /> Accept
                </button>
                <button onClick={() => onFeedback('modified')} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-100 text-blue-700 hover:bg-blue-200 dark:bg-blue-900/30 dark:text-blue-300 transition-colors">
                  <Edit3 size={14} /> Modify
                </button>
                <button onClick={() => onFeedback('rejected')} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-red-100 text-red-700 hover:bg-red-200 dark:bg-red-900/30 dark:text-red-300 transition-colors">
                  <XCircle size={14} /> Reject
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function getTrendForAthlete(athleteId: string): { label: string; change: string; positive: boolean } {
  const sessions = getAllTrainingSessions(athleteId);
  if (sessions.length < 2) return { label: 'No data', change: '—', positive: false };
  const sorted = [...sessions].sort((a, b) => b.date.localeCompare(a.date));
  const last7 = sorted.slice(0, 7);
  const prev7 = sorted.slice(7, 14);
  if (last7.length === 0 || prev7.length === 0) return { label: 'Insufficient data', change: '—', positive: false };
  const recentAvg = last7.reduce((s, x) => s + x.trainingLoad, 0) / last7.length;
  const prevAvg = prev7.reduce((s, x) => s + x.trainingLoad, 0) / prev7.length;
  const pct = prevAvg === 0 ? 0 : ((recentAvg - prevAvg) / prevAvg) * 100;
  return { label: 'Training Load', change: `${pct > 0 ? '+' : ''}${pct.toFixed(0)}%`, positive: pct >= 0 };
}
