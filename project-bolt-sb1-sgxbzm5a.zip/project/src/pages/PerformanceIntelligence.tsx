import { useState, useMemo } from 'react';
import { getAllAthletes, getAllTrainingSessions, getAllMatchRecords, getAllCapacityTests, getAllInsights, computeDataQuality } from '@/lib/extendedData';
import { computeTrainingAverages, computeMatchAverages, computeLoads, computeMonotony, getLoadStatus } from '@/lib/demoData';
import {
  assessDataSufficiency, computeDescriptiveStats, detectTrend, detectChangePoint,
  detectAnomalies, computeDevelopmentIndex, computeDemandMatrix, computeLoadOptimization,
  assessEvidenceLevel, ALGORITHM_REGISTRY, type DataSufficiency, type TrendResult,
  type AnomalyResult, type DevelopmentIndex, type DemandMatrixEntry, type LoadOptimization,
} from '@/lib/statisticalEngine';
import { SectionTitle, KpiCard, Avatar, DataQualityBadge } from '@/components/ui';
import {
  ShieldCheck, AlertTriangle, TrendingUp, TrendingDown, Minus, Activity, Database,
  FlaskConical, BarChart3, GitBranch, AlertCircle, Info, ChevronDown, ChevronUp,
} from 'lucide-react';

export function PerformanceIntelligence({ athleteId, onSelectAthlete }: { athleteId: string; onSelectAthlete: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === athleteId) || athletes[0];
  const sessions = getAllTrainingSessions(athleteId);
  const matches = getAllMatchRecords(athleteId);
  const tests = getAllCapacityTests(athleteId);
  const insights = getAllInsights(athleteId);
  const dq = computeDataQuality(athleteId);

  const [showAlgorithms, setShowAlgorithms] = useState(false);
  const [selectedAthleteId, setSelectedAthleteId] = useState(athleteId);

  const currentAthleteId = selectedAthleteId;
  const currentSessions = getAllTrainingSessions(currentAthleteId);
  const currentMatches = getAllMatchRecords(currentAthleteId);
  const currentTests = getAllCapacityTests(currentAthleteId);
  const currentDq = computeDataQuality(currentAthleteId);

  const sufficiency = useMemo(() => assessDataSufficiency({
    sessions: currentSessions, matches: currentMatches, capacityTests: currentTests, interventions: [], dataCompleteness: (currentDq.gps + currentDq.hr) / 2,
  }), [currentSessions, currentMatches, currentTests, currentDq]);

  const trainAvg = computeTrainingAverages(currentSessions);
  const matchAvg = computeMatchAverages(currentMatches);
  const { acute, chronic, acwr } = computeLoads(currentSessions);
  const monotony = computeMonotony(currentSessions);
  const loadStatus = getLoadStatus(acute, chronic);

  // Descriptive stats for training load
  const loadStats = useMemo(() => computeDescriptiveStats(currentSessions.map((s) => s.trainingLoad)), [currentSessions]);
  const hsrStats = useMemo(() => computeDescriptiveStats(currentSessions.map((s) => s.highSpeedRunning)), [currentSessions]);

  // Trend detection for key metrics
  const sprintTrend = useMemo(() => {
    const test = currentTests.find((t) => t.name === '30 m Sprint');
    if (!test) return null;
    return detectTrend(test.history, test.higherIsBetter);
  }, [currentTests]);

  const changePoint = useMemo(() => {
    const test = currentTests.find((t) => t.name === '30 m Sprint');
    if (!test) return null;
    return detectChangePoint(test.history);
  }, [currentTests]);

  const anomalies = useMemo(() => detectAnomalies({
    sessions: currentSessions, matches: currentMatches, capacityTests: currentTests,
  }), [currentSessions, currentMatches, currentTests]);

  // Development index
  const devIndex = useMemo(() => {
    const capacityProgression = currentTests.length > 0
      ? Math.min(100, Math.round((currentTests.filter((t) => t.higherIsBetter ? t.latest > t.baseline : t.latest < t.baseline).length / currentTests.length) * 100))
      : 50;
    const demandCoverage = trainAvg && matchAvg ? Math.round(Math.min(trainAvg.highSpeedRunning / matchAvg.highSpeedRunning, 1) * 100) : 50;
    const loadAlignment = loadStatus === 'OPTIMAL' ? 85 : loadStatus === 'HIGH' ? 60 : loadStatus === 'LOW' ? 50 : 30;
    const performanceTrend = sprintTrend?.direction === 'improving' ? 85 : sprintTrend?.direction === 'stable' ? 70 : sprintTrend?.direction === 'plateau' ? 55 : 40;
    const dataConfidence = (currentDq.gps + currentDq.hr) / 2;
    return computeDevelopmentIndex({
      capacityProgression, demandCoverage, loadAlignment, performanceTrend, dataConfidence, dataSufficiency: sufficiency.level,
    });
  }, [currentTests, trainAvg, matchAvg, loadStatus, sprintTrend, currentDq, sufficiency]);

  // Demand matrix
  const demandMatrix = useMemo(() => {
    if (!trainAvg || !matchAvg) return [];
    const positionDemands = [
      { label: 'Total Distance', value: '', unit: 'km', category: 'volume' },
      { label: 'High-Speed Running', value: '', unit: 'm', category: 'intensity' },
      { label: 'Sprint Distance', value: '', unit: 'm', category: 'intensity' },
      { label: 'Accelerations', value: '', unit: 'count', category: 'frequency' },
      { label: 'Decelerations', value: '', unit: 'count', category: 'frequency' },
      { label: 'High-Intensity Efforts', value: '', unit: 'count', category: 'frequency' },
    ];
    const weights: Record<string, 'high' | 'medium' | 'low'> = {
      'Total Distance': 'medium', 'High-Speed Running': 'high', 'Sprint Distance': 'high',
      'Accelerations': 'medium', 'Decelerations': 'medium', 'High-Intensity Efforts': 'high',
    };
    return computeDemandMatrix({
      trainAvg: {
        'Total Distance': trainAvg.totalDistance, 'High-Speed Running': trainAvg.highSpeedRunning,
        'Sprint Distance': trainAvg.sprintDistance, 'Accelerations': trainAvg.accelerations,
        'Decelerations': trainAvg.decelerations, 'High-Intensity Efforts': trainAvg.highIntensityEfforts,
      },
      matchAvg: {
        'Total Distance': matchAvg.totalDistance, 'High-Speed Running': matchAvg.highSpeedRunning,
        'Sprint Distance': matchAvg.sprintDistance, 'Accelerations': matchAvg.accelerations,
        'Decelerations': matchAvg.decelerations, 'High-Intensity Efforts': matchAvg.highIntensityEfforts,
      },
      positionDemands, positionWeights: weights,
    });
  }, [trainAvg, matchAvg]);

  // Load optimization
  const loadOpt = useMemo(() => {
    if (!trainAvg || !matchAvg) return null;
    const recent7 = currentSessions.slice(0, 7);
    const prev7 = currentSessions.slice(7, 14);
    const recentChange = prev7.length > 0
      ? ((recent7.reduce((s, x) => s + x.trainingLoad, 0) / recent7.length) - (prev7.reduce((s, x) => s + x.trainingLoad, 0) / prev7.length)) / (prev7.reduce((s, x) => s + x.trainingLoad, 0) / prev7.length) * 100
      : 0;
    return computeLoadOptimization({
      trainAvg: trainAvg.highSpeedRunning, matchAvg: matchAvg.highSpeedRunning,
      baseline: trainAvg.highSpeedRunning, recentChange, dataSufficiency: sufficiency.level,
    });
  }, [trainAvg, matchAvg, currentSessions, sufficiency]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Performance Intelligence</h1>
          <p className="text-sm text-muted mt-1">Validation, statistical analysis & advanced intelligence</p>
        </div>
        <select
          value={selectedAthleteId}
          onChange={(e) => { setSelectedAthleteId(e.target.value); onSelectAthlete(e.target.value); }}
          className="surface-2 rounded-lg px-4 py-2.5 text-sm text-[rgb(var(--text))] border border-[rgb(var(--border))] focus:border-[rgb(var(--primary))] outline-none"
        >
          {athletes.map((a) => (
            <option key={a.id} value={a.id}>{a.name} — {a.position}</option>
          ))}
        </select>
      </div>

      {/* Data Sufficiency */}
      <div className={`card p-5 border-l-4 ${
        sufficiency.level === 'sufficient' ? 'border-l-emerald-500' :
        sufficiency.level === 'limited' ? 'border-l-amber-500' : 'border-l-red-500'
      }`}>
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-[rgb(var(--primary-light))] flex items-center justify-center text-[rgb(var(--primary))] shrink-0">
            <ShieldCheck size={20} />
          </div>
          <div className="flex-1">
            <h2 className="font-bold text-[rgb(var(--text))]">Data Sufficiency Assessment</h2>
            <p className="text-sm text-muted mt-1">{sufficiency.reason}</p>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-3">
              <div className="surface-2 rounded-lg p-3 text-center">
                <div className="text-xs text-muted">Sessions</div>
                <div className="text-lg font-bold text-[rgb(var(--text))]">{sufficiency.sessions}</div>
              </div>
              <div className="surface-2 rounded-lg p-3 text-center">
                <div className="text-xs text-muted">Matches</div>
                <div className="text-lg font-bold text-[rgb(var(--text))]">{sufficiency.matches}</div>
              </div>
              <div className="surface-2 rounded-lg p-3 text-center">
                <div className="text-xs text-muted">Capacity Tests</div>
                <div className="text-lg font-bold text-[rgb(var(--text))]">{sufficiency.capacityTests}</div>
              </div>
              <div className="surface-2 rounded-lg p-3 text-center">
                <div className="text-xs text-muted">Time Span</div>
                <div className="text-lg font-bold text-[rgb(var(--text))]">{sufficiency.timeSpanDays}d</div>
              </div>
              <div className="surface-2 rounded-lg p-3 text-center">
                <div className="text-xs text-muted">Completeness</div>
                <div className="text-lg font-bold text-[rgb(var(--text))]">{sufficiency.dataCompleteness}%</div>
              </div>
            </div>
            <div className="mt-3">
              <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-semibold ${
                sufficiency.level === 'sufficient' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' :
                sufficiency.level === 'limited' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' :
                'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
              }`}>
                {sufficiency.level === 'sufficient' && <ShieldCheck size={14} />}
                {sufficiency.level === 'limited' && <AlertTriangle size={14} />}
                {sufficiency.level === 'insufficient' && <AlertCircle size={14} />}
                {sufficiency.level.charAt(0).toUpperCase() + sufficiency.level.slice(1)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Development Index */}
      {devIndex && (
        <div className="card p-5">
          <SectionTitle title="Athlete Development Index" subtitle="Composite score with full component breakdown" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="surface-2 rounded-xl p-6 text-center flex flex-col items-center justify-center">
              <div className={`text-5xl font-bold ${
                devIndex.score >= 75 ? 'text-emerald-500' : devIndex.score >= 50 ? 'text-amber-500' : 'text-red-500'
              }`}>{devIndex.score}<span className="text-2xl text-muted">/100</span></div>
              <div className="mt-2">
                <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${
                  devIndex.confidence === 'High' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' :
                  devIndex.confidence === 'Moderate' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' :
                  'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
                }`}>
                  Confidence: {devIndex.confidence}
                </span>
              </div>
              <p className="text-xs text-muted mt-2">{devIndex.reason}</p>
            </div>
            <div className="lg:col-span-2 space-y-2">
              {devIndex.components.map((comp) => (
                <div key={comp.label} className="surface-2 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-[rgb(var(--text))]">{comp.label}</span>
                    <span className="text-sm font-bold text-[rgb(var(--text))]">{comp.score}/100</span>
                  </div>
                  <div className="h-2 bg-[rgb(var(--surface-3))] rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{
                      width: `${comp.score}%`,
                      backgroundColor: comp.score >= 75 ? 'rgb(var(--success))' : comp.score >= 50 ? 'rgb(var(--warning))' : 'rgb(var(--error))',
                    }} />
                  </div>
                  <p className="text-xs text-muted mt-1">{comp.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Descriptive Statistics */}
      <div className="card p-5">
        <SectionTitle title="Descriptive Statistics" subtitle="Training load and high-speed running distributions" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {loadStats && (
            <StatCard title="Training Load" unit="AU" stats={loadStats} />
          )}
          {hsrStats && (
            <StatCard title="High-Speed Running" unit="m" stats={hsrStats} />
          )}
        </div>
      </div>

      {/* Trend & Change-Point Detection */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {sprintTrend && (
          <div className="card p-5">
            <SectionTitle title="Capacity Trend Analysis" subtitle="30m sprint performance over time" />
            <TrendDisplay trend={sprintTrend} />
          </div>
        )}
        {changePoint && (
          <div className="card p-5">
            <SectionTitle title="Change-Point Detection" subtitle="Potential shifts in performance trajectory" />
            <div className={`rounded-xl p-4 ${changePoint.detected ? 'bg-amber-50 dark:bg-amber-900/20' : 'surface-2'}`}>
              <div className="flex items-start gap-2">
                {changePoint.detected ? <AlertTriangle size={18} className="text-amber-500 shrink-0 mt-0.5" /> : <Info size={18} className="text-muted shrink-0 mt-0.5" />}
                <p className="text-sm text-[rgb(var(--text))]">{changePoint.description}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Performance Demand Matrix */}
      {demandMatrix.length > 0 && (
        <div className="card p-5">
          <SectionTitle title="Performance Demand Matrix" subtitle="Training coverage vs competition demands by metric" />
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[rgb(var(--border))]">
                  <th className="text-left py-2 px-3 font-medium text-muted">Demand</th>
                  <th className="text-center py-2 px-3 font-medium text-muted">Importance</th>
                  <th className="text-right py-2 px-3 font-medium text-muted">Training</th>
                  <th className="text-right py-2 px-3 font-medium text-muted">Match</th>
                  <th className="text-right py-2 px-3 font-medium text-muted">Coverage</th>
                  <th className="text-center py-2 px-3 font-medium text-muted">Gap</th>
                </tr>
              </thead>
              <tbody>
                {demandMatrix.map((entry) => (
                  <tr key={entry.demand} className="border-b border-[rgb(var(--border))] last:border-0">
                    <td className="py-2 px-3 text-[rgb(var(--text))]">{entry.demand}</td>
                    <td className="py-2 px-3 text-center">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        entry.importance === 'high' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' :
                        entry.importance === 'medium' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' :
                        'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'
                      }`}>{entry.importance}</span>
                    </td>
                    <td className="py-2 px-3 text-right text-muted">{entry.trainingValue.toFixed(1)} {entry.unit}</td>
                    <td className="py-2 px-3 text-right text-muted">{entry.matchValue.toFixed(1)} {entry.unit}</td>
                    <td className="py-2 px-3 text-right font-semibold text-[rgb(var(--text))]">{entry.coverage}%</td>
                    <td className="py-2 px-3 text-center">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        entry.gap === 'large' ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' :
                        entry.gap === 'moderate' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' :
                        entry.gap === 'small' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300' :
                        'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300'
                      }`}>{entry.gap}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Load Optimization */}
      {loadOpt && (
        <div className="card p-5">
          <SectionTitle title="Load Optimization" subtitle="Data-driven training exposure assessment" />
          <div className={`rounded-xl p-4 mb-3 ${
            loadOpt.status === 'aligned' ? 'bg-emerald-50 dark:bg-emerald-900/20' :
            loadOpt.status === 'underexposed' ? 'bg-amber-50 dark:bg-amber-900/20' :
            loadOpt.status === 'overexposed' ? 'bg-red-50 dark:bg-red-900/20' :
            loadOpt.status === 'rapid_change' ? 'bg-orange-50 dark:bg-orange-900/20' :
            'bg-gray-50 dark:bg-gray-900/20'
          }`}>
            <div className="flex items-center gap-2 mb-2">
              <Activity size={18} className="text-[rgb(var(--primary))]" />
              <span className="font-semibold text-[rgb(var(--text))] capitalize">{loadOpt.status.replace('_', ' ')}</span>
            </div>
            <p className="text-sm text-[rgb(var(--text))]">{loadOpt.description}</p>
          </div>
          {loadOpt.recommendations.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs text-muted uppercase tracking-wider">Recommendations</h4>
              {loadOpt.recommendations.map((rec, i) => (
                <div key={i} className="flex items-start gap-2 text-sm text-[rgb(var(--text))]">
                  <span className="text-[rgb(var(--primary))] font-bold shrink-0">{i + 1}.</span>
                  {rec}
                </div>
              ))}
            </div>
          )}
          {loadOpt.tradeoffs.length > 0 && (
            <div className="mt-3 space-y-1">
              <h4 className="text-xs text-muted uppercase tracking-wider">Trade-offs to Consider</h4>
              {loadOpt.tradeoffs.map((t, i) => (
                <div key={i} className="text-xs text-muted flex items-start gap-1.5">
                  <Info size={12} className="shrink-0 mt-0.5" /> {t}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Anomaly Detection */}
      {anomalies.length > 0 && (
        <div className="card p-5">
          <SectionTitle title="Performance Anomalies" subtitle={`${anomalies.length} anomalies detected`} />
          <div className="space-y-2 max-h-80 overflow-y-auto scrollbar-thin">
            {anomalies.slice(0, 10).map((a, i) => (
              <AnomalyRow key={i} anomaly={a} />
            ))}
          </div>
        </div>
      )}

      {/* Evidence Hierarchy */}
      <div className="card p-5">
        <SectionTitle title="Evidence Hierarchy" subtitle="How AthleteIQ classifies its conclusions" />
        <div className="space-y-2">
          {[
            { level: 1, label: 'Observation', desc: 'A single observation', color: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300' },
            { level: 2, label: 'Pattern', desc: 'Repeated observation across multiple sessions', color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300' },
            { level: 3, label: 'Association', desc: 'Measurable relationship between variables', color: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-300' },
            { level: 4, label: 'Stronger Inference', desc: 'Repeated observations with adequate data and methodology', color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' },
            { level: 5, label: 'Causal Claim', desc: 'Only where study design genuinely supports causal inference', color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300' },
          ].map((e) => (
            <div key={e.level} className="flex items-center gap-3 surface-2 rounded-lg p-3">
              <span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold ${e.color}`}>{e.level}</span>
              <div>
                <div className="text-sm font-semibold text-[rgb(var(--text))]">{e.label}</div>
                <div className="text-xs text-muted">{e.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Algorithm Registry */}
      <div className="card p-5">
        <button onClick={() => setShowAlgorithms(!showAlgorithms)} className="w-full flex items-center justify-between">
          <SectionTitle title="Algorithm Registry" subtitle="Versioned calculations for reproducibility" />
          {showAlgorithms ? <ChevronUp size={20} className="text-muted" /> : <ChevronDown size={20} className="text-muted" />}
        </button>
        {showAlgorithms && (
          <div className="mt-3 overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[rgb(var(--border))]">
                  <th className="text-left py-2 px-3 font-medium text-muted">Algorithm</th>
                  <th className="text-left py-2 px-3 font-medium text-muted">Version</th>
                  <th className="text-left py-2 px-3 font-medium text-muted hidden md:table-cell">Description</th>
                  <th className="text-center py-2 px-3 font-medium text-muted">Status</th>
                </tr>
              </thead>
              <tbody>
                {ALGORITHM_REGISTRY.map((alg) => (
                  <tr key={alg.name} className="border-b border-[rgb(var(--border))] last:border-0">
                    <td className="py-2 px-3 text-[rgb(var(--text))]">{alg.name}</td>
                    <td className="py-2 px-3 text-muted">{alg.version}</td>
                    <td className="py-2 px-3 text-muted hidden md:table-cell">{alg.description}</td>
                    <td className="py-2 px-3 text-center">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        alg.status === 'production' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' :
                        alg.status === 'experimental' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' :
                        'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
                      }`}>{alg.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ title, unit, stats }: { title: string; unit: string; stats: NonNullable<ReturnType<typeof computeDescriptiveStats>> }) {
  return (
    <div className="surface-2 rounded-xl p-4">
      <h4 className="text-sm font-semibold text-[rgb(var(--text))] mb-3">{title}</h4>
      <div className="grid grid-cols-2 gap-3 text-sm">
        <div><span className="text-muted">Mean: </span><span className="font-semibold text-[rgb(var(--text))]">{stats.mean} {unit}</span></div>
        <div><span className="text-muted">Median: </span><span className="font-semibold text-[rgb(var(--text))]">{stats.median} {unit}</span></div>
        <div><span className="text-muted">Std Dev: </span><span className="font-semibold text-[rgb(var(--text))]">{stats.stdDev} {unit}</span></div>
        <div><span className="text-muted">CV: </span><span className="font-semibold text-[rgb(var(--text))]">{stats.cv}%</span></div>
        <div><span className="text-muted">Min: </span><span className="font-semibold text-[rgb(var(--text))]">{stats.min} {unit}</span></div>
        <div><span className="text-muted">Max: </span><span className="font-semibold text-[rgb(var(--text))]">{stats.max} {unit}</span></div>
        <div><span className="text-muted">IQR: </span><span className="font-semibold text-[rgb(var(--text))]">{stats.iqr} {unit}</span></div>
        <div><span className="text-muted">N: </span><span className="font-semibold text-[rgb(var(--text))]">{stats.count}</span></div>
      </div>
    </div>
  );
}

function TrendDisplay({ trend }: { trend: TrendResult }) {
  const icons = {
    improving: <TrendingUp size={20} className="text-emerald-500" />,
    declining: <TrendingDown size={20} className="text-red-500" />,
    stable: <Minus size={20} className="text-blue-500" />,
    plateau: <Minus size={20} className="text-amber-500" />,
    variable: <Activity size={20} className="text-purple-500" />,
    insufficient: <Info size={20} className="text-muted" />,
  };
  return (
    <div className="surface-2 rounded-xl p-4">
      <div className="flex items-center gap-3 mb-3">
        {icons[trend.direction]}
        <span className="text-lg font-bold capitalize text-[rgb(var(--text))]">{trend.direction}</span>
      </div>
      <p className="text-sm text-[rgb(var(--text))]">{trend.interpretation}</p>
      <div className="mt-3 flex items-center gap-4 text-xs text-muted">
        <span>Slope: {trend.slope}</span>
        <span>R²: {trend.r2}</span>
        <span>Confidence: {trend.confidence}</span>
      </div>
    </div>
  );
}

function AnomalyRow({ anomaly }: { anomaly: AnomalyResult }) {
  const severityColors = {
    info: 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300',
    warning: 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-300',
    critical: 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300',
  };
  return (
    <div className={`flex items-start gap-2 rounded-lg p-3 text-sm ${severityColors[anomaly.severity]}`}>
      {anomaly.severity === 'critical' ? <AlertCircle size={16} className="shrink-0 mt-0.5" /> :
       anomaly.severity === 'warning' ? <AlertTriangle size={16} className="shrink-0 mt-0.5" /> :
       <Info size={16} className="shrink-0 mt-0.5" />}
      <div>
        <span className="font-semibold">{anomaly.metric}</span>
        <span className="ml-1 opacity-80">· {anomaly.date}</span>
        <p className="mt-0.5">{anomaly.description}</p>
        <p className="text-xs opacity-70 mt-0.5">{anomaly.expected}</p>
      </div>
    </div>
  );
}
