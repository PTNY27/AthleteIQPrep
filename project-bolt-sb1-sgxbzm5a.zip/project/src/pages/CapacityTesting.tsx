import { useState } from 'react';
import { getAllAthletes, getAllCapacityTests } from '@/lib/extendedData';
import { Avatar, SectionTitle } from '@/components/ui';
import { LineChart } from '@/components/charts/Charts';
import { TrendingUp, TrendingDown, Minus, ClipboardList } from 'lucide-react';
import type { CapacityTest } from '@/lib/types';

const categoryOrder = ['Speed', 'Acceleration', 'Repeated Sprint Ability', 'Aerobic Capacity', 'Anaerobic Capacity', 'Change of Direction', 'Strength / Power'];

export function CapacityTesting({ athleteId, onSelectAthlete }: { athleteId: string; onSelectAthlete: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === athleteId) || athletes[0];
  const tests = getAllCapacityTests(athlete.id);
  const [selectedCat, setSelectedCat] = useState<string | null>(null);

  const categories = [...new Set(tests.map((t) => t.category))].sort((a, b) => categoryOrder.indexOf(a) - categoryOrder.indexOf(b));
  const filteredTests = selectedCat ? tests.filter((t) => t.category === selectedCat) : tests;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Capacity Testing</h1>
          <p className="text-sm text-muted mt-1">Baseline → Test Result → Benchmark → Gap</p>
        </div>
        <div className="relative">
          <AthleteDropdown selectedId={athleteId} onSelect={onSelectAthlete} />
        </div>
      </div>

      {/* Athlete header */}
      <div className="card p-4 flex items-center gap-4">
        <Avatar initials={athlete.initials} color={athlete.avatarColor} size={48} />
        <div>
          <h3 className="font-bold text-[rgb(var(--text))]">{athlete.name}</h3>
          <p className="text-sm text-muted">{athlete.position} · {athlete.sport === 'football' ? 'Football' : 'Rugby'}</p>
        </div>
        <div className="ml-auto flex items-center gap-4">
          <div className="text-right">
            <div className="text-xs text-muted">Tests Completed</div>
            <div className="text-lg font-bold text-[rgb(var(--text))]">{tests.length}</div>
          </div>
          <div className="text-right">
            <div className="text-xs text-muted">Last Tested</div>
            <div className="text-sm font-medium text-[rgb(var(--text))]">{tests[0]?.date || '—'}</div>
          </div>
        </div>
      </div>

      {/* Category filter */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setSelectedCat(null)}
          className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
            selectedCat === null ? 'bg-[rgb(var(--primary))] text-white' : 'surface-2 text-muted hover:text-[rgb(var(--text))]'
          }`}
        >
          All Categories
        </button>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCat(cat)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              selectedCat === cat ? 'bg-[rgb(var(--primary))] text-white' : 'surface-2 text-muted hover:text-[rgb(var(--text))]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Test cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredTests.map((test) => (
          <TestCard key={test.id} test={test} />
        ))}
      </div>

      {/* Summary table */}
      <div className="card p-5">
        <SectionTitle title="Capacity Summary" subtitle="All tests — baseline, latest, benchmark, and gap" />
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[rgb(var(--border))]">
                <th className="text-left py-2 px-3 font-medium text-muted">Category</th>
                <th className="text-left py-2 px-3 font-medium text-muted">Test</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Baseline</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Latest</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Benchmark</th>
                <th className="text-right py-2 px-3 font-medium text-muted">Gap</th>
                <th className="text-center py-2 px-3 font-medium text-muted">Trend</th>
              </tr>
            </thead>
            <tbody>
              {tests.map((test) => {
            const gap = test.higherIsBetter
              ? ((test.benchmark - test.latest) / test.benchmark) * 100
              : ((test.latest - test.benchmark) / test.benchmark) * 100;
            const change = test.higherIsBetter
              ? ((test.latest - test.baseline) / test.baseline) * 100
              : ((test.baseline - test.latest) / test.baseline) * 100;
            const improving = test.higherIsBetter ? test.latest > test.baseline : test.latest < test.baseline;
            return (
              <tr key={test.id} className="border-b border-[rgb(var(--border))] last:border-0 hover:bg-[rgb(var(--surface-2))]">
                <td className="py-2.5 px-3 text-muted text-xs">{test.category}</td>
                <td className="py-2.5 px-3 font-medium text-[rgb(var(--text))]">{test.name}</td>
                <td className="py-2.5 px-3 text-right text-muted">{test.baseline} {test.unit}</td>
                <td className="py-2.5 px-3 text-right font-semibold text-[rgb(var(--text))]">{test.latest} {test.unit}</td>
                <td className="py-2.5 px-3 text-right text-muted">{test.benchmark} {test.unit}</td>
                <td className={`py-2.5 px-3 text-right font-semibold ${gap > 5 ? 'text-amber-500' : gap < -5 ? 'text-emerald-500' : 'text-muted'}`}>
                  {gap > 0 ? '-' : '+'}{Math.abs(gap).toFixed(1)}%
                </td>
                <td className="py-2.5 px-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    {improving ? (
                      <TrendingUp size={14} className="text-emerald-500" />
                    ) : change === 0 ? (
                      <Minus size={14} className="text-subtle" />
                    ) : (
                      <TrendingDown size={14} className="text-red-500" />
                    )}
                    <span className={`text-xs ${improving ? 'text-emerald-500' : 'text-red-500'}`}>
                      {improving ? '+' : ''}{change.toFixed(1)}%
                    </span>
                  </div>
                </td>
              </tr>
            );
          })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function TestCard({ test }: { test: CapacityTest }) {
  const gap = test.higherIsBetter
    ? ((test.benchmark - test.latest) / test.benchmark) * 100
    : ((test.latest - test.benchmark) / test.benchmark) * 100;
  const change = test.higherIsBetter
    ? ((test.latest - test.baseline) / test.baseline) * 100
    : ((test.baseline - test.latest) / test.baseline) * 100;
  const improving = test.higherIsBetter ? test.latest > test.baseline : test.latest < test.baseline;

  const chartData = test.history.map((h) => ({
    label: new Date(h.date).toLocaleDateString('en', { month: 'short' }),
    value: h.value,
  }));

  return (
    <div className="card p-5">
      <div className="flex items-start justify-between mb-3">
        <div>
          <span className="text-xs text-muted uppercase tracking-wider">{test.category}</span>
          <h3 className="font-bold text-[rgb(var(--text))]">{test.name}</h3>
        </div>
        <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
          improving ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'
        }`}>
          {improving ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
          {improving ? '+' : ''}{change.toFixed(1)}%
        </div>
      </div>

      <LineChart
        data={chartData}
        unit={test.unit}
        height={160}
        benchmark={test.benchmark}
        baseline={test.baseline}
        higherIsBetter={test.higherIsBetter}
        color={improving ? 'rgb(var(--success))' : 'rgb(var(--error))'}
      />

      <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-[rgb(var(--border))]">
        <div>
          <div className="text-xs text-muted">Baseline</div>
          <div className="text-sm font-semibold text-[rgb(var(--text))]">{test.baseline} {test.unit}</div>
        </div>
        <div>
          <div className="text-xs text-muted">Latest</div>
          <div className="text-sm font-semibold text-[rgb(var(--text))]">{test.latest} {test.unit}</div>
        </div>
        <div>
          <div className="text-xs text-muted">Benchmark</div>
          <div className="text-sm font-semibold text-[rgb(var(--text))]">{test.benchmark} {test.unit}</div>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between">
        <span className="text-xs text-muted">Gap to benchmark</span>
        <span className={`text-xs font-bold ${gap > 5 ? 'text-amber-500' : gap < -5 ? 'text-emerald-500' : 'text-muted'}`}>
          {gap > 0 ? '-' : '+'}{Math.abs(gap).toFixed(1)}%
        </span>
      </div>
    </div>
  );
}

function AthleteDropdown({ selectedId, onSelect }: { selectedId: string; onSelect: (id: string) => void }) {
  const athletes = getAllAthletes();
  const athlete = athletes.find((a) => a.id === selectedId) || athletes[0];
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 surface rounded-xl px-3 py-2 hover:border-[rgb(var(--primary))] transition-colors"
      >
        <Avatar initials={athlete.initials} color={athlete.avatarColor} size={32} />
        <span className="text-sm font-medium text-[rgb(var(--text))]">{athlete.name}</span>
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full mt-2 z-20 w-64 card rounded-xl shadow-lg overflow-hidden animate-scale-in">
            {athletes.map((a) => (
              <button
                key={a.id}
                onClick={() => { onSelect(a.id); setOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-[rgb(var(--surface-2))] transition-colors text-left ${a.id === selectedId ? 'bg-[rgb(var(--surface-2))]' : ''}`}
              >
                <Avatar initials={a.initials} color={a.avatarColor} size={36} />
                <div>
                  <div className="text-sm font-medium text-[rgb(var(--text))]">{a.name}</div>
                  <div className="text-xs text-muted">{a.position}</div>
                </div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
