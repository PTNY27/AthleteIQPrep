import { useState } from 'react';
import { getAllAthletes, getAllTrainingSessions, getAllMatchRecords, getAllCapacityTests } from '@/lib/extendedData';
import { computeLoads, getLoadStatus } from '@/lib/demoData';
import { Avatar, SportBadge, StatusBadge } from '@/components/ui';
import { TrendingUp, TrendingDown, Minus, ChevronRight } from 'lucide-react';

interface AthletesPageProps {
  onSelectAthlete: (id: string) => void;
}

export function AthletesPage({ onSelectAthlete }: AthletesPageProps) {
  const [filter, setFilter] = useState<'all' | 'football' | 'rugby'>('all');

  const athletes = getAllAthletes();
  const filtered = athletes.filter((a) => filter === 'all' || a.sport === filter);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Athletes</h1>
        <p className="text-sm text-muted mt-1">Performance-focused athlete profiles</p>
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        {(['all', 'football', 'rugby'] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              filter === f
                ? 'bg-[rgb(var(--primary))] text-white'
                : 'surface text-muted hover:text-[rgb(var(--text))]'
            }`}
          >
            {f === 'all' ? 'All Athletes' : f === 'football' ? 'Football' : 'Rugby'}
          </button>
        ))}
      </div>

      {/* Athlete cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map((athlete) => {
          const sessions = getAllTrainingSessions(athlete.id);
          const matches = getAllMatchRecords(athlete.id);
          const { acute, chronic, acwr } = computeLoads(sessions);
          const status = getLoadStatus(acute, chronic);
          const tests = getAllCapacityTests(athlete.id);
          const improving = tests.filter((t) => t.higherIsBetter ? t.latest > t.baseline : t.latest < t.baseline).length;
          const declining = tests.filter((t) => t.higherIsBetter ? t.latest < t.baseline : t.latest > t.baseline).length;
          const stable = tests.length - improving - declining;

          return (
            <button
              key={athlete.id}
              onClick={() => onSelectAthlete(athlete.id)}
              className="card p-5 text-left hover:border-[rgb(var(--primary))] transition-all group"
            >
              <div className="flex items-start gap-4">
                <Avatar initials={athlete.initials} color={athlete.avatarColor} size={56} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-[rgb(var(--text))] text-lg">{athlete.name}</h3>
                    <ChevronRight size={18} className="text-subtle group-hover:text-[rgb(var(--primary))] group-hover:translate-x-1 transition-all" />
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <SportBadge sport={athlete.sport} />
                    <span className="text-sm text-muted">{athlete.position}</span>
                  </div>
                  <div className="text-xs text-muted mt-1">{athlete.team} · {athlete.age} yrs</div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-[rgb(var(--border))]">
                <div>
                  <div className="text-xs text-muted">Load Status</div>
                  <div className="mt-1"><StatusBadge status={status} /></div>
                </div>
                <div>
                  <div className="text-xs text-muted">ACWR</div>
                  <div className="text-sm font-bold text-[rgb(var(--text))] mt-1">{acwr.toFixed(2)}</div>
                </div>
                <div>
                  <div className="text-xs text-muted">Matches</div>
                  <div className="text-sm font-bold text-[rgb(var(--text))] mt-1">{matches.length}</div>
                </div>
              </div>

              <div className="flex items-center gap-4 mt-3">
                <div className="flex items-center gap-1.5">
                  <TrendingUp size={14} className="text-emerald-500" />
                  <span className="text-xs text-muted">{improving} improving</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Minus size={14} className="text-subtle" />
                  <span className="text-xs text-muted">{stable} stable</span>
                </div>
                {declining > 0 && (
                  <div className="flex items-center gap-1.5">
                    <TrendingDown size={14} className="text-red-500" />
                    <span className="text-xs text-muted">{declining} declining</span>
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
