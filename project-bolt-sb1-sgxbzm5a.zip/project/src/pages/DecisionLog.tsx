import { useMemo, useState } from 'react';
import { demoDecisionLog, computeRecommendationHistory, type DecisionRecord } from '@/lib/statisticalEngine';
import { SectionTitle, Avatar, KpiCard } from '@/components/ui';
import { getAllAthletes } from '@/lib/extendedData';
import { CheckCircle2, XCircle, Edit3, FileText, TrendingUp, Activity, HelpCircle, Download } from 'lucide-react';

export function DecisionLog() {
  const athletes = getAllAthletes();
  const [filter, setFilter] = useState<'all' | 'accepted' | 'modified' | 'rejected'>('all');

  const history = useMemo(() => computeRecommendationHistory(demoDecisionLog), []);
  const filtered = filter === 'all' ? demoDecisionLog : demoDecisionLog.filter((d) => d.coachDecision === filter);

  const getAthlete = (id: string) => athletes.find((a) => a.id === id);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-[rgb(var(--text))]">Decision Log</h1>
        <p className="text-sm text-muted mt-1">Performance decision record: recommendation → decision → intervention → outcome → evaluation</p>
      </div>

      {/* Summary KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard label="Total Decisions" value={history.total.toString()} sublabel="All recommendations" icon={<FileText size={20} />} color="rgb(var(--chart-1))" />
        <KpiCard label="Accepted" value={history.accepted.toString()} sublabel={`${Math.round(history.accepted / history.total * 100)}% of total`} icon={<CheckCircle2 size={20} />} color="rgb(var(--success))" />
        <KpiCard label="Modified" value={history.modified.toString()} sublabel="Coach adjusted" icon={<Edit3 size={20} />} color="rgb(var(--warning))" />
        <KpiCard label="Rejected" value={history.rejected.toString()} sublabel="Coach declined" icon={<XCircle size={20} />} color="rgb(var(--error))" />
      </div>

      {/* Outcome summary */}
      <div className="card p-5">
        <SectionTitle title="Recommendation Outcome History" subtitle="What happened after recommendations were acted on" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="surface-2 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-emerald-500">{history.positiveOutcomes}</div>
            <div className="text-xs text-muted">Positive Outcomes</div>
          </div>
          <div className="surface-2 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-amber-500">{history.partialOutcomes}</div>
            <div className="text-xs text-muted">Partial Outcomes</div>
          </div>
          <div className="surface-2 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-blue-500">{history.noChangeOutcomes}</div>
            <div className="text-xs text-muted">No Clear Change</div>
          </div>
          <div className="surface-2 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-muted">{history.unknownOutcomes}</div>
            <div className="text-xs text-muted">Unknown / Pending</div>
          </div>
        </div>
        <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
          <p className="text-xs text-blue-700 dark:text-blue-300">
            This is called "Recommendation Outcome History" — not "AI accuracy" — because the methodology does not measure predictive accuracy. It tracks what happened after decisions were made.
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        {[
          { key: 'all', label: 'All Decisions' },
          { key: 'accepted', label: 'Accepted' },
          { key: 'modified', label: 'Modified' },
          { key: 'rejected', label: 'Rejected' },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key as typeof filter)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              filter === f.key ? 'bg-[rgb(var(--primary))] text-white' : 'surface-2 text-muted hover:text-[rgb(var(--text))]'
            }`}
          >
            {f.label}
          </button>
        ))}
        <button className="ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium surface-2 text-muted hover:text-[rgb(var(--text))] transition-all">
          <Download size={14} /> Export Log
        </button>
      </div>

      {/* Decision records */}
      <div className="space-y-3">
        {filtered.map((record) => {
          const athlete = getAthlete(record.athleteId);
          return <DecisionCard key={record.id} record={record} athlete={athlete} />;
        })}
      </div>

      {/* Learning Loop */}
      <div className="card p-5">
        <SectionTitle title="AI Learning Loop" subtitle="How decisions feed back into the system" />
        <div className="flex flex-col lg:flex-row items-stretch gap-2 text-xs">
          {['Recommendation', 'Coach Decision', 'Intervention', 'Outcome', 'Evaluation', 'Learning'].map((step, i, arr) => (
            <div key={step} className="flex items-center gap-2 flex-1">
              <div className="flex-1 surface-2 rounded-lg p-3 text-center font-medium text-[rgb(var(--text))]">{step}</div>
              {i < arr.length - 1 && <span className="text-subtle shrink-0">→</span>}
            </div>
          ))}
        </div>
        <p className="text-xs text-muted mt-3">
          This creates a historical decision dataset. AthleteIQ does not automatically train a machine-learning model from this data — data quality and decision consistency must be validated first.
        </p>
      </div>
    </div>
  );
}

function DecisionCard({ record, athlete }: { record: DecisionRecord; athlete?: ReturnType<typeof getAllAthletes>[0] }) {
  const decisionConfig = {
    accepted: { color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300', icon: <CheckCircle2 size={14} />, label: 'Accepted' },
    modified: { color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300', icon: <Edit3 size={14} />, label: 'Modified' },
    rejected: { color: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300', icon: <XCircle size={14} />, label: 'Rejected' },
  };

  const outcomeConfig = {
    positive: { color: 'text-emerald-500', label: 'Positive' },
    partial: { color: 'text-amber-500', label: 'Partial' },
    no_change: { color: 'text-blue-500', label: 'No Clear Change' },
    negative: { color: 'text-red-500', label: 'Negative' },
    insufficient: { color: 'text-muted', label: 'Insufficient Data' },
  };

  const dc = decisionConfig[record.coachDecision];

  return (
    <div className="card p-5">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-3">
          {athlete && <Avatar initials={athlete.initials} color={athlete.avatarColor} size={36} />}
          <div>
            <h3 className="text-sm font-semibold text-[rgb(var(--text))]">{record.finding}</h3>
            <p className="text-xs text-muted">{record.date} · {record.athleteName}</p>
          </div>
        </div>
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${dc.color}`}>
          {dc.icon} {dc.label}
        </span>
      </div>

      <div className="space-y-2 text-sm">
        <div>
          <span className="text-xs text-muted uppercase tracking-wider">Evidence: </span>
          <span className="text-[rgb(var(--text))]">{record.evidence}</span>
        </div>
        <div>
          <span className="text-xs text-muted uppercase tracking-wider">Recommendation: </span>
          <span className="text-[rgb(var(--text))]">{record.recommendation}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted uppercase tracking-wider">Confidence:</span>
          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
            record.confidence === 'High' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' :
            record.confidence === 'Moderate' ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300' :
            'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'
          }`}>{record.confidence}</span>
        </div>
      </div>

      {record.outcome && (
        <div className="mt-3 pt-3 border-t border-[rgb(var(--border))]">
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp size={14} className="text-[rgb(var(--primary))]" />
            <span className="text-xs text-muted uppercase tracking-wider">Outcome:</span>
            <span className={`text-sm font-semibold ${outcomeConfig[record.outcome].color}`}>
              {outcomeConfig[record.outcome].label}
            </span>
          </div>
          {record.followUp && (
            <p className="text-xs text-muted mt-1">{record.followUp}</p>
          )}
        </div>
      )}

      {!record.outcome && (
        <div className="mt-3 pt-3 border-t border-[rgb(var(--border))]">
          <div className="flex items-center gap-2">
            <HelpCircle size={14} className="text-muted" />
            <span className="text-xs text-muted">Outcome pending — awaiting follow-up assessment</span>
          </div>
        </div>
      )}
    </div>
  );
}
