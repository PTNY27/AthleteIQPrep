import type { LoadStatus, GapStatus, LoadClassification, ReadinessStatus, DataQualityStatus } from '@/lib/types';

export function StatusBadge({ status }: { status: LoadStatus }) {
  const styles: Record<LoadStatus, string> = {
    LOW: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
    OPTIMAL: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
    HIGH: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
    FLAG: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',
  };
  const dots: Record<LoadStatus, string> = {
    LOW: 'bg-blue-500',
    OPTIMAL: 'bg-emerald-500',
    HIGH: 'bg-amber-500',
    FLAG: 'bg-red-500',
  };
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status]}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dots[status]}`} />
      {status}
    </span>
  );
}

export function GapBadge({ status }: { status: GapStatus }) {
  const styles: Record<GapStatus, string> = {
    UNDEREXPOSURE: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
    APPROPRIATE: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
    EXCESSIVE: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status]}`}>
      {status}
    </span>
  );
}

export function LoadClassBadge({ classification }: { classification: LoadClassification }) {
  const styles: Record<LoadClassification, string> = {
    'Low Load': 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',
    'Moderate Load': 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
    'High Load': 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
    'Very High Load': 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',
  };
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${styles[classification]}`}>
      {classification}
    </span>
  );
}

export function SportBadge({ sport }: { sport: 'football' | 'rugby' }) {
  return sport === 'football' ? (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300">
      Football
    </span>
  ) : (
    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300">
      Rugby
    </span>
  );
}

interface KpiCardProps {
  label: string;
  value: string;
  unit?: string;
  sublabel?: string;
  trend?: number;
  icon?: React.ReactNode;
  color?: string;
}

export function KpiCard({ label, value, unit, sublabel, trend, icon, color }: KpiCardProps) {
  return (
    <div className="card p-5 animate-slide-up">
      <div className="flex items-start justify-between mb-3">
        <span className="text-xs font-medium text-muted uppercase tracking-wider">{label}</span>
        {icon && <span style={{ color: color || 'rgb(var(--primary))' }}>{icon}</span>}
      </div>
      <div className="flex items-baseline gap-1">
        <span className="text-3xl font-bold text-[rgb(var(--text))]">{value}</span>
        {unit && <span className="text-sm text-muted">{unit}</span>}
      </div>
      <div className="flex items-center justify-between mt-2">
        {sublabel && <span className="text-xs text-muted">{sublabel}</span>}
        {trend !== undefined && (
          <span className={`text-xs font-semibold ${trend >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
            {trend >= 0 ? '+' : ''}{trend.toFixed(1)}%
          </span>
        )}
      </div>
    </div>
  );
}

export function Avatar({ initials, color, size = 40 }: { initials: string; color: string; size?: number }) {
  return (
    <div
      className="rounded-full flex items-center justify-center font-bold text-white shrink-0"
      style={{ width: size, height: size, backgroundColor: color, fontSize: size * 0.4 }}
    >
      {initials}
    </div>
  );
}

export function SectionTitle({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-end justify-between mb-4">
      <div>
        <h2 className="text-lg font-bold text-[rgb(var(--text))]">{title}</h2>
        {subtitle && <p className="text-sm text-muted mt-0.5">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function ReadinessBadge({ status }: { status: ReadinessStatus }) {
  const styles: Record<ReadinessStatus, string> = {
    READY: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
    MONITOR: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
    REVIEW: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',
  };
  const dots: Record<ReadinessStatus, string> = {
    READY: 'bg-emerald-500',
    MONITOR: 'bg-amber-500',
    REVIEW: 'bg-red-500',
  };
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status]}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dots[status]}`} />
      {status}
    </span>
  );
}

export function DataQualityBadge({ status, gps, hr }: { status: DataQualityStatus; gps?: number; hr?: number }) {
  const styles: Record<DataQualityStatus, string> = {
    GOOD: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300',
    PARTIAL: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',
    POOR: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',
  };
  const dots: Record<DataQualityStatus, string> = {
    GOOD: 'bg-emerald-500',
    PARTIAL: 'bg-amber-500',
    POOR: 'bg-red-500',
  };
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${styles[status]}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dots[status]}`} />
      {status}
      {gps !== undefined && hr !== undefined && status !== 'GOOD' && (
        <span className="text-xs font-normal opacity-70">· GPS {gps}% · HR {hr}%</span>
      )}
    </span>
  );
}

export function TimePeriodSelector({ value, onChange }: { value: string; onChange: (v: '7d' | '14d' | '28d' | '6w' | '8w' | '12w' | 'season') => void }) {
  const periods: { key: '7d' | '14d' | '28d' | '6w' | '8w' | '12w' | 'season'; label: string }[] = [
    { key: '7d', label: '7 Days' },
    { key: '14d', label: '14 Days' },
    { key: '28d', label: '28 Days' },
    { key: '6w', label: '6 Weeks' },
    { key: '8w', label: '8 Weeks' },
    { key: '12w', label: '12 Weeks' },
    { key: 'season', label: 'Season' },
  ];
  return (
    <div className="flex flex-wrap gap-1.5">
      {periods.map((p) => (
        <button
          key={p.key}
          onClick={() => onChange(p.key)}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
            value === p.key ? 'bg-[rgb(var(--primary))] text-white' : 'surface-2 text-muted hover:text-[rgb(var(--text))]'
          }`}
        >
          {p.label}
        </button>
      ))}
    </div>
  );
}
