import { useState, useEffect } from 'react';
import { Activity, Users, Target, ClipboardList, Dumbbell, Trophy, BarChart3, Sparkles, Moon, Sun, Menu, X, FlaskConical, Brain, Beaker, FileSearch, ScrollText, TestTube, ClipboardCheck, UserCircle, Search, Settings as SettingsIcon, Database, Upload, History, ShieldCheck } from 'lucide-react';

export type PageKey =
  | 'coach-dashboard'
  | 'dashboard'
  | 'athletes'
  | 'profile'
  | 'athlete-profile'
  | 'demands'
  | 'capacity'
  | 'training'
  | 'match'
  | 'comparison'
  | 'interventions'
  | 'ai'
  | 'intelligence'
  | 'intervention-eval'
  | 'research'
  | 'decision-log'
  | 'validation-lab'
  | 'scouting'
  | 'data-sources'
  | 'import-data'
  | 'import-history'
  | 'data-quality'
  | 'settings';

interface NavItem {
  key: PageKey;
  label: string;
  icon: React.ReactNode;
}

const navSections: { label: string; items: NavItem[] }[] = [
  {
    label: 'Coaching',
    items: [
      { key: 'coach-dashboard', label: 'Coach Dashboard', icon: <ClipboardCheck size={20} /> },
      { key: 'athletes', label: 'My Athletes', icon: <Users size={20} /> },
      { key: 'profile', label: 'Athlete Workspace', icon: <UserCircle size={20} /> },
    ],
  },
  {
    label: 'Performance',
    items: [
      { key: 'dashboard', label: 'Performance Dashboard', icon: <Activity size={20} /> },
      { key: 'athlete-profile', label: 'Athlete Profile', icon: <UserCircle size={20} /> },
      { key: 'demands', label: 'Performance Demands', icon: <Target size={20} /> },
      { key: 'capacity', label: 'Capacity Testing', icon: <ClipboardList size={20} /> },
      { key: 'training', label: 'Training Load', icon: <Dumbbell size={20} /> },
      { key: 'match', label: 'Match Load', icon: <Trophy size={20} /> },
      { key: 'comparison', label: 'Training vs Match', icon: <BarChart3 size={20} /> },
      { key: 'interventions', label: 'Interventions', icon: <FlaskConical size={20} /> },
      { key: 'ai', label: 'AI Insights', icon: <Sparkles size={20} /> },
    ],
  },
  {
    label: 'Scouting',
    items: [
      { key: 'scouting', label: 'Scouting Workspace', icon: <Search size={20} /> },
    ],
  },
  {
    label: 'Intelligence',
    items: [
      { key: 'intelligence', label: 'Performance Intelligence', icon: <Brain size={20} /> },
      { key: 'intervention-eval', label: 'Intervention Evaluation', icon: <Beaker size={20} /> },
      { key: 'research', label: 'Research Mode', icon: <FileSearch size={20} /> },
      { key: 'decision-log', label: 'Decision Log', icon: <ScrollText size={20} /> },
    ],
  },
  {
    label: 'Data Pipeline',
    items: [
      { key: 'data-sources', label: 'Data Sources', icon: <Database size={20} /> },
      { key: 'import-data', label: 'Import Data', icon: <Upload size={20} /> },
      { key: 'import-history', label: 'Import History', icon: <History size={20} /> },
      { key: 'data-quality', label: 'Data Quality Centre', icon: <ShieldCheck size={20} /> },
    ],
  },
  {
    label: 'Quality Control',
    items: [
      { key: 'validation-lab', label: 'Validation Lab', icon: <TestTube size={20} /> },
    ],
  },
  {
    label: 'System',
    items: [
      { key: 'settings', label: 'Settings', icon: <SettingsIcon size={20} /> },
    ],
  },
];

interface SidebarProps {
  current: PageKey;
  onNavigate: (page: PageKey) => void;
}

export function Sidebar({ current, onNavigate }: SidebarProps) {
  const [dark, setDark] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const root = document.documentElement;
    if (dark) root.classList.add('dark');
    else root.classList.remove('dark');
  }, [dark]);

  const handleNav = (page: PageKey) => {
    onNavigate(page);
    setMobileOpen(false);
  };

  return (
    <>
      {/* Mobile header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 h-14 surface border-b">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[rgb(var(--primary))] flex items-center justify-center">
            <Activity size={18} className="text-white" />
          </div>
          <span className="font-bold text-[rgb(var(--text))]">AthleteIQ</span>
        </div>
        <button onClick={() => setMobileOpen(!mobileOpen)} className="p-2 text-muted">
          {mobileOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-black/30" onClick={() => setMobileOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed lg:sticky top-0 left-0 z-50 lg:z-30
        h-screen w-64 surface border-r
        flex flex-col
        transition-transform duration-300
        ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 h-16 border-b shrink-0 mt-14 lg:mt-0">
          <div className="w-9 h-9 rounded-xl bg-[rgb(var(--primary))] flex items-center justify-center shrink-0">
            <Activity size={20} className="text-white" />
          </div>
          <div>
            <span className="font-bold text-[rgb(var(--text))] text-lg leading-none block">AthleteIQ</span>
            <span className="text-xs text-subtle">Performance Intelligence</span>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto scrollbar-thin px-3 py-4 space-y-1">
          {navSections.map((section) => (
            <div key={section.label} className="mb-4">
              <div className="px-3 py-1.5 text-xs font-semibold text-subtle uppercase tracking-wider">{section.label}</div>
              <div className="space-y-1">
                {section.items.map((item) => {
                  const active = current === item.key;
                  return (
                    <button
                      key={item.key}
                      onClick={() => handleNav(item.key)}
                      className={`
                        w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium
                        transition-all duration-200
                        ${active
                          ? 'bg-[rgb(var(--primary))] text-white shadow-sm'
                          : 'text-muted hover:bg-[rgb(var(--surface-2))] hover:text-[rgb(var(--text))]'
                        }
                      `}
                    >
                      <span className={active ? 'text-white' : ''}>{item.icon}</span>
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Footer */}
        <div className="px-3 py-4 border-t space-y-2 shrink-0">
          <button
            onClick={() => setDark(!dark)}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-muted hover:bg-[rgb(var(--surface-2))] hover:text-[rgb(var(--text))] transition-all"
          >
            {dark ? <Sun size={20} /> : <Moon size={20} />}
            {dark ? 'Light Mode' : 'Dark Mode'}
          </button>
          <div className="px-3 py-2 text-xs text-subtle">
            Strategy first. Technology next.
          </div>
        </div>
      </aside>
    </>
  );
}
