import { useEffect, useRef, useState } from 'react';

interface LineChartProps {
  data: { label: string; value: number }[];
  unit: string;
  color?: string;
  height?: number;
  higherIsBetter?: boolean;
  benchmark?: number;
  baseline?: number;
}

export function LineChart({
  data,
  unit,
  color = 'rgb(var(--chart-1))',
  height = 200,
  higherIsBetter,
  benchmark,
  baseline,
}: LineChartProps) {
  const ref = useRef<SVGSVGElement>(null);
  const [width, setWidth] = useState(600);
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    const observer = new ResizeObserver((entries) => {
      if (entries[0]) setWidth(entries[0].contentRect.width);
    });
    if (ref.current?.parentElement) observer.observe(ref.current.parentElement);
    const t = setTimeout(() => setAnimated(true), 100);
    return () => { observer.disconnect(); clearTimeout(t); };
  }, []);

  const padding = { top: 20, right: 20, bottom: 30, left: 45 };
  const chartW = Math.max(width - padding.left - padding.right, 10);
  const chartH = height - padding.top - padding.bottom;

  const values = data.map((d) => d.value);
  if (benchmark) values.push(benchmark);
  if (baseline) values.push(baseline);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const yMin = min - range * 0.15;
  const yMax = max + range * 0.15;

  const xStep = data.length > 1 ? chartW / (data.length - 1) : 0;
  const yScale = (v: number) => chartH - ((v - yMin) / (yMax - yMin)) * chartH;

  const points = data.map((d, i) => ({
    x: padding.left + i * xStep,
    y: padding.top + yScale(d.value),
    value: d.value,
    label: d.label,
  }));

  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaPath = `${linePath} L ${points[points.length - 1].x} ${padding.top + chartH} L ${points[0].x} ${padding.top + chartH} Z`;

  const yTicks = 4;
  const yTickValues = Array.from({ length: yTicks + 1 }, (_, i) => yMin + (i / yTicks) * (yMax - yMin));

  const progress = animated ? 1 : 0;

  return (
    <svg ref={ref} width="100%" height={height} className="overflow-visible">
      <defs>
        <linearGradient id={`grad-${unit.replace(/\s/g, '')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.18" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
        <clipPath id={`clip-${unit.replace(/\s/g, '')}`}>
          <rect x={padding.left} y={padding.top} width={chartW * progress} height={chartH} />
        </clipPath>
      </defs>

      {/* Y-axis grid */}
      {yTickValues.map((v, i) => (
        <g key={i}>
          <line
            x1={padding.left}
            y1={padding.top + (i / yTicks) * chartH}
            x2={padding.left + chartW}
            y2={padding.top + (i / yTicks) * chartH}
            stroke="rgb(var(--border))"
            strokeWidth="1"
            strokeDasharray="2 4"
            opacity="0.5"
          />
          <text x={padding.left - 8} y={padding.top + (i / yTicks) * chartH + 4} textAnchor="end" fontSize="10" fill="rgb(var(--text-subtle))">
            {v.toFixed(v < 10 ? 1 : 0)}
          </text>
        </g>
      ))}

      {/* Benchmark line */}
      {benchmark && (
        <g>
          <line
            x1={padding.left}
            y1={padding.top + yScale(benchmark)}
            x2={padding.left + chartW}
            y2={padding.top + yScale(benchmark)}
            stroke="rgb(var(--success))"
            strokeWidth="1.5"
            strokeDasharray="6 4"
            opacity={progress}
          />
          <text x={padding.left + chartW - 4} y={padding.top + yScale(benchmark) - 6} textAnchor="end" fontSize="10" fill="rgb(var(--success))" fontWeight="600" opacity={progress}>
            Benchmark {benchmark}{unit}
          </text>
        </g>
      )}

      {/* Baseline line */}
      {baseline && (
        <g>
          <line
            x1={padding.left}
            y1={padding.top + yScale(baseline)}
            x2={padding.left + chartW}
            y2={padding.top + yScale(baseline)}
            stroke="rgb(var(--text-subtle))"
            strokeWidth="1"
            strokeDasharray="4 4"
            opacity={progress * 0.6}
          />
          <text x={padding.left + 4} y={padding.top + yScale(baseline) - 6} textAnchor="start" fontSize="10" fill="rgb(var(--text-subtle))" opacity={progress * 0.8}>
            Baseline {baseline}{unit}
          </text>
        </g>
      )}

      {/* Area + Line */}
      <g clipPath={`url(#clip-${unit.replace(/\s/g, '')})`}>
        <path d={areaPath} fill={`url(#grad-${unit.replace(/\s/g, '')})`} />
        <path d={linePath} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      </g>

      {/* Points */}
      {points.map((p, i) => (
        <g key={i} opacity={progress} style={{ transition: `opacity 0.3s ease ${0.3 + i * 0.08}s` }}>
          <circle cx={p.x} cy={p.y} r="4" fill="rgb(var(--surface))" stroke={color} strokeWidth="2.5" />
          <text x={p.x} y={p.y - 12} textAnchor="middle" fontSize="10" fill="rgb(var(--text))" fontWeight="600">
            {p.value.toFixed(p.value < 10 ? 2 : 1)}
          </text>
        </g>
      ))}

      {/* X-axis labels */}
      {points.map((p, i) => (
        <text key={i} x={p.x} y={height - 8} textAnchor="middle" fontSize="10" fill="rgb(var(--text-subtle))">
          {p.label}
        </text>
      ))}
    </svg>
  );
}

interface BarChartProps {
  data: { label: string; value: number; color?: string }[];
  unit: string;
  height?: number;
  showValues?: boolean;
}

export function BarChart({ data, unit, height = 200, showValues = true }: BarChartProps) {
  const ref = useRef<SVGSVGElement>(null);
  const [width, setWidth] = useState(600);
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    const observer = new ResizeObserver((entries) => {
      if (entries[0]) setWidth(entries[0].contentRect.width);
    });
    if (ref.current?.parentElement) observer.observe(ref.current.parentElement);
    const t = setTimeout(() => setAnimated(true), 100);
    return () => { observer.disconnect(); clearTimeout(t); };
  }, []);

  const padding = { top: 20, right: 20, bottom: 30, left: 45 };
  const chartW = Math.max(width - padding.left - padding.right, 10);
  const chartH = height - padding.top - padding.bottom;

  const max = Math.max(...data.map((d) => d.value)) * 1.15 || 1;
  const barWidth = chartW / data.length;
  const gap = barWidth * 0.2;
  const actualBarW = barWidth - gap;

  const yTicks = 4;
  const yTickValues = Array.from({ length: yTicks + 1 }, (_, i) => (i / yTicks) * max);

  return (
    <svg ref={ref} width="100%" height={height} className="overflow-visible">
      {yTickValues.map((v, i) => (
        <g key={i}>
          <line
            x1={padding.left}
            y1={padding.top + (i / yTicks) * chartH}
            x2={padding.left + chartW}
            y2={padding.top + (i / yTicks) * chartH}
            stroke="rgb(var(--border))"
            strokeWidth="1"
            strokeDasharray="2 4"
            opacity="0.5"
          />
          <text x={padding.left - 8} y={padding.top + (i / yTicks) * chartH + 4} textAnchor="end" fontSize="10" fill="rgb(var(--text-subtle))">
            {v.toFixed(v < 10 ? 1 : 0)}
          </text>
        </g>
      ))}

      {data.map((d, i) => {
        const barH = (d.value / max) * chartH * (animated ? 1 : 0);
        const x = padding.left + i * barWidth + gap / 2;
        const y = padding.top + chartH - barH;
        const color = d.color || 'rgb(var(--chart-1))';
        return (
          <g key={i} style={{ transition: `all 0.5s ease ${i * 0.05}s` }}>
            <rect x={x} y={y} width={actualBarW} height={barH} fill={color} rx="4" opacity="0.9" />
            {showValues && (
              <text x={x + actualBarW / 2} y={y - 6} textAnchor="middle" fontSize="10" fill="rgb(var(--text))" fontWeight="600">
                {d.value.toFixed(d.value < 10 ? 1 : 0)}
              </text>
            )}
            <text x={x + actualBarW / 2} y={height - 8} textAnchor="middle" fontSize="10" fill="rgb(var(--text-subtle))">
              {d.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

interface ComparisonBarProps {
  label: string;
  trainingValue: number;
  matchValue: number;
  unit: string;
  gapPercent: number;
  status: 'UNDEREXPOSURE' | 'APPROPRIATE' | 'EXCESSIVE';
}

export function ComparisonBar({ label, trainingValue, matchValue, unit, gapPercent, status }: ComparisonBarProps) {
  const [animated, setAnimated] = useState(false);
  useEffect(() => { const t = setTimeout(() => setAnimated(true), 100); return () => clearTimeout(t); }, []);

  const max = Math.max(trainingValue, matchValue) * 1.15 || 1;
  const trainPct = (trainingValue / max) * 100 * (animated ? 1 : 0);
  const matchPct = (matchValue / max) * 100 * (animated ? 1 : 0);

  const statusColor = status === 'UNDEREXPOSURE' ? 'rgb(var(--warning))' : status === 'EXCESSIVE' ? 'rgb(var(--error))' : 'rgb(var(--success))';
  const gapColor = gapPercent < -15 ? 'text-amber-500' : gapPercent > 25 ? 'text-red-500' : 'text-emerald-500';

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-[rgb(var(--text))]">{label}</span>
        <span className={`text-sm font-bold ${gapColor}`}>{gapPercent > 0 ? '+' : ''}{gapPercent.toFixed(0)}%</span>
      </div>
      <div className="space-y-1.5">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted w-16">Training</span>
          <div className="flex-1 h-6 bg-[rgb(var(--surface-2))] rounded-md overflow-hidden">
            <div
              className="h-full rounded-md transition-all duration-700 ease-out"
              style={{ width: `${trainPct}%`, backgroundColor: 'rgb(var(--chart-1))' }}
            />
          </div>
          <span className="text-xs font-semibold text-[rgb(var(--text))] w-20 text-right">{trainingValue.toFixed(trainingValue < 10 ? 1 : 0)} {unit}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted w-16">Match</span>
          <div className="flex-1 h-6 bg-[rgb(var(--surface-2))] rounded-md overflow-hidden">
            <div
              className="h-full rounded-md transition-all duration-700 ease-out"
              style={{ width: `${matchPct}%`, backgroundColor: statusColor }}
            />
          </div>
          <span className="text-xs font-semibold text-[rgb(var(--text))] w-20 text-right">{matchValue.toFixed(matchValue < 10 ? 1 : 0)} {unit}</span>
        </div>
      </div>
    </div>
  );
}

interface RadarChartProps {
  data: { label: string; value: number; max: number }[];
  size?: number;
}

export function RadarChart({ data, size = 260 }: RadarChartProps) {
  const [animated, setAnimated] = useState(false);
  useEffect(() => { const t = setTimeout(() => setAnimated(true), 100); return () => clearTimeout(t); }, []);

  const center = size / 2;
  const radius = size / 2 - 40;
  const angleStep = (Math.PI * 2) / data.length;

  const getPoint = (i: number, ratio: number) => ({
    x: center + Math.cos(i * angleStep - Math.PI / 2) * radius * ratio,
    y: center + Math.sin(i * angleStep - Math.PI / 2) * radius * ratio,
  });

  const rings = [0.25, 0.5, 0.75, 1];

  const dataPoints = data.map((d, i) => {
    const ratio = Math.min(d.value / d.max, 1) * (animated ? 1 : 0);
    return getPoint(i, ratio);
  });

  const polygonPath = dataPoints.map((p) => `${p.x},${p.y}`).join(' ');

  return (
    <svg width={size} height={size} className="mx-auto">
      {/* Rings */}
      {rings.map((r, ri) => (
        <polygon
          key={ri}
          points={data.map((_, i) => {
            const p = getPoint(i, r);
            return `${p.x},${p.y}`;
          }).join(' ')}
          fill="none"
          stroke="rgb(var(--border))"
          strokeWidth="1"
          opacity="0.5"
        />
      ))}

      {/* Axes */}
      {data.map((_, i) => {
        const p = getPoint(i, 1);
        return <line key={i} x1={center} y1={center} x2={p.x} y2={p.y} stroke="rgb(var(--border))" strokeWidth="1" opacity="0.5" />;
      })}

      {/* Data polygon */}
      <polygon
        points={polygonPath}
        fill="rgb(var(--chart-1))"
        fillOpacity="0.15"
        stroke="rgb(var(--chart-1))"
        strokeWidth="2"
        style={{ transition: 'all 0.6s ease' }}
      />

      {/* Data points */}
      {dataPoints.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r="3" fill="rgb(var(--chart-1))" strokeWidth="2" stroke="rgb(var(--surface))" style={{ transition: 'all 0.6s ease' }} />
      ))}

      {/* Labels */}
      {data.map((d, i) => {
        const p = getPoint(i, 1.25);
        return (
          <text key={i} x={p.x} y={p.y} textAnchor="middle" dominantBaseline="middle" fontSize="9" fill="rgb(var(--text-muted))" fontWeight="500">
            {d.label}
          </text>
        );
      })}
    </svg>
  );
}

interface DonutGaugeProps {
  value: number;
  max: number;
  label: string;
  unit: string;
  color?: string;
  size?: number;
}

export function DonutGauge({ value, max, label, unit, color = 'rgb(var(--chart-1))', size = 140 }: DonutGaugeProps) {
  const [animated, setAnimated] = useState(false);
  useEffect(() => { const t = setTimeout(() => setAnimated(true), 100); return () => clearTimeout(t); }, []);

  const center = size / 2;
  const radius = size / 2 - 12;
  const circumference = 2 * Math.PI * radius;
  const ratio = Math.min(value / max, 1);
  const offset = circumference * (1 - ratio * (animated ? 1 : 0));

  return (
    <div className="flex flex-col items-center">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={center} cy={center} r={radius} fill="none" stroke="rgb(var(--surface-2))" strokeWidth="10" />
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="none"
            stroke={color}
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 0.8s ease' }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <span className="text-2xl font-bold text-[rgb(var(--text))]">{value.toFixed(value < 10 ? 1 : 0)}</span>
          {unit && <span className="text-xs text-muted">{unit}</span>}
        </div>
      </div>
      <span className="text-xs text-muted font-medium mt-1">{label}</span>
    </div>
  );
}

interface StackedBarProps {
  data: { label: string; values: { label: string; value: number; color: string }[] }[];
  height?: number;
}

export function StackedBarChart({ data, height = 200 }: StackedBarProps) {
  const ref = useRef<SVGSVGElement>(null);
  const [width, setWidth] = useState(600);
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    const observer = new ResizeObserver((entries) => {
      if (entries[0]) setWidth(entries[0].contentRect.width);
    });
    if (ref.current?.parentElement) observer.observe(ref.current.parentElement);
    const t = setTimeout(() => setAnimated(true), 100);
    return () => { observer.disconnect(); clearTimeout(t); };
  }, []);

  const padding = { top: 20, right: 20, bottom: 30, left: 45 };
  const chartW = Math.max(width - padding.left - padding.right, 10);
  const chartH = height - padding.top - padding.bottom;

  const totals = data.map((d) => d.values.reduce((s, v) => s + v.value, 0));
  const max = Math.max(...totals) * 1.15 || 1;
  const barWidth = chartW / data.length;
  const gap = barWidth * 0.25;
  const actualBarW = barWidth - gap;

  const yTicks = 4;
  const yTickValues = Array.from({ length: yTicks + 1 }, (_, i) => (i / yTicks) * max);

  return (
    <svg ref={ref} width="100%" height={height} className="overflow-visible">
      {yTickValues.map((v, i) => (
        <g key={i}>
          <line
            x1={padding.left}
            y1={padding.top + (i / yTicks) * chartH}
            x2={padding.left + chartW}
            y2={padding.top + (i / yTicks) * chartH}
            stroke="rgb(var(--border))"
            strokeWidth="1"
            strokeDasharray="2 4"
            opacity="0.5"
          />
          <text x={padding.left - 8} y={padding.top + (i / yTicks) * chartH + 4} textAnchor="end" fontSize="10" fill="rgb(var(--text-subtle))">
            {v.toFixed(0)}
          </text>
        </g>
      ))}

      {data.map((d, i) => {
        const x = padding.left + i * barWidth + gap / 2;
        let cumY = padding.top + chartH;
        return (
          <g key={i}>
            {d.values.map((v, vi) => {
              const barH = (v.value / max) * chartH * (animated ? 1 : 0);
              cumY -= barH;
              return (
                <rect
                  key={vi}
                  x={x}
                  y={cumY}
                  width={actualBarW}
                  height={barH}
                  fill={v.color}
                  rx={vi === d.values.length - 1 ? 4 : 0}
                  style={{ transition: `all 0.5s ease ${i * 0.05}s` }}
                />
              );
            })}
            <text x={x + actualBarW / 2} y={height - 8} textAnchor="middle" fontSize="10" fill="rgb(var(--text-subtle))">
              {d.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

interface HBarChartProps {
  data: { label: string; value: number; color?: string; unit?: string }[];
  height?: number;
}

export function HBarChart({ data, height = 200 }: HBarChartProps) {
  const [animated, setAnimated] = useState(false);
  useEffect(() => { const t = setTimeout(() => setAnimated(true), 100); return () => clearTimeout(t); }, []);

  const max = Math.max(...data.map((d) => d.value)) * 1.1 || 1;
  const rowH = Math.max(height / data.length, 30);
  const barH = 20;

  return (
    <div className="space-y-1" style={{ minHeight: height }}>
      {data.map((d, i) => (
        <div key={i} className="flex items-center gap-3" style={{ height: rowH }}>
          <span className="text-xs text-muted w-28 text-right truncate">{d.label}</span>
          <div className="flex-1 h-5 bg-[rgb(var(--surface-2))] rounded-md overflow-hidden">
            <div
              className="h-full rounded-md transition-all duration-700 ease-out flex items-center justify-end pr-2"
              style={{
                width: `${(d.value / max) * 100 * (animated ? 1 : 0)}%`,
                backgroundColor: d.color || 'rgb(var(--chart-1))',
                transitionDelay: `${i * 0.05}s`,
              }}
            >
              <span className="text-xs font-semibold text-white whitespace-nowrap">
                {d.value.toFixed(d.value < 10 ? 1 : 0)}{d.unit || ''}
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
