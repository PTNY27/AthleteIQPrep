/*
# AthleteIQ Stage 7 — Coach-Centred Athlete Development Tables

Creates the database backend for Stage 7 coaching workflows: Individual Development Plans,
development objectives, goals, coaching sessions, coach notes, coach decisions, athlete
feedback, development reviews, and audit trail.

This is a single-tenant application (no sign-in screen), so all tables use
`TO anon, authenticated` policies allowing the anon-key frontend to read and write.

## New Tables

1. **development_plans** — Coach-controlled IDP per athlete (name, period, status, objectives)
2. **development_objectives** — Individual objectives within a plan (priority, baseline, target, review date)
3. **goals** — Measurable goals linked to objectives (metric, baseline, target, target date, status)
4. **coaching_sessions** — Coach-created training/development sessions (structure, activities, status)
5. **coach_notes** — Timestamped coach observations (private/shared, category, content)
6. **coach_decisions** — Decision gate records (accept/edit/reject/defer with rationale)
7. **athlete_feedback** — Athlete-reported subjective feedback (session difficulty, perceived effort, comments)
8. **development_reviews** — Formal coach review records (baseline, progress, new assessment, decision)
9. **audit_trail** — Audit trail for significant coaching decisions (user, action, original, new, rationale)

## Security

- RLS enabled on every table.
- All policies use `TO anon, authenticated` with `USING (true)` / `WITH CHECK (true)`
  because this is a single-tenant app with no sign-in — data is intentionally shared.
- No user_id columns or auth.uid() references.

## Notes

1. All tables have created_at and updated_at timestamps for audit purposes.
2. JSONB columns store flexible structures (session activities, review data, etc.).
3. Foreign keys cascade on athlete deletion to maintain referential integrity.
4. Coaching sessions support both individual (athlete_id) and group (group_id) sessions.
*/

-- ===== DEVELOPMENT PLANS =====
CREATE TABLE IF NOT EXISTS development_plans (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  coach_id text NOT NULL DEFAULT 'coach-1',
  name text NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  status text NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'ACTIVE', 'PAUSED', 'COMPLETED', 'ARCHIVED')),
  objectives jsonb NOT NULL DEFAULT '[]',
  review_date date,
  reassessment_date date,
  coach_notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_dev_plans_athlete_id ON development_plans(athlete_id);
CREATE INDEX IF NOT EXISTS idx_dev_plans_status ON development_plans(status);

ALTER TABLE development_plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_dev_plans" ON development_plans;
CREATE POLICY "anon_select_dev_plans" ON development_plans FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_dev_plans" ON development_plans;
CREATE POLICY "anon_insert_dev_plans" ON development_plans FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_dev_plans" ON development_plans;
CREATE POLICY "anon_update_dev_plans" ON development_plans FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_dev_plans" ON development_plans;
CREATE POLICY "anon_delete_dev_plans" ON development_plans FOR DELETE
  TO anon, authenticated USING (true);

-- ===== DEVELOPMENT OBJECTIVES =====
CREATE TABLE IF NOT EXISTS development_objectives (
  id text PRIMARY KEY,
  plan_id text NOT NULL REFERENCES development_plans(id) ON DELETE CASCADE,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  priority text NOT NULL DEFAULT 'MEDIUM' CHECK (priority IN ('HIGH', 'MEDIUM', 'LOW')),
  baseline double precision,
  target double precision,
  unit text,
  target_date date,
  status text NOT NULL DEFAULT 'NOT_STARTED' CHECK (status IN ('NOT_STARTED', 'IN_PROGRESS', 'ON_TRACK', 'AT_RISK', 'ACHIEVED', 'CLOSED')),
  evidence text,
  coach_notes text,
  review_date date,
  ai_generated boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_dev_objectives_plan_id ON development_objectives(plan_id);
CREATE INDEX IF NOT EXISTS idx_dev_objectives_athlete_id ON development_objectives(athlete_id);

ALTER TABLE development_objectives ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_dev_objectives" ON development_objectives;
CREATE POLICY "anon_select_dev_objectives" ON development_objectives FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_dev_objectives" ON development_objectives;
CREATE POLICY "anon_insert_dev_objectives" ON development_objectives FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_dev_objectives" ON development_objectives;
CREATE POLICY "anon_update_dev_objectives" ON development_objectives FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_dev_objectives" ON development_objectives;
CREATE POLICY "anon_delete_dev_objectives" ON development_objectives FOR DELETE
  TO anon, authenticated USING (true);

-- ===== GOALS =====
CREATE TABLE IF NOT EXISTS goals (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  objective_id text REFERENCES development_objectives(id) ON DELETE SET NULL,
  metric text NOT NULL,
  baseline double precision,
  target double precision,
  unit text,
  target_date date NOT NULL,
  priority text NOT NULL DEFAULT 'MEDIUM' CHECK (priority IN ('HIGH', 'MEDIUM', 'LOW')),
  status text NOT NULL DEFAULT 'NOT_STARTED' CHECK (status IN ('NOT_STARTED', 'IN_PROGRESS', 'ON_TRACK', 'AT_RISK', 'ACHIEVED', 'CLOSED')),
  coach_notes text,
  ai_generated boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_goals_athlete_id ON goals(athlete_id);
CREATE INDEX IF NOT EXISTS idx_goals_objective_id ON goals(objective_id);
CREATE INDEX IF NOT EXISTS idx_goals_status ON goals(status);

ALTER TABLE goals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_goals" ON goals;
CREATE POLICY "anon_select_goals" ON goals FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_goals" ON goals;
CREATE POLICY "anon_insert_goals" ON goals FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_goals" ON goals;
CREATE POLICY "anon_update_goals" ON goals FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_goals" ON goals;
CREATE POLICY "anon_delete_goals" ON goals FOR DELETE
  TO anon, authenticated USING (true);

-- ===== COACHING SESSIONS =====
CREATE TABLE IF NOT EXISTS coaching_sessions (
  id text PRIMARY KEY,
  coach_id text NOT NULL DEFAULT 'coach-1',
  athlete_id text REFERENCES athletes(id) ON DELETE CASCADE,
  group_id text,
  date date NOT NULL,
  duration integer NOT NULL,
  name text NOT NULL,
  objective text,
  priority text NOT NULL DEFAULT 'MEDIUM' CHECK (priority IN ('HIGH', 'MEDIUM', 'LOW')),
  location text,
  equipment text,
  structure jsonb NOT NULL DEFAULT '[]',
  status text NOT NULL DEFAULT 'PLANNED' CHECK (status IN ('PLANNED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED', 'MISSED')),
  coach_notes text,
  ai_generated boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_coaching_sessions_athlete_id ON coaching_sessions(athlete_id);
CREATE INDEX IF NOT EXISTS idx_coaching_sessions_date ON coaching_sessions(date);
CREATE INDEX IF NOT EXISTS idx_coaching_sessions_status ON coaching_sessions(status);

ALTER TABLE coaching_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_coaching_sessions" ON coaching_sessions;
CREATE POLICY "anon_select_coaching_sessions" ON coaching_sessions FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_coaching_sessions" ON coaching_sessions;
CREATE POLICY "anon_insert_coaching_sessions" ON coaching_sessions FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_coaching_sessions" ON coaching_sessions;
CREATE POLICY "anon_update_coaching_sessions" ON coaching_sessions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_coaching_sessions" ON coaching_sessions;
CREATE POLICY "anon_delete_coaching_sessions" ON coaching_sessions FOR DELETE
  TO anon, authenticated USING (true);

-- ===== COACH NOTES =====
CREATE TABLE IF NOT EXISTS coach_notes (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  coach_id text NOT NULL DEFAULT 'coach-1',
  category text NOT NULL CHECK (category IN ('observation', 'session', 'behaviour', 'tactical', 'technical', 'training_response', 'development', 'review')),
  visibility text NOT NULL DEFAULT 'private' CHECK (visibility IN ('private', 'shared', 'staff')),
  content text NOT NULL,
  session_id text REFERENCES coaching_sessions(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_coach_notes_athlete_id ON coach_notes(athlete_id);
CREATE INDEX IF NOT EXISTS idx_coach_notes_created_at ON coach_notes(created_at);

ALTER TABLE coach_notes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_coach_notes" ON coach_notes;
CREATE POLICY "anon_select_coach_notes" ON coach_notes FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_coach_notes" ON coach_notes;
CREATE POLICY "anon_insert_coach_notes" ON coach_notes FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_coach_notes" ON coach_notes;
CREATE POLICY "anon_update_coach_notes" ON coach_notes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_coach_notes" ON coach_notes;
CREATE POLICY "anon_delete_coach_notes" ON coach_notes FOR DELETE
  TO anon, authenticated USING (true);

-- ===== COACH DECISIONS =====
CREATE TABLE IF NOT EXISTS coach_decisions (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  recommendation_id text,
  recommendation_type text NOT NULL CHECK (recommendation_type IN ('priority', 'goal', 'session', 'objective', 'plan', 'report')),
  decision text NOT NULL CHECK (decision IN ('accepted', 'edited', 'rejected', 'deferred')),
  original_suggestion text NOT NULL,
  final_decision text,
  rationale text,
  coach_id text NOT NULL DEFAULT 'coach-1',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_coach_decisions_athlete_id ON coach_decisions(athlete_id);
CREATE INDEX IF NOT EXISTS idx_coach_decisions_created_at ON coach_decisions(created_at);

ALTER TABLE coach_decisions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_coach_decisions" ON coach_decisions;
CREATE POLICY "anon_select_coach_decisions" ON coach_decisions FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_coach_decisions" ON coach_decisions;
CREATE POLICY "anon_insert_coach_decisions" ON coach_decisions FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_coach_decisions" ON coach_decisions;
CREATE POLICY "anon_update_coach_decisions" ON coach_decisions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_coach_decisions" ON coach_decisions;
CREATE POLICY "anon_delete_coach_decisions" ON coach_decisions FOR DELETE
  TO anon, authenticated USING (true);

-- ===== ATHLETE FEEDBACK =====
CREATE TABLE IF NOT EXISTS athlete_feedback (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  session_id text REFERENCES coaching_sessions(id) ON DELETE CASCADE,
  session_difficulty integer CHECK (session_difficulty >= 1 AND session_difficulty <= 10),
  perceived_effort integer CHECK (perceived_effort >= 1 AND perceived_effort <= 10),
  confidence integer CHECK (confidence >= 1 AND confidence <= 10),
  completion boolean,
  comments text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_athlete_feedback_athlete_id ON athlete_feedback(athlete_id);
CREATE INDEX IF NOT EXISTS idx_athlete_feedback_session_id ON athlete_feedback(session_id);

ALTER TABLE athlete_feedback ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_athlete_feedback" ON athlete_feedback;
CREATE POLICY "anon_select_athlete_feedback" ON athlete_feedback FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_athlete_feedback" ON athlete_feedback;
CREATE POLICY "anon_insert_athlete_feedback" ON athlete_feedback FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_athlete_feedback" ON athlete_feedback;
CREATE POLICY "anon_update_athlete_feedback" ON athlete_feedback FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_athlete_feedback" ON athlete_feedback;
CREATE POLICY "anon_delete_athlete_feedback" ON athlete_feedback FOR DELETE
  TO anon, authenticated USING (true);

-- ===== DEVELOPMENT REVIEWS =====
CREATE TABLE IF NOT EXISTS development_reviews (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  plan_id text REFERENCES development_plans(id) ON DELETE SET NULL,
  review_date date NOT NULL,
  baseline_summary text,
  progress_summary text,
  completed_work text,
  coach_observations text,
  athlete_feedback_summary text,
  new_assessment_summary text,
  updated_insight_summary text,
  coach_decision text NOT NULL CHECK (coach_decision IN ('continue', 'modify', 'increase_difficulty', 'reduce_difficulty', 'change_priority', 'close_objective', 'create_new_objective', 'reassess_later')),
  ai_generated_summary text,
  ai_generated boolean NOT NULL DEFAULT false,
  coach_id text NOT NULL DEFAULT 'coach-1',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_dev_reviews_athlete_id ON development_reviews(athlete_id);
CREATE INDEX IF NOT EXISTS idx_dev_reviews_plan_id ON development_reviews(plan_id);

ALTER TABLE development_reviews ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_dev_reviews" ON development_reviews;
CREATE POLICY "anon_select_dev_reviews" ON development_reviews FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_dev_reviews" ON development_reviews;
CREATE POLICY "anon_insert_dev_reviews" ON development_reviews FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_dev_reviews" ON development_reviews;
CREATE POLICY "anon_update_dev_reviews" ON development_reviews FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_dev_reviews" ON development_reviews;
CREATE POLICY "anon_delete_dev_reviews" ON development_reviews FOR DELETE
  TO anon, authenticated USING (true);

-- ===== AUDIT TRAIL =====
CREATE TABLE IF NOT EXISTS audit_trail (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  athlete_id text REFERENCES athletes(id) ON DELETE SET NULL,
  user_id text NOT NULL DEFAULT 'coach-1',
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id text,
  original_value text,
  new_value text,
  ai_involved boolean NOT NULL DEFAULT false,
  rationale text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_trail_athlete_id ON audit_trail(athlete_id);
CREATE INDEX IF NOT EXISTS idx_audit_trail_created_at ON audit_trail(created_at);

ALTER TABLE audit_trail ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_audit_trail" ON audit_trail;
CREATE POLICY "anon_select_audit_trail" ON audit_trail FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_audit_trail" ON audit_trail;
CREATE POLICY "anon_insert_audit_trail" ON audit_trail FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_audit_trail" ON audit_trail;
CREATE POLICY "anon_update_audit_trail" ON audit_trail FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_audit_trail" ON audit_trail;
CREATE POLICY "anon_delete_audit_trail" ON audit_trail FOR DELETE
  TO anon, authenticated USING (true);