/*
# Stage 9 — Multi-Sport Organisational Intelligence Tables

## Overview
Creates the database layer for Stage 9: team, programme, and organisation-level
intelligence, benchmark versioning, KPI snapshots, action tracking, alerts,
saved views, report versioning, intelligence insights, anomaly flags, and
pattern detection. All tables follow the existing single-tenant, no-auth
pattern (TO anon, authenticated, USING (true)) used by Stages 5–8.

## New Tables (12)

1. **intelligence_insights** — AI/system-generated insights at athlete, team,
   programme, or organisation scope. Status workflow: draft → review_required →
   reviewed → actioned → archived. AI-generated insights start as review_required.
2. **action_tasks** — Convert recommendations into trackable tasks with owner,
   priority, due date, linked scope, status, and outcome.
3. **alert_configs** — Configurable alert rules (overdue assessment, unusual
   performance change, declining trend, etc.) with priority and threshold.
4. **saved_views** — Saved analytical filter views scoped to athlete/team/
   programme/organisation.
5. **report_versions** — Versioned reports with author, data period, benchmark
   version, KPI version, included evidence, and modifications. Historical
   reports remain reproducible.
6. **benchmark_versions** — Versioned benchmarks with sport, metric, population,
   sample size, source, methodology, effective date, owner, and status
   (active/superseded). Historical assessments preserve the benchmark version
   used at the time.
7. **kpi_snapshots** — Point-in-time KPI recordings with version, scope, target,
   current value, measurement period, and status.
8. **anomaly_flags** — Detected anomalies (sudden change, impossible measurement,
   unusual workload, duplicate, contradictory, data entry error). An anomaly is
   a review flag, not a diagnosis.
9. **pattern_flags** — Detected patterns (repeated decline/improvement, recurring
   gaps, role strengths, team-wide or programme-wide changes) with sample size
   and confidence.
10. **org_data_quality** — Organisation-wide data quality scores broken down by
    completeness, recency, consistency, validity, context availability, and
    issue counts.
11. **attention_items** — Prioritised items requiring professional attention
    (data issues, overdue assessments, performance changes, disagreements,
    incomplete development, pending review).
12. **ai_org_audit_log** — Audit trail for AI organisational assistant queries
    and responses, including the query, response summary, and whether the
    response was reviewed.

## Security
- RLS enabled on every table.
- All policies use TO anon, authenticated with USING (true) / WITH CHECK (true)
  — consistent with the existing single-tenant, no-auth architecture.
- 4 policies per table (SELECT, INSERT, UPDATE, DELETE).

## Notes
1. No user_id columns — this is a single-tenant app with no auth.
2. Indexes on scope_type/scope_id, status, and created_at for query performance.
3. All tables use gen_random_uuid() for primary keys.
4. Timestamps default to now().
*/

-- 1. Intelligence Insights
CREATE TABLE IF NOT EXISTS intelligence_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope_type text NOT NULL CHECK (scope_type IN ('athlete', 'team', 'programme', 'organisation')),
  scope_id text NOT NULL,
  scope_name text NOT NULL,
  title text NOT NULL,
  summary text NOT NULL,
  evidence jsonb NOT NULL DEFAULT '[]',
  context text,
  data_quality text,
  confidence text NOT NULL CHECK (confidence IN ('high', 'moderate', 'low', 'insufficient')),
  limitations text,
  interpretation text,
  recommended_action text NOT NULL CHECK (recommended_action IN ('review_recommended', 'further_assessment', 'data_collection', 'development_review', 'performance_review', 'scouting_review')),
  created_by text NOT NULL,
  created_at timestamptz DEFAULT now(),
  status text NOT NULL DEFAULT 'review_required' CHECK (status IN ('draft', 'review_required', 'reviewed', 'actioned', 'archived')),
  ai_generated boolean NOT NULL DEFAULT false,
  reviewed_by text,
  reviewed_at timestamptz
);
ALTER TABLE intelligence_insights ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_intelligence_insights" ON intelligence_insights;
CREATE POLICY "anon_select_intelligence_insights" ON intelligence_insights FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_intelligence_insights" ON intelligence_insights;
CREATE POLICY "anon_insert_intelligence_insights" ON intelligence_insights FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_intelligence_insights" ON intelligence_insights;
CREATE POLICY "anon_update_intelligence_insights" ON intelligence_insights FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_intelligence_insights" ON intelligence_insights;
CREATE POLICY "anon_delete_intelligence_insights" ON intelligence_insights FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_insights_scope ON intelligence_insights (scope_type, scope_id);
CREATE INDEX IF NOT EXISTS idx_insights_status ON intelligence_insights (status);

-- 2. Action Tasks
CREATE TABLE IF NOT EXISTS action_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recommendation text NOT NULL,
  owner text NOT NULL,
  priority text NOT NULL CHECK (priority IN ('high', 'medium', 'low')),
  due_date date,
  linked_scope text NOT NULL CHECK (linked_scope IN ('athlete', 'team', 'programme', 'organisation')),
  linked_scope_id text NOT NULL,
  linked_scope_name text NOT NULL,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'assigned', 'in_progress', 'completed', 'deferred', 'cancelled')),
  completion_date date,
  outcome text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE action_tasks ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_action_tasks" ON action_tasks;
CREATE POLICY "anon_select_action_tasks" ON action_tasks FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_action_tasks" ON action_tasks;
CREATE POLICY "anon_insert_action_tasks" ON action_tasks FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_action_tasks" ON action_tasks;
CREATE POLICY "anon_update_action_tasks" ON action_tasks FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_action_tasks" ON action_tasks;
CREATE POLICY "anon_delete_action_tasks" ON action_tasks FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_action_tasks_status ON action_tasks (status);
CREATE INDEX IF NOT EXISTS idx_action_tasks_scope ON action_tasks (linked_scope, linked_scope_id);

-- 3. Alert Configs
CREATE TABLE IF NOT EXISTS alert_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  label text NOT NULL,
  priority text NOT NULL CHECK (priority IN ('informational', 'low', 'moderate', 'high', 'critical')),
  enabled boolean NOT NULL DEFAULT true,
  threshold numeric,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE alert_configs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_alert_configs" ON alert_configs;
CREATE POLICY "anon_select_alert_configs" ON alert_configs FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_alert_configs" ON alert_configs;
CREATE POLICY "anon_insert_alert_configs" ON alert_configs FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_alert_configs" ON alert_configs;
CREATE POLICY "anon_update_alert_configs" ON alert_configs FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_alert_configs" ON alert_configs;
CREATE POLICY "anon_delete_alert_configs" ON alert_configs FOR DELETE TO anon, authenticated USING (true);

-- 4. Saved Views
CREATE TABLE IF NOT EXISTS saved_views (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  scope text NOT NULL CHECK (scope IN ('athlete', 'team', 'programme', 'organisation')),
  filters jsonb NOT NULL DEFAULT '{}',
  created_by text NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE saved_views ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_saved_views" ON saved_views;
CREATE POLICY "anon_select_saved_views" ON saved_views FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_saved_views" ON saved_views;
CREATE POLICY "anon_insert_saved_views" ON saved_views FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_saved_views" ON saved_views;
CREATE POLICY "anon_update_saved_views" ON saved_views FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_saved_views" ON saved_views;
CREATE POLICY "anon_delete_saved_views" ON saved_views FOR DELETE TO anon, authenticated USING (true);

-- 5. Report Versions
CREATE TABLE IF NOT EXISTS report_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_type text NOT NULL CHECK (report_type IN ('athlete', 'team', 'programme', 'organisation')),
  scope_id text NOT NULL,
  scope_name text NOT NULL,
  author text NOT NULL,
  date date NOT NULL,
  data_period text NOT NULL,
  benchmark_version text NOT NULL,
  kpi_version text,
  report_version text NOT NULL,
  included_evidence jsonb NOT NULL DEFAULT '[]',
  modifications text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE report_versions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_report_versions" ON report_versions;
CREATE POLICY "anon_select_report_versions" ON report_versions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_report_versions" ON report_versions;
CREATE POLICY "anon_insert_report_versions" ON report_versions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_report_versions" ON report_versions;
CREATE POLICY "anon_update_report_versions" ON report_versions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_report_versions" ON report_versions;
CREATE POLICY "anon_delete_report_versions" ON report_versions FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_report_versions_scope ON report_versions (report_type, scope_id);

-- 6. Benchmark Versions
CREATE TABLE IF NOT EXISTS benchmark_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  benchmark_id text NOT NULL,
  benchmark_name text NOT NULL,
  version text NOT NULL,
  sport text NOT NULL,
  metric text NOT NULL,
  population text NOT NULL,
  sample_size integer NOT NULL DEFAULT 0,
  source text NOT NULL,
  methodology text NOT NULL,
  effective_date date NOT NULL,
  owner text NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'superseded')),
  created_at timestamptz DEFAULT now()
);
ALTER TABLE benchmark_versions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_benchmark_versions" ON benchmark_versions;
CREATE POLICY "anon_select_benchmark_versions" ON benchmark_versions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_benchmark_versions" ON benchmark_versions;
CREATE POLICY "anon_insert_benchmark_versions" ON benchmark_versions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_benchmark_versions" ON benchmark_versions;
CREATE POLICY "anon_update_benchmark_versions" ON benchmark_versions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_benchmark_versions" ON benchmark_versions;
CREATE POLICY "anon_delete_benchmark_versions" ON benchmark_versions FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_benchmark_versions_sport ON benchmark_versions (sport);
CREATE INDEX IF NOT EXISTS idx_benchmark_versions_status ON benchmark_versions (status);

-- 7. KPI Snapshots
CREATE TABLE IF NOT EXISTS kpi_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kpi_id text NOT NULL,
  kpi_name text NOT NULL,
  version text NOT NULL,
  scope text NOT NULL CHECK (scope IN ('athlete', 'team', 'programme', 'organisation')),
  scope_id text NOT NULL,
  target text NOT NULL,
  current_value text NOT NULL,
  measurement_period text NOT NULL,
  status text NOT NULL CHECK (status IN ('on_track', 'at_risk', 'off_track', 'insufficient_data')),
  recorded_at timestamptz DEFAULT now()
);
ALTER TABLE kpi_snapshots ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_kpi_snapshots" ON kpi_snapshots;
CREATE POLICY "anon_select_kpi_snapshots" ON kpi_snapshots FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_kpi_snapshots" ON kpi_snapshots;
CREATE POLICY "anon_insert_kpi_snapshots" ON kpi_snapshots FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_kpi_snapshots" ON kpi_snapshots;
CREATE POLICY "anon_update_kpi_snapshots" ON kpi_snapshots FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_kpi_snapshots" ON kpi_snapshots;
CREATE POLICY "anon_delete_kpi_snapshots" ON kpi_snapshots FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_kpi_snapshots_scope ON kpi_snapshots (scope, scope_id);

-- 8. Anomaly Flags
CREATE TABLE IF NOT EXISTS anomaly_flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  athlete_id text NOT NULL,
  type text NOT NULL CHECK (type IN ('sudden_change', 'impossible_measurement', 'unusual_workload', 'duplicate', 'unexpected_result', 'contradictory', 'data_entry_error')),
  description text NOT NULL,
  metric text NOT NULL,
  severity text NOT NULL CHECK (severity IN ('info', 'warning', 'critical')),
  detected_at timestamptz DEFAULT now(),
  status text NOT NULL DEFAULT 'unresolved' CHECK (status IN ('unresolved', 'reviewing', 'resolved'))
);
ALTER TABLE anomaly_flags ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_anomaly_flags" ON anomaly_flags;
CREATE POLICY "anon_select_anomaly_flags" ON anomaly_flags FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_anomaly_flags" ON anomaly_flags;
CREATE POLICY "anon_insert_anomaly_flags" ON anomaly_flags FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_anomaly_flags" ON anomaly_flags;
CREATE POLICY "anon_update_anomaly_flags" ON anomaly_flags FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_anomaly_flags" ON anomaly_flags;
CREATE POLICY "anon_delete_anomaly_flags" ON anomaly_flags FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_anomaly_athlete ON anomaly_flags (athlete_id);
CREATE INDEX IF NOT EXISTS idx_anomaly_status ON anomaly_flags (status);

-- 9. Pattern Flags
CREATE TABLE IF NOT EXISTS pattern_flags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope text NOT NULL CHECK (scope IN ('athlete', 'team', 'programme', 'organisation')),
  scope_id text NOT NULL,
  type text NOT NULL CHECK (type IN ('repeated_decline', 'repeated_improvement', 'recurring_gap', 'testing_weakness', 'role_strength', 'team_wide_change', 'programme_wide_pattern')),
  description text NOT NULL,
  evidence text NOT NULL,
  sample_size integer NOT NULL DEFAULT 0,
  confidence text NOT NULL CHECK (confidence IN ('high', 'moderate', 'low', 'insufficient')),
  detected_at timestamptz DEFAULT now()
);
ALTER TABLE pattern_flags ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_pattern_flags" ON pattern_flags;
CREATE POLICY "anon_select_pattern_flags" ON pattern_flags FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_pattern_flags" ON pattern_flags;
CREATE POLICY "anon_insert_pattern_flags" ON pattern_flags FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_pattern_flags" ON pattern_flags;
CREATE POLICY "anon_update_pattern_flags" ON pattern_flags FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_pattern_flags" ON pattern_flags;
CREATE POLICY "anon_delete_pattern_flags" ON pattern_flags FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_pattern_scope ON pattern_flags (scope, scope_id);

-- 10. Org Data Quality
CREATE TABLE IF NOT EXISTS org_data_quality (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  overall_score integer NOT NULL DEFAULT 0,
  completeness integer NOT NULL DEFAULT 0,
  recency integer NOT NULL DEFAULT 0,
  consistency integer NOT NULL DEFAULT 0,
  validity integer NOT NULL DEFAULT 0,
  context_availability integer NOT NULL DEFAULT 0,
  issues jsonb NOT NULL DEFAULT '{}',
  recorded_at timestamptz DEFAULT now()
);
ALTER TABLE org_data_quality ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_org_data_quality" ON org_data_quality;
CREATE POLICY "anon_select_org_data_quality" ON org_data_quality FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_org_data_quality" ON org_data_quality;
CREATE POLICY "anon_insert_org_data_quality" ON org_data_quality FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_org_data_quality" ON org_data_quality;
CREATE POLICY "anon_update_org_data_quality" ON org_data_quality FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_org_data_quality" ON org_data_quality;
CREATE POLICY "anon_delete_org_data_quality" ON org_data_quality FOR DELETE TO anon, authenticated USING (true);

-- 11. Attention Items
CREATE TABLE IF NOT EXISTS attention_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL CHECK (type IN ('data_issue', 'overdue_assessment', 'performance_change', 'unresolved_disagreement', 'incomplete_development', 'pending_review')),
  priority text NOT NULL CHECK (priority IN ('high', 'medium', 'low')),
  description text NOT NULL,
  scope text NOT NULL CHECK (scope IN ('athlete', 'team', 'programme', 'organisation')),
  scope_id text NOT NULL,
  scope_name text NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE attention_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_attention_items" ON attention_items;
CREATE POLICY "anon_select_attention_items" ON attention_items FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_attention_items" ON attention_items;
CREATE POLICY "anon_insert_attention_items" ON attention_items FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_attention_items" ON attention_items;
CREATE POLICY "anon_update_attention_items" ON attention_items FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_attention_items" ON attention_items;
CREATE POLICY "anon_delete_attention_items" ON attention_items FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_attention_priority ON attention_items (priority);

-- 12. AI Org Audit Log
CREATE TABLE IF NOT EXISTS ai_org_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  query text NOT NULL,
  response_summary text NOT NULL,
  evidence jsonb NOT NULL DEFAULT '[]',
  limitations text,
  reviewed boolean NOT NULL DEFAULT false,
  reviewed_by text,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE ai_org_audit_log ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_ai_org_audit_log" ON ai_org_audit_log;
CREATE POLICY "anon_select_ai_org_audit_log" ON ai_org_audit_log FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_ai_org_audit_log" ON ai_org_audit_log;
CREATE POLICY "anon_insert_ai_org_audit_log" ON ai_org_audit_log FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_ai_org_audit_log" ON ai_org_audit_log;
CREATE POLICY "anon_update_ai_org_audit_log" ON ai_org_audit_log FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_ai_org_audit_log" ON ai_org_audit_log;
CREATE POLICY "anon_delete_ai_org_audit_log" ON ai_org_audit_log FOR DELETE TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_ai_audit_created ON ai_org_audit_log (created_at);
