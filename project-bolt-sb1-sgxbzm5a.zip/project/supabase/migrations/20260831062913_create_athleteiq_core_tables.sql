/*
# AthleteIQ Core Database Schema

Creates the full database backend for the AthleteIQ performance intelligence platform.
This is a single-tenant application (no sign-in screen), so all tables use
`TO anon, authenticated` policies allowing the anon-key frontend to read and write.

## New Tables

1. **athletes** — Player profiles (name, sport, position, team, age, avatar)
2. **training_sessions** — GPS/training load data per session (distance, HSR, sprint, sRPE, etc.)
3. **match_records** — Match performance data (minutes, distance, HSR, contacts for rugby)
4. **capacity_tests** — Physical test definitions (sprint, jump, aerobic, etc. with benchmark)
5. **capacity_test_history** — Historical results for each capacity test (date, value)
6. **ai_insights** — AI-generated findings with evidence, interpretation, confidence
7. **interventions** — Tracked training interventions with pre/post results
8. **decision_log** — Coach decisions on AI recommendations (accept/modify/reject)
9. **validation_test_results** — Validation Lab test outcomes with review status

## Security

- RLS enabled on every table.
- All policies use `TO anon, authenticated` with `USING (true)` / `WITH CHECK (true)`
  because this is a single-tenant app with no sign-in — data is intentionally shared.
- No user_id columns or auth.uid() references.

## Notes

1. Numeric fields use `double precision` to match the TypeScript `number` type and allow NaN-free storage.
2. Optional fields (contacts, contactLoad, gpsCompleteness, etc.) are nullable.
3. The hrZonePercent JSONB column stores the zone breakdown object.
4. capacity_test_history is a child table linked to capacity_tests via foreign key.
5. validation_test_results stores the Validation Lab output for audit trail and human review.
6. All tables have created_at timestamps for audit purposes.
*/

-- ===== ATHLETES =====
CREATE TABLE IF NOT EXISTS athletes (
  id text PRIMARY KEY,
  name text NOT NULL,
  sport text NOT NULL CHECK (sport IN ('football', 'rugby')),
  position text NOT NULL,
  age integer NOT NULL,
  team text NOT NULL,
  avatar_color text NOT NULL,
  initials text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE athletes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_athletes" ON athletes;
CREATE POLICY "anon_select_athletes" ON athletes FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_athletes" ON athletes;
CREATE POLICY "anon_insert_athletes" ON athletes FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_athletes" ON athletes;
CREATE POLICY "anon_update_athletes" ON athletes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_athletes" ON athletes;
CREATE POLICY "anon_delete_athletes" ON athletes FOR DELETE
  TO anon, authenticated USING (true);

-- ===== TRAINING SESSIONS =====
CREATE TABLE IF NOT EXISTS training_sessions (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  date date NOT NULL,
  type text NOT NULL,
  duration double precision NOT NULL,
  total_distance double precision NOT NULL,
  relative_distance double precision NOT NULL,
  high_speed_running double precision NOT NULL,
  sprint_distance double precision NOT NULL,
  accelerations integer NOT NULL,
  decelerations integer NOT NULL,
  high_intensity_efforts integer NOT NULL,
  player_load double precision NOT NULL,
  avg_heart_rate double precision NOT NULL,
  max_heart_rate double precision NOT NULL,
  hr_zone_percent jsonb,
  session_rpe double precision NOT NULL,
  training_load double precision NOT NULL,
  contacts integer,
  contact_load double precision,
  gps_completeness double precision,
  hr_completeness double precision,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_training_sessions_athlete_id ON training_sessions(athlete_id);
CREATE INDEX IF NOT EXISTS idx_training_sessions_date ON training_sessions(date);

ALTER TABLE training_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_training" ON training_sessions;
CREATE POLICY "anon_select_training" ON training_sessions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_training" ON training_sessions;
CREATE POLICY "anon_insert_training" ON training_sessions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_training" ON training_sessions;
CREATE POLICY "anon_update_training" ON training_sessions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_training" ON training_sessions;
CREATE POLICY "anon_delete_training" ON training_sessions FOR DELETE
  TO anon, authenticated USING (true);

-- ===== MATCH RECORDS =====
CREATE TABLE IF NOT EXISTS match_records (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  date date NOT NULL,
  opponent text NOT NULL,
  duration double precision NOT NULL,
  minutes_played double precision NOT NULL,
  total_distance double precision NOT NULL,
  relative_distance double precision NOT NULL,
  high_speed_running double precision NOT NULL,
  sprint_distance double precision NOT NULL,
  accelerations integer NOT NULL,
  decelerations integer NOT NULL,
  high_intensity_efforts integer NOT NULL,
  avg_heart_rate double precision NOT NULL,
  max_heart_rate double precision NOT NULL,
  session_rpe double precision NOT NULL,
  contacts integer,
  contact_load double precision,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_match_records_athlete_id ON match_records(athlete_id);
CREATE INDEX IF NOT EXISTS idx_match_records_date ON match_records(date);

ALTER TABLE match_records ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_matches" ON match_records;
CREATE POLICY "anon_select_matches" ON match_records FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_matches" ON match_records;
CREATE POLICY "anon_insert_matches" ON match_records FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_matches" ON match_records;
CREATE POLICY "anon_update_matches" ON match_records FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_matches" ON match_records;
CREATE POLICY "anon_delete_matches" ON match_records FOR DELETE
  TO anon, authenticated USING (true);

-- ===== CAPACITY TESTS =====
CREATE TABLE IF NOT EXISTS capacity_tests (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  category text NOT NULL,
  name text NOT NULL,
  unit text NOT NULL,
  baseline double precision NOT NULL,
  latest double precision NOT NULL,
  previous double precision NOT NULL,
  benchmark double precision NOT NULL,
  date date NOT NULL,
  higher_is_better boolean NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_capacity_tests_athlete_id ON capacity_tests(athlete_id);

ALTER TABLE capacity_tests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_capacity" ON capacity_tests;
CREATE POLICY "anon_select_capacity" ON capacity_tests FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_capacity" ON capacity_tests;
CREATE POLICY "anon_insert_capacity" ON capacity_tests FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_capacity" ON capacity_tests;
CREATE POLICY "anon_update_capacity" ON capacity_tests FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_capacity" ON capacity_tests;
CREATE POLICY "anon_delete_capacity" ON capacity_tests FOR DELETE
  TO anon, authenticated USING (true);

-- ===== CAPACITY TEST HISTORY =====
CREATE TABLE IF NOT EXISTS capacity_test_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  capacity_test_id text NOT NULL REFERENCES capacity_tests(id) ON DELETE CASCADE,
  test_date date NOT NULL,
  value double precision NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_capacity_history_test_id ON capacity_test_history(capacity_test_id);
CREATE INDEX IF NOT EXISTS idx_capacity_history_date ON capacity_test_history(test_date);

ALTER TABLE capacity_test_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_cap_history" ON capacity_test_history;
CREATE POLICY "anon_select_cap_history" ON capacity_test_history FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_cap_history" ON capacity_test_history;
CREATE POLICY "anon_insert_cap_history" ON capacity_test_history FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_cap_history" ON capacity_test_history;
CREATE POLICY "anon_update_cap_history" ON capacity_test_history FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_cap_history" ON capacity_test_history;
CREATE POLICY "anon_delete_cap_history" ON capacity_test_history FOR DELETE
  TO anon, authenticated USING (true);

-- ===== AI INSIGHTS =====
CREATE TABLE IF NOT EXISTS ai_insights (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('anomaly', 'trend', 'gap', 'optimization', 'pattern')),
  severity text NOT NULL CHECK (severity IN ('info', 'warning', 'critical', 'positive')),
  finding text NOT NULL,
  evidence text NOT NULL,
  interpretation text NOT NULL,
  action text NOT NULL,
  metric text NOT NULL,
  confidence text NOT NULL CHECK (confidence IN ('Low', 'Moderate', 'High')),
  data_quality text NOT NULL CHECK (data_quality IN ('GOOD', 'PARTIAL', 'POOR')),
  feedback text CHECK (feedback IS NULL OR feedback IN ('accepted', 'modified', 'rejected')),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ai_insights_athlete_id ON ai_insights(athlete_id);

ALTER TABLE ai_insights ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_insights" ON ai_insights;
CREATE POLICY "anon_select_insights" ON ai_insights FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_insights" ON ai_insights;
CREATE POLICY "anon_insert_insights" ON ai_insights FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_insights" ON ai_insights;
CREATE POLICY "anon_update_insights" ON ai_insights FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_insights" ON ai_insights;
CREATE POLICY "anon_delete_insights" ON ai_insights FOR DELETE
  TO anon, authenticated USING (true);

-- ===== INTERVENTIONS =====
CREATE TABLE IF NOT EXISTS interventions (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  objective text NOT NULL,
  metric text NOT NULL,
  start_date date NOT NULL,
  end_date date NOT NULL,
  duration_weeks integer NOT NULL,
  starting_point double precision NOT NULL,
  target double precision NOT NULL,
  current double precision NOT NULL,
  unit text NOT NULL,
  strategy text NOT NULL,
  status text NOT NULL CHECK (status IN ('active', 'completed', 'planned')),
  target_achieved boolean,
  capacity_changed boolean,
  match_performance_changed boolean,
  similarity_improved boolean,
  before_value double precision,
  after_value double precision,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_interventions_athlete_id ON interventions(athlete_id);

ALTER TABLE interventions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_interventions" ON interventions;
CREATE POLICY "anon_select_interventions" ON interventions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_interventions" ON interventions;
CREATE POLICY "anon_insert_interventions" ON interventions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_interventions" ON interventions;
CREATE POLICY "anon_update_interventions" ON interventions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_interventions" ON interventions;
CREATE POLICY "anon_delete_interventions" ON interventions FOR DELETE
  TO anon, authenticated USING (true);

-- ===== DECISION LOG =====
CREATE TABLE IF NOT EXISTS decision_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  athlete_id text REFERENCES athletes(id) ON DELETE SET NULL,
  insight_id text REFERENCES ai_insights(id) ON DELETE SET NULL,
  decision text NOT NULL CHECK (decision IN ('accepted', 'modified', 'rejected')),
  original_recommendation text,
  modified_recommendation text,
  rationale text,
  reviewer text,
  decided_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_decision_log_athlete_id ON decision_log(athlete_id);
CREATE INDEX IF NOT EXISTS idx_decision_log_decided_at ON decision_log(decided_at);

ALTER TABLE decision_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_decisions" ON decision_log;
CREATE POLICY "anon_select_decisions" ON decision_log FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_decisions" ON decision_log;
CREATE POLICY "anon_insert_decisions" ON decision_log FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_decisions" ON decision_log;
CREATE POLICY "anon_update_decisions" ON decision_log FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_decisions" ON decision_log;
CREATE POLICY "anon_delete_decisions" ON decision_log FOR DELETE
  TO anon, authenticated USING (true);

-- ===== VALIDATION TEST RESULTS =====
CREATE TABLE IF NOT EXISTS validation_test_results (
  id text PRIMARY KEY,
  test_id text NOT NULL,
  name text NOT NULL,
  category text NOT NULL,
  sport text NOT NULL,
  position text NOT NULL,
  dataset text NOT NULL,
  input_conditions text NOT NULL,
  expected_behavior text NOT NULL,
  actual_behavior text NOT NULL,
  result text NOT NULL CHECK (result IN ('pass', 'fail', 'warning', 'insufficient', 'n/a')),
  severity text NOT NULL CHECK (severity IN ('critical', 'high', 'medium', 'low', 'informational')),
  error text,
  algorithm_version text NOT NULL,
  notes text,
  review_status text CHECK (review_status IS NULL OR review_status IN ('approved', 'rejected', 'needs_investigation')),
  reviewer text,
  review_comment text,
  reviewed_at timestamptz,
  run_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_validation_category ON validation_test_results(category);
CREATE INDEX IF NOT EXISTS idx_validation_result ON validation_test_results(result);
CREATE INDEX IF NOT EXISTS idx_validation_run_at ON validation_test_results(run_at);

ALTER TABLE validation_test_results ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_validation" ON validation_test_results;
CREATE POLICY "anon_select_validation" ON validation_test_results FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_validation" ON validation_test_results;
CREATE POLICY "anon_insert_validation" ON validation_test_results FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_validation" ON validation_test_results;
CREATE POLICY "anon_update_validation" ON validation_test_results FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_validation" ON validation_test_results;
CREATE POLICY "anon_delete_validation" ON validation_test_results FOR DELETE
  TO anon, authenticated USING (true);
