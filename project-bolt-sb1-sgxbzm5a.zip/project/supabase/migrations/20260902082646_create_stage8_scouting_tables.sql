/*
# AthleteIQ Stage 8 — Scouting, Talent Identification & Recruitment Tables

Creates the database backend for Stage 8 scouting workflows: scouting projects,
target profiles, scout observations, scouting reports, shortlists, watchlists,
recruitment pipeline, and scouting decision audit trail.

Single-tenant app (no sign-in), so all tables use TO anon, authenticated with
USING(true)/WITH CHECK(true).

## New Tables

1. **scouting_projects** — Scouting projects (sport, position, age range, status)
2. **target_profiles** — Recruitment target profiles with weighted criteria (versioned)
3. **scout_observations** — Structured scout observations (technical, tactical, physical, behavioural)
4. **scouting_reports** — Full scouting reports with recommendation
5. **shortlists** — Shortlist entries linking athletes to projects
6. **watchlist** — Watchlist entries for monitoring prospects
7. **recruitment_pipeline** — Multi-stage recruitment pipeline tracking
8. **scouting_decisions** — Decision gate records for scouting actions
9. **saved_scouting_views** — Saved search/filter views for scouts
*/

-- ===== SCOUTING PROJECTS =====
CREATE TABLE IF NOT EXISTS scouting_projects (
  id text PRIMARY KEY,
  name text NOT NULL,
  sport text NOT NULL,
  position text,
  age_min integer,
  age_max integer,
  competition_level text,
  location text,
  description text,
  status text NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'ACTIVE', 'PAUSED', 'COMPLETED', 'ARCHIVED')),
  created_by text NOT NULL DEFAULT 'scout-1',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_scout_projects_status ON scouting_projects(status);
CREATE INDEX IF NOT EXISTS idx_scout_projects_sport ON scouting_projects(sport);

ALTER TABLE scouting_projects ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_scout_projects" ON scouting_projects;
CREATE POLICY "anon_select_scout_projects" ON scouting_projects FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_scout_projects" ON scouting_projects;
CREATE POLICY "anon_insert_scout_projects" ON scouting_projects FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_scout_projects" ON scouting_projects;
CREATE POLICY "anon_update_scout_projects" ON scouting_projects FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_scout_projects" ON scouting_projects;
CREATE POLICY "anon_delete_scout_projects" ON scouting_projects FOR DELETE TO anon, authenticated USING (true);

-- ===== TARGET PROFILES =====
CREATE TABLE IF NOT EXISTS target_profiles (
  id text PRIMARY KEY,
  project_id text NOT NULL REFERENCES scouting_projects(id) ON DELETE CASCADE,
  version text NOT NULL DEFAULT 'v1.0',
  name text NOT NULL,
  criteria jsonb NOT NULL DEFAULT '[]',
  weights jsonb NOT NULL DEFAULT '{}',
  is_active boolean NOT NULL DEFAULT true,
  created_by text NOT NULL DEFAULT 'scout-1',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_target_profiles_project_id ON target_profiles(project_id);

ALTER TABLE target_profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_target_profiles" ON target_profiles;
CREATE POLICY "anon_select_target_profiles" ON target_profiles FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_target_profiles" ON target_profiles;
CREATE POLICY "anon_insert_target_profiles" ON target_profiles FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_target_profiles" ON target_profiles;
CREATE POLICY "anon_update_target_profiles" ON target_profiles FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_target_profiles" ON target_profiles;
CREATE POLICY "anon_delete_target_profiles" ON target_profiles FOR DELETE TO anon, authenticated USING (true);

-- ===== SCOUT OBSERVATIONS =====
CREATE TABLE IF NOT EXISTS scout_observations (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  project_id text REFERENCES scouting_projects(id) ON DELETE SET NULL,
  scout_id text NOT NULL DEFAULT 'scout-1',
  category text NOT NULL CHECK (category IN ('technical', 'tactical', 'physical', 'behavioural')),
  observation text NOT NULL,
  rating integer CHECK (rating >= 1 AND rating <= 10),
  context text,
  opposition_level text,
  conditions text,
  observation_date date NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_scout_obs_athlete_id ON scout_observations(athlete_id);
CREATE INDEX IF NOT EXISTS idx_scout_obs_project_id ON scout_observations(project_id);
CREATE INDEX IF NOT EXISTS idx_scout_obs_category ON scout_observations(category);

ALTER TABLE scout_observations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_scout_obs" ON scout_observations;
CREATE POLICY "anon_select_scout_obs" ON scout_observations FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_scout_obs" ON scout_observations;
CREATE POLICY "anon_insert_scout_obs" ON scout_observations FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_scout_obs" ON scout_observations;
CREATE POLICY "anon_update_scout_obs" ON scout_observations FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_scout_obs" ON scout_observations;
CREATE POLICY "anon_delete_scout_obs" ON scout_observations FOR DELETE TO anon, authenticated USING (true);

-- ===== SCOUTING REPORTS =====
CREATE TABLE IF NOT EXISTS scouting_reports (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  project_id text REFERENCES scouting_projects(id) ON DELETE SET NULL,
  scout_id text NOT NULL DEFAULT 'scout-1',
  context text,
  current_performance text,
  key_strengths text,
  development_areas text,
  tactical_observations text,
  physical_observations text,
  development_trajectory text,
  profile_match text,
  areas_requiring_evidence text,
  recommendation text NOT NULL CHECK (recommendation IN ('RECOMMEND', 'SHORTLIST', 'MONITOR', 'FURTHER_ASSESSMENT', 'DO_NOT_PROGRESS')),
  next_action text,
  ai_generated_draft text,
  ai_generated boolean NOT NULL DEFAULT false,
  approved_by text,
  approved_at timestamptz,
  status text NOT NULL DEFAULT 'DRAFT' CHECK (status IN ('DRAFT', 'SUBMITTED', 'APPROVED', 'ARCHIVED')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_scout_reports_athlete_id ON scouting_reports(athlete_id);
CREATE INDEX IF NOT EXISTS idx_scout_reports_project_id ON scouting_reports(project_id);
CREATE INDEX IF NOT EXISTS idx_scout_reports_recommendation ON scouting_reports(recommendation);

ALTER TABLE scouting_reports ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_scout_reports" ON scouting_reports;
CREATE POLICY "anon_select_scout_reports" ON scouting_reports FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_scout_reports" ON scouting_reports;
CREATE POLICY "anon_insert_scout_reports" ON scouting_reports FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_scout_reports" ON scouting_reports;
CREATE POLICY "anon_update_scout_reports" ON scouting_reports FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_scout_reports" ON scouting_reports;
CREATE POLICY "anon_delete_scout_reports" ON scouting_reports FOR DELETE TO anon, authenticated USING (true);

-- ===== SHORTLISTS =====
CREATE TABLE IF NOT EXISTS shortlists (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  project_id text NOT NULL REFERENCES scouting_projects(id) ON DELETE CASCADE,
  scout_id text NOT NULL DEFAULT 'scout-1',
  evidence_summary text,
  last_observation_date date,
  next_action text,
  review_date date,
  status text NOT NULL DEFAULT 'SHORTLISTED' CHECK (status IN ('SHORTLISTED', 'REMOVED', 'PROMOTED')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_shortlists_athlete_id ON shortlists(athlete_id);
CREATE INDEX IF NOT EXISTS idx_shortlists_project_id ON shortlists(project_id);
CREATE INDEX IF NOT EXISTS idx_shortlists_status ON shortlists(status);

ALTER TABLE shortlists ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_shortlists" ON shortlists;
CREATE POLICY "anon_select_shortlists" ON shortlists FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_shortlists" ON shortlists;
CREATE POLICY "anon_insert_shortlists" ON shortlists FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_shortlists" ON shortlists;
CREATE POLICY "anon_update_shortlists" ON shortlists FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_shortlists" ON shortlists;
CREATE POLICY "anon_delete_shortlists" ON shortlists FOR DELETE TO anon, authenticated USING (true);

-- ===== WATCHLIST =====
CREATE TABLE IF NOT EXISTS watchlist (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  project_id text REFERENCES scouting_projects(id) ON DELETE SET NULL,
  scout_id text NOT NULL DEFAULT 'scout-1',
  reason text,
  status text NOT NULL DEFAULT 'WATCHING' CHECK (status IN ('WATCHING', 'REMOVED', 'PROMOTED')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_watchlist_athlete_id ON watchlist(athlete_id);
CREATE INDEX IF NOT EXISTS idx_watchlist_status ON watchlist(status);

ALTER TABLE watchlist ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_watchlist" ON watchlist;
CREATE POLICY "anon_select_watchlist" ON watchlist FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_watchlist" ON watchlist;
CREATE POLICY "anon_insert_watchlist" ON watchlist FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_watchlist" ON watchlist;
CREATE POLICY "anon_update_watchlist" ON watchlist FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_watchlist" ON watchlist;
CREATE POLICY "anon_delete_watchlist" ON watchlist FOR DELETE TO anon, authenticated USING (true);

-- ===== RECRUITMENT PIPELINE =====
CREATE TABLE IF NOT EXISTS recruitment_pipeline (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  project_id text NOT NULL REFERENCES scouting_projects(id) ON DELETE CASCADE,
  stage text NOT NULL CHECK (stage IN ('IDENTIFIED', 'OBSERVING', 'SHORTLISTED', 'FURTHER_ASSESSMENT', 'SCOUT_REVIEW', 'COACH_REVIEW', 'TRIAL', 'RECRUITMENT_DECISION', 'ONBOARDING')),
  previous_stage text,
  decision_maker text,
  rationale text,
  ai_involved boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_recruit_pipeline_athlete_id ON recruitment_pipeline(athlete_id);
CREATE INDEX IF NOT EXISTS idx_recruit_pipeline_project_id ON recruitment_pipeline(project_id);
CREATE INDEX IF NOT EXISTS idx_recruit_pipeline_stage ON recruitment_pipeline(stage);

ALTER TABLE recruitment_pipeline ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_recruit_pipeline" ON recruitment_pipeline;
CREATE POLICY "anon_select_recruit_pipeline" ON recruitment_pipeline FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_recruit_pipeline" ON recruitment_pipeline;
CREATE POLICY "anon_insert_recruit_pipeline" ON recruitment_pipeline FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_recruit_pipeline" ON recruitment_pipeline;
CREATE POLICY "anon_update_recruit_pipeline" ON recruitment_pipeline FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_recruit_pipeline" ON recruitment_pipeline;
CREATE POLICY "anon_delete_recruit_pipeline" ON recruitment_pipeline FOR DELETE TO anon, authenticated USING (true);

-- ===== SCOUTING DECISIONS =====
CREATE TABLE IF NOT EXISTS scouting_decisions (
  id text PRIMARY KEY,
  athlete_id text NOT NULL REFERENCES athletes(id) ON DELETE CASCADE,
  project_id text REFERENCES scouting_projects(id) ON DELETE SET NULL,
  decision_type text NOT NULL CHECK (decision_type IN ('shortlist', 'watchlist', 'further_assessment', 'trial', 'progress', 'monitor', 'do_not_progress', 'close', 'recruit')),
  decision text NOT NULL CHECK (decision IN ('accepted', 'edited', 'rejected', 'deferred')),
  original_suggestion text,
  final_decision text,
  rationale text,
  decision_maker text NOT NULL DEFAULT 'scout-1',
  ai_involved boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_scout_decisions_athlete_id ON scouting_decisions(athlete_id);
CREATE INDEX IF NOT EXISTS idx_scout_decisions_project_id ON scouting_decisions(project_id);

ALTER TABLE scouting_decisions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_scout_decisions" ON scouting_decisions;
CREATE POLICY "anon_select_scout_decisions" ON scouting_decisions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_scout_decisions" ON scouting_decisions;
CREATE POLICY "anon_insert_scout_decisions" ON scouting_decisions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_scout_decisions" ON scouting_decisions;
CREATE POLICY "anon_update_scout_decisions" ON scouting_decisions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_scout_decisions" ON scouting_decisions;
CREATE POLICY "anon_delete_scout_decisions" ON scouting_decisions FOR DELETE TO anon, authenticated USING (true);

-- ===== SAVED SCOUTING VIEWS =====
CREATE TABLE IF NOT EXISTS saved_scouting_views (
  id text PRIMARY KEY,
  name text NOT NULL,
  scout_id text NOT NULL DEFAULT 'scout-1',
  filters jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_saved_views_scout_id ON saved_scouting_views(scout_id);

ALTER TABLE saved_scouting_views ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "anon_select_saved_views" ON saved_scouting_views;
CREATE POLICY "anon_select_saved_views" ON saved_scouting_views FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_saved_views" ON saved_scouting_views;
CREATE POLICY "anon_insert_saved_views" ON saved_scouting_views FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_saved_views" ON saved_scouting_views;
CREATE POLICY "anon_update_saved_views" ON saved_scouting_views FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_saved_views" ON saved_scouting_views;
CREATE POLICY "anon_delete_saved_views" ON saved_scouting_views FOR DELETE TO anon, authenticated USING (true);